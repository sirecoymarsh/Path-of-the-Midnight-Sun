GS.dataCache['AF397EDA18EDD145F59B4D00BB37193351D2'] = {
    "uid": "AF397EDA18EDD145F59B4D00BB37193351D2",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Genera Dati Armors",
        "type": "data_record",
        "order": 11,
        "category": "commonEvents",
        "id": "AF397EDA18EDD145F59B4D00BB37193351D2",
        "isFolder": false,
        "data": {
            "name": "Genera Dati Armors",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [],
            "commands": [
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "A\nR\nM\nO\nR\nS"
                    },
                    "indent": 0,
                    "uid": "193A9AED40D9A7466F582661CB221DF94A1E",
                    "expanded": true
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "977941CF9FD8F1492F4958D0CA16066D236B",
                                "Graphics/Kath's UI/Inventory Icons/Leather Vest.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "06F6FF7689B08640161ACFA4FD7F4A3AA847"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BB94A95197C1D146D95A6A082FDBF71F55F9",
                            "defaultText": "일상복으로"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "69C1EC325A89724AE63970B4EF414574B4B4",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "977941CF9FD8F1492F4958D0CA16066D236B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D9DB02889571E84CCA69A87500EC8E2617E8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "155D78CC2A0B00460B1BA731403A0EE26B36",
                            "defaultText": "흔히 쓰이는 조끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ABB845AA28DC47498869ABF6FF075DA605A5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "977941CF9FD8F1492F4958D0CA16066D236B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A0E1E5F14CB7F24C0B483D38D4976187FDDC"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BBB6015C55217644CD8955D13A015F2F247C",
                                "Graphics/Kath's UI/Inventory Icons/Leather Vest.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "91BE052E6E678144054A43B856E134A86CFE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "37A186993062794F8E58C139A7D191F36397",
                            "defaultText": "격식 있는 자리에서 입는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9109FF7C01FB244EEC28FA04012A4560EDA5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BBB6015C55217644CD8955D13A015F2F247C",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7841BEBF5967D24989898ED7FE31A589217C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "06581C6449E2644777990761311B21F5A4FC",
                            "defaultText": "평범한 옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C0F0C67B2653D645C07804B0F606C9916D58",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BBB6015C55217644CD8955D13A015F2F247C",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FBE5838A76C04846464996385C2F2BA83C0F"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "ED07A92D1BF738441B792F085F199E68E3D2",
                                "Graphics/Kath's UI/Inventory Icons/Bone Armor.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ED3519823EE7F64C22282687ACFC416B893B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B5B7C638878DD84267889AC1243B0078695C",
                            "defaultText": "끔찍하게 생겼지만"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B96339BF5073A648DD482276BEE0BA6E9968",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "ED07A92D1BF738441B792F085F199E68E3D2",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "47A471CA5B89F740DA1998F80774706BCCD6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A65870233B99614422080B65C90181BFCEE3",
                            "defaultText": "나름 쓸모가 있다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B3B10AB475CE7442A469A5F65D25F5D10CC9",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "ED07A92D1BF738441B792F085F199E68E3D2",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4D6A59D94C0E444BAF6BFF819673B8093C00"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "ED7D96C83A440646365913B3BDE4A087C5E1",
                                "Graphics/Kath's UI/Inventory Icons/Bone Armor.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0D72A7944DFFF3413B683F12E50B128CE59C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FDCE46170DEEC74951496020362D42F4485D",
                            "defaultText": "끔찍하게 생겼지만"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "32E906EA2B2138466C9888F1369C54717148",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "ED7D96C83A440646365913B3BDE4A087C5E1",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "51B5E900300BD94F8F8B8DA467A8F2FE4F81"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9700FC7E486A78439399A3F5A540F51F2629",
                            "defaultText": "제법 튼튼하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A81C2D868505E64FB318BAE2C386285895EB",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "ED7D96C83A440646365913B3BDE4A087C5E1",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2CCE396221FBE34F2829A4A7ED7031D383A8"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BD2733609057A14ACD79BBE710968C4E898A",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Plate.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "45C5E14500F6E6433839C1E91D1D749BD898"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EE59FF7F30ECE24086285B98EC1B672BD42E",
                            "defaultText": "평화로운 시절에는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6B5F8FE78CBDB54A1C58D0A35539EDDD4B16",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BD2733609057A14ACD79BBE710968C4E898A",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2AADA6E896314545151B45C4A7C009C1F831"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F2E2E8E817946242A00BD982A57650D819FE",
                            "defaultText": "식량 보관함으로 쓴다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "681EEBDD1A662348A72AFAA713DDA5FB9B1B",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BD2733609057A14ACD79BBE710968C4E898A",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F3975642788714A2A6B7CE75B86D7B7DE68"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "5FB36869809C4146A26B3B52CC16141F45E5",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Plate.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CBB7EEDC0FD9314D9C78C6A63F696B044D8B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9802F8A52BAB8240CB697B5502E5B56EFD74",
                            "defaultText": "전쟁 중에는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E0EC4DBC3C2C964B7F590FE2B4828389C844",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "5FB36869809C4146A26B3B52CC16141F45E5",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8337B94E75E18645AA599D572A0ACA900A19"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8A703AEB649B9944A74ADB500BDA9CC8E333",
                            "defaultText": "몸을 지켜 준다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2EE90AD51FFE20404148F2726F805DAB4590",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "5FB36869809C4146A26B3B52CC16141F45E5",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B7CC5C847509764DC51B988123D914B21516"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "9E11144D9E18A146655B993045B86ADBC430",
                                "Graphics/Kath's UI/Inventory Icons/Iron Mail.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B3DE1F2C4D622440025B65D8E303B6FBA129"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "94CF79E1598A464927281493014613FD39E8",
                            "defaultText": "철로 만든"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2B90AEFD37B313446B2838068E6C57371CB2",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9E11144D9E18A146655B993045B86ADBC430",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B73A6A86512A634E3D19D042CAEAA0417BD9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3B75AA4557021946D36AEEA1A4A1F081E78A",
                            "defaultText": "표준형 갑옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CEB2EF8615D2054E6079D1223D2C4B390E55",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9E11144D9E18A146655B993045B86ADBC430",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DEDE301506A54946606B91706B123DA1A355"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "3CB934848412F0404639EFA28E35FBDE656D",
                                "Graphics/Kath's UI/Inventory Icons/Iron Mail.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5EFCC71E6A9CB343CD39B3C353E46587F363"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A560551E6FAAF0431A1A5054D4F684E5A42E",
                            "defaultText": "철로 만든"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "544FA3CB0A3C5544E31ABC34DD80F22AA92A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3CB934848412F0404639EFA28E35FBDE656D",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "368C99AB65E6B54E9D690A47BCBBB7CAC2B9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "428135B04FE33248F86BA1D3D5B5685911F9",
                            "defaultText": "강화 갑옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C55F2B9A5F51D5452388B4D56B033E21B842",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3CB934848412F0404639EFA28E35FBDE656D",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8675772498AF874D3168F101F7F096507C6E"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "F8C81C4898DCE843876BC733577752C7889B",
                                "Graphics/Kath's UI/Inventory Icons/Pyro Robe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9F1C70AD2EBBE94B445A4A3492C3E9A8F72C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8D49C32364A1534CE4782C29F4A6EA6997B7",
                            "defaultText": "맞춤 제작한 로브."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2F3BD0BE73712941228B11E55C293550B623",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F8C81C4898DCE843876BC733577752C7889B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B7156CEA49638742607A366640A8754E9B00"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D9A23E9F9FC6164D2D2AA7A79F8791B59362",
                            "defaultText": "화염으로부터 지켜 준다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7688974E6A350748E81A3D8562EFAC5B06ED",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F8C81C4898DCE843876BC733577752C7889B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F991175D7E3E054EFD888B7226C2EE714DCE"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "94F50A453FF4E84ABC2879406036747808B4",
                                "Graphics/Kath's UI/Inventory Icons/Pyro Robe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "40D43190212EA841582AD5F72193E56EB6F0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9290F5CD16C760497D19FAE46DBF1D3F974C",
                            "defaultText": "화염과 번개에"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7B8FBC0D5145494DF43B14D3B6202D2F4C51",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "94F50A453FF4E84ABC2879406036747808B4",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CCB13D172D5E594DD24AB8F7A842B8D0CC11"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A72B9DCC2851C34B364B0D32770251D0131C",
                            "defaultText": "강한 로브."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E4078F7548AE714B8D48BD629BF88D9CB5AA",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "94F50A453FF4E84ABC2879406036747808B4",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "080CC8AA6BFF824612485A15CEA3B4940928"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FF752B72631AE14C6D680FE28993B7292306",
                                "Graphics/Kath's UI/Inventory Icons/Polar Vest.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4E873A4269B1D1446538FFB5CED01F260C79"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "CF3B20142631C8458B4B0963B7A72925FFB8",
                            "defaultText": "맞춤 제작한 조끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9B897F7C4455194C864842784389FF6E8587",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FF752B72631AE14C6D680FE28993B7292306",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F409C36170EB964B2C9A54B61090E0093C53"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "52614F6B617D474C225A8365BE5DA2C34EAE",
                            "defaultText": "얼음으로부터 지켜 준다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2CA4C7A984C5E143C18B1944E546C1FE14A0",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FF752B72631AE14C6D680FE28993B7292306",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AA160F1D7B1B1246BE9AD51777AB3D5EBF52"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "2CB12D870B8DB748F44AF9E5FE285D2FE79F",
                                "Graphics/Kath's UI/Inventory Icons/Polar Vest.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6FBA65516DD6434C7738AA66A9ED025BF0F5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E7F592E915667443B81A2B345880F5763742",
                            "defaultText": "얼음과 바람에"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CF3276A68BCCF14D4B198D56CA2F41223448",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "2CB12D870B8DB748F44AF9E5FE285D2FE79F",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D9D40E852B6404457E2AFF61997C8FC806B9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0401C02A1745574E551BE0B738E09FDC67FA",
                            "defaultText": "강한 조끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F84DC35431150443DD4BC07170A5AB3B729A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "2CB12D870B8DB748F44AF9E5FE285D2FE79F",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "51677BCB679BA541520BBB43892B46586F7C"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "0C2828D75605484A88194940BE3D6A188DFC",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Armor.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1257EC97523708413B79305569BD1F2AC9F1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C10299E6640991499C3AF6C6DA6D68F037C5",
                            "defaultText": "미스릴로 만든"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DB5A917A61B66844B74B4EE7921590DD8127",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0C2828D75605484A88194940BE3D6A188DFC",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "45EAFBD752061749336B53776DF915D891CB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8233CAC306E6974B849B7DC77D5C040279DA",
                            "defaultText": "보기 드문 갑옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3CEFD49E118D5841DB1AC877A2924DDB7E32",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0C2828D75605484A88194940BE3D6A188DFC",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6BCD419768E4B64F6F4B76328B3B9AE30478"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "B38B5FD91AAD444B7B7B03B087A7B5F3C77E",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Armor.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "917E100C624E4848E129CA08FA62A9B3AB6A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "211978663AA5994FF919BF0423F2F659D0F0",
                            "defaultText": "미스릴로 만든"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F4BD55F622EB443F59A9995AFA8A5F244FB",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "B38B5FD91AAD444B7B7B03B087A7B5F3C77E",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D5AA4115737F074CDC6883A78DAA16028BDC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A584FCFE41F0B24C83983F3870BCEBC4E14A",
                            "defaultText": "강화 갑옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "755FA67E14D5C342C02AF592DFA36C4A351F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "B38B5FD91AAD444B7B7B03B087A7B5F3C77E",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "72436BBC6D2BC14EBF28F725875DFC214598"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FE52091C103372417B5A2B554F34DF841BA6",
                                "Graphics/Kath's UI/Inventory Icons/Luminous Coat.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B6584455720D444D0B2AE233AA0C2447B694"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0B75DE242F9BA84D5B382842615EEFB107F2",
                            "defaultText": "그림자 공격을 막아 주는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "12C23DF05D95714F722B711588A138E96D51",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FE52091C103372417B5A2B554F34DF841BA6",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E930E0CD760446441A3B6435E677FA4BBE72"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E7391F1C2465764C5A188E72AEA2F74DBA03",
                            "defaultText": "희귀한 외투."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E042CB9171C4794967087916CD97E901C4DE",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FE52091C103372417B5A2B554F34DF841BA6",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8B94F578120F8746568802D12181497B967D"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BEEC715317584849E83919E6573D255023AC",
                                "Graphics/Kath's UI/Inventory Icons/Luminous Coat.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ED3A9F712FC9F4488E69C6B73D52A0C49515"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "76E43A7114D4A84EEE7AB497040A0202D1E5",
                            "defaultText": "빛과 그림자에 강한"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6C7B4FEB8A4F43492B489312FDF3A395B7E0",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BEEC715317584849E83919E6573D255023AC",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "64FAB3C08CD1A345771B0D175E0C529A924B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4E122FDC14D0F9431A2AB18551F3A1146BB9",
                            "defaultText": "희귀한 외투."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3C366DDA74E674450E29E075A168C4F23FE3",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BEEC715317584849E83919E6573D255023AC",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "339241B418F5264F835AB9E14875EC56636D"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "09DAB5FD82B1C144528AEA61B1E28D2AC3D6",
                                "Graphics/Kath's UI/Inventory Icons/Valon Mail.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8053B9352A6F3842A8385B8772B106C1DB88"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D291144B5EA67349318837D8669B95CF6A60",
                            "defaultText": "신성한 힘을 품은"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D4622D0701D2A541A28AC21868CAB7638342",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "09DAB5FD82B1C144528AEA61B1E28D2AC3D6",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8E39819F2FA6F345441B8797BA0589B08177"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "70A92C650CAD944F727B55A1B42DA0799D8F",
                            "defaultText": "전설의 갑옷."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1239F48353B5F846091A00C292F8217B9860",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "09DAB5FD82B1C144528AEA61B1E28D2AC3D6",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6B31C28569E2F04F9E2AD5B6491B567514D6"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "93C85E773CB8264AB008F7400D52A2411177",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Plate.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E61B571A4045F348EF4ADE7372BA07C026C7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BE484FBC2C4E3940920B00D85DEC73919099",
                            "defaultText": "평범해 보이지만,"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4686F95E1E9E6447934841075376B1E44A7B",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "93C85E773CB8264AB008F7400D52A2411177",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C3AA528F5053804AEF88F764B7D8619D4B16"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B904795326DA5045AF59E10477298EBA9D43",
                            "defaultText": "사실... 하이퍼다!!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3E5DE5E025E7C74BA758BCE9610C97A94239",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "93C85E773CB8264AB008F7400D52A2411177",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "97D8EBDA95DB974C1838ABC9A144EF177F45"
                }
            ],
            "index": "AF397EDA18EDD145F59B4D00BB37193351D2",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "Desc 1",
                    "index": 0,
                    "scope": 0
                },
                {
                    "name": "Desc 2",
                    "index": 1,
                    "scope": 1
                },
                {
                    "name": "Desc 3",
                    "index": 2,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "BE484FBC2C4E3940920B00D85DEC73919099": {
                "t": "IT SEEMS NORMAL,",
                "d": {
                    "eid": "4686F95E1E9E6447934841075376B1E44A7B"
                }
            },
            "B904795326DA5045AF59E10477298EBA9D43": {
                "t": "BUT IT'S... HYPER!!",
                "d": {
                    "eid": "3E5DE5E025E7C74BA758BCE9610C97A94239"
                }
            },
            "BB94A95197C1D146D95A6A082FDBF71F55F9": {
                "t": "Commonly used",
                "d": {
                    "eid": "69C1EC325A89724AE63970B4EF414574B4B4"
                }
            },
            "155D78CC2A0B00460B1BA731403A0EE26B36": {
                "t": "in everyday life.",
                "d": {
                    "eid": "ABB845AA28DC47498869ABF6FF075DA605A5"
                }
            },
            "37A186993062794F8E58C139A7D191F36397": {
                "t": "Common clothes",
                "d": {
                    "eid": "9109FF7C01FB244EEC28FA04012A4560EDA5"
                }
            },
            "06581C6449E2644777990761311B21F5A4FC": {
                "t": "for fancy occasions.",
                "d": {
                    "eid": "C0F0C67B2653D645C07804B0F606C9916D58"
                }
            },
            "B5B7C638878DD84267889AC1243B0078695C": {
                "t": "Looks horrifying,",
                "d": {
                    "eid": "B96339BF5073A648DD482276BEE0BA6E9968"
                }
            },
            "A65870233B99614422080B65C90181BFCEE3": {
                "t": "but has its uses.",
                "d": {
                    "eid": "B3B10AB475CE7442A469A5F65D25F5D10CC9"
                }
            },
            "FDCE46170DEEC74951496020362D42F4485D": {
                "t": "Looks horrifying,",
                "d": {
                    "eid": "32E906EA2B2138466C9888F1369C54717148"
                }
            },
            "9700FC7E486A78439399A3F5A540F51F2629": {
                "t": "but it's sturdy.",
                "d": {
                    "eid": "A81C2D868505E64FB318BAE2C386285895EB"
                }
            },
            "EE59FF7F30ECE24086285B98EC1B672BD42E": {
                "t": "Used to store food",
                "d": {
                    "eid": "6B5F8FE78CBDB54A1C58D0A35539EDDD4B16"
                }
            },
            "F2E2E8E817946242A00BD982A57650D819FE": {
                "t": "in times of peace.",
                "d": {
                    "eid": "681EEBDD1A662348A72AFAA713DDA5FB9B1B"
                }
            },
            "9802F8A52BAB8240CB697B5502E5B56EFD74": {
                "t": "Offers protection",
                "d": {
                    "eid": "E0EC4DBC3C2C964B7F590FE2B4828389C844"
                }
            },
            "8A703AEB649B9944A74ADB500BDA9CC8E333": {
                "t": "during wartime.",
                "d": {
                    "eid": "2EE90AD51FFE20404148F2726F805DAB4590"
                }
            },
            "94CF79E1598A464927281493014613FD39E8": {
                "t": "Standard armor",
                "d": {
                    "eid": "2B90AEFD37B313446B2838068E6C57371CB2"
                }
            },
            "3B75AA4557021946D36AEEA1A4A1F081E78A": {
                "t": "made of iron.",
                "d": {
                    "eid": "CEB2EF8615D2054E6079D1223D2C4B390E55"
                }
            },
            "A560551E6FAAF0431A1A5054D4F684E5A42E": {
                "t": "Reinforced armor",
                "d": {
                    "eid": "544FA3CB0A3C5544E31ABC34DD80F22AA92A"
                }
            },
            "428135B04FE33248F86BA1D3D5B5685911F9": {
                "t": "made of iron.",
                "d": {
                    "eid": "C55F2B9A5F51D5452388B4D56B033E21B842"
                }
            },
            "8D49C32364A1534CE4782C29F4A6EA6997B7": {
                "t": "Tailor-made robe,",
                "d": {
                    "eid": "2F3BD0BE73712941228B11E55C293550B623"
                }
            },
            "D9A23E9F9FC6164D2D2AA7A79F8791B59362": {
                "t": "protects from Fire.",
                "d": {
                    "eid": "7688974E6A350748E81A3D8562EFAC5B06ED"
                }
            },
            "9290F5CD16C760497D19FAE46DBF1D3F974C": {
                "t": "A robe useful against",
                "d": {
                    "eid": "7B8FBC0D5145494DF43B14D3B6202D2F4C51"
                }
            },
            "A72B9DCC2851C34B364B0D32770251D0131C": {
                "t": "Fire and Thunder.",
                "d": {
                    "eid": "E4078F7548AE714B8D48BD629BF88D9CB5AA"
                }
            },
            "CF3B20142631C8458B4B0963B7A72925FFB8": {
                "t": "Tailor-made robe,",
                "d": {
                    "eid": "9B897F7C4455194C864842784389FF6E8587"
                }
            },
            "52614F6B617D474C225A8365BE5DA2C34EAE": {
                "t": "protects from Ice.",
                "d": {
                    "eid": "2CA4C7A984C5E143C18B1944E546C1FE14A0"
                }
            },
            "E7F592E915667443B81A2B345880F5763742": {
                "t": "It protects from",
                "d": {
                    "eid": "CF3276A68BCCF14D4B198D56CA2F41223448"
                }
            },
            "0401C02A1745574E551BE0B738E09FDC67FA": {
                "t": "Ice and Wind.",
                "d": {
                    "eid": "F84DC35431150443DD4BC07170A5AB3B729A"
                }
            },
            "C10299E6640991499C3AF6C6DA6D68F037C5": {
                "t": "An uncommon armor",
                "d": {
                    "eid": "DB5A917A61B66844B74B4EE7921590DD8127"
                }
            },
            "8233CAC306E6974B849B7DC77D5C040279DA": {
                "t": "made of mythril.",
                "d": {
                    "eid": "3CEFD49E118D5841DB1AC877A2924DDB7E32"
                }
            },
            "211978663AA5994FF919BF0423F2F659D0F0": {
                "t": "A reinforced armor",
                "d": {
                    "eid": "5F4BD55F622EB443F59A9995AFA8A5F244FB"
                }
            },
            "A584FCFE41F0B24C83983F3870BCEBC4E14A": {
                "t": "made of mythril.",
                "d": {
                    "eid": "755FA67E14D5C342C02AF592DFA36C4A351F"
                }
            },
            "0B75DE242F9BA84D5B382842615EEFB107F2": {
                "t": "A rare garb that",
                "d": {
                    "eid": "12C23DF05D95714F722B711588A138E96D51"
                }
            },
            "E7391F1C2465764C5A188E72AEA2F74DBA03": {
                "t": "deflects Shadow.",
                "d": {
                    "eid": "E042CB9171C4794967087916CD97E901C4DE"
                }
            },
            "76E43A7114D4A84EEE7AB497040A0202D1E5": {
                "t": "Rare garb, strong vs.",
                "d": {
                    "eid": "6C7B4FEB8A4F43492B489312FDF3A395B7E0"
                }
            },
            "4E122FDC14D0F9431A2AB18551F3A1146BB9": {
                "t": "Light and Shadow.",
                "d": {
                    "eid": "3C366DDA74E674450E29E075A168C4F23FE3"
                }
            },
            "D291144B5EA67349318837D8669B95CF6A60": {
                "t": "Legendary armor",
                "d": {
                    "eid": "D4622D0701D2A541A28AC21868CAB7638342"
                }
            },
            "70A92C650CAD944F727B55A1B42DA0799D8F": {
                "t": "with divine properties.",
                "d": {
                    "eid": "1239F48353B5F846091A00C292F8217B9860"
                }
            }
        },
        "parentId": "8A7A025317CD78422148C8F665F1528EFA9E"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}