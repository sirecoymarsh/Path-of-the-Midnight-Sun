param(
    [Parameter(Mandatory = $true)][string]$PackageDir,
    [Parameter(Mandatory = $true)][string]$GameDataDir,
    [Parameter(Mandatory = $true)][string]$BackupRoot
)

$ErrorActionPreference = 'Stop'

$ExpectedSemanticManifestSha256 = 'A29BB8B8DB0683F5AFE3A12DEFEB64CBABB45EF6402C6AC90CBBB917E979DCBB'
$ExpectedInstallManifestSha256 = '957A4715373C0C6E668872E0C567050AB03111E3F015A7DD11DD53099B5B8746'
$ExpectedTranslationMapSha256 = '12EFA0C94A93417AF104530A8FE74F1086D5E3DEA6C5D3185FB9F2F0021C2754'
$ExpectedLanguageQaSha256 = '499C414B73F362BBB9C3E2562D3200F2C4BDF25136D98603B7A95ED6E48A0B88'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}

function Install-Atomic([string]$Source, [string]$Target, [string]$ExpectedSourceHash, [string]$ExpectedCurrentHash) {
    $parent = [System.IO.Path]::GetDirectoryName($Target)
    $temp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_tmp_' + [Guid]::NewGuid().ToString('N'))
    $replaceBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_replace_backup_' + [Guid]::NewGuid().ToString('N'))
    $recoveryTemp = $null
    $failedReplacementBackup = $null
    $preserveRecoveryArtifacts = $false
    try {
        if ((Get-Sha256 $Target) -ne $ExpectedCurrentHash) { throw "Target changed immediately before replace: $Target" }
        [System.IO.File]::Copy($Source, $temp, $true)
        if ((Get-Sha256 $temp) -ne $ExpectedSourceHash) { throw "Temporary file hash mismatch: $Target" }
        [System.IO.File]::Replace($temp, $Target, $replaceBackup, $true)
        if ((Get-Sha256 $Target) -ne $ExpectedSourceHash) {
            if ((Test-Path -LiteralPath $replaceBackup -PathType Leaf) -and (Get-Sha256 $replaceBackup) -eq $ExpectedCurrentHash) {
                $recoveryTemp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_recovery_tmp_' + [Guid]::NewGuid().ToString('N'))
                $failedReplacementBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_failed_replace_' + [Guid]::NewGuid().ToString('N'))
                [System.IO.File]::Copy($replaceBackup, $recoveryTemp, $false)
                [System.IO.File]::Replace($recoveryTemp, $Target, $failedReplacementBackup, $true)
                if ((Get-Sha256 $Target) -eq $ExpectedCurrentHash) {
                    throw "Atomic replace post-hash mismatch; previous target was restored: $Target"
                }
            }
            $preserveRecoveryArtifacts = $true
            throw "Atomic replace post-hash mismatch and automatic recovery was not verified: $Target"
        }
    }
    finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        if ($null -ne $recoveryTemp -and (Test-Path -LiteralPath $recoveryTemp)) { Remove-Item -LiteralPath $recoveryTemp -Force -ErrorAction SilentlyContinue }
        $targetHasKnownHash = $false
        try {
            $targetHash = Get-Sha256 $Target
            $targetHasKnownHash = ($targetHash -eq $ExpectedSourceHash -or $targetHash -eq $ExpectedCurrentHash)
        }
        catch { $targetHasKnownHash = $false }
        if ($preserveRecoveryArtifacts -or -not $targetHasKnownHash) {
            if (Test-Path -LiteralPath $replaceBackup) { Write-Warning "Preserved atomic recovery file: $replaceBackup" }
            if ($null -ne $failedReplacementBackup -and (Test-Path -LiteralPath $failedReplacementBackup)) { Write-Warning "Preserved failed replacement file: $failedReplacementBackup" }
        }
        else {
            if (Test-Path -LiteralPath $replaceBackup) { Remove-Item -LiteralPath $replaceBackup -Force }
            if ($null -ne $failedReplacementBackup -and (Test-Path -LiteralPath $failedReplacementBackup)) { Remove-Item -LiteralPath $failedReplacementBackup -Force }
        }
    }
}

function Assert-GameDataPath([string]$ResolvedPath) {
    $dir = [System.IO.DirectoryInfo]::new($ResolvedPath)
    foreach ($name in @('data', 'app', 'resources', 'Path of the Midnight Sun')) {
        if ($null -eq $dir -or -not $dir.Name.Equals($name, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Unexpected game data directory: $ResolvedPath"
        }
        $dir = $dir.Parent
    }
}

function Test-IsSameOrChildPath([string]$CandidatePath, [string]$ParentPath) {
    $separators = [char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    $candidate = [System.IO.Path]::GetFullPath($CandidatePath).TrimEnd($separators)
    $parent = [System.IO.Path]::GetFullPath($ParentPath).TrimEnd($separators)
    if ($candidate.Equals($parent, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $candidate.StartsWith($parent + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}

function Assert-GameStopped() {
    $running = @(Get-Process -Name 'Game' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        $processIds = @($running | ForEach-Object { $_.Id }) -join ', '
        throw "Game.exe is running (PID: $processIds). Close the game before installing the patch."
    }
}

function Assert-ManifestBinding($InstallManifest, $SemanticManifest) {
    foreach ($field in @('total_files', 'total_items', 'total_descriptions', 'total_assignment_fixes')) {
        if ([int]$InstallManifest.$field -ne [int]$SemanticManifest.$field) {
            throw "Install/semantic manifest total mismatch: $field"
        }
    }
    if ([string]$InstallManifest.created_at -ne [string]$SemanticManifest.created_at) {
        throw 'Install/semantic manifest creation timestamp mismatch.'
    }
    foreach ($field in @('original_baseline_sha256', 'translation_map_sha256', 'final_language_qa_sha256', 'safety_audit_sha256', 'language_qa_status', 'crossreview_corrections')) {
        if ([string]$InstallManifest.provenance.$field -ne [string]$SemanticManifest.provenance.$field) {
            throw "Install/semantic manifest provenance mismatch: $field"
        }
    }

    $installFiles = @($InstallManifest.files)
    $semanticFiles = @($SemanticManifest.files)
    if ($installFiles.Count -ne $semanticFiles.Count) { throw 'Install/semantic manifest file count mismatch.' }
    $semanticByName = @{}
    foreach ($entry in $semanticFiles) {
        $name = [string]$entry.filename
        if ($semanticByName.ContainsKey($name)) { throw "Semantic manifest contains duplicate filename: $name" }
        $semanticByName[$name] = $entry
    }
    foreach ($entry in $installFiles) {
        $name = [string]$entry.filename
        if (-not $semanticByName.ContainsKey($name)) { throw "Install manifest file missing from semantic manifest: $name" }
        $semanticEntry = $semanticByName[$name]
        foreach ($field in @('current_sha256', 'fixed_sha256')) {
            if (-not ([string]$entry.$field).Equals([string]$semanticEntry.$field, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Install/semantic manifest hash mismatch for $name`: $field"
            }
        }
        foreach ($field in @('descriptions', 'items', 'assignment_fixes')) {
            if ([int]$entry.$field -ne [int]$semanticEntry.$field) {
                throw "Install/semantic manifest count mismatch for $name`: $field"
            }
        }
        if (@($semanticEntry.changes).Count -ne [int]$entry.descriptions) {
            throw "Semantic description-list count mismatch: $name"
        }
        if (@($semanticEntry.assignment_changes).Count -ne [int]$entry.assignment_fixes) {
            throw "Semantic assignment-list count mismatch: $name"
        }
    }
}

$ExpectedFiles = @(
    '41CBED6F8786674A7378E12460C9D1048AE9.json.js',
    '5D77860A40DEA14D006A7B84567F8E48F035.json.js',
    '63CBFF694B300540D51B6EF7C54CFCAE65F8.json.js',
    '6B404F6014C1D644FF491FA77838BC0B8A54.json.js',
    '7C2EE73472D001426498205105734B41E32B.json.js',
    '7C550F5815B42142530BAAB7872310C75643.json.js',
    'AF397EDA18EDD145F59B4D00BB37193351D2.json.js',
    'C0DA75809B5B644024290C22C69B1F0AEDAA.json.js',
    'CC252A043238154CF30A8B365C570C7918F2.json.js',
    'DED5468F8AC8C746CC39999179146FDA82F9.json.js',
    'E7C324D26C5CE349846A5F2459608AEAA70F.json.js',
    'FB98203B89D57842D30B8D07EFDF5D2F98DB.json.js'
)

$packageResolved = (Resolve-Path -LiteralPath $PackageDir).Path
$gameResolved = (Resolve-Path -LiteralPath $GameDataDir).Path
$backupRootResolved = (Resolve-Path -LiteralPath $BackupRoot).Path
Assert-GameDataPath $gameResolved
if (Test-IsSameOrChildPath $backupRootResolved $gameResolved) { throw 'BackupRoot must be outside GameDataDir.' }
if (Test-IsSameOrChildPath $backupRootResolved $packageResolved) { throw 'BackupRoot must be outside PackageDir.' }

$manifestPath = Join-Path $packageResolved 'install_manifest.json'
$semanticManifestPath = Join-Path $packageResolved 'manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf) -or -not (Test-Path -LiteralPath $semanticManifestPath -PathType Leaf)) {
    throw 'Package install/semantic manifest is missing.'
}
$manifestHash = Get-Sha256 $manifestPath
$semanticManifestHash = Get-Sha256 $semanticManifestPath
if ($manifestHash -ne $ExpectedInstallManifestSha256) { throw 'Package install manifest does not match the approved release.' }
if ($semanticManifestHash -ne $ExpectedSemanticManifestSha256) { throw 'Package semantic manifest does not match the approved release.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$semanticManifest = Get-Content -LiteralPath $semanticManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-ManifestBinding $manifest $semanticManifest
$files = @($manifest.files)
if ($files.Count -ne [int]$manifest.total_files -or $files.Count -ne 12) { throw 'Package manifest file count mismatch.' }
if ([int]$manifest.total_items -ne 181 -or [int]$manifest.total_descriptions -ne 392 -or [int]$manifest.total_assignment_fixes -ne 2) { throw 'Package manifest item/description/fix totals mismatch.' }
if (@($files.filename | Sort-Object -Unique).Count -ne $files.Count) { throw 'Package manifest contains duplicate filenames.' }
if (($files | Measure-Object -Property descriptions -Sum).Sum -ne [int]$manifest.total_descriptions) { throw 'Package description count mismatch.' }
if (($files | Measure-Object -Property assignment_fixes -Sum).Sum -ne [int]$manifest.total_assignment_fixes) { throw 'Package assignment-fix count mismatch.' }
$manifestNames = @($files | ForEach-Object { [string]$_.filename } | Sort-Object)
$expectedNames = @($ExpectedFiles | Sort-Object)
if ((Compare-Object -ReferenceObject $expectedNames -DifferenceObject $manifestNames).Count -ne 0) { throw 'Package file allowlist mismatch.' }
$translationMapPath = Join-Path $packageResolved 'translation_map.json'
$languageQaPath = Join-Path $packageResolved 'final_language_qa.json'
if (-not (Test-Path -LiteralPath $translationMapPath -PathType Leaf) -or -not (Test-Path -LiteralPath $languageQaPath -PathType Leaf)) { throw 'Package provenance files are missing.' }
if (([string]$manifest.provenance.translation_map_sha256).ToUpperInvariant() -ne $ExpectedTranslationMapSha256) { throw 'Manifest translation-map release hash mismatch.' }
if (([string]$manifest.provenance.final_language_qa_sha256).ToUpperInvariant() -ne $ExpectedLanguageQaSha256) { throw 'Manifest language-QA release hash mismatch.' }
if ((Get-Sha256 $translationMapPath) -ne $ExpectedTranslationMapSha256) { throw 'Translation-map provenance hash mismatch.' }
if ((Get-Sha256 $languageQaPath) -ne $ExpectedLanguageQaSha256) { throw 'Language-QA provenance hash mismatch.' }
if ([string]$manifest.provenance.language_qa_status -ne 'pass' -or [int]$manifest.provenance.crossreview_corrections -ne 38) { throw 'Package provenance status mismatch.' }

# Full preflight before any write.
foreach ($entry in $files) {
    $name = [string]$entry.filename
    if ([System.IO.Path]::GetFileName($name) -ne $name) { throw "Unsafe manifest filename: $name" }
    $source = Join-Path $packageResolved $name
    $target = Join-Path $gameResolved $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Package file missing: $name" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Game file missing: $name" }
    if ((Get-Sha256 $source) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Package hash mismatch: $name" }
    if ((Get-Sha256 $target) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Live game hash changed: $name" }
}

Assert-GameStopped

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $backupRootResolved ("item_descriptions_" + $stamp)
if (Test-Path -LiteralPath $backupDir) { throw "Backup directory already exists: $backupDir" }
New-Item -ItemType Directory -Path $backupDir | Out-Null
if ((Get-Sha256 $manifestPath) -ne $manifestHash) { throw 'Package manifest changed after validation.' }
if ((Get-Sha256 $semanticManifestPath) -ne $semanticManifestHash) { throw 'Package semantic manifest changed after validation.' }
Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $backupDir 'patch_manifest.json')
if ((Get-Sha256 (Join-Path $backupDir 'patch_manifest.json')) -ne $manifestHash) { throw 'Backed-up manifest hash mismatch.' }
Copy-Item -LiteralPath $semanticManifestPath -Destination (Join-Path $backupDir 'semantic_manifest.json')
if ((Get-Sha256 (Join-Path $backupDir 'semantic_manifest.json')) -ne $ExpectedSemanticManifestSha256) { throw 'Backed-up semantic manifest hash mismatch.' }
$patchedBackupDir = Join-Path $backupDir 'patched'
New-Item -ItemType Directory -Path $patchedBackupDir | Out-Null

foreach ($entry in $files) {
    $name = [string]$entry.filename
    $target = Join-Path $gameResolved $name
    $backup = Join-Path $backupDir $name
    [System.IO.File]::Copy($target, $backup, $false)
    if ((Get-Sha256 $backup) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Backup verification failed: $name" }
    $patchedBackup = Join-Path $patchedBackupDir $name
    [System.IO.File]::Copy((Join-Path $packageResolved $name), $patchedBackup, $false)
    if ((Get-Sha256 $patchedBackup) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Patched recovery snapshot failed: $name" }
}

Assert-GameStopped

$journalPath = Join-Path $backupDir 'install_journal.json'
$completed = New-Object System.Collections.Generic.List[string]
[ordered]@{ status = 'prepared'; updated_at = (Get-Date).ToString('o'); completed_files = @() } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $journalPath -Encoding UTF8
try {
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        Install-Atomic -Source (Join-Path $packageResolved $name) -Target (Join-Path $gameResolved $name) -ExpectedSourceHash ([string]$entry.fixed_sha256).ToUpperInvariant() -ExpectedCurrentHash ([string]$entry.current_sha256).ToUpperInvariant()
        $completed.Add($name)
        [ordered]@{ status = 'installing'; updated_at = (Get-Date).ToString('o'); completed_files = @($completed) } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $journalPath -Encoding UTF8
    }
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        if ((Get-Sha256 (Join-Path $gameResolved $name)) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Post-install verification failed: $name" }
    }
}
catch {
    $installError = $_.Exception.Message
    $rollbackErrors = New-Object System.Collections.Generic.List[string]
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        try {
            $target = Join-Path $gameResolved $name
            $targetHash = Get-Sha256 $target
            $currentHash = ([string]$entry.current_sha256).ToUpperInvariant()
            $fixedHash = ([string]$entry.fixed_sha256).ToUpperInvariant()
            if ($targetHash -eq $fixedHash) {
                Install-Atomic -Source (Join-Path $backupDir $name) -Target $target -ExpectedSourceHash $currentHash -ExpectedCurrentHash $fixedHash
            }
            elseif ($targetHash -ne $currentHash) {
                Install-Atomic -Source (Join-Path $backupDir $name) -Target $target -ExpectedSourceHash $currentHash -ExpectedCurrentHash $targetHash
            }
        }
        catch { $rollbackErrors.Add("$name`: $($_.Exception.Message)") }
    }
    if ($rollbackErrors.Count -gt 0) {
        [ordered]@{ status = 'rollback_incomplete'; updated_at = (Get-Date).ToString('o'); error = $installError; rollback_errors = @($rollbackErrors); completed_files = @($completed) } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $journalPath -Encoding UTF8
        throw "Installation failed and rollback was incomplete: $installError | $($rollbackErrors -join ' | ')"
    }
    [ordered]@{ status = 'rolled_back'; updated_at = (Get-Date).ToString('o'); error = $installError; completed_files = @($completed) } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $journalPath -Encoding UTF8
    throw "Installation rolled back: $installError"
}

[ordered]@{ status = 'installed'; updated_at = (Get-Date).ToString('o'); completed_files = @($completed) } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $journalPath -Encoding UTF8

$result = [ordered]@{
    status = 'installed'
    installed_at = (Get-Date).ToString('o')
    game_data_dir = $gameResolved
    package_dir = $packageResolved
    backup_dir = $backupDir
    files = $files.Count
    items = [int]$manifest.total_items
    descriptions = [int]$manifest.total_descriptions
    assignment_fixes = [int]$manifest.total_assignment_fixes
}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backupDir 'install_result.json') -Encoding UTF8
$result | ConvertTo-Json -Depth 5
