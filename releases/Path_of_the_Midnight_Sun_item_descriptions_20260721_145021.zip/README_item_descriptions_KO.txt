Path of the Midnight Sun 한국어 아이템 설명 패치
=================================================

범위
----
- 아이템 설명 블록 181개, 런타임 설명 문자열 392줄
- 소비품, 음식, 재료, 검, 도끼, 활, 방패, 갑옷, 투구, 장신구, 마나드롭, 중요 아이템
- Rubber Band(고무줄) 설명이 Storm Pendant(폭풍 펜던트)에 잘못 복사되던 원본 대상-ID 오류 2건 수정
- 대사/선택지/장소 이동/인명 런타임 수정은 건드리지 않음

설치
----
1. 게임을 완전히 종료합니다.
2. 이 ZIP을 원하는 폴더에 풉니다.
3. 압축을 푼 패치 폴더 바깥에 백업용 빈 폴더를 하나 만듭니다.
4. PowerShell에서 압축을 푼 폴더로 이동한 뒤 실행합니다.

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install_item_descriptions.ps1 `
    -PackageDir . `
    -GameDataDir "P:\SteamLibrary\steamapps\common\Path of the Midnight Sun\resources\app\data" `
    -BackupRoot "..\PathMidnightSun_Backups"

설치기는 쓰기 전에 12개 원본 파일과 패치 파일의 SHA-256을 모두 검사합니다.
백업 폴더는 게임 data 폴더와 압축을 푼 패치 폴더 바깥에 있어야 합니다.
게임 파일이 예상 버전과 다르면 아무것도 쓰지 않고 중단합니다.
설치가 성공하면 출력된 backup_dir 경로를 보관하세요.

복원
----
게임을 종료한 뒤 다음 명령을 실행합니다.

  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\restore_item_descriptions.ps1 `
    -BackupDir "설치 때 출력된 backup_dir" `
    -GameDataDir "P:\SteamLibrary\steamapps\common\Path of the Midnight Sun\resources\app\data"

설치 또는 복원이 중간에 끊겨 원본/패치본이 섞여도, backup_dir의 복원 스크립트 입력으로
정확한 원본 해시를 확인한 뒤 복구할 수 있습니다.

검증 수치
---------
- 수정 파일: 12
- 번역 문자열: 392
- 구조 오류 수정: 2
- 허용된 변경 leaf: 394
- JavaScript 구문 및 UID/LCID/해시 검증: 통과
