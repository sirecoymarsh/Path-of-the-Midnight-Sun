GS.dataCache['41CBED6F8786674A7378E12460C9D1048AE9'] = {
    "uid": "41CBED6F8786674A7378E12460C9D1048AE9",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Genera Dati FOOD",
        "type": "data_record",
        "order": 14,
        "category": "commonEvents",
        "id": "41CBED6F8786674A7378E12460C9D1048AE9",
        "isFolder": false,
        "parentId": "8A7A025317CD78422148C8F665F1528EFA9E",
        "data": {
            "name": "Genera Dati FOOD",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [],
            "commands": [
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "F\nO\nO\nD"
                    },
                    "indent": 0,
                    "uid": "1FD959FD3E4658413E28D23334FFFDAD8DC6",
                    "expanded": true
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "0A829B2443B61240B8892E20FF3C3AAB8967",
                                "Graphics/Kath's UI/Inventory Icons/Piece of Meat S.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7DFC296A401DD14FDE48E37508FF2D3E41F8"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "95CBC068419BE442C899B374834DF34A98FC",
                            "defaultText": "작은 고기 조각."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9AC8185F486DF64DD97A2F776F6BF9DA4212",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0A829B2443B61240B8892E20FF3C3AAB8967",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7886643F7781D444E589C804749D22BC45C9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "45A4D46B38CD8442C7585A16D60ECB38CCAC",
                            "defaultText": "익히지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F13608199A0364D49292FD8731DDC30BA24",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0A829B2443B61240B8892E20FF3C3AAB8967",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "134C11A27B3BF64E31981953BB6ADA5DC461"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "73803BF9902CB14DD51977859A9E6F7DF889",
                                "Graphics/Kath's UI/Inventory Icons/Piece of Meat M.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "06CA43FB4DBAE94D1219A08549A36EF77744"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7C47BFA145F2F14E5D3BEDE17BA329D83AEA",
                            "defaultText": "제법 큰 고기 덩어리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8ED80FF57092274AB12BACD3907A9E46A073",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "73803BF9902CB14DD51977859A9E6F7DF889",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4777E5A01EEBB547416AD733E678ED33D62B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5C9CB2B55A1D1146076BC972004C3090DF53",
                            "defaultText": "익히지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3CBF7A7E46EF7242C4392E50F84CA8854454",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "73803BF9902CB14DD51977859A9E6F7DF889",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0DF7C6CB3CCF5143CD9867921BE534D66C01"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "196E20BC01A9524CA189B2235672858EBE92",
                                "Graphics/Kath's UI/Inventory Icons/Piece of Meat L.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "724A078C25BCF148301BC371F768631A61EA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E073AA634344A4423569F5D208F95D6DC262",
                            "defaultText": "사체에서 큼직하게 떼어 낸 고기."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7341317E715B354EBE494166EB37E6A4C0AE",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "196E20BC01A9524CA189B2235672858EBE92",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5CA0ECE100B57446321B52E6DD70C8F17C32"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2516398361083840881A87B71CDF3728E14C",
                            "defaultText": "익히지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2E7009A64E82944A1C8B93344775588EC72A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "196E20BC01A9524CA189B2235672858EBE92",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "05E5ECCC1B99854BDD293619F3C0BDD8BA7D"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FBACF4665AA01841DD2A1072C15F3DEA67A1",
                                "Graphics/Kath's UI/Inventory Icons/Fish Fillet.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D157C7DD3773F14AE678F7C83B461CEBF093"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1F837BBB17CEB846971BC5438A120C8C4D83",
                            "defaultText": "익히지 않은 생선살."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4984A8FF6C38304A80794333DEF493740D3C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FBACF4665AA01841DD2A1072C15F3DEA67A1",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4708E300894A964D282B61403EC0F7A3929F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EAF7FC4B2CF62142975B5DE304A6478F9392",
                            "defaultText": "날로 먹는 이도 있다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F144DC135B3088493A5B49623843C214A40C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FBACF4665AA01841DD2A1072C15F3DEA67A1",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "102BF071628DA442AE2877F831C272DEA856"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "449B6B5620D59440636874E641C4B2A1DEFF",
                                "Graphics/Kath's UI/Inventory Icons/Orange.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4869231822C573488D997056D7F7C113FED0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0A95763C35E3724AC00B2778A905FC1844BB",
                            "defaultText": "몸에 좋은 비타민이 풍부한"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1DB7F8062E93E5419E9A6950DFAC34F82020",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "449B6B5620D59440636874E641C4B2A1DEFF",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FC64845D2751724A9C583E272480EB648FFC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8A2B472963DB8647178A9B38ADEA5C618D53",
                            "defaultText": "과즙 가득한 과일."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "58693CEC2459014DE06B25425018825E6BF9",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "449B6B5620D59440636874E641C4B2A1DEFF",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "91C108E73A72F641A348FB09CDF4B743152E"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "69E149733BC7074F828827A1D8C6CFC03A2C",
                                "Graphics/Kath's UI/Inventory Icons/Tomato.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F4E40F5F585D134FFE494340159BBFECFF39"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9A1AAC0B6EF686473C983E660F767D04E474",
                            "defaultText": "날로 먹기도 하고"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "38209CE88D9CD941BD59BEF1228BAA5BCA24",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "69E149733BC7074F828827A1D8C6CFC03A2C",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AA2F913E5550C4422B3BD6A32C74624B247E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "896ECA8B4BE82147558B06F2B306275E1040",
                            "defaultText": "요리에도 쓰는 채소."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C83465369DAFF147A91B41F266D08EC4C8E4",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "69E149733BC7074F828827A1D8C6CFC03A2C",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "594EDEDC362C714CF77A9E86E74E74892A21"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "31904BFC210994450B98E9562207710B9F2F",
                                "Graphics/Kath's UI/Inventory Icons/Mango.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C4E9D5B7871031445A78FA190C4162B1D1B0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "94908E9949DC22451A29A6B9C14EAAC1ED81",
                            "defaultText": "유난히 맛이 좋은"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "22871E048FC6E344FD88C531A73774320014",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "31904BFC210994450B98E9562207710B9F2F",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0846A60A8C5F574A575B9BB224E65ABE617B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F6795F0D4FEFC64BD648BBD8BC1E0B3C41CD",
                            "defaultText": "이국적인 과일."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AEB88DE67F20E94B7A78BD598FBCE0BC63CE",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "31904BFC210994450B98E9562207710B9F2F",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FA033BCE7B08B34D188BA972FC4C7DFBFFEE"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FA2240BD1D542244542939D2A97D88F19D5E",
                                "Graphics/Kath's UI/Inventory Icons/Apple.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2487FAA88878D945F62B88A34B278C1D30FA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "500D25987DCFD245CB48218178527A440BA4",
                            "defaultText": "아르비움 전역에서 사랑받는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E0E44B8429E7B947D74866E6011D61F8F674",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FA2240BD1D542244542939D2A97D88F19D5E",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EFC3FFC95DF664466B39461958ACBF8A4FE1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "42EB3B981EAA57472A7BECC5468D341E55BD",
                            "defaultText": "흔한 과일."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0E460F6110D37344F50A96E7F56C2FB8DA81",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FA2240BD1D542244542939D2A97D88F19D5E",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6A5F127564F63942E338E663F17757DB36E5"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "71A6CF5D20B6E342F76BE388F9370E6FF6C6",
                                "Graphics/Kath's UI/Inventory Icons/Mushrooms.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F34A3E5A6A9938471E6A6D76BD1DA8D434D7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5187455C6253D4486F29B5C5317EAD881E47",
                            "defaultText": "숲에서 자란 균류."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3DB0DB6D1818814F4F1933C65733A0631314",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "71A6CF5D20B6E342F76BE388F9370E6FF6C6",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "94C74AFE1F1D08407C4B00454815AF6EF55E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6141E64116D0F14997687E13DC55C6AC19A1",
                            "defaultText": "먹을 수는 있을 듯하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3C109F88425C64415728BED5514C4A4C880E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "71A6CF5D20B6E342F76BE388F9370E6FF6C6",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0F4B710A4CC99341A81B50A07859A8988F02"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "840920F309DB994F211BC2C8C1B24FB6174B",
                                "Graphics/Kath's UI/Inventory Icons/Ficus Fruit.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F2D025465719C94A26195FD12E07FEC46E5E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "18E301DF3301B140D28B8411D89147748660",
                            "defaultText": "선인장에서 자라는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CFD5B0937DD5964C735A65F4AA53DD9946CE",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "840920F309DB994F211BC2C8C1B24FB6174B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F151409249F2A248686805D55E7A3896060E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "5945081F6CCFE447E15B0D2399C6658BF895",
                            "defaultText": "이국적인 과일."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B2E17A8A4116D3414C4B200022DF4D7C87B5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "840920F309DB994F211BC2C8C1B24FB6174B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "73213DF430352745366BFC32811DCA7CC14E"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "E6C151254391704CFE4AF263C4D51DAD7754",
                                "Graphics/Kath's UI/Inventory Icons/Wheat.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4847F25473A6014AAD2AF8E21B8EC1E5D8C3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "01281B3E35F6684F9028AB113D2B4726B598",
                            "defaultText": "흔한 곡물."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "605AB1966B22B84D7C3852A8A9A266C2E372",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "E6C151254391704CFE4AF263C4D51DAD7754",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D2093E9637EA13432F4B0B75DDE6397F1251"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "65F9E9DB7D1256464358E72940BFFADEC781",
                            "defaultText": "가공하지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "87EEFC43912007481D4B005986E6AC56B9A5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "E6C151254391704CFE4AF263C4D51DAD7754",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2DB4B1F6347DC545713BC3C4661B2A59B21B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "568D125A4A68C64E5D4AD1C0C56CC516846D",
                                "Graphics/Kath's UI/Inventory Icons/Rice.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8F1617633615464C8D4ACBC57F994777022D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "16875C6D4541C543444A1465DC195AA68270",
                            "defaultText": "볏과 식물의 씨앗."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "47918BCB6A19B54DD3895C81567E2B72D6A5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "568D125A4A68C64E5D4AD1C0C56CC516846D",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2C58C06656298441564A11321C7E022B3DAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BC8C23FF3AB0C841B81858B616E5BD0E1E03",
                            "defaultText": "가공하지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82E8B5608861224FFF1B92A6C77DC7DF79FA",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "568D125A4A68C64E5D4AD1C0C56CC516846D",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6C189C31237545467C3B9964DEF8C690681B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FFD534A9961777498C18E222452B542B6E53",
                                "Graphics/Kath's UI/Inventory Icons/Potato.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1F7167160775F44F1458232895DC998F22BA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2B396C386117454E587A6DF22AB3F2295A12",
                            "defaultText": "전분과 영양이 풍부한 덩이줄기."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E4368BD83146E14D073B67A2E5F018C78275",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FFD534A9961777498C18E222452B542B6E53",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "575CC6795FED2442CD1BAEA79CAD3BB96AFF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6E48E14D8B28D4436848065115C58A6DE968",
                            "defaultText": "익히지 않으면 위험하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FC7911DD64F9B248820A9234DAA750F2F229",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FFD534A9961777498C18E222452B542B6E53",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A83205048D896240059AEFD6775A4F5B7839"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BD59A0AF1918304F4279093591261A6C66CB",
                                "Graphics/Kath's UI/Inventory Icons/Lettuce.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AE58F1242471B64B76480094332FD4A7EEAB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B6FB1D2259C5184F3C694518F5D406736C6B",
                            "defaultText": "샐러드와 여러 요리에"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A597AD2B5BD7C3486D4881D6ED07836C445A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BD59A0AF1918304F4279093591261A6C66CB",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "02C088434E1404409E0BC53118BEE28E1296"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0C9FA64064E75845B49BBDB184299BC0D4D0",
                            "defaultText": "흔히 쓰이는 채소."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9937583F12EC354E22187387EB035D93192E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BD59A0AF1918304F4279093591261A6C66CB",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B897262355D5254B3369CB8214FFEAEE6A57"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BFFF48AF1209E7417F2A0F29C05B97D3B7CA",
                                "Graphics/Kath's UI/Inventory Icons/Milk.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "778D5292796B5046252A3E16ECFFBF897AFC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A4C6F9CE3CF5244CDE78AAB6CB9531423553",
                            "defaultText": "소의 젖샘에서"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B397DB0C69F4774C375BA256AE4C1FCCBD28",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BFFF48AF1209E7417F2A0F29C05B97D3B7CA",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B76A0DE16A44E74BCB49A9C1461E18656904"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ED067E253E80E942905BD74091EB19141977",
                            "defaultText": "만들어지는 액체."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "297ECFC93CD856487B6BBCA2AC47680BF67E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BFFF48AF1209E7417F2A0F29C05B97D3B7CA",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "418F3C1F89F24846FE19126846B6F509CFAD"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "DDB6BB3C12F91942FF59BF881A925916AD48",
                                "Graphics/Kath's UI/Inventory Icons/Coffee.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6E6A871A64AFB3432379AD045C19D1BDD3CB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8DE01F2D0641C84706488C152BFE8E4B642D",
                            "defaultText": "이게 없으면 하루를"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C1AF0D441C5AE445B1494BE3E195D66719F7",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DDB6BB3C12F91942FF59BF881A925916AD48",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9B9CD8688E6A1149ED5AB7512CB37CC8A41A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F9A2700B62C0264A2359FC730C252DE95D90",
                            "defaultText": "시작 못 하는 이도 많다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0A89BBD54FAEA64E921ABA64E50BA1917146",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DDB6BB3C12F91942FF59BF881A925916AD48",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9143EF1C3A13D143C42B79F7A55D4D5201B8"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "C4AA150854E4A24D9D1A114627289DF0AA5A",
                                "Graphics/Kath's UI/Inventory Icons/Cappuccino.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2C2DFEE48AA7034D2498A0C71A9E0F7B9030"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc1",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "23E4621C190CF44A0379A151F292A00824C1",
                            "defaultText": "평범한 커피가 너무 시거나"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "791A72A85C04364DCB4AD1533B1B3FC10E72",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C4AA150854E4A24D9D1A114627289DF0AA5A",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9080A7766F30C74FB55B4B191F58434047BC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "desc2",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "839E42F03DE8B94ECB2825B70ADA8DADC6D7",
                            "defaultText": "심심하다는 이들을 위한 음료."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4538A34A7E95E04FA30954A6E60D555E423C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C4AA150854E4A24D9D1A114627289DF0AA5A",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B21B882161F2C446932BE2A5BEF374095E24"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "6816B0198B86F8456C6846F8A08E021D63A1",
                                "Graphics/Kath's UI/Inventory Icons/Croissant.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DEA0A953849F46466A79BF06A4C8E6493159"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "73D0F44190FE554C1818D9C37939D00A72BD",
                            "defaultText": "버터 향 가득한 페이스트리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D123DE937EB1C940EE68FF2657F76573A165",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6816B0198B86F8456C6846F8A08E021D63A1",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "666436CA679F434DF36AB61284749FC2360F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "815383DF55FC1241DB39E225DFA2CF11F79E",
                            "defaultText": "바삭하면서도 속은 부드럽다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "36D819859C1F3346D9590A1162E4544E3AA1",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6816B0198B86F8456C6846F8A08E021D63A1",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E571B9B94A1E644ACC0A7D869C242741B3CD"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "A61006745779B54F95583F031E23AAF3B85A",
                                "Graphics/Kath's UI/Inventory Icons/Bowl of Soup.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C25D28C87E11D04F672993628AC63321F6B2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7DD1EF908D78954DAB788438ADFB54BAC81A",
                            "defaultText": "게살 조각을 넣어"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D4167980756B474D4228C0731D62AB3EC40F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "A61006745779B54F95583F031E23AAF3B85A",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "731949AC605FA144DF493497CA050EC88314"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "838D32424C9B974EF4489D90ECF28060B7BF",
                            "defaultText": "맑게 끓인 수프."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D37B998A84A47242CD48C6C1096A9B9D7BD0",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "A61006745779B54F95583F031E23AAF3B85A",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0B5661108F89B8431C4B8FE16687B040BA24"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                                "Graphics/Kath's UI/Inventory Icons/Grilled Steak with Potatoes.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CD5B25F63ADA5247CE785DA972F44BFEC3F9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E42C07AF7C41C141FA1958C6020F21038265",
                            "defaultText": "구운 고기와"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "04A1B41851512842B45991375ABB8F2A515C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3DB9DB78400414D816BAF3168ED41A4998E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D56852C913966247EA9ACE99479D4F60CDD7",
                            "defaultText": "감자구이를 곁들인 요리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "255D08DF3B52D34F926BA2A00FD296283194",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9C600051973C934A7C8B3A4886F271FB642D"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                                "Graphics/Kath's UI/Inventory Icons/Beer.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8AD9541111646445451ACAA6911B73A41719"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BE4789F16CB2D64F553BBE8597839A4EBEBE",
                            "defaultText": "맥아로 빚은 술."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3B90C927FC5864F4F689322B1583E90B2A6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ED9A4995577A794F3D7A63F5A5C6925A5FC7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FC74FAA87C549140F97A05F38FDF6CD9A6AE",
                            "defaultText": "다음 전투에서 취기가 돈다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B649E90E16D08041B43A9F4472DC1B45F09A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B617231240CE2743457BFAA77C710BE96FA1"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "4BE0921B0375824E39486375D29E6D610E31",
                                "Graphics/Kath's UI/Inventory Icons/Fresh Water.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4E1E352349FF1345CE2A0FB3B57B6AF4A676"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9F642F742C66544D148BA9C05EE96FF7B511",
                            "defaultText": "하루에 적어도"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9F9F2FE423D55742ED3870A2DE48CEDDDF83",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4BE0921B0375824E39486375D29E6D610E31",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7D7BA3D903301149288AFDE3DAE42F88E598"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "64A520739412C841A089FE49A3BF43A22983",
                            "defaultText": "2리터는 마시자!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "735B6F867BACE741AA5AB7D8B03087F76046",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4BE0921B0375824E39486375D29E6D610E31",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D4D60AC535E85842A53A98C99E4A17C58C95"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "3A6470303809F6402069BCA779DE051805FA",
                                "Graphics/Kath's UI/Inventory Icons/Special Salad.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C7C16FBF25B7A640929B4E07500BE198FDE6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "4EB8B85894B1E44AA53B1F349E65284219D4",
                            "defaultText": "건강한 샐러드에"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "94905C7214A6724C6C8824E9C259E98B19F6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3A6470303809F6402069BCA779DE051805FA",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0BCB715C507EE14E4D6AED4644297CA6E121"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DD9245F1705C54460A4B8AC152A7EB8E81D8",
                            "defaultText": "크림소스를 듬뿍 얹었다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4FA8F382703B5845CA5A8031503DC8D29C14",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3A6470303809F6402069BCA779DE051805FA",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4DB589A542900243E33814F70D210A3C683D"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "676733150C7A184BC488AB97C468CBE0A128",
                                "Graphics/Kath's UI/Inventory Icons/Parmesan Cheese.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5635A30E7EC3A848414B2635A1F9BB49F5D7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7AF95B253295F949D18A54486EE69CF4DA79",
                            "defaultText": "그대로 먹어도 별미고"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F68142F25321645103B7983D00893C30A43",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "676733150C7A184BC488AB97C468CBE0A128",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "69AD06784E13164E173B7A151196EB80FBF2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "16F8C1575B65F74A4149CC131DF8B3113860",
                            "defaultText": "음식에 갈아 얹어도 좋다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8F27634712C13245C88860F63F5CBA712A6F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "676733150C7A184BC488AB97C468CBE0A128",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B3933F565891D741001976F338DD17AD2D53"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "D099EDDA3E2B3446FD2835580A8561A44551",
                                "Graphics/Kath's UI/Inventory Icons/Grilled Fish.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0A31839932247540B01B36678338320A3CAC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "650DC6C075939146E24A7FF582917CCB7ECD",
                            "defaultText": "날생선은 너무 전위적이라는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9F4C9B20142E3844A468AB246084831A58A4",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "D099EDDA3E2B3446FD2835580A8561A44551",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "124A493F78572142EB183F43F1EE496AA51F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D6CA5829242F084B434AD357A0FC6282F18E",
                            "defaultText": "사람들을 위한 요리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B9697EA490AB2548CF28062061681CD4058C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "D099EDDA3E2B3446FD2835580A8561A44551",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "042374E055A201485A1AF7A9B3124B566591"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "A22335E58B019145941B83457E31F119B83F",
                                "Graphics/Kath's UI/Inventory Icons/Spaghetti.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8E9923162EE4954185994697C0BFB4DCB0DA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "84F26E913E92614D4E1AD815190919C0334B",
                            "defaultText": "고전적인 요리. 서툰"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AFAE1ED6628B104DD0583FB130793DEC5285",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "A22335E58B019145941B83457E31F119B83F",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "09DC7AE074DC464DB30B0312269E5CDCA99B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2654ED690BFD8343AB3B42B97A78F16021AB",
                            "defaultText": "외지인이 곧잘 망친다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C3FC627285C1564FB8594183C94B5679E043",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "A22335E58B019145941B83457E31F119B83F",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FDD8AD93743BC54B54982EB17BFDB0DEAB52"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "0DD3AFDA93801640D11AA788CDFB0E37FFA8",
                                "Graphics/Kath's UI/Inventory Icons/Wine.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8AD687DF9F93D04CD31B6321F45546EA68A3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EF4ED36D76F496426A5960459303F9610BB6",
                            "defaultText": "마시면 다음 전투에서"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4CE2731942D97845805B4B7663C54A831E0D",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0DD3AFDA93801640D11AA788CDFB0E37FFA8",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5320890064070140213A9AA07E15428ABB11"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "FF213CAA7CF14542A01923B20EE2D8A8A3D7",
                            "defaultText": "취기가 돈다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C329CECA3D6FE74CAB48BA55CB163357F1C2",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0DD3AFDA93801640D11AA788CDFB0E37FFA8",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B395998315DC364E642AAFB4AE1A35773ED0"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "0D82AB962B80954BDC586098B4C1AFD3957D",
                                "Graphics/Kath's UI/Inventory Icons/Veggie Pizza.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DA14EC4A997FA54E4F9B97E82B88BB71194F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "28E185DA2DE30240A78B40531EE7BA03D39D",
                            "defaultText": "신께 버림받은 자들은"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2677FC9B3861834F27495A41EFADAD3E2955",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0D82AB962B80954BDC586098B4C1AFD3957D",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "73CD94B503E7E2424D2A9273E824C1C2CF30"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AB66195728D7A6466589D007BD5C57E66812",
                            "defaultText": "여기에 파인애플을 얹는다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2E8128D8739F3142C81BB53557EE8D7F1F5F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0D82AB962B80954BDC586098B4C1AFD3957D",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C57524A1669D56416C39C3A65261829E7AB2"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "DD0ACDC6894B11470778ECE1D02DF106E798",
                                "Graphics/Kath's UI/Inventory Icons/Beef Wellington.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B175E66B43C9E6456F483FD26D771D1ABAF9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "86E2970D214C124BB46A6A13322AFE6BDD61",
                            "defaultText": "귀족들이 즐기는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "10F6EC5F8498B44042794F4266D41287EBD9",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DD0ACDC6894B11470778ECE1D02DF106E798",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B8A4791D8405544D060A18C4375795780DBC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "30DA20376A3C164FF83A4D52867D6CED1D33",
                            "defaultText": "호이카데식 별미."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "781B7CCE39E4F5465009921690B220598EB3",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DD0ACDC6894B11470778ECE1D02DF106E798",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "301284EB77793142753B9958447B03AE3707"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "DEE7AAAD1574144D1B4BE211A16A8D562887",
                                "Graphics/Kath's UI/Inventory Icons/Kushari.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8F4ECFD019E1184DAD881CA5BEB56C085139"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "11BE46D963FAA347719B3CD72F31BD50381E",
                            "defaultText": "파스타와 쌀, 채소를 넣은"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E2BD45B5357AE245DC2894A6C2261542EC51",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DEE7AAAD1574144D1B4BE211A16A8D562887",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5F18A46F5FB6644202485941BA2F81A0FCEE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F038AF90409A364D5D9971318D66185F25B7",
                            "defaultText": "미드바르식 요리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C6B5BE63203E6146AF49DF341E39D682DEF7",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "DEE7AAAD1574144D1B4BE211A16A8D562887",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4414334B8073C540F7184612C9ED87E20AB5"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "C98688CB0047C441801A40F66BE04850B37E",
                                "Graphics/Kath's UI/Inventory Icons/Sayadeya.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AE858F8959F1444A12888AB98628758A074E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F5A6026D4B317248FE8A53472EA12CB2EB49",
                            "defaultText": "생선과 향긋한 쌀로 만든"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E0C861CC60279243062AC38392D3B5327529",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C98688CB0047C441801A40F66BE04850B37E",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BE078FDF6BAE534B04298727B4114E15E249"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7477993A547C3447E33BE657AB06293F7471",
                            "defaultText": "인기 있는 미드바르 요리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0E07B9776D36F741E4587358F003C3B7A13E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C98688CB0047C441801A40F66BE04850B37E",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4B846EC2245BA2428A4A7E63FFDCCAE378C8"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FA57CD1788ACF74D66095834719FD0FDE24C",
                                "Graphics/Kath's UI/Inventory Icons/Sushi.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2C33A4EB887EB5450F7A1AF29CAF8586095D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EA3A0E4419E5A14E0F3A2915DCFA1E23247A",
                            "defaultText": "예술 작품으로 불릴 만한"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "306156AB6066F84F6538D597E0DE3E567B13",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FA57CD1788ACF74D66095834719FD0FDE24C",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2321B44041B95440880B95A74CAD738F33C7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6CC7CB252AF0B2450C7B9D29CF357B4CFC04",
                            "defaultText": "파일럼식 요리."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D57DC956581A9648A78B8A261198E09799C0",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FA57CD1788ACF74D66095834719FD0FDE24C",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4F898BAA15C4A74F4C18F451A695583A05F1"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "91B4FD6F4DE6A24F7E592BC938E666CAC51E",
                                "Graphics/Kath's UI/Inventory Icons/Gorgonzola.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CC1663E819FD114D131AAA81CAEEA8693B29"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D7614DB759D4564C5B6839772C6D905D82FE",
                            "defaultText": "곰팡이로 숙성한"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "608798FB64D268471869D7A2F3ADA9339561",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "91B4FD6F4DE6A24F7E592BC938E666CAC51E",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BAD7261D146AE34B3698AB133E8EFBD484C5"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A8B492C15A0D47425F881AD5CD7E06564F22",
                            "defaultText": "흙내음 짙은 치즈."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BEB9DB8C3A57C74FBB6BF71743C8F6E65E08",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "91B4FD6F4DE6A24F7E592BC938E666CAC51E",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0886ABB8392EA349FB2AAD62F63651911E65"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "EBA214B73A7445455719E0E9E91057954732",
                                "Graphics/Kath's UI/Inventory Icons/Ice Cream.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5CCA0EAE4ED343421398FB424BBA3B071334"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "37CB765514A2714F062910E0B95B271340CE",
                            "defaultText": "남녀노소 누구나 좋아하는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A5A326C370C2F043DA28EB82A27E624E2895",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "EBA214B73A7445455719E0E9E91057954732",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D666679986D9844ACF2B10375A8EBCF1D39F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "64419CC05853A549A55BBC43FE38D6EC1EF6",
                            "defaultText": "차가운 디저트."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A52D1A428D806049437A7E312F92631F4360",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "EBA214B73A7445455719E0E9E91057954732",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "41EF6A671B5691439479D5C351FD081C8C6D"
                }
            ],
            "index": "41CBED6F8786674A7378E12460C9D1048AE9",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "desc1",
                    "index": 0,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                },
                {
                    "name": "desc2",
                    "index": 1,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                },
                {
                    "name": "desc3",
                    "index": 2,
                    "scope": 1
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "8DE01F2D0641C84706488C152BFE8E4B642D": {
                "t": "For many, the day",
                "d": {
                    "eid": "C1AF0D441C5AE445B1494BE3E195D66719F7"
                }
            },
            "F9A2700B62C0264A2359FC730C252DE95D90": {
                "t": "can't start without this.",
                "d": {
                    "eid": "0A89BBD54FAEA64E921ABA64E50BA1917146"
                }
            },
            "73D0F44190FE554C1818D9C37939D00A72BD": {
                "t": "A buttery pastry, crunchy",
                "d": {
                    "eid": "D123DE937EB1C940EE68FF2657F76573A165"
                }
            },
            "815383DF55FC1241DB39E225DFA2CF11F79E": {
                "t": "yet soft when you bite.",
                "d": {
                    "eid": "36D819859C1F3346D9590A1162E4544E3AA1"
                }
            },
            "7DD1EF908D78954DAB788438ADFB54BAC81A": {
                "t": "A clear soup with small",
                "d": {
                    "eid": "D4167980756B474D4228C0731D62AB3EC40F"
                }
            },
            "838D32424C9B974EF4489D90ECF28060B7BF": {
                "t": "pieces of crab in it.",
                "d": {
                    "eid": "D37B998A84A47242CD48C6C1096A9B9D7BD0"
                }
            },
            "E42C07AF7C41C141FA1958C6020F21038265": {
                "t": "A grilled meat fillet",
                "d": {
                    "eid": "04A1B41851512842B45991375ABB8F2A515C"
                }
            },
            "D56852C913966247EA9ACE99479D4F60CDD7": {
                "t": "with roasted potatoes.",
                "d": {
                    "eid": "255D08DF3B52D34F926BA2A00FD296283194"
                }
            },
            "BE4789F16CB2D64F553BBE8597839A4EBEBE": {
                "t": "A malt drink. Makes you",
                "d": {
                    "eid": "E3B90C927FC5864F4F689322B1583E90B2A6"
                }
            },
            "FC74FAA87C549140F97A05F38FDF6CD9A6AE": {
                "t": "tipsy in the next battle.",
                "d": {
                    "eid": "B649E90E16D08041B43A9F4472DC1B45F09A"
                }
            },
            "9F642F742C66544D148BA9C05EE96FF7B511": {
                "t": "You should drink",
                "d": {
                    "eid": "9F9F2FE423D55742ED3870A2DE48CEDDDF83"
                }
            },
            "64A520739412C841A089FE49A3BF43A22983": {
                "t": "at least 2 liters/day!",
                "d": {
                    "eid": "735B6F867BACE741AA5AB7D8B03087F76046"
                }
            },
            "EF4ED36D76F496426A5960459303F9610BB6": {
                "t": "Drink this and you'll start",
                "d": {
                    "eid": "4CE2731942D97845805B4B7663C54A831E0D"
                }
            },
            "FF213CAA7CF14542A01923B20EE2D8A8A3D7": {
                "t": "the next battle tipsy.",
                "d": {
                    "eid": "C329CECA3D6FE74CAB48BA55CB163357F1C2"
                }
            },
            "95CBC068419BE442C899B374834DF34A98FC": {
                "t": "A small piece of meat.",
                "d": {
                    "eid": "9AC8185F486DF64DD97A2F776F6BF9DA4212"
                }
            },
            "45A4D46B38CD8442C7585A16D60ECB38CCAC": {
                "t": "Dangerous if uncooked.",
                "d": {
                    "eid": "5F13608199A0364D49292FD8731DDC30BA24"
                }
            },
            "7C47BFA145F2F14E5D3BEDE17BA329D83AEA": {
                "t": "A good chunk of meat.",
                "d": {
                    "eid": "8ED80FF57092274AB12BACD3907A9E46A073"
                }
            },
            "5C9CB2B55A1D1146076BC972004C3090DF53": {
                "t": "Dangerous if uncooked.",
                "d": {
                    "eid": "3CBF7A7E46EF7242C4392E50F84CA8854454"
                }
            },
            "E073AA634344A4423569F5D208F95D6DC262": {
                "t": "Big portion of a carcass.",
                "d": {
                    "eid": "7341317E715B354EBE494166EB37E6A4C0AE"
                }
            },
            "2516398361083840881A87B71CDF3728E14C": {
                "t": "Dangerous if uncooked.",
                "d": {
                    "eid": "2E7009A64E82944A1C8B93344775588EC72A"
                }
            },
            "1F837BBB17CEB846971BC5438A120C8C4D83": {
                "t": "Uncooked fish fillet.",
                "d": {
                    "eid": "4984A8FF6C38304A80794333DEF493740D3C"
                }
            },
            "EAF7FC4B2CF62142975B5DE304A6478F9392": {
                "t": "Some like eating it raw.",
                "d": {
                    "eid": "F144DC135B3088493A5B49623843C214A40C"
                }
            },
            "0A95763C35E3724AC00B2778A905FC1844BB": {
                "t": "A juicy fruit, full of",
                "d": {
                    "eid": "1DB7F8062E93E5419E9A6950DFAC34F82020"
                }
            },
            "8A2B472963DB8647178A9B38ADEA5C618D53": {
                "t": "precious vitamins.",
                "d": {
                    "eid": "58693CEC2459014DE06B25425018825E6BF9"
                }
            },
            "9A1AAC0B6EF686473C983E660F767D04E474": {
                "t": "A vegetable consumed",
                "d": {
                    "eid": "38209CE88D9CD941BD59BEF1228BAA5BCA24"
                }
            },
            "896ECA8B4BE82147558B06F2B306275E1040": {
                "t": "raw or used in cooking.",
                "d": {
                    "eid": "C83465369DAFF147A91B41F266D08EC4C8E4"
                }
            },
            "94908E9949DC22451A29A6B9C14EAAC1ED81": {
                "t": "An exotic fruit that tastes",
                "d": {
                    "eid": "22871E048FC6E344FD88C531A73774320014"
                }
            },
            "F6795F0D4FEFC64BD648BBD8BC1E0B3C41CD": {
                "t": "particularly delicious.",
                "d": {
                    "eid": "AEB88DE67F20E94B7A78BD598FBCE0BC63CE"
                }
            },
            "500D25987DCFD245CB48218178527A440BA4": {
                "t": "A common fruit, loved",
                "d": {
                    "eid": "E0E44B8429E7B947D74866E6011D61F8F674"
                }
            },
            "42EB3B981EAA57472A7BECC5468D341E55BD": {
                "t": "in all of Arvium.",
                "d": {
                    "eid": "0E460F6110D37344F50A96E7F56C2FB8DA81"
                }
            },
            "5187455C6253D4486F29B5C5317EAD881E47": {
                "t": "A fungus from the woods.",
                "d": {
                    "eid": "3DB0DB6D1818814F4F1933C65733A0631314"
                }
            },
            "6141E64116D0F14997687E13DC55C6AC19A1": {
                "t": "It appears to be edible.",
                "d": {
                    "eid": "3C109F88425C64415728BED5514C4A4C880E"
                }
            },
            "18E301DF3301B140D28B8411D89147748660": {
                "t": "An exotic fruit. It",
                "d": {
                    "eid": "CFD5B0937DD5964C735A65F4AA53DD9946CE"
                }
            },
            "5945081F6CCFE447E15B0D2399C6658BF895": {
                "t": "grows on cacti.",
                "d": {
                    "eid": "B2E17A8A4116D3414C4B200022DF4D7C87B5"
                }
            },
            "01281B3E35F6684F9028AB113D2B4726B598": {
                "t": "Common cereal grains.",
                "d": {
                    "eid": "605AB1966B22B84D7C3852A8A9A266C2E372"
                }
            },
            "65F9E9DB7D1256464358E72940BFFADEC781": {
                "t": "Dangerous if unprocessed.",
                "d": {
                    "eid": "87EEFC43912007481D4B005986E6AC56B9A5"
                }
            },
            "16875C6D4541C543444A1465DC195AA68270": {
                "t": "Seeds of a grass species.",
                "d": {
                    "eid": "47918BCB6A19B54DD3895C81567E2B72D6A5"
                }
            },
            "BC8C23FF3AB0C841B81858B616E5BD0E1E03": {
                "t": "Dangerous if unprocessed.",
                "d": {
                    "eid": "82E8B5608861224FFF1B92A6C77DC7DF79FA"
                }
            },
            "2B396C386117454E587A6DF22AB3F2295A12": {
                "t": "Starchy, nutritious tuber.",
                "d": {
                    "eid": "E4368BD83146E14D073B67A2E5F018C78275"
                }
            },
            "6E48E14D8B28D4436848065115C58A6DE968": {
                "t": "Dangerous if uncooked.",
                "d": {
                    "eid": "FC7911DD64F9B248820A9234DAA750F2F229"
                }
            },
            "B6FB1D2259C5184F3C694518F5D406736C6B": {
                "t": "A plant used for salads",
                "d": {
                    "eid": "A597AD2B5BD7C3486D4881D6ED07836C445A"
                }
            },
            "0C9FA64064E75845B49BBDB184299BC0D4D0": {
                "t": "or other common recipes.",
                "d": {
                    "eid": "9937583F12EC354E22187387EB035D93192E"
                }
            },
            "A4C6F9CE3CF5244CDE78AAB6CB9531423553": {
                "t": "Liquid produced from the",
                "d": {
                    "eid": "B397DB0C69F4774C375BA256AE4C1FCCBD28"
                }
            },
            "ED067E253E80E942905BD74091EB19141977": {
                "t": "mammary glands of cows.",
                "d": {
                    "eid": "297ECFC93CD856487B6BBCA2AC47680BF67E"
                }
            },
            "23E4621C190CF44A0379A151F292A00824C1": {
                "t": "For those who find normal",
                "d": {
                    "eid": "791A72A85C04364DCB4AD1533B1B3FC10E72"
                }
            },
            "839E42F03DE8B94ECB2825B70ADA8DADC6D7": {
                "t": "coffee too sour or boring.",
                "d": {
                    "eid": "4538A34A7E95E04FA30954A6E60D555E423C"
                }
            },
            "4EB8B85894B1E44AA53B1F349E65284219D4": {
                "t": "A healthy salad with",
                "d": {
                    "eid": "94905C7214A6724C6C8824E9C259E98B19F6"
                }
            },
            "DD9245F1705C54460A4B8AC152A7EB8E81D8": {
                "t": "a creamy sauce on top.",
                "d": {
                    "eid": "4FA8F382703B5845CA5A8031503DC8D29C14"
                }
            },
            "7AF95B253295F949D18A54486EE69CF4DA79": {
                "t": "A delicacy eaten as is",
                "d": {
                    "eid": "5F68142F25321645103B7983D00893C30A43"
                }
            },
            "16F8C1575B65F74A4149CC131DF8B3113860": {
                "t": "or grated on top of food.",
                "d": {
                    "eid": "8F27634712C13245C88860F63F5CBA712A6F"
                }
            },
            "650DC6C075939146E24A7FF582917CCB7ECD": {
                "t": "For those who find raw",
                "d": {
                    "eid": "9F4C9B20142E3844A468AB246084831A58A4"
                }
            },
            "D6CA5829242F084B434AD357A0FC6282F18E": {
                "t": "fish a little too avant-garde.",
                "d": {
                    "eid": "B9697EA490AB2548CF28062061681CD4058C"
                }
            },
            "84F26E913E92614D4E1AD815190919C0334B": {
                "t": "Classic dish, often ruined",
                "d": {
                    "eid": "AFAE1ED6628B104DD0583FB130793DEC5285"
                }
            },
            "2654ED690BFD8343AB3B42B97A78F16021AB": {
                "t": "by incompetent foreigners.",
                "d": {
                    "eid": "C3FC627285C1564FB8594183C94B5679E043"
                }
            },
            "28E185DA2DE30240A78B40531EE7BA03D39D": {
                "t": "People forgotten by God",
                "d": {
                    "eid": "2677FC9B3861834F27495A41EFADAD3E2955"
                }
            },
            "AB66195728D7A6466589D007BD5C57E66812": {
                "t": "put pineapple on this.",
                "d": {
                    "eid": "2E8128D8739F3142C81BB53557EE8D7F1F5F"
                }
            },
            "86E2970D214C124BB46A6A13322AFE6BDD61": {
                "t": "An Hoikadian delicacy",
                "d": {
                    "eid": "10F6EC5F8498B44042794F4266D41287EBD9"
                }
            },
            "30DA20376A3C164FF83A4D52867D6CED1D33": {
                "t": "appreciated by nobles.",
                "d": {
                    "eid": "781B7CCE39E4F5465009921690B220598EB3"
                }
            },
            "11BE46D963FAA347719B3CD72F31BD50381E": {
                "t": "A Midbarnese dish with",
                "d": {
                    "eid": "E2BD45B5357AE245DC2894A6C2261542EC51"
                }
            },
            "F038AF90409A364D5D9971318D66185F25B7": {
                "t": "pasta, rice and veggies.",
                "d": {
                    "eid": "C6B5BE63203E6146AF49DF341E39D682DEF7"
                }
            },
            "F5A6026D4B317248FE8A53472EA12CB2EB49": {
                "t": "Popular Midbarnese dish",
                "d": {
                    "eid": "E0C861CC60279243062AC38392D3B5327529"
                }
            },
            "7477993A547C3447E33BE657AB06293F7471": {
                "t": "with fish and fragrant rice.",
                "d": {
                    "eid": "0E07B9776D36F741E4587358F003C3B7A13E"
                }
            },
            "EA3A0E4419E5A14E0F3A2915DCFA1E23247A": {
                "t": "Pylumese dish that may be",
                "d": {
                    "eid": "306156AB6066F84F6538D597E0DE3E567B13"
                }
            },
            "6CC7CB252AF0B2450C7B9D29CF357B4CFC04": {
                "t": "considered a work of art.",
                "d": {
                    "eid": "D57DC956581A9648A78B8A261198E09799C0"
                }
            },
            "D7614DB759D4564C5B6839772C6D905D82FE": {
                "t": "An earthy cheese, made",
                "d": {
                    "eid": "608798FB64D268471869D7A2F3ADA9339561"
                }
            },
            "A8B492C15A0D47425F881AD5CD7E06564F22": {
                "t": "with cultures of a fungus.",
                "d": {
                    "eid": "BEB9DB8C3A57C74FBB6BF71743C8F6E65E08"
                }
            },
            "37CB765514A2714F062910E0B95B271340CE": {
                "t": "A cold dessert loved by",
                "d": {
                    "eid": "A5A326C370C2F043DA28EB82A27E624E2895"
                }
            },
            "64419CC05853A549A55BBC43FE38D6EC1EF6": {
                "t": "people of all ages.",
                "d": {
                    "eid": "A52D1A428D806049437A7E312F92631F4360"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}