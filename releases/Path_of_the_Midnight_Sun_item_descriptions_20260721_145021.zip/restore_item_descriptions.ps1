param(
    [Parameter(Mandatory = $true)][string]$BackupDir,
    [Parameter(Mandatory = $true)][string]$GameDataDir
)

$ErrorActionPreference = 'Stop'

$ExpectedSemanticManifestSha256 = 'A29BB8B8DB0683F5AFE3A12DEFEB64CBABB45EF6402C6AC90CBBB917E979DCBB'
$ExpectedInstallManifestSha256 = '957A4715373C0C6E668872E0C567050AB03111E3F015A7DD11DD53099B5B8746'
$ExpectedTranslationMapSha256 = '12EFA0C94A93417AF104530A8FE74F1086D5E3DEA6C5D3185FB9F2F0021C2754'
$ExpectedLanguageQaSha256 = '499C414B73F362BBB9C3E2562D3200F2C4BDF25136D98603B7A95ED6E48A0B88'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}

function Install-Atomic([string]$Source, [string]$Target, [string]$ExpectedSourceHash, [string]$ExpectedCurrentHash) {
    $parent = [System.IO.Path]::GetDirectoryName($Target)
    $temp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_tmp_' + [Guid]::NewGuid().ToString('N'))
    $replaceBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_replace_backup_' + [Guid]::NewGuid().ToString('N'))
    $recoveryTemp = $null
    $failedReplacementBackup = $null
    $preserveRecoveryArtifacts = $false
    try {
        if ((Get-Sha256 $Target) -ne $ExpectedCurrentHash) { throw "Target changed immediately before replace: $Target" }
        [System.IO.File]::Copy($Source, $temp, $true)
        if ((Get-Sha256 $temp) -ne $ExpectedSourceHash) { throw "Temporary restore hash mismatch: $Target" }
        [System.IO.File]::Replace($temp, $Target, $replaceBackup, $true)
        if ((Get-Sha256 $Target) -ne $ExpectedSourceHash) {
            if ((Test-Path -LiteralPath $replaceBackup -PathType Leaf) -and (Get-Sha256 $replaceBackup) -eq $ExpectedCurrentHash) {
                $recoveryTemp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_recovery_tmp_' + [Guid]::NewGuid().ToString('N'))
                $failedReplacementBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_failed_replace_' + [Guid]::NewGuid().ToString('N'))
                [System.IO.File]::Copy($replaceBackup, $recoveryTemp, $false)
                [System.IO.File]::Replace($recoveryTemp, $Target, $failedReplacementBackup, $true)
                if ((Get-Sha256 $Target) -eq $ExpectedCurrentHash) {
                    throw "Atomic restore post-hash mismatch; previous target was restored: $Target"
                }
            }
            $preserveRecoveryArtifacts = $true
            throw "Atomic restore post-hash mismatch and automatic recovery was not verified: $Target"
        }
    }
    finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        if ($null -ne $recoveryTemp -and (Test-Path -LiteralPath $recoveryTemp)) { Remove-Item -LiteralPath $recoveryTemp -Force -ErrorAction SilentlyContinue }
        $targetHasKnownHash = $false
        try {
            $targetHash = Get-Sha256 $Target
            $targetHasKnownHash = ($targetHash -eq $ExpectedSourceHash -or $targetHash -eq $ExpectedCurrentHash)
        }
        catch { $targetHasKnownHash = $false }
        if ($preserveRecoveryArtifacts -or -not $targetHasKnownHash) {
            if (Test-Path -LiteralPath $replaceBackup) { Write-Warning "Preserved atomic recovery file: $replaceBackup" }
            if ($null -ne $failedReplacementBackup -and (Test-Path -LiteralPath $failedReplacementBackup)) { Write-Warning "Preserved failed replacement file: $failedReplacementBackup" }
        }
        else {
            if (Test-Path -LiteralPath $replaceBackup) { Remove-Item -LiteralPath $replaceBackup -Force }
            if ($null -ne $failedReplacementBackup -and (Test-Path -LiteralPath $failedReplacementBackup)) { Remove-Item -LiteralPath $failedReplacementBackup -Force }
        }
    }
}

function Assert-GameDataPath([string]$ResolvedPath) {
    $dir = [System.IO.DirectoryInfo]::new($ResolvedPath)
    foreach ($name in @('data', 'app', 'resources', 'Path of the Midnight Sun')) {
        if ($null -eq $dir -or -not $dir.Name.Equals($name, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Unexpected game data directory: $ResolvedPath"
        }
        $dir = $dir.Parent
    }
}

function Test-IsSameOrChildPath([string]$CandidatePath, [string]$ParentPath) {
    $separators = [char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
    $candidate = [System.IO.Path]::GetFullPath($CandidatePath).TrimEnd($separators)
    $parent = [System.IO.Path]::GetFullPath($ParentPath).TrimEnd($separators)
    if ($candidate.Equals($parent, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $candidate.StartsWith($parent + [System.IO.Path]::DirectorySeparatorChar, [System.StringComparison]::OrdinalIgnoreCase)
}

function Assert-GameStopped() {
    $running = @(Get-Process -Name 'Game' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        $processIds = @($running | ForEach-Object { $_.Id }) -join ', '
        throw "Game.exe is running (PID: $processIds). Close the game before restoring files."
    }
}

function Assert-ManifestBinding($InstallManifest, $SemanticManifest) {
    foreach ($field in @('total_files', 'total_items', 'total_descriptions', 'total_assignment_fixes')) {
        if ([int]$InstallManifest.$field -ne [int]$SemanticManifest.$field) {
            throw "Backup install/semantic manifest total mismatch: $field"
        }
    }
    if ([string]$InstallManifest.created_at -ne [string]$SemanticManifest.created_at) {
        throw 'Backup install/semantic manifest creation timestamp mismatch.'
    }
    foreach ($field in @('original_baseline_sha256', 'translation_map_sha256', 'final_language_qa_sha256', 'safety_audit_sha256', 'language_qa_status', 'crossreview_corrections')) {
        if ([string]$InstallManifest.provenance.$field -ne [string]$SemanticManifest.provenance.$field) {
            throw "Backup install/semantic manifest provenance mismatch: $field"
        }
    }

    $installFiles = @($InstallManifest.files)
    $semanticFiles = @($SemanticManifest.files)
    if ($installFiles.Count -ne $semanticFiles.Count) { throw 'Backup install/semantic manifest file count mismatch.' }
    $semanticByName = @{}
    foreach ($entry in $semanticFiles) {
        $name = [string]$entry.filename
        if ($semanticByName.ContainsKey($name)) { throw "Backup semantic manifest contains duplicate filename: $name" }
        $semanticByName[$name] = $entry
    }
    foreach ($entry in $installFiles) {
        $name = [string]$entry.filename
        if (-not $semanticByName.ContainsKey($name)) { throw "Backup install manifest file missing from semantic manifest: $name" }
        $semanticEntry = $semanticByName[$name]
        foreach ($field in @('current_sha256', 'fixed_sha256')) {
            if (-not ([string]$entry.$field).Equals([string]$semanticEntry.$field, [System.StringComparison]::OrdinalIgnoreCase)) {
                throw "Backup install/semantic manifest hash mismatch for $name`: $field"
            }
        }
        foreach ($field in @('descriptions', 'items', 'assignment_fixes')) {
            if ([int]$entry.$field -ne [int]$semanticEntry.$field) {
                throw "Backup install/semantic manifest count mismatch for $name`: $field"
            }
        }
        if (@($semanticEntry.changes).Count -ne [int]$entry.descriptions) {
            throw "Backup semantic description-list count mismatch: $name"
        }
        if (@($semanticEntry.assignment_changes).Count -ne [int]$entry.assignment_fixes) {
            throw "Backup semantic assignment-list count mismatch: $name"
        }
    }
}

$ExpectedFiles = @(
    '41CBED6F8786674A7378E12460C9D1048AE9.json.js',
    '5D77860A40DEA14D006A7B84567F8E48F035.json.js',
    '63CBFF694B300540D51B6EF7C54CFCAE65F8.json.js',
    '6B404F6014C1D644FF491FA77838BC0B8A54.json.js',
    '7C2EE73472D001426498205105734B41E32B.json.js',
    '7C550F5815B42142530BAAB7872310C75643.json.js',
    'AF397EDA18EDD145F59B4D00BB37193351D2.json.js',
    'C0DA75809B5B644024290C22C69B1F0AEDAA.json.js',
    'CC252A043238154CF30A8B365C570C7918F2.json.js',
    'DED5468F8AC8C746CC39999179146FDA82F9.json.js',
    'E7C324D26C5CE349846A5F2459608AEAA70F.json.js',
    'FB98203B89D57842D30B8D07EFDF5D2F98DB.json.js'
)

$backupResolved = (Resolve-Path -LiteralPath $BackupDir).Path
$gameResolved = (Resolve-Path -LiteralPath $GameDataDir).Path
Assert-GameDataPath $gameResolved
if (Test-IsSameOrChildPath $backupResolved $gameResolved) { throw 'BackupDir must be outside GameDataDir.' }
$manifestPath = Join-Path $backupResolved 'patch_manifest.json'
$semanticManifestPath = Join-Path $backupResolved 'semantic_manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf) -or -not (Test-Path -LiteralPath $semanticManifestPath -PathType Leaf)) {
    throw 'Backup install/semantic manifest is missing.'
}
$manifestHash = Get-Sha256 $manifestPath
$semanticManifestHash = Get-Sha256 $semanticManifestPath
if ($manifestHash -ne $ExpectedInstallManifestSha256) { throw 'Backup install manifest does not match the approved release.' }
if ($semanticManifestHash -ne $ExpectedSemanticManifestSha256) { throw 'Backup semantic manifest does not match the approved release.' }
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$semanticManifest = Get-Content -LiteralPath $semanticManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-ManifestBinding $manifest $semanticManifest
$files = @($manifest.files)
if ($files.Count -ne [int]$manifest.total_files -or $files.Count -ne 12) { throw 'Backup manifest file count mismatch.' }
if ([int]$manifest.total_items -ne 181 -or [int]$manifest.total_descriptions -ne 392 -or [int]$manifest.total_assignment_fixes -ne 2) { throw 'Backup manifest item/description/fix totals mismatch.' }
if (@($files.filename | Sort-Object -Unique).Count -ne $files.Count) { throw 'Backup manifest contains duplicate filenames.' }
if (($files | Measure-Object -Property descriptions -Sum).Sum -ne [int]$manifest.total_descriptions) { throw 'Backup description count mismatch.' }
if (($files | Measure-Object -Property assignment_fixes -Sum).Sum -ne [int]$manifest.total_assignment_fixes) { throw 'Backup assignment-fix count mismatch.' }
$manifestNames = @($files | ForEach-Object { [string]$_.filename } | Sort-Object)
$expectedNames = @($ExpectedFiles | Sort-Object)
if ((Compare-Object -ReferenceObject $expectedNames -DifferenceObject $manifestNames).Count -ne 0) { throw 'Backup file allowlist mismatch.' }
if ([string]$manifest.provenance.language_qa_status -ne 'pass' -or [int]$manifest.provenance.crossreview_corrections -ne 38) { throw 'Backup provenance status mismatch.' }
if (([string]$manifest.provenance.translation_map_sha256).ToUpperInvariant() -ne $ExpectedTranslationMapSha256) { throw 'Backup translation-map release hash mismatch.' }
if (([string]$manifest.provenance.final_language_qa_sha256).ToUpperInvariant() -ne $ExpectedLanguageQaSha256) { throw 'Backup language-QA release hash mismatch.' }

# Full restore preflight before any write. A prior interrupted install may have
# left an exact mixture of original and patched hashes; both are recoverable.
foreach ($entry in $files) {
    $name = [string]$entry.filename
    if ([System.IO.Path]::GetFileName($name) -ne $name) { throw "Unsafe manifest filename: $name" }
    $backup = Join-Path $backupResolved $name
    $target = Join-Path $gameResolved $name
    if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw "Backup file missing: $name" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Game file missing: $name" }
    if ((Get-Sha256 $backup) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Backup hash mismatch: $name" }
    $targetHash = Get-Sha256 $target
    $currentHash = ([string]$entry.current_sha256).ToUpperInvariant()
    $fixedHash = ([string]$entry.fixed_sha256).ToUpperInvariant()
    if ($targetHash -ne $currentHash -and $targetHash -ne $fixedHash) { throw "Live game has an unknown hash: $name" }
}
if ((Get-Sha256 $manifestPath) -ne $manifestHash) { throw 'Backup manifest changed after validation.' }
if ((Get-Sha256 $semanticManifestPath) -ne $semanticManifestHash) { throw 'Backup semantic manifest changed after validation.' }
Assert-GameStopped

$rollbackDir = Join-Path $backupResolved ('.restore_rollback_' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $rollbackDir | Out-Null
$preRestoreHashes = @{}
$preserveRollback = $false
try {
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        $preRestoreHashes[$name] = Get-Sha256 (Join-Path $gameResolved $name)
        $rollbackFile = Join-Path $rollbackDir $name
        [System.IO.File]::Copy((Join-Path $gameResolved $name), $rollbackFile, $false)
        if ((Get-Sha256 $rollbackFile) -ne $preRestoreHashes[$name]) { throw "Restore rollback snapshot failed: $name" }
    }
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        $target = Join-Path $gameResolved $name
        $targetHash = Get-Sha256 $target
        $currentHash = ([string]$entry.current_sha256).ToUpperInvariant()
        $fixedHash = ([string]$entry.fixed_sha256).ToUpperInvariant()
        if ($targetHash -eq $fixedHash) {
            Install-Atomic -Source (Join-Path $backupResolved $name) -Target $target -ExpectedSourceHash $currentHash -ExpectedCurrentHash $fixedHash
        }
        elseif ($targetHash -ne $currentHash) {
            throw "Target changed during restore: $name"
        }
    }
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        if ((Get-Sha256 (Join-Path $gameResolved $name)) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Post-restore verification failed: $name" }
    }
}
catch {
    $restoreError = $_.Exception.Message
    $rollbackErrors = New-Object System.Collections.Generic.List[string]
    foreach ($name in @($preRestoreHashes.Keys)) {
        $entry = $files | Where-Object { $_.filename -eq $name } | Select-Object -First 1
        try {
            $target = Join-Path $gameResolved $name
            $targetHash = Get-Sha256 $target
            $desiredHash = [string]$preRestoreHashes[$name]
            if ($targetHash -ne $desiredHash) {
                $rollbackFile = Join-Path $rollbackDir $name
                if (-not (Test-Path -LiteralPath $rollbackFile -PathType Leaf)) { throw "Rollback snapshot missing: $name" }
                Install-Atomic -Source $rollbackFile -Target $target -ExpectedSourceHash $desiredHash -ExpectedCurrentHash $targetHash
            }
        }
        catch { $rollbackErrors.Add("$name`: $($_.Exception.Message)") }
    }
    if ($rollbackErrors.Count -gt 0) {
        $preserveRollback = $true
        throw "Restore failed and rollback was incomplete; snapshots preserved at $rollbackDir`: $restoreError | $($rollbackErrors -join ' | ')"
    }
    throw "Restore rolled back to the patched state: $restoreError"
}
finally {
    if (-not $preserveRollback -and (Test-Path -LiteralPath $rollbackDir)) {
        Get-ChildItem -LiteralPath $rollbackDir -File | Remove-Item -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $rollbackDir -Force -ErrorAction SilentlyContinue
    }
}

[ordered]@{
    status = 'restored'
    restored_at = (Get-Date).ToString('o')
    game_data_dir = $gameResolved
    backup_dir = $backupResolved
    files = $files.Count
    items = [int]$manifest.total_items
    descriptions = [int]$manifest.total_descriptions
    assignment_fixes = [int]$manifest.total_assignment_fixes
} | ConvertTo-Json -Depth 5
