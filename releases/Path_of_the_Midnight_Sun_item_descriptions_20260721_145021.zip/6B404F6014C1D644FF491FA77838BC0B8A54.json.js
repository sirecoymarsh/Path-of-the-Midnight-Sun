GS.dataCache['6B404F6014C1D644FF491FA77838BC0B8A54'] = {
    "uid": "6B404F6014C1D644FF491FA77838BC0B8A54",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Genera Dati Asce",
        "type": "data_record",
        "order": 7,
        "category": "commonEvents",
        "id": "6B404F6014C1D644FF491FA77838BC0B8A54",
        "isFolder": false,
        "data": {
            "name": "Genera Dati Asce",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [],
            "commands": [
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "O\nG\nG\nE\nT\nT\nI"
                    },
                    "indent": 0,
                    "uid": "193A9AED40D9A7466F582661CB221DF94A1E",
                    "expanded": true
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "77EA9FA214C7C74D5E08F7A253D6ABA6CECB",
                                "Graphics/Kath's UI/Inventory Icons/Cristoph’s axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9E219E607E9E12498E8BB965860AF2D9227B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7F40EE0E719B4449878A8BD7637D85550238",
                            "defaultText": "수많은 기묘한 전투를"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5717D0A11F792843F95AC6A2396CB10ADDD9",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "77EA9FA214C7C74D5E08F7A253D6ABA6CECB",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5855DEC30C59B643037AAD16598791BE2130"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ECC88109133D68467329CA55A0B484068C85",
                            "defaultText": "겪어 온 도끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CEFA25C65D1FA044BC5AE8E168FD50ABC096",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "77EA9FA214C7C74D5E08F7A253D6ABA6CECB",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "56E30A5E3941A9495718CF8877BFE6E5BCEE"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "9E0B251C287FA74EC14B84D59CC6EED519FC",
                                "Graphics/Kath's UI/Inventory Icons/Iron Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AC60BA8534F0D74AB9590695A62534B9858C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7677AA8D7058094FA02A22C4991CBF774163",
                            "defaultText": "나무를 패는 도끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2F51AA615829C740F71803B2E2736041F82F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9E0B251C287FA74EC14B84D59CC6EED519FC",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "30EA2CCA15EBD641738A6AD691DE89FF0BA9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9239F06C7FE98242A06AA916DD192D45742F",
                            "defaultText": "적도 팬다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "534C2B771AAA2848587810E11E051A15E424",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9E0B251C287FA74EC14B84D59CC6EED519FC",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FFADFFA87974E54BF55AEBB43B280E1565BB"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "B89D72907266F5414039A784B2953CD521AB",
                                "Graphics/Kath's UI/Inventory Icons/Iron Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3DB8674A64E90645017B48B092F703FDE578"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "BFBE5DD334C63340775A56530B16A49FDEB3",
                            "defaultText": "나무를 패는 도끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6C083C3532D2E44DF62A57D7DDEB9A47C02C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "B89D72907266F5414039A784B2953CD521AB",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8C5C6A3F914B134DD84859D0BD16B4794F14"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D9919B9F0D042649BB1944534B8E6EEEF502",
                            "defaultText": "죄인도 팬다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B433C8313D50D04EEF89378037D6A60B8CDF",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "B89D72907266F5414039A784B2953CD521AB",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "99C1F74547A8F84CB69A1A437BE1A340CD97"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "65DCBED348CB784CA06B9CC6E0E6C4FCA9A7",
                                "Graphics/Kath's UI/Inventory Icons/Killer Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B01D32F03B77694BC22AF746BC188E79EA9F"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F75DD19D50B9F4412D6A0F0190C0DE8DA502",
                            "defaultText": "치명타율을 높인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B40EB5FE380E634382587743C24290B021F8",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "65DCBED348CB784CA06B9CC6E0E6C4FCA9A7",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C6C725C11FB2B44A913935F32ADB933F0C3B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C8F872438EF5254819793C870453FF3C4B35",
                            "defaultText": "위험해 보인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "679EDF3397D2774E4D586844840EE16E402C",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "65DCBED348CB784CA06B9CC6E0E6C4FCA9A7",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1917666226A91246CD78FF92BE22D47352A7"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "F82B4D294286A34559693370567542EFB179",
                                "Graphics/Kath's UI/Inventory Icons/Killer Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9F63F778306C8745B92AB41736FA9FA076CF"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E65463DC5DBAB24FFC795281440AB76F1F2D",
                            "defaultText": "치명타율을 높인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "14B780B91A9C6740F9688C242B0287A0F4CA",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F82B4D294286A34559693370567542EFB179",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "35C626AB28C1D944BD3BF73448B213E2B8EE"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "2A2B9544802B8643F47A49F15B62B71C22CD",
                            "defaultText": "아주 위험하다!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "62C3740D2759B145FD58A98182E79DF044B7",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "F82B4D294286A34559693370567542EFB179",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5ACFE25D2B16E84F40387D95DEFAFBBE803C"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "BCDAC8365427234CAA3B72B5EF7975C59C0B",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5C53EF7C8280724DF82ACB82948C63885281"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E48F839242CA9345FF69AC44C8605D8016B1",
                            "defaultText": "희귀한 도끼. 어쩌면"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E013E5A22E8C274A325BF035286FD96E50B5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BCDAC8365427234CAA3B72B5EF7975C59C0B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7B661AF6530302444768D4506D6B9E7F6DFA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D7542A302E3FF7454C38E459609B594AA0FB",
                            "defaultText": "크리스토프에겐 과분하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0343E6026963894F982B1843910C0AC351BB",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "BCDAC8365427234CAA3B72B5EF7975C59C0B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "375F788A30F80741088A6DF1D5AD233BBE35"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "67CA10947F93B5430E597EC42B27731559D8",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ABBAAE2B7694914F3A7BD782D06BBAC9406B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7D732B611AC5E242406AF27779D636D0ED8D",
                            "defaultText": "희귀한 도끼. 분명"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "190ABAF5665F614B868A4C456B7FE6D38102",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "67CA10947F93B5430E597EC42B27731559D8",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BE8128693177D8457D3B97138B5A05DB5262"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "271C463663D9B64F2219EBB519FBF3D2DBA0",
                            "defaultText": "크리스토프에겐 과분하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "605A97E0473C32445B8AC7C1CCD49AD72256",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "67CA10947F93B5430E597EC42B27731559D8",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DFC4D0EA31B50343123A16A2D414542C96C4"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "2924B1C6786BF7463238F5F4EE22167138A3",
                                "Graphics/Kath's UI/Inventory Icons/Magic Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E50DB49861CA9447F53BB312FC952BD23DB3"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "C3F617A45AD1F947DE8AB59341AFF655CA8A",
                            "defaultText": "발론자께 감사하자."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2C45E2B7176C614B1E6BF488AFC563E10555",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "2924B1C6786BF7463238F5F4EE22167138A3",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "149D4B597CE86843A27842E7A1A897235DCC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "87AAF2B36817E0417549F1979769609971AC",
                            "defaultText": "크리스토프의 마나 고민을 덜어 준다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A0D6681C9C7586488089B4B32A74C383F91D",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "2924B1C6786BF7463238F5F4EE22167138A3",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FD5D78C96E6C124BFE28BA34666DEC8ADBFA"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "63772A558702F54F7B4A84E37EA2D38A4BC2",
                                "Graphics/Kath's UI/Inventory Icons/Magic Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2E3914926390044A3E7A3159BB77F908C3CD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "F8B51944214C624DAA8B01959D76B54CA086",
                            "defaultText": "발론자께 감사하자."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A6FEBDDA6527C241A25BBB370D24527D2029",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "63772A558702F54F7B4A84E37EA2D38A4BC2",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "727AF4242CE6154531490060C0B642C5A860"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "8989F79A1CA86142D77A2483F75CDEE8CFE4",
                            "defaultText": "크리스토프의 마나 고민을 해결한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "81A87E845FEC0643222A8B6153E520EED5D5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "63772A558702F54F7B4A84E37EA2D38A4BC2",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C852C31C788D404C4778F037CDA5A535DCE4"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "324274890E0E5240888BEC16C45885C3F312",
                                "Graphics/Kath's UI/Inventory Icons/Conjurer Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FA07E4D971A9F740231B41240E5F9FC1026C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "D1B055437E20D74C6B1BDE47F9766ABAB828",
                            "defaultText": "상태 이상 부여 확률이 10%"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "AC702DFB4B0EE64ED0385919CE34992F5A2A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "324274890E0E5240888BEC16C45885C3F312",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1D009B254441B343C63A376181EE0FFB8AC2"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B3B9318171D4E24D469AB9C2DFF2DB766DD9",
                            "defaultText": "증가한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3EE8E2664EA414A32492661C144CFA9EE79",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "324274890E0E5240888BEC16C45885C3F312",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4C1D67777F1641496E6BF328FDD9482CD68B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "0AE32A521F5D92483F79A4D57C9B194C7B53",
                                "Graphics/Kath's UI/Inventory Icons/Conjurer Axe.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FB84C10C7D92C74A3F884479C8A48AAD044D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1CED27224257464F455ADE1247913A1099C9",
                            "defaultText": "상태 이상 부여 확률이 20%"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BD35DF8F3E06A1429F4BBCB184AED5BE8C3E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0AE32A521F5D92483F79A4D57C9B194C7B53",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0FB9C74D7763C7427A88B7171FACE5F1F15C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6C8F08E059A6D24EA60BE1786BD9148C7775",
                            "defaultText": "증가한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "647FCBB68829E54FEB48F561934ECF359D19",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "0AE32A521F5D92483F79A4D57C9B194C7B53",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0BB1B8B25894654CDB4A7E12C0A47A4D220B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "AED1869D8C3DF64DE168122649A88DB8E410",
                                "Graphics/Kath's UI/Inventory Icons/Garm.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "92414B008189974FEC797496DB7356F26E9E"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "771936043B8373436E6AE17110DD702A748B",
                            "defaultText": "악을 멸하는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "57AE186E9C4BB74C95780262BE43C091D98A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "AED1869D8C3DF64DE168122649A88DB8E410",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3BD56DD8CA69944557839C95EC14658B5D4"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "17C25DA038BC6246E459AE869409B67020B6",
                            "defaultText": "이계의 도끼."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4F9A0E964DFFA44D5C7BE0379260BB549668",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "AED1869D8C3DF64DE168122649A88DB8E410",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5140F9719E6D5242EC1AC3130792F700960D"
                }
            ],
            "index": "6B404F6014C1D644FF491FA77838BC0B8A54",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "Desc 1",
                    "index": 0,
                    "scope": 0
                },
                {
                    "name": "Desc 2",
                    "index": 1,
                    "scope": 1
                },
                {
                    "name": "Desc 3",
                    "index": 2,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "7F40EE0E719B4449878A8BD7637D85550238": {
                "t": "An axe that has seen",
                "d": {
                    "eid": "5717D0A11F792843F95AC6A2396CB10ADDD9"
                }
            },
            "ECC88109133D68467329CA55A0B484068C85": {
                "t": "many weird battles.",
                "d": {
                    "eid": "CEFA25C65D1FA044BC5AE8E168FD50ABC096"
                }
            },
            "7677AA8D7058094FA02A22C4991CBF774163": {
                "t": "Used to chop wood.",
                "d": {
                    "eid": "2F51AA615829C740F71803B2E2736041F82F"
                }
            },
            "9239F06C7FE98242A06AA916DD192D45742F": {
                "t": "And enemies.",
                "d": {
                    "eid": "534C2B771AAA2848587810E11E051A15E424"
                }
            },
            "BFBE5DD334C63340775A56530B16A49FDEB3": {
                "t": "Used to chop wood.",
                "d": {
                    "eid": "6C083C3532D2E44DF62A57D7DDEB9A47C02C"
                }
            },
            "D9919B9F0D042649BB1944534B8E6EEEF502": {
                "t": "And sinners.",
                "d": {
                    "eid": "B433C8313D50D04EEF89378037D6A60B8CDF"
                }
            },
            "F75DD19D50B9F4412D6A0F0190C0DE8DA502": {
                "t": "Enhances Crit.",
                "d": {
                    "eid": "B40EB5FE380E634382587743C24290B021F8"
                }
            },
            "C8F872438EF5254819793C870453FF3C4B35": {
                "t": "Seems dangerous.",
                "d": {
                    "eid": "679EDF3397D2774E4D586844840EE16E402C"
                }
            },
            "E65463DC5DBAB24FFC795281440AB76F1F2D": {
                "t": "Enhances Crit.",
                "d": {
                    "eid": "14B780B91A9C6740F9688C242B0287A0F4CA"
                }
            },
            "2A2B9544802B8643F47A49F15B62B71C22CD": {
                "t": "Very dangerous!",
                "d": {
                    "eid": "62C3740D2759B145FD58A98182E79DF044B7"
                }
            },
            "E48F839242CA9345FF69AC44C8605D8016B1": {
                "t": "Rare axe, perhaps too",
                "d": {
                    "eid": "E013E5A22E8C274A325BF035286FD96E50B5"
                }
            },
            "D7542A302E3FF7454C38E459609B594AA0FB": {
                "t": "valuable for Cristoph.",
                "d": {
                    "eid": "0343E6026963894F982B1843910C0AC351BB"
                }
            },
            "7D732B611AC5E242406AF27779D636D0ED8D": {
                "t": "Rare axe, surely too",
                "d": {
                    "eid": "190ABAF5665F614B868A4C456B7FE6D38102"
                }
            },
            "271C463663D9B64F2219EBB519FBF3D2DBA0": {
                "t": "valuable for Cristoph.",
                "d": {
                    "eid": "605A97E0473C32445B8AC7C1CCD49AD72256"
                }
            },
            "C3F617A45AD1F947DE8AB59341AFF655CA8A": {
                "t": "Thank Valonja, it helps",
                "d": {
                    "eid": "2C45E2B7176C614B1E6BF488AFC563E10555"
                }
            },
            "87AAF2B36817E0417549F1979769609971AC": {
                "t": "Cristoph's Mana issues.",
                "d": {
                    "eid": "A0D6681C9C7586488089B4B32A74C383F91D"
                }
            },
            "F8B51944214C624DAA8B01959D76B54CA086": {
                "t": "Thank Valonja, it fixes",
                "d": {
                    "eid": "A6FEBDDA6527C241A25BBB370D24527D2029"
                }
            },
            "8989F79A1CA86142D77A2483F75CDEE8CFE4": {
                "t": "Cristoph's Mana issues.",
                "d": {
                    "eid": "81A87E845FEC0643222A8B6153E520EED5D5"
                }
            },
            "D1B055437E20D74C6B1BDE47F9766ABAB828": {
                "t": "10% extra chance",
                "d": {
                    "eid": "AC702DFB4B0EE64ED0385919CE34992F5A2A"
                }
            },
            "B3B9318171D4E24D469AB9C2DFF2DB766DD9": {
                "t": "to inflict statuses.",
                "d": {
                    "eid": "E3EE8E2664EA414A32492661C144CFA9EE79"
                }
            },
            "1CED27224257464F455ADE1247913A1099C9": {
                "t": "20% extra chance",
                "d": {
                    "eid": "BD35DF8F3E06A1429F4BBCB184AED5BE8C3E"
                }
            },
            "6C8F08E059A6D24EA60BE1786BD9148C7775": {
                "t": "to inflict statuses.",
                "d": {
                    "eid": "647FCBB68829E54FEB48F561934ECF359D19"
                }
            },
            "771936043B8373436E6AE17110DD702A748B": {
                "t": "Otherworldy axe,",
                "d": {
                    "eid": "57AE186E9C4BB74C95780262BE43C091D98A"
                }
            },
            "17C25DA038BC6246E459AE869409B67020B6": {
                "t": "evil's bane.",
                "d": {
                    "eid": "4F9A0E964DFFA44D5C7BE0379260BB549668"
                }
            }
        },
        "parentId": "8A7A025317CD78422148C8F665F1528EFA9E"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}