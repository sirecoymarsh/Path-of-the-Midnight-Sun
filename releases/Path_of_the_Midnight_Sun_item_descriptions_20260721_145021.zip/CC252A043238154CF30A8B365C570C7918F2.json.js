GS.dataCache['CC252A043238154CF30A8B365C570C7918F2'] = {
    "uid": "CC252A043238154CF30A8B365C570C7918F2",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Genera Dati Key Items",
        "type": "data_record",
        "order": 16,
        "category": "commonEvents",
        "id": "CC252A043238154CF30A8B365C570C7918F2",
        "isFolder": false,
        "data": {
            "name": "Genera Dati Key Items",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [],
            "commands": [
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "O\nG\nG\nE\nT\nT\nI"
                    },
                    "indent": 0,
                    "uid": "193A9AED40D9A7466F582661CB221DF94A1E",
                    "expanded": true
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "AF156FD61C1BB6478E8AC202FCDDB7047CAA",
                                "Graphics/Kath's UI/Inventory Icons/Old Scroll.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "164EA96614195146D9891885F581B8BE634C"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "DA12294B7DD5F149D11B73199861C80CBCD4",
                            "defaultText": "시처럼 보인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C01C94172526C44FE258F872205862CD4DAE",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "AF156FD61C1BB6478E8AC202FCDDB7047CAA",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A092BB993016454A7F4B46F263450E1276BC"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3B65BB1E91CC1241B33BE474AD522AC7D174",
                            "defaultText": "아닌가...?"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9D358F4F405491433A9925C899ADB3E96319",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "AF156FD61C1BB6478E8AC202FCDDB7047CAA",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "B3102B8D11FF92404D193C45A055D3268F70"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Desc 3",
                            "index": 2,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ABEDD7BE86D2F142C68BA774038527822150",
                            "defaultText": "칼레발라에게 돌려주자."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C220E4261F92D34A377A3349AC84FEAAB6C8",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "AF156FD61C1BB6478E8AC202FCDDB7047CAA",
                        "param": {
                            "name": "Descrizione 3",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "Desc 3",
                            "index": 2,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A5F37F438691374C1698A3951428B1FADBEC"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "3418E1FB8BD7C845011A20C0C7D686BDF59E",
                                "Graphics/Kath's UI/Inventory Icons/Old Keys.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EC91D359678E1445D7583742017826A0AA8A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "AE3AEA965E02B746918851F7F6A5F57DAFCE",
                            "defaultText": "방에 있는 상자를"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "76648B8185A062456C99C35956DF49D8EB46",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3418E1FB8BD7C845011A20C0C7D686BDF59E",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A0645D04846EB945465A28225A5BD9DE22EA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "B5C4782828A80148062B1C47B6368F514CF7",
                            "defaultText": "여는 열쇠 꾸러미."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A222085E5CFED0413889029900A532324914",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3418E1FB8BD7C845011A20C0C7D686BDF59E",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FE2C20A00A10A148F68B3A0416CCB931B67D"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "Desc 3",
                            "index": 2,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "138BEE1A2B9CA243A70A7CE297AEBCF62D57",
                            "defaultText": "묘한 냄새가 난다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "CFD827825A4A1649C61B1B9889F910700E1A",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3418E1FB8BD7C845011A20C0C7D686BDF59E",
                        "param": {
                            "name": "Descrizione 3",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "Desc 3",
                            "index": 2,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "51FCB75B696A3343280958D8525EC28B0F0A"
                }
            ],
            "index": "CC252A043238154CF30A8B365C570C7918F2",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "Desc 1",
                    "index": 0,
                    "scope": 0
                },
                {
                    "name": "Desc 2",
                    "index": 1,
                    "scope": 1
                },
                {
                    "name": "Desc 3",
                    "index": 2,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "DA12294B7DD5F149D11B73199861C80CBCD4": {
                "t": "It seems like a poem.",
                "d": {
                    "eid": "C01C94172526C44FE258F872205862CD4DAE"
                }
            },
            "3B65BB1E91CC1241B33BE474AD522AC7D174": {
                "t": "Or maybe not...?",
                "d": {
                    "eid": "9D358F4F405491433A9925C899ADB3E96319"
                }
            },
            "ABEDD7BE86D2F142C68BA774038527822150": {
                "t": "Return it to Kalevala.",
                "d": {
                    "eid": "C220E4261F92D34A377A3349AC84FEAAB6C8"
                }
            },
            "AE3AEA965E02B746918851F7F6A5F57DAFCE": {
                "t": "Keys for a chest in",
                "d": {
                    "eid": "76648B8185A062456C99C35956DF49D8EB46"
                }
            },
            "B5C4782828A80148062B1C47B6368F514CF7": {
                "t": "your room. They",
                "d": {
                    "eid": "A222085E5CFED0413889029900A532324914"
                }
            },
            "138BEE1A2B9CA243A70A7CE297AEBCF62D57": {
                "t": "have an odd smell.",
                "d": {
                    "eid": "CFD827825A4A1649C61B1B9889F910700E1A"
                }
            }
        },
        "parentId": "8A7A025317CD78422148C8F665F1528EFA9E"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}