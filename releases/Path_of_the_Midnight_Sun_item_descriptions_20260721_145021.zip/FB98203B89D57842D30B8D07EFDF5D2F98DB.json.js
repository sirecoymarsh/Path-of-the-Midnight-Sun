GS.dataCache['FB98203B89D57842D30B8D07EFDF5D2F98DB'] = {
    "uid": "FB98203B89D57842D30B8D07EFDF5D2F98DB",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Genera Dati Spade",
        "type": "data_record",
        "order": 5,
        "category": "commonEvents",
        "id": "FB98203B89D57842D30B8D07EFDF5D2F98DB",
        "isFolder": false,
        "data": {
            "name": "Genera Dati Spade",
            "startCondition": 0,
            "conditionEnabled": false,
            "parallel": false,
            "autoPreload": false,
            "singleInstance": false,
            "inline": false,
            "parameters": [],
            "commands": [
                {
                    "id": "gs.Comment",
                    "params": {
                        "text": "O\nG\nG\nE\nT\nT\nI"
                    },
                    "indent": 0,
                    "uid": "193A9AED40D9A7466F582661CB221DF94A1E",
                    "expanded": true
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "16E279EC76965648138820D4AE82FED75F6D",
                                "Graphics/Kath's UI/Inventory Icons/Ornieres Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E61B571A4045F348EF4ADE7372BA07C026C7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "25F32D4D7DA342427949FD25D13C7801E485",
                            "defaultText": "오르니에르 경이 쓰던 검."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4686F95E1E9E6447934841075376B1E44A7B",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "16E279EC76965648138820D4AE82FED75F6D",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C3AA528F5053804AEF88F764B7D8619D4B16"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6DAF25474B24C8458878629382C28258E27B",
                            "defaultText": "문득 향수를 불러일으킨다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3E5DE5E025E7C74BA758BCE9610C97A94239",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "16E279EC76965648138820D4AE82FED75F6D",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "97D8EBDA95DB974C1838ABC9A144EF177F45"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FE39EED41BEB7046655808019153972819BC",
                                "Graphics/Kath's UI/Inventory Icons/Hellios Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "907D0F9C214861408388A5C82E66415975C0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1965885F75B2584B2D4AD3012F24DF37ECE6",
                            "defaultText": "차원마저 가르는"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C9F60A3B40B5D740616850707CC4804B4523",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FE39EED41BEB7046655808019153972819BC",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "1E8BD8982E3BB449D31AC383AC7FA8389C53"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "EED84A383112184AF118AA127F0C449063DF",
                            "defaultText": "이계의 검."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7C75FBB95CE7574C6E3980A406F0D074ECD6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FE39EED41BEB7046655808019153972819BC",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FB780F673D0F3642902AB2F395F59805E971"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "25BADC707F4B73415258EA98362E6958770B",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8BFCE63A3D553349E6693401ECB374E9C270"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1D8D09134DEDD34B4B48EE54F2FF32DFC71D",
                            "defaultText": "튼튼해서 가난한 병사들이"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6C6D3D9F461EB6456C4BF594956AE550236B",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "25BADC707F4B73415258EA98362E6958770B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E1526A590924A4491249E2D7B827CC4E2B7B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "92FE0BC71A79894DEE3A5CF3517769F55EB5",
                            "defaultText": "주로 쓰는 검."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F35FDF880ADC5846427ABB997BE8D303CC93",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "25BADC707F4B73415258EA98362E6958770B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0E2935E2108C4647B31B5BE3D0D530EC9A5B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "FF8A0EF7844876459E8AC032E19770DB2F32",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D934B5563A28A44A335B8B39F613C8FD14FB"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9CF65DE673865342D95A2903960E2DE1A641",
                            "defaultText": "튼튼해서 많은 병사들이"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "61CD03B224617646C18A78B5CE03D449C66F",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FF8A0EF7844876459E8AC032E19770DB2F32",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9DCDE3492505D242FC79E6F7E3CFFD93D6B6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "ADD0D59D17FD84419F393149AD0B6FBCD1A3",
                            "defaultText": "즐겨 쓰는 검."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "0DA5C5922ED4274368495EE18CB7C857D1EF",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "FF8A0EF7844876459E8AC032E19770DB2F32",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "9B056AEF4DF40242217A9752B8975AA2B6A0"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "D91576FA49556245E52B5A44D7C65D29C58F",
                                "Graphics/Kath's UI/Inventory Icons/Iron Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BA3193F7672011410B89C5C6DCCA385711A0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "81D558836B8E2547160877C2D3F6BA83803D",
                            "defaultText": "날이 선 무기."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "82B01F606C1F9645D0489100CE074778CA1D",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "D91576FA49556245E52B5A44D7C65D29C58F",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6DBE8C8625BD61458889F25620D073AD0E74"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1308ACB73F3E614BFA48FF31D68A729754C9",
                            "defaultText": "사람을 죽인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F1A9C8671AA58948F19B18935BD3A000052E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "D91576FA49556245E52B5A44D7C65D29C58F",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "631C56988D92C147096B4E288DE7DDFE6551"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "6CACFDEF74BF114B595AF7D19FC3EDE625F3",
                                "Graphics/Kath's UI/Inventory Icons/Iron Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "200CE9F52953D3464E7B86E6417FE0CF3043"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "610D345752CED34DDA58EEA7BC8AC92AF734",
                            "defaultText": "날이 선 무기."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F714166D4DF6A346F35BE301B80D351046F0",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6CACFDEF74BF114B595AF7D19FC3EDE625F3",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ADECEF0C45E63141291BE45611FAB24995F1"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "3807403462AAE84CF25B42E02CFC2BDADA1B",
                            "defaultText": "사람을 죽인다!!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A08AD08C4535464A71181007AFE52AD34710",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6CACFDEF74BF114B595AF7D19FC3EDE625F3",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "7C3109293DCFC746221A2013FE2BF30B8004"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "3B0CC1DC3A5686405B19B414D254FE0FB1D1",
                                "Graphics/Kath's UI/Inventory Icons/Killer Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "77D1C23A6B7746472E0BEF654C52A497C4B6"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A218394E835CE345935B34D37F44507EA9FF",
                            "defaultText": "치명타율을 높인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "55F9C4802384824021882AB3578131FFDEC6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3B0CC1DC3A5686405B19B414D254FE0FB1D1",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "48F6FB3949312841AB5B43E8D98D8399513A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9A7119C40DFAF34D602B95C34FD8FFEC6EC7",
                            "defaultText": "좀 치명적이다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D8E6E38D153AE542950AA9882B810865DB60",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "3B0CC1DC3A5686405B19B414D254FE0FB1D1",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6087D8D989751042105BBD139455D77913F0"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "C6D1445F4CA9C34C1C7A6D692C4EDB45AEC8",
                                "Graphics/Kath's UI/Inventory Icons/Killer Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E6E4D82B2CEE1642191BC639182C6EDD8B36"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0EB58CEC66F92949B14BEC48594271354D4B",
                            "defaultText": "치명타율을 높인다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3ED56AB94C08174EC62B72E78AA7D7EC6245",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C6D1445F4CA9C34C1C7A6D692C4EDB45AEC8",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "42D9C5A35FC7C342482AB4217377BE7A02D0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "A973D1D2392E9645B408EA617401BEAFEC6A",
                            "defaultText": "아주 치명적이다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8D21AEF994401840F128D0C1F6CCFA0DE6DC",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "C6D1445F4CA9C34C1C7A6D692C4EDB45AEC8",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "ACE5E9553A79544D0C18B217FB11DC0FA230"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "35E7299A287587446A4AD6D2044690237C90",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "96EA96DD2E90094DFD7978E365F77A306CB7"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "941CA61C2CB1334B6A3BEA1539A9D9243EAF",
                            "defaultText": "희귀한 검. 어쩌면"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "29ECF4506D47C44A013889E90DAE4E55FA32",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "35E7299A287587446A4AD6D2044690237C90",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "197FB81C1FAE8844952A26145C662DDC2BCA"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "7DA8028E3543854F091849046FC5F1FFB834",
                            "defaultText": "값어치는 할지도 모른다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "184549684D5AB647781AE997924A82F00511",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "35E7299A287587446A4AD6D2044690237C90",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E32123B5593D074ADC395491B8F96D71E7D7"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "61DD9E108F9900450158BDD85229904EDCEF",
                                "Graphics/Kath's UI/Inventory Icons/Mythril Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3CB2421A0A63A344BE6A2D36D06FFE3BF4B0"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "52C1B33198FBD94C451933E4B11DEA356CAD",
                            "defaultText": "희귀한 검."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A92F485830A9234B96299E085696701240CB",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "61DD9E108F9900450158BDD85229904EDCEF",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "224E8D14889B784F2078067831EA41BCD766"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "19B1818D1EB6E3477D0B76741C2BCB25DEB3",
                            "defaultText": "제값은 확실히 한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "23A07E751B72424E5198B8F3E3952E9FFCBF",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "61DD9E108F9900450158BDD85229904EDCEF",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6DA04566068A024EF338F6061287202B0BA9"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "6BA079671A75924DF2088566F587FCFA8F0D",
                                "Graphics/Kath's UI/Inventory Icons/Magic Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "DCD503534CBE294B3C2B96169BF1BA7ECA7B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "97E8A0AA7E0C41421B4AA2C27D8435861685",
                            "defaultText": "이걸 들고 있으면"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C6DDB1CF9F5A374B7C7BBB24273A9797FB80",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6BA079671A75924DF2088566F587FCFA8F0D",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "4625C2B500938142612A61870A7266EDC65B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "6E4F78747C4F58499248CF771E20E69E63C1",
                            "defaultText": "제법 특별해진 기분이 든다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "C6ABCDEB914C67412319F356F8C58A9EA15E",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "6BA079671A75924DF2088566F587FCFA8F0D",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "949034AE4EE4A943B6981D55F18F75C53799"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "1C6017A3325EB949FF99DEB7AFADE5B35FDD",
                                "Graphics/Kath's UI/Inventory Icons/Magic Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "85B29BF09F38884FEE0AA29291E4499BB55B"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "120B5B3F4EACB243473BE0B201C7087F0504",
                            "defaultText": "이걸 들고 있으면"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "2DFC93065C5BF34C5A7801C79339CAF30666",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "1C6017A3325EB949FF99DEB7AFADE5B35FDD",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FFE3B81611FC34487658FE17FBADCC14C29A"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "89C5006F8C57744E77286BC1713B8293338D",
                            "defaultText": "정말 특별해진 기분이 든다!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "15C7BF8270A1E149947875E266B95B6F10D3",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "1C6017A3325EB949FF99DEB7AFADE5B35FDD",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "F7C5E2EB5963D2465C89F9B0760247453AFA"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "4013C0C989F33340000AC38796E7C78B71C1",
                                "Graphics/Kath's UI/Inventory Icons/Conjurer Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "BEB7E72C3E963943D428B921A2D0A0018DC9"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9F2CD7E978A855416D4ABF733D518D19ADFA",
                            "defaultText": "상태 이상 부여 확률이 10%"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EA17880D7EA7664A9B6A4C37D11F3D998423",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4013C0C989F33340000AC38796E7C78B71C1",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "464734DE7086384C16396C452AFCCA73AE02"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "261E97B06ADC584C8A3BBF30E0E75964AC41",
                            "defaultText": "증가한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "6D74ECD94FE6E4452F195B57830ADD1ED646",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4013C0C989F33340000AC38796E7C78B71C1",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "EF489F3247BA334B7D7B8D54AD68A72F752A"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "9034D21566F44146AD1975725B4786D8DBBD",
                                "Graphics/Kath's UI/Inventory Icons/Conjurer Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "5805361141D7F74F8E493D30E9E13DD09C75"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "0B3C72AF0E33F9448618D7E72C4F4A5CE1EC",
                            "defaultText": "상태 이상 부여 확률이 20%"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "211403E643BA0346F508CF85189369DB0CD5",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9034D21566F44146AD1975725B4786D8DBBD",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "3B23102A3418224B8B2BBC8888F94AA782CD"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "44FB3DC2369C9740658AB7D898729F1331D8",
                            "defaultText": "증가한다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "8964B2D89173634125892095C8F2229FDE3D",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "9034D21566F44146AD1975725B4786D8DBBD",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "42FE0DC078F53247023946939C7A4210855B"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "4FCB47A96252C749A33B86D7CC5578B272E9",
                                "Graphics/Kath's UI/Inventory Icons/Spadiavolo.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "FEA734AB38AA25470C48F03683939EE3FB72"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "052D5FBE654E3542C40937E896734821FD13",
                            "defaultText": "오랜 친구가 남긴"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E3E9F4E96FE75741CB3951C0752BF4DAFFD6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4FCB47A96252C749A33B86D7CC5578B272E9",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A9FF8A561D49F54AA888AF285CF973DCC414"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "59BD11BB5203D444028ABCE3CDEC7D7E2CD0",
                            "defaultText": "추억의 물건."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "A84A7FAF0160724BB18BA1B1DB3FE00D93A3",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "4FCB47A96252C749A33B86D7CC5578B272E9",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "D13A77AD1803B54BB68ABB17F77375B0A473"
                },
                {
                    "id": "gs.Condition",
                    "params": {
                        "variable": {
                            "name": "Unlocked Legendary Minerva",
                            "index": 110,
                            "scope": 1,
                            "changed": true,
                            "domain": "com.degica.vnm.default"
                        },
                        "numberValue": 0,
                        "textValue": "",
                        "switchValue": 0,
                        "valueType": 1,
                        "operation": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 0,
                    "uid": "E848C6C93A5733451C89AD12127866498BD7"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "310925672846014A3B4AFD038A3CCB2DB41B",
                                "Graphics/Kath's UI/Inventory Icons/Bronze Sword.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "D200E9EA42CE5748561BF448A0CF65EAAC29"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "E25AB49629D9C244AB2870996DFC323B55B3",
                            "defaultText": "별의 군주를 위한"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3A16B4837A1EE944B88952D3C3C6C00E7509",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3B3E8E003127914FFF3A51A923CA3B391A78"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "9ED86FAA72CDA54CBA9AC7717B7293B2207A",
                            "defaultText": "기적의 검이다!!"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "8699BC1630ADF442E3380DB48469EDE79372",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "0CD2C3E74077F1403F2AFBB4D56251496BBB"
                },
                {
                    "id": "gs.ConditionElse",
                    "params": {},
                    "indent": 0,
                    "uid": "E36070F744A81048656915C057BAB037C007"
                },
                {
                    "id": "gs.CallCommonEvent",
                    "params": {
                        "commonEventId": "E5B13B84877F644B791A9823714E7505DB9D",
                        "parameters": {
                            "values": [
                                "310925672846014A3B4AFD038A3CCB2DB41B",
                                "Graphics/Kath's UI/Inventory Icons/Falkion.png"
                            ]
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "EBA2245C33938148123BE77503B1296FD937"
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Attacco equip",
                            "type": 0,
                            "value": 2
                        },
                        "numberValue": 30,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "BA6C30E4273FA74F420BB7D5EA7BF5247C43"
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Velocità equip",
                            "type": 0,
                            "value": 1
                        },
                        "numberValue": 10,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "B4455D553956D54DBC69E2318E260B24B19F"
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Critico equip",
                            "type": 0,
                            "value": 1
                        },
                        "numberValue": 10,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 0,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "3399ABFE8B984246641ADB2924ACD6074423"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1871E8E980FBB045F66A46A3DB2D14C4FCD1",
                            "defaultText": "전설적인 이름과 달리"
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "A01F5E0F907B944BB44B52A372A1A7196CC6",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Descrizione 1",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 0,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "91416AEA9FC05748BD0A0B7304E7C4540638"
                },
                {
                    "id": "gs.ChangeStringVariables",
                    "params": {
                        "source": 0,
                        "target": 0,
                        "sourceVariable": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetReferenceDomain": "com.degica.vnm.default",
                        "targetReference": {
                            "index": 0,
                            "scope": 1,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetVariable": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "targetRangeScope": 0,
                        "rangeStart": 0,
                        "rangeEnd": 0,
                        "operation": 0,
                        "valueType": 0,
                        "textValue": {
                            "lcId": "1E2831426FC68245CD8A59C7F2FD51A93998",
                            "defaultText": "성능은 평범하다."
                        },
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "96B5BE50735226442F1A81939A8B1BC061A9",
                    "expanded": true
                },
                {
                    "id": "vn.CharacterSetParameter",
                    "params": {
                        "characterId": "310925672846014A3B4AFD038A3CCB2DB41B",
                        "param": {
                            "name": "Descrizione 2",
                            "type": 2,
                            "value": ""
                        },
                        "numberValue": 0,
                        "textValue": {
                            "name": "",
                            "index": 1,
                            "scope": 0,
                            "domain": "com.degica.vnm.default"
                        },
                        "switchValue": 0,
                        "valueType": 2,
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        }
                    },
                    "indent": 1,
                    "uid": "6F68A2842C63314BB6899595F0FE5ABE5F65"
                }
            ],
            "index": "FB98203B89D57842D30B8D07EFDF5D2F98DB",
            "booleanVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "stringVariables": [
                {
                    "name": "Desc 1",
                    "index": 0,
                    "scope": 0
                },
                {
                    "name": "Desc 2",
                    "index": 1,
                    "scope": 1
                },
                {
                    "name": "Desc 3",
                    "index": 2,
                    "scope": 0,
                    "domain": "com.degica.vnm.default"
                }
            ],
            "numberVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ],
            "listVariables": [
                {
                    "name": "",
                    "index": 0,
                    "scope": 0
                }
            ]
        },
        "localizableStrings": {
            "25F32D4D7DA342427949FD25D13C7801E485": {
                "t": "Sir Ornières' old sword.",
                "d": {
                    "eid": "4686F95E1E9E6447934841075376B1E44A7B"
                }
            },
            "6DAF25474B24C8458878629382C28258E27B": {
                "t": "It feels rather nostalgic.",
                "d": {
                    "eid": "3E5DE5E025E7C74BA758BCE9610C97A94239"
                }
            },
            "1D8D09134DEDD34B4B48EE54F2FF32DFC71D": {
                "t": "A sturdy sword, used",
                "d": {
                    "eid": "6C6D3D9F461EB6456C4BF594956AE550236B"
                }
            },
            "92FE0BC71A79894DEE3A5CF3517769F55EB5": {
                "t": "by poor soldiers.",
                "d": {
                    "eid": "F35FDF880ADC5846427ABB997BE8D303CC93"
                }
            },
            "E25AB49629D9C244AB2870996DFC323B55B3": {
                "t": "MIRACLE-BLADE",
                "d": {
                    "eid": "3A16B4837A1EE944B88952D3C3C6C00E7509"
                }
            },
            "9ED86FAA72CDA54CBA9AC7717B7293B2207A": {
                "t": "FOR STAR LORDS!!",
                "d": {
                    "eid": "8699BC1630ADF442E3380DB48469EDE79372"
                }
            },
            "1965885F75B2584B2D4AD3012F24DF37ECE6": {
                "t": "An otherworldly blade",
                "d": {
                    "eid": "C9F60A3B40B5D740616850707CC4804B4523"
                }
            },
            "EED84A383112184AF118AA127F0C449063DF": {
                "t": "that cuts dimensions.",
                "d": {
                    "eid": "7C75FBB95CE7574C6E3980A406F0D074ECD6"
                }
            },
            "9CF65DE673865342D95A2903960E2DE1A641": {
                "t": "A sturdy sword, liked",
                "d": {
                    "eid": "61CD03B224617646C18A78B5CE03D449C66F"
                }
            },
            "ADD0D59D17FD84419F393149AD0B6FBCD1A3": {
                "t": "by many soldiers.",
                "d": {
                    "eid": "0DA5C5922ED4274368495EE18CB7C857D1EF"
                }
            },
            "81D558836B8E2547160877C2D3F6BA83803D": {
                "t": "An edged weapon.",
                "d": {
                    "eid": "82B01F606C1F9645D0489100CE074778CA1D"
                }
            },
            "1308ACB73F3E614BFA48FF31D68A729754C9": {
                "t": "It kills people.",
                "d": {
                    "eid": "F1A9C8671AA58948F19B18935BD3A000052E"
                }
            },
            "610D345752CED34DDA58EEA7BC8AC92AF734": {
                "t": "An edged weapon.",
                "d": {
                    "eid": "F714166D4DF6A346F35BE301B80D351046F0"
                }
            },
            "3807403462AAE84CF25B42E02CFC2BDADA1B": {
                "t": "It kills people!!",
                "d": {
                    "eid": "A08AD08C4535464A71181007AFE52AD34710"
                }
            },
            "A218394E835CE345935B34D37F44507EA9FF": {
                "t": "Enhances Crit.",
                "d": {
                    "eid": "55F9C4802384824021882AB3578131FFDEC6"
                }
            },
            "9A7119C40DFAF34D602B95C34FD8FFEC6EC7": {
                "t": "Kinda lethal.",
                "d": {
                    "eid": "D8E6E38D153AE542950AA9882B810865DB60"
                }
            },
            "0EB58CEC66F92949B14BEC48594271354D4B": {
                "t": "Enhances Crit.",
                "d": {
                    "eid": "3ED56AB94C08174EC62B72E78AA7D7EC6245"
                }
            },
            "A973D1D2392E9645B408EA617401BEAFEC6A": {
                "t": "Very lethal.",
                "d": {
                    "eid": "8D21AEF994401840F128D0C1F6CCFA0DE6DC"
                }
            },
            "941CA61C2CB1334B6A3BEA1539A9D9243EAF": {
                "t": "Rare sword, maybe",
                "d": {
                    "eid": "29ECF4506D47C44A013889E90DAE4E55FA32"
                }
            },
            "7DA8028E3543854F091849046FC5F1FFB834": {
                "t": "worth its price.",
                "d": {
                    "eid": "184549684D5AB647781AE997924A82F00511"
                }
            },
            "52C1B33198FBD94C451933E4B11DEA356CAD": {
                "t": "A rare sword",
                "d": {
                    "eid": "A92F485830A9234B96299E085696701240CB"
                }
            },
            "19B1818D1EB6E3477D0B76741C2BCB25DEB3": {
                "t": "worth its price.",
                "d": {
                    "eid": "23A07E751B72424E5198B8F3E3952E9FFCBF"
                }
            },
            "97E8A0AA7E0C41421B4AA2C27D8435861685": {
                "t": "Makes you feel",
                "d": {
                    "eid": "C6DDB1CF9F5A374B7C7BBB24273A9797FB80"
                }
            },
            "6E4F78747C4F58499248CF771E20E69E63C1": {
                "t": "quite special.",
                "d": {
                    "eid": "C6ABCDEB914C67412319F356F8C58A9EA15E"
                }
            },
            "120B5B3F4EACB243473BE0B201C7087F0504": {
                "t": "Makes you feel",
                "d": {
                    "eid": "2DFC93065C5BF34C5A7801C79339CAF30666"
                }
            },
            "89C5006F8C57744E77286BC1713B8293338D": {
                "t": "very special!",
                "d": {
                    "eid": "15C7BF8270A1E149947875E266B95B6F10D3"
                }
            },
            "9F2CD7E978A855416D4ABF733D518D19ADFA": {
                "t": "10% extra chance",
                "d": {
                    "eid": "EA17880D7EA7664A9B6A4C37D11F3D998423"
                }
            },
            "261E97B06ADC584C8A3BBF30E0E75964AC41": {
                "t": "to inflict statuses.",
                "d": {
                    "eid": "6D74ECD94FE6E4452F195B57830ADD1ED646"
                }
            },
            "0B3C72AF0E33F9448618D7E72C4F4A5CE1EC": {
                "t": "20% extra chance",
                "d": {
                    "eid": "211403E643BA0346F508CF85189369DB0CD5"
                }
            },
            "44FB3DC2369C9740658AB7D898729F1331D8": {
                "t": "to inflict statuses.",
                "d": {
                    "eid": "8964B2D89173634125892095C8F2229FDE3D"
                }
            },
            "052D5FBE654E3542C40937E896734821FD13": {
                "t": "A memento from",
                "d": {
                    "eid": "E3E9F4E96FE75741CB3951C0752BF4DAFFD6"
                }
            },
            "59BD11BB5203D444028ABCE3CDEC7D7E2CD0": {
                "t": "an old friend.",
                "d": {
                    "eid": "A84A7FAF0160724BB18BA1B1DB3FE00D93A3"
                }
            },
            "1871E8E980FBB045F66A46A3DB2D14C4FCD1": {
                "t": "Despite its legendary",
                "d": {
                    "eid": "A01F5E0F907B944BB44B52A372A1A7196CC6"
                }
            },
            "1E2831426FC68245CD8A59C7F2FD51A93998": {
                "t": "name, it's average.",
                "d": {
                    "eid": "96B5BE50735226442F1A81939A8B1BC061A9"
                }
            }
        },
        "parentId": "8A7A025317CD78422148C8F665F1528EFA9E"
    },
    "summary": [
        "name",
        "type",
        "order"
    ],
    "externalItems": []
}