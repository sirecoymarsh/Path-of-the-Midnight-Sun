GS.dataCache['BE5A163286A552413489D7D448672301E5DC'] = {
    "uid": "BE5A163286A552413489D7D448672301E5DC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-03c Enter Phoebe (END)",
        "type": "vn.scene",
        "parentId": "8D381E7C10471941382A2AC92CD7DB63FF30",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 10,
        "localizableStrings": {
            "505B915A6FD21345763BAF41E3D9AC51899D": {
                "t": "Rya and Faratras are coming this way. And that woman with them... is that Empress Phoebe?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "66DDF391719229408478DCB881396A1301E9"
                }
            },
            "0A0EF20E520608492A0B7596D21904334C66": {
                "t": "W-Whelp... Now that I think about it, how should I act around an empress?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3A6FF3B6779A5944B53BA3F3285B67D17630"
                }
            },
            "EEFF05CF47AF1846EC88DA354AE5153267F4": {
                "t": "D-Do I have to speak with some specific mannerism? Will I be imprisoned if I don't show my due respects?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A63928898E82D5441D48A4983FD9C09263BA"
                }
            },
            "9CD7A7726F4064435768D03483D1692DDFA7": {
                "t": "Better be as polite as possible--",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CD86D4DB42634640C379908686F26C7D5B63"
                }
            },
            "A4111EB97E82B04F622B1AD12D0C2548DD7A": {
                "t": "Oh.{W:250} Yo!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "BD1011AC7AFA424B9A3A2187987E3F27F03F"
                }
            },
            "E8CA434A3009E94B723BDB65A20A16007428": {
                "t": "Er, excuse me miss, I must've been mistaken.{W:250} I was waiting for the empress--",
                "d": {
                    "cid": 0,
                    "eid": "6B2C35EC65AF394138184D80ACB5C10A2614"
                }
            },
            "5F8435542B4D92426B5BDB03CA732AB16B21": {
                "t": "YOU!?",
                "d": {
                    "eid": "8A05F4428A4FD34B215B3762A49647FBCDD0"
                }
            },
            "F968C2CA538C914E3B2919B7DA5B816B68DD": {
                "t": "O-Oh, sure.",
                "d": {
                    "eid": "A5B3BF56497F644AF5780D583E1D2D6B144F"
                }
            },
            "842A20D462B7074D7989EC7296F04F77EAAE": {
                "t": "I...{W:250} was pretty shocked too, at first.{W:250} But this is indeed the empress of Magnolia.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "114A73F08F4B11436F7834B21FFE324947F9"
                }
            },
            "485463029BDEE64C0178B96501FE0D26D2F8": {
                "t": "Hey, Phoebe.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "5B6A959978F624492578EDF8831683CC07B6"
                }
            },
            "FBF6036C5E3AA84E286A73D887B8629B3B5E": {
                "t": "She's chipper! And casual!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EFD3EC3574E8354608387DB839F968D202C4"
                }
            },
            "1B0097F81A4B464C5C4A8E26E5D5875D81BC": {
                "t": "I can understand your doubts, but don't let appearances fool you.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "AD17D8307591F946C14A06C7EC80ADBCA06B"
                }
            },
            "3518C2C52A40B1477B4AB1B96E0551A32631": {
                "t": "Despite her... peculiar way of expressing herself, my sister is a genius of diplomacy and tactics.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "4ABBA4F58FA0F244E89B9C71461133FC5B4A"
                }
            },
            "E8B3EF9928D4A1435158F1111968C1C7DA33": {
                "t": "I... kindly accept that compliment. But I have to disagree.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "954020E148B2A743F289C205F168186D5425"
                }
            },
            "75DC570968B2F54D2C4A9963A35AB5D82D04": {
                "t": "They're like day and night...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E63CC3E282657745664843B7E8851A36142B"
                }
            },
            "E7913B1F8D09F140111BF0D55DD60E0C07A9": {
                "t": "Anyway, Faratras told me about yesterday's battle. I was a bit astonished. Did you really fight the soldiers of Hoikade?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "9EDB42CD4017A54B578B3838B26582E10DD4"
                }
            },
            "9B6EF7EE1348B14B9F28EC78F58CEC8B16E4": {
                "t": "I'm not a criminal! Forgive me!",
                "d": {
                    "eid": "9D84FC6F6E236149651B1355C9963C4DBFAB"
                }
            },
            "82E17B7E650BE84FB4781D6423335752D75A": {
                "t": "I was involved in the battle.",
                "d": {
                    "eid": "8EABCD6E5A899944030819046B8E706526C0"
                }
            },
            "083D81D3573B774A2F29F2872C6CA2B46FA7": {
                "t": "Yo, t'was fun for real!",
                "d": {
                    "eid": "AE6EC0B133979949A7881D546EB3A2EC3D56"
                }
            },
            "59A008022159D54DB178CE674527D398E87C": {
                "t": "Worry not, there's no need for justifications. I understand it must've been a difficult choice for ya.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "77279EAE55C305425B48B0D39A1207837B3B"
                }
            },
            "96E564BB73E9354F635BB2B51C8E176D0AC8": {
                "t": "Hah! Tryin' to sound funny, aren't ya?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "A0A6652B3BACF840A79A1969FF4FCA486D47"
                }
            },
            "F2A442026E4EB24A634A86038B8F74BA6CF0": {
                "t": "In any case, let me recap the situation. Y'all were defending yourselves from a bunch of brainwashed soldiers...",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "7986ED4A3A22034B798AF2581867B7EC6CAA"
                }
            },
            "DFBCDF7C0DF684476B085BB21E30E56FB6AF": {
                "t": "And the one who planned all this was Munie, the queen of Hoikade?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "A0B96E753C49124B7A6BDB67BFC64412E168"
                }
            },
            "238F58A16801C840C1198FA33FB2608CA29E": {
                "t": "Precisely. According to Hellios' intel, at least.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "936BBCA5667A40436B196E284E61974424AA"
                }
            },
            "60AE49265750444EEA991C6269EF07D06D21": {
                "t": "And who guarantees that Hellios is trustworthy?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F5D7CE4D5621774D3D7B6BB14D54983EC8DE"
                }
            },
            "196762BB5EBC284A8848262578ADD891A603": {
                "t": "You're free to believe me or not, Your Highness. I want my actions to speak before my words.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "6AB0231B38D1554B7D0887B29C798F5893C1"
                }
            },
            "4C79B45E31E7834BE88A34B9C084D4F39CA9": {
                "t": "He saved my life. He knew about the plan beforehand, and he thinks I'm innocent.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7AD2EA907056A04EE68BC373B42E9596D891"
                }
            },
            "1A33B6AE617EE140417877662A690160A827": {
                "t": "That's more than enough for me.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EAC679EA0E77A54B713A47E5FB57853B8CAB"
                }
            },
            "8144F2FC1CF40544E1590494E540B756D081": {
                "t": "Assuming that you REALLY are innocent.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "791E218892F0D547C1685FC5F779A045BFE8"
                }
            },
            "12B681723535694D707B88149240AE3F4078": {
                "t": "Wow, it's really hard to trust each other here, huh?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D8C2EFC480A3F247A48A5CE7B510BE8E8E0B"
                }
            },
            "47975E5E0BC6134B7D0A8C87CD0B430499A9": {
                "t": "I understand your doubts, sis, but she may be telling the truth.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "CAADBCC2115BE64B224B8113DA559A83B923"
                }
            },
            "51327D2314E7B14AD88A8F35674576CC10C5": {
                "t": "... ... ...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "7BE4A6B878B33241D63931F59EC96D3733A7"
                }
            },
            "E8282C654F9FB843EA3A5965F1D5EA5328E1": {
                "t": "You don't seem in much pain.",
                "d": {
                    "eid": "F0BD139B50841947058B9D02EC306C1EF39D"
                }
            },
            "E7B67F2C4D6A2444F63914694EB3AF67CE85": {
                "t": "Understandable. Please, stay strong.",
                "d": {
                    "eid": "D585B2AF5C1B814E438B3C3693753E7A1D14"
                }
            },
            "8A5BE1D712F5E148213AE3626A93BD15304E": {
                "t": "Tch, how 'considerate' of you. I'm trying my best to keep my emotions in check.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "46E1D83B2D7915437B6AE370BDF15CBA14A2"
                }
            },
            "E1DA55DE105B504E552A7AD28E27CC9A7076": {
                "t": "Thank you for your concern, it's... most appreciated. I'm really doing my best.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "82A652478743154B1A28C637FD1B80321ABE"
                }
            },
            "CAECEB4418CC1447A31BF3E15BBAF8174F0A": {
                "t": "I fear that these feelings may corrupt my control over the Demon. It's absolutely essential that I find some peace.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "37AB9F91483FC24A501905B3EF5B94E39CCD"
                }
            },
            "8CD3A0158490434DF77A6786907842846D61": {
                "t": "And there is only one place where I would feel safe, right now.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "6BFA286F7245E34ACF185DF9F0824D91EA06"
                }
            },
            "E5EE5A2133E6A54DAD0A0B02759AF24314E6": {
                "t": "Lazulis.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "409A7D316AF4614D61194C01C205CCA5BFB2"
                }
            },
            "41B19E03666BF246DC19F7B8EEE6E4763395": {
                "t": "That's one of the five great nations, right? I don't want to make a fool of myself and ask for such basic information.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4DDD96F666D7614F6B4B6086102FBD7C4F39"
                }
            },
            "B4B3E8B8063F104E2A6859D923EECE8AB25B": {
                "t": "Lazulis is protected by strict anti-war laws. Even Munie will think twice before ordering her troops to pursue me there.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "DA371781628072447A6891A921BD16E08149"
                }
            },
            "48D9AA5586955749AF399A320A4B8525425C": {
                "t": "But Lazulis is far away. And Hoikade will surely try to capture you again before you get there.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "FCE32DFF44804643999961826A23A6DD147A"
                }
            },
            "E4BF0C5F5AE2774BE17BA7B6CE9F5146F4D2": {
                "t": "That's why I must ask for your help.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "B5C8AEDE0C712843838A6B403C46FD0A5B4C"
                }
            },
            "ECDE4CA58BC8F2499029FEA67FFD06F65A6A": {
                "t": "Helping ya now would paradoxically result in a declaration of war. Queen Munie also sent me a messenger asking permission to cross our borders.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "CEC9E96675EC344CB25A7789BF82193FE63A"
                }
            },
            "96FA6222036C91464498EBD495482DB23679": {
                "t": "I know. That's why I wasn't expecting anything. Sorry, I've wasted your time.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "90B9636A3C36974A5D99763233AA5FA0FFFD"
                }
            },
            "FD9DEEC87ABD404054181E22D585895E4EFA": {
                "t": "However... If ya really are innocent, I can't let ya go like this.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "CE65412966476840DC4A66673AC482DE5E28"
                }
            },
            "917268AC1C98E44DB10A9BB3D173CB74DE21": {
                "t": "... What do you mean?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "9F143C0E6085B647F479F534701A64A5F759"
                }
            },
            "0DF9355269CAC647CB78A213869CCF3BDDDC": {
                "t": "I'll give ya a few trusted warriors, who'll pretend to be brainwashed too. This way, Hoikade won't have the right to say anythin'.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "0FC381BD2B998443A2382557CCC20257649C"
                }
            },
            "620BC4EB1C3B1842716BE7A3F1A74E5FC2E1": {
                "t": "But I'll also have to let their forces cross Magnolia, to avoid a war. So, ya may end up fighting 'em again. ",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "EE65F0BB89761343E24A18F1DA76D2C1F3BA"
                }
            },
            "79476F400D9BA841C79A40A7C420F9BF625B": {
                "t": "This... is far more than I'd dared to expect! Thank you so much, Empress!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BA76E3720A99A64B052B1157E4E9D184F6A0"
                }
            },
            "E360F78052B9A3438C48FE152204E352EE04": {
                "t": "That's unexpectedly convenient for everyone.\nTruly a brilliant solution, I must say.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "EAB8FE7203F00649382A8773E0F8E8C41B4F"
                }
            },
            "F89776421943C14B203A3DF3E2CEA33C43DD": {
                "t": "That's my sister for you. A genius who rose to the head of the empire at the age of fifteen.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F083893253064846F959F037AD9AF4BCE356"
                }
            },
            "9A6E695C3DA5D44A9F4AF798AA0F029C2E70": {
                "t": "Heh, enough flattery, I'm just doing what's best for Magnolia.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "F70F8DFF19C4E14C105B050481326CE03360"
                }
            },
            "D525F49B49572746216B00607B805F19FFAC": {
                "t": "If Faratras were truthful, I'd have helped the innocent Vassal in her mission. If not, I'd have let Hoikade capture a criminal who fled from the country.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "F6D62F7D6269A140B32AD596A49E10E9AEA1"
                }
            },
            "9C50BBC71B821742EB7920E93CEA609450B1": {
                "t": "With that being said, what are YA gonna do?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "2C398BB6905FB6458B9B4B474BB6545B5C5C"
                }
            },
            "BBF010A5447E574BD559F3C7255F98A62076": {
                "t": "Me? I can only do one thing...",
                "d": {
                    "eid": "97C4932F3C85414CA7482A45347753637016"
                }
            },
            "C50AB10629A98541D5884562A7F2405C33F7": {
                "t": "I will follow Lady Faratras.",
                "d": {
                    "eid": "C2305ACA7DF0384E03791194F7A2EA51D0A1"
                }
            },
            "B47F5B9258E1B947E0780136E4513B6FF7B9": {
                "t": "Well, I still have my mission.",
                "d": {
                    "eid": "71C642F35F28654E6B7BB814F3D51D39FCD9"
                }
            },
            "C2DE5967771F8649115800A1E8E6AB70446E": {
                "t": "Sure. If ya follow Lady Faratras, that'll serve as some sort of... insurance, for us.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "125D6C920E723442807968158549601ED5FB"
                }
            },
            "E2A78F876BC8134E2838DD94364866689511": {
                "t": "I'm glad you see it that way.",
                "d": {
                    "cid": 0,
                    "eid": "9554E5D20681144A9C4BF5F750A652D862F0"
                }
            },
            "2C5B6D66816656451E6A4C21870BB0A2F180": {
                "t": "To add on that, there's something we need to confirm from you, {LT:1}.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "09118E026B24314B8F893B922703EAD98769"
                }
            },
            "9EB531972A5C6149051AB667CBF639D4ACD2": {
                "t": "Umh? And what would that be?",
                "d": {
                    "cid": 0,
                    "eid": "F0B83AF55254E048D1693450B2260A96FB4E"
                }
            },
            "250E975E75E3C544605BDE58F5E857E17F30": {
                "t": "The Manadrop on yer sword...\nIs it REALLY a Manadrop?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "2DB194BE7E89654B073B4F59BA7FC834E10E"
                }
            },
            "2FD2ECAF7DBEB043E32905B431BE59640B2C": {
                "t": "Umh, I still haven't been able to remember any spells, so I can't be certain. But what else would it be?",
                "d": {
                    "cid": 0,
                    "eid": "C854DCC730147340769A6E69834364A93509"
                }
            },
            "BFD3F4095518C54D5C495173289A40141163": {
                "t": "Hmph, just as we thought.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "333A17E4492496470D0AEA526A60906D874C"
                }
            },
            "A93046239408A340052A2DB6C22FEA951954": {
                "t": "Sir Ornières. I've seen that object before during my travels.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "C01D38835292E4486B8B955150ACE276CECE"
                }
            },
            "BEEBF0D23D693449147AE1E3504C11996DC2": {
                "t": "It's classified information, but... the magic power it keeps emitting is a bit unusual.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "52051D488C0FC644FD5B80E44AA1C00C8B04"
                }
            },
            "4150A622524B2844927991F684FE02CB5EEE": {
                "t": "A Mana... what, now?",
                "d": {
                    "eid": "FFE4BA082A652648D59A0663D8A67EEE7610"
                }
            },
            "9AC72AFC607CB2468A4A0B20543C6BE96678": {
                "t": "So, is it that special?",
                "d": {
                    "eid": "9B88204336CFE14E3119B2E2045E12A5F1E4"
                }
            },
            "7C14CC5E3EDDC643FE7966E8A156A64306E2": {
                "t": "Finally, my protagonist powers.",
                "d": {
                    "eid": "69BE2AD265274144F93850E1DB021E95DE58"
                }
            },
            "2A99AE2B863EB948A149DDD6054C7F588DED": {
                "t": "A Manacrest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "30AF8E8E4D6C8043486879C76A5BACC62FBC"
                }
            },
            "C6CE0D9B0E95624F3638CE33F2BB24CA5877": {
                "t": "Don't let it go to your head.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F98F566364AAC0465D19ADE1CF0C56678904"
                }
            },
            "A8D110394BC3C9424D3B342198C8171C0BEA": {
                "t": "Could it truly be...? I didn't even think a Manacrest existed.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "EC17FD014D7BB24811899926598373737AB5"
                }
            },
            "778212082D294645FF8BEA51FF51690EE369": {
                "t": "Our intel is second to none, so I can say that with absolute certainty.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "8F0DE47E35C51347C24A9F122D6F4F1CD9E6"
                }
            },
            "0EBA4B9D627E964ED97AFB641E551AEEF291": {
                "t": "Sis, ya'll follow the group too, and collect more info on the Vassal and Sir Ornières' Manacrest.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "39E0F95D6786A04BFF3BF321B342527980A0"
                }
            },
            "959D436F835CE1458A4B804228E83458A86E": {
                "t": "That's not what I'd planned to do this week, but... it'll work out.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F85468BA6443A34C320A9B43FDE69274791E"
                }
            },
            "AED28368222DE24B3C2B0617F4C93055F009": {
                "t": "Wait, can someone explain to me what a Manacrest is?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "F2C92FFC7E45D8491C0BB5D3CD264EF29069"
                }
            },
            "E310327675A58643F80B39C09EFAD067DCE7": {
                "t": "We'll depart soon. Get ready.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "822728AE3DADE642D919DA6338F41C8276EC"
                }
            },
            "D629EF073BA5974DE16B5F4705406DCBF028": {
                "t": "Hello? I need some answers here!",
                "d": {
                    "cid": 0,
                    "eid": "A00527F86E58644A745810E7775C27A92E4B"
                }
            },
            "A9BA148A492995465D6BD384CF54748ECD3D": {
                "t": "HEEEEY!!",
                "d": {
                    "cid": 0,
                    "eid": "FFADE5B23A55984F8F380C713A7D25B872DA"
                }
            },
            "9F6CE24B1C5796411B1AE76788127C647937": {
                "t": "I'm sure of it. That's not a Manadrop...\nIt's a {SP:1}{C:1}Manacrest{C:0}.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "577BF51C9E3B474A2F69E4E7F650B5FD8A69"
                }
            },
            "98D2454C33B89745475A2BE3FA3A1FC184F2": {
                "t": "She's younger than expected.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "72CDAC96547FB345CE7BBF07BCA094D3988E"
                }
            },
            "7940E2855DD88144D548DA960996AAFB6396": {
                "t": "No sign of Cristoph and Luckos. Are they still getting onto those 'snacks' he was talking about?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D048B061643EB743714B0074D9C257152E37"
                }
            },
            "242571DA3DBD7642E27BF2727387B7601D3E": {
                "t": "... ... ...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "15EA4B8D41424440D52969C5997097BFFBCC"
                }
            },
            "2C7A1042827FB54AB978D4E2469DE3E340D5": {
                "t": "Yup, that's me! I'm {SP:2}{C:1}Magnolia's empress, Phoebe{C:0}.{W:250}\nNice to meet ya!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "A4A32F7B2948204F9A08D4C2F4C708E6EF59"
                }
            },
            "D39A347A47EBE446F68A05F64F3C448D0B68": {
                "t": "C'mon, no need to look so surprised!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "B15C78A462BA9647A68813687A021F5A3DAB"
                }
            },
            "FFA15F1B31ED844A1439E993FAA00E9020B3": {
                "t": "Ahem.{W:250} Pleased to make your acquaintance, Your Highness.",
                "d": {
                    "cid": 0,
                    "eid": "482492D32CF7F445619B96707A2E66F05C7C"
                }
            },
            "D020A4AC389C684C6A6841C36FE41C5BDE00": {
                "t": "Please, call me Phoebe.{W:250} I'm fine with casual talk.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "55B740B257A2E240C95A0465FC6B6AA67F97"
                }
            },
            "F0B5C517637279457B2B56222B364C12436B": {
                "t": "W-{W:250}What!?",
                "d": {
                    "cid": 0,
                    "eid": "B3E8FB837F54964B331A01E7538060039803"
                }
            },
            "7572132C631F624D254A3689921895BB2EF7": {
                "t": "You must be that Hellios fellow, right?{W:250} Good to have ya here.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "BCF398AC07F62147EC2BC4A1075EE883D046"
                }
            },
            "024880F66279654E78793CF22A07DD38B111": {
                "t": "Now that I think about it...\nCan I really trust Magnolia?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A0B6B9AA364C1348F63B299492448E084C98"
                }
            },
            "AF5D91BE6667604815383814C06AC4113F9D": {
                "t": "This situation is so complicated. I wish I had more information... or more experience to back me up.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "05FCAA6C7A4EF240A32AA3080605B49A8200"
                }
            },
            "214372DD27B108496269DFC90AF117540298": {
                "t": "And this empress? What a headache...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "696EECBE6F64494C7789DC23444938B34173"
                }
            },
            "1CD2BEBF26C97848098B368285CF88282282": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C4AAE915603A684FB4486096B32240F884B6"
                }
            },
            "3403F1EE5E32D041663B2E21B2B1AF537A00": {
                "t": "So she says, but my sis here is way better than me, haha!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "631EAE6360FF454D183A47A4DF69E21FD480"
                }
            },
            "DC60E09F26C2A641C55AED61D10D63551379": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "00386F392F8AD440F34BB673F617B63C94BF"
                }
            },
            "91037E4A6CB524407138CC751E9D01DBD26C": {
                "t": "Hey, Faratras, what do you want from Magnolia, hmh?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "3D61342D1CB643498D4B8FA726F853E88D36"
                }
            },
            "D1A546FE7B19534901986E264BDC07DF9A5E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "DBEC25694D6F7340FE6A62671DA4EEA75FAD"
                }
            },
            "817C40E92A7A8842AE7ACD82063171D7CE27": {
                "t": "... I don't want to kill anymore.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EDCEEADE6CCE06408F68C569527453A3FB9D"
                }
            },
            "E8D1835F3BBD2340096979B813BD414FE214": {
                "t": "All those innocent lives... their weight is too much to bear.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "ACF2654B5BEC164B2E4952662B5B0DE7DDB3"
                }
            },
            "7DE8F1C87B8994412F58E484BFA0096F5C0B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "8D7C6748674F35460A3B4107DC18A51998C0"
                }
            },
            "AAC0978D168E0649C2884216AFCD682CD03B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "FB0048126E399047903B00B42C5AFC894E34"
                }
            },
            "DB25395C11E8A949D968DA4110A302D6F27B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "415EBC79667FD64CDE68D543CDE127BED12C"
                }
            },
            "C14DF6E7260AE84E767958721F3B8FDDFC8A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F5D1F3B6037CE1430A4B36655F85BBB8CDD2"
                }
            },
            "7687BBB27DC7A246700AAAC4369723C53976": {
                "t": "Sigh... More mysteries.\nHow awesome.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1C57F5438887054EE469D41204F671342BBB"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D655888335EE743C128F3D36E4D91A340A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D43B7E6C80FA60488718C0A52EAD9726EF61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FBE97F211A99D64C389BB1C15BEF1A80D6BB",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B54DA71C5BBD41411F592C07CE9310ABF6C6"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D8FE86CE7A39D84B42192D51C5054F7525E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2890734659C146495C58BC71DEFFFDE1595D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D32725412D86C14B078B30D1BEDF67BEA2A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C46138080BAD4449F58FA42BF13C54FDD58"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "505B915A6FD21345763BAF41E3D9AC51899D",
                        "defaultText": "리아와 파라트라스가 이쪽으로 오고 있어.\n같이 있는 저 여자는... 피비 여제인가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "66DDF391719229408478DCB881396A1301E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "779EFD524ADF234E888A8322E124D68D31F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FFD67C49429EB4493319615218D1FD94CB9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98D2454C33B89745475A2BE3FA3A1FC184F2",
                        "defaultText": "생각보다 젊네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "72CDAC96547FB345CE7BBF07BCA094D3988E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E464C449880F1246986B04964187C8201990"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDD6A33B9989A740F6890A12A124C4DACA8D"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "model": {
                        "name": "Faratras Overworld.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 702,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1732,
                        "y": 200,
                        "zoom": {
                            "x": 0.17,
                            "y": 0.17,
                            "d": 0.17
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "BB8BB27B2EC5D543A52ADCE6581FCEE070CD",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "model": {
                        "name": "Rya.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 702,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1640,
                        "y": 207,
                        "zoom": {
                            "x": 0.12,
                            "y": 0.12,
                            "d": 0.12
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "EB709B14530334441888190723C29014DBDF",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "model": {
                        "name": "Phoebe.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 702,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1680,
                        "y": 171,
                        "zoom": {
                            "x": 0.18,
                            "y": 0.18,
                            "d": 0.18
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "798D936B6573C8465658DE218E3267D33F93",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "A41230848F68D249C68B98F9F7D675B6A543"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8EC6EBC7840064417C696F510123A11C8ED8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "5314453064E9E64A1D19E0A46E02288B238B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "110311B547FC334A509AD634CA13933E540A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "092C009820C627466C99EA5458042786828B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close, reopen message box"
                },
                "indent": 0,
                "uid": "99F5340669B0E64DE55ABDE3B94605A7724C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FB945A6B475342410C7BFFF565D8747E87EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC1340E9530F87417548F63802995F8EC674"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "575F14BF6FF30746AC4BD6794CEFD2D35759"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7940E2855DD88144D548DA960996AAFB6396",
                        "defaultText": "크리스토프와 루코스는 안 보이네.\n아직도 그 ‘간식’을 가지러 간 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "D048B061643EB743714B0074D9C257152E37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5ABB7AB8B85684373387106D620BABECC8B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "82C2630E7AC5714D26398FE3306A5C012276"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "duration": 21,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "3C6F80232F3E64455B78F5121ACE74DBD01A"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 21,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A85CA6D0436C3546D52958750DF8B2E33E3B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "duration": 21,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F60BF2F5250A364B9D69C994527D7EC082A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 24,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A0EF20E520608492A0B7596D21904334C66",
                        "defaultText": "이-이런... 그러고 보니 여제 앞에서는 어떻게 행동해야 하지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "3A6FF3B6779A5944B53BA3F3285B67D17630"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1E21D4C44A0E54F816B9D665421309A004B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 24,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEFF05CF47AF1846EC88DA354AE5153267F4",
                        "defaultText": "트-특별한 말투를 써야 하나?\n예를 갖추지 않으면 감옥에 갇히는 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "A63928898E82D5441D48A4983FD9C09263BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D5441090DADC848514BC3B6724B23248F13"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 24,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9CD7A7726F4064435768D03483D1692DDFA7",
                        "defaultText": "최대한 정중하게 해야--"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "CD86D4DB42634640C379908686F26C7D5B63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C76D4AF65C26184C761ACC58B897511FDE49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "B6EE7AD6786298480C19F570CF041228A8FB"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6BC7621F2E0775433E8837655F205E9B94B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            20,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "88B05EE00BD7C4425E38456500841118C718"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69012A4D0AD9334D13791CA970DDF8FF3FA5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            2,
                            20,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "083750E66140314DE84B4DF76C35DBA8FBDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73F758991510A84CF95B8726C8246E9807EF"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "model": {
                        "name": "Phoebe.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 810,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 263,
                        "y": 14,
                        "zoom": {
                            "x": 1.8,
                            "y": 1.8,
                            "d": 1.8
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "06B308959E8DC240E85A21C57064D0416082",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 0.8,
                    "lipSyncSensitivity": 0.9,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 1,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "50A1CD24487C65474C2938759AFE45E9B314",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 0,
                "uid": "375A9BF274D4C64E251A8F275823E87CCE8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A277A614EA35443F59903784D6BB6792C56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4111EB97E82B04F622B1AD12D0C2548DD7A",
                        "defaultText": "어.{W:250} 안녕!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C04-03c_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BD1011AC7AFA424B9A3A2187987E3F27F03F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C8A9E5458991444482B3228D68B455DF8A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1C1469275A9F34539684480906C7ADA9972"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "242571DA3DBD7642E27BF2727387B7601D3E",
                        "defaultText": "... ... ...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15EA4B8D41424440D52969C5997097BFFBCC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DB8DB9C23928149F55841A2C016E5B4E2B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AED4FBF643C25743087AB774425DA848D3C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8CA434A3009E94B723BDB65A20A16007428",
                        "defaultText": "저, 실례합니다. 제가 착각했나 봅니다.{W:250}\n여제를 기다리고 있었는데--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C04-03c_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6B2C35EC65AF394138184D80ACB5C10A2614",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81FC08A172243543638BEC54C02B913F8490"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FD78C255A1D0146883829A6F442699F3B87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C7A1042827FB54AB978D4E2469DE3E340D5",
                        "defaultText": "응, 내가 맞아! {SP:2}{C:1}마그놀리아의 여제 피비{C:0}야.{W:250}\n만나서 반가워!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C04-03c_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A4A32F7B2948204F9A08D4C2F4C708E6EF59",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "799FF92D6164584FF9789699A956D14D94B1"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5F8435542B4D92426B5BDB03CA732AB16B21",
                        "defaultText": "피비 님이 여제라고요!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8A05F4428A4FD34B215B3762A49647FBCDD0",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F968C2CA538C914E3B2919B7DA5B816B68DD",
                        "defaultText": "아-아, 알겠습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A5B3BF56497F644AF5780D583E1D2D6B144F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "either",
                            "either",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "542C5CA0595CE344DA896F640E81F002142C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BD7912AB4AC0204E23681DB713F8DEC23642"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "either"
                },
                "indent": 0,
                "uid": "97F15A1D40BEB8449C6BA8C8189A9ECB60AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "903895383F09B345F88A6B170F2F06BF75BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40EE83BD60D2E840CB08093598CF89909C3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D39A347A47EBE446F68A05F64F3C448D0B68",
                        "defaultText": "자자, 그렇게 놀랄 필요 없어!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C04-03c_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B15C78A462BA9647A68813687A021F5A3DAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A36FD2D9FAC104A7E5B2FC6871AC3DD5577"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "15FB92C414494846763BCA418830165E50CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F70A185676F474FBF7A63A29C28A61BE336"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CDAC68C0B2A664BF06BD5D36042F4A4C8DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "842A20D462B7074D7989EC7296F04F77EAAE",
                        "defaultText": "나도...{W:250} 처음에는 꽤 놀랐어.{W:250}\n하지만 이분이 마그놀리아의 여제가 맞아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C04-03c_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "114A73F08F4B11436F7834B21FFE324947F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6CEEBA7D3ACC8541097991845693F9195BB0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2BB4B341463F541FA7A8633DD0A40ADC842"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFA15F1B31ED844A1439E993FAA00E9020B3",
                        "defaultText": "흠흠.{W:250} 만나 뵙게 되어 영광입니다, 폐하."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C04-03c_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "482492D32CF7F445619B96707A2E66F05C7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC686BAC415527407C193486F16876D4D922"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7446E45B6BB1914B44182381F950948D31D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D020A4AC389C684C6A6841C36FE41C5BDE00",
                        "defaultText": "그냥 피비라고 불러.{W:250} 편하게 말해도 돼."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C04-03c_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "55B740B257A2E240C95A0465FC6B6AA67F97",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "002F06907876D34BAB19D0C336E4DAFB7522"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16FA0A0E52B2A6482B3A6BA1B1569FE2E6F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F0B5C517637279457B2B56222B364C12436B",
                        "defaultText": "뭐-{W:250}뭐라고요!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C04-03c_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B3E8FB837F54964B331A01E7538060039803",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7D556D068B7B647826830429990A18C929B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 11,
                "uid": "26BC244F62B4F344E14AB050043B358D1640"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1F0A30C6FFD824C548BDBE8D7A5A2AC7FAB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "514003273404D4451919B5C57183C8B0B60A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "485463029BDEE64C0178B96501FE0D26D2F8",
                        "defaultText": "안녕, 피비."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C04-03c_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5B6A959978F624492578EDF8831683CC07B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66CC7A472F38D74A5D4B6446AB9BE282918C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D05A5D237236343641A11B11262F7F62084"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DE507DB5BE1E04D083A62D3034533FA0E35"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7572132C631F624D254A3689921895BB2EF7",
                        "defaultText": "네가 그 헬리오스라는 친구지?{W:250}\n와 줘서 고마워."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C04-03c_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BCF398AC07F62147EC2BC4A1075EE883D046",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A530C1297105A846B358B2915F22120BB0E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A96993286704244C912BFE01342983545B2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "26BB19B48EA66543246B7D12FA0B7F4E5B10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FBF6036C5E3AA84E286A73D887B8629B3B5E",
                        "defaultText": "활기차다! 게다가 격의도 없어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFD3EC3574E8354608387DB839F968D202C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E24B51513F85144D349D7E8A365AE225160"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "755D64202BC3494386190468010F39B01E24"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "97803A5657E6B941A92B4065282AFEB63101"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A85076E39C50B647EC3B59126E2BD38ADFB3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "87D9E61E537AE14D267AAF613AC098C203CC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "@@@END OF VOICED DIALOGUE"
                },
                "indent": 0,
                "uid": "F0C38F088918A9457969FF9475A5AD299752",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFCB241B51041843F28B29E0BB9051D6A74A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E6F6AD6890F0E4477F1B8FA2ED4BD3686E5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6801B80A45B2A74FC6196E03B6E8A317EC71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E625591F7722634319287E37334219511719"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "024880F66279654E78793CF22A07DD38B111",
                        "defaultText": "그러고 보니...\n정말 마그놀리아를 믿어도 될까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0B6B9AA364C1348F63B299492448E084C98",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30CF2ED826F2D547AC7933E39E86DBE24A6B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF5D91BE6667604815383814C06AC4113F9D",
                        "defaultText": "상황이 너무 복잡해. 정보가 더 있었으면...\n아니면 판단을 뒷받침할 경험이라도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "05FCAA6C7A4EF240A32AA3080605B49A8200",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3BDAC92686E404BE76AA3D25965DC68BFE6"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "FD1F4B2A77DF52467179C163FC51AA911AB6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "44EE13CD76814547A989BB24B54D348827C2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "214372DD27B108496269DFC90AF117540298",
                        "defaultText": "게다가 이 여제는 또 뭐야? 골치 아프네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "696EECBE6F64494C7789DC23444938B34173",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96DCE30765558143463B674620D6A203C7C2"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "279C03AD41F36940288B8DE6880237790938",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E7C914A3ECB5145EA2A5AC43F686405360A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B0097F81A4B464C5C4A8E26E5D5875D81BC",
                        "defaultText": "의심하는 건 이해하지만, 겉모습에 속지 마."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AD17D8307591F946C14A06C7EC80ADBCA06B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4719393720BE4472F19D4B9588E0201EADF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2FD3B23201E31467849224306F928308E92"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3518C2C52A40B1477B4AB1B96E0551A32631",
                        "defaultText": "표현 방식은... 독특하지만,\n내 언니는 외교와 전술의 천재야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4ABBA4F58FA0F244E89B9C71461133FC5B4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34BB81495B96C343569964E9FB594C59AC6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5D71EF3A4947E842C6292E81E7D539841A0F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1CD2BEBF26C97848098B368285CF88282282",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "E3-Phoebe_line10_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C4AAE915603A684FB4486096B32240F884B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "40C8E39D8234274B0D78FEC5D9D7F4A65FA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "459193B695E2154DB38B2EC8A053438B43FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3403F1EE5E32D041663B2E21B2B1AF537A00",
                        "defaultText": "그렇게 말하지만, 우리 동생이 나보다 훨씬 뛰어나. 하하!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "631EAE6360FF454D183A47A4DF69E21FD480",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EE7CC9B32FE60465B79F2E08B702583F697"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "188C2E042D52A84502191DC2819CFBA181B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8B3EF9928D4A1435158F1111968C1C7DA33",
                        "defaultText": "그... 칭찬은 감사히 받을게. 하지만 동의할 수는 없어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "954020E148B2A743F289C205F168186D5425",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "164C418B36F81344DF5945423EE9905C2C63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12AFC81871051646F9082AE79AA025742597"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75DC570968B2F54D2C4A9963A35AB5D82D04",
                        "defaultText": "정말 낮과 밤처럼 다르네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E63CC3E282657745664843B7E8851A36142B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9244C5AA20F90242453A8BB1A049B5718FDF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B879BAB7ED7344710281EF382E6B73B58B8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7913B1F8D09F140111BF0D55DD60E0C07A9",
                        "defaultText": "아무튼 어제 전투 얘기는 파라트라스에게 들었어.\n정말 호이카데 병사들과 싸운 거야?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9EDB42CD4017A54B578B3838B26582E10DD4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FFBD5EC588B7243972957E2237D2E634350"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9B6EF7EE1348B14B9F28EC78F58CEC8B16E4",
                        "defaultText": "전 범죄자가 아닙니다! 용서해 주세요!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9D84FC6F6E236149651B1355C9963C4DBFAB",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "82E17B7E650BE84FB4781D6423335752D75A",
                        "defaultText": "그 전투에 가담했습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8EABCD6E5A899944030819046B8E706526C0",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "083D81D3573B774A2F29F2872C6CA2B46FA7",
                        "defaultText": "야, 진짜 재밌었다니까!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AE6EC0B133979949A7881D546EB3A2EC3D56",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "justification",
                            "justification",
                            "derp",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "149043CA178D064D842A3220DD7FF529DB6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F101B2CE1035E34FFD1B8714F3D4D7CF9B88"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "justification"
                },
                "indent": 0,
                "uid": "260CF37959DDB04EBE5A9554570ADFB00BDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "061AF2A28638F64EA25A41689B3F24589E82"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "59A008022159D54DB178CE674527D398E87C",
                        "defaultText": "걱정 마, 변명할 필요 없어.\n힘든 선택이었을 거라는 건 이해해."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "77279EAE55C305425B48B0D39A1207837B3B",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of inquiry",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1C8B88B61DDF9242EE1990F366F0A168224F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "derp"
                },
                "indent": 0,
                "uid": "D6D4DF108813D8461B4997E2FCD77F85387C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "582DC6C24EA9084FCD2830B579E5DA9F07FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "15C063AE1477814DF109D7C0AD16FD84489E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BABDD5C456DA145C69963F43C0E0B55F9B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96E564BB73E9354F635BB2B51C8E176D0AC8",
                        "defaultText": "하! 웃기려고 그러는 거지?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0A6652B3BACF840A79A1969FF4FCA486D47",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABA2DCC16E935741CB4A220147D9080BA08F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of inquiry"
                },
                "indent": 0,
                "uid": "BDE03B4543C9274AE17AF6C4DC713C8502EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DD6ABDA815AB5413E7A4C178C723F2A6A16"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2A442026E4EB24A634A86038B8F74BA6CF0",
                        "defaultText": "어쨌든 상황을 정리해 보자.\n너희는 세뇌당한 병사들에게서 자신을 지켰고..."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7986ED4A3A22034B798AF2581867B7EC6CAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7BDDB784B867742FF4A7A5745B8D17A6065"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DFBCDF7C0DF684476B085BB21E30E56FB6AF",
                        "defaultText": "이 모든 일을 꾸민 건 호이카데의 무니 여왕이고?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0B96E753C49124B7A6BDB67BFC64412E168",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D11AC1D44A023645396A33D8FE1575334B94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            16,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C7876A71B0445465E4A1AF6C1296FD75BC0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34B96BE7462D484B855B5B455B18799C38A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AB1FDD45EC45247FD384B8318ED7FFB01B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "238F58A16801C840C1198FA33FB2608CA29E",
                        "defaultText": "정확해. 적어도 헬리오스의 정보에 따르면."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "936BBCA5667A40436B196E284E61974424AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA2A0B108E04C144354BCA369E40511A1569"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42A6FB115D69274FC56B2C370329907F9A3F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60AE49265750444EEA991C6269EF07D06D21",
                        "defaultText": "헬리오스를 믿어도 된다는 보장은?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F5D7CE4D5621774D3D7B6BB14D54983EC8DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B323C0592124E343F4488E41B1437DE0ED8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78F2BCC11EA5D440F52A0C0556AD63CD5E81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "596326E678BE974B3A4AA5A3048CD570A9BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "196762BB5EBC284A8848262578ADD891A603",
                        "defaultText": "믿고 말고는 폐하의 자유입니다.\n말보다 행동으로 먼저 증명하겠습니다."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6AB0231B38D1554B7D0887B29C798F5893C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "010B30A29582A64BB3584235834858132F89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A605B456783B3540F0091652E02E1B838753"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CA9A5A47256344FF52A7B755CE2E17AC967"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5EA247C1B4FA44B5A2B5BD9E9DD94CE4676"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C79B45E31E7834BE88A34B9C084D4F39CA9",
                        "defaultText": "그는 내 목숨을 구했어. 계획을 미리 알고 있었고,\n내가 결백하다고 생각해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7AD2EA907056A04EE68BC373B42E9596D891",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "417330A37495B948A218A476EC9D893733BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A33B6AE617EE140417877662A690160A827",
                        "defaultText": "내겐 그걸로 충분해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EAC679EA0E77A54B713A47E5FB57853B8CAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF96D73B8BEFA0466619F1554D9A3073AF9C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F85BF332504D694C21289F83F452B977F309"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07B2309F711ED8478F9AC7B1C85414D851D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8144F2FC1CF40544E1590494E540B756D081",
                        "defaultText": "네가 정말 결백하다는 전제하에 말이지."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "791E218892F0D547C1685FC5F779A045BFE8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA7EF6A0701B2249F039B1442B2374CDCDF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "003EB9D540876848208A5F6609218C32FCC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12B681723535694D707B88149240AE3F4078",
                        "defaultText": "와, 여기서는 서로 믿기가 정말 어렵구나?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D8C2EFC480A3F247A48A5CE7B510BE8E8E0B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29BFF48282314540EB581544EC86D7A929B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "831F99698BEF524D091B5981613A20D87C23"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC60E09F26C2A641C55AED61D10D63551379",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "E3-Phoebe_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "00386F392F8AD440F34BB673F617B63C94BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1FBA0C5E90FA74452A3B64E3450F26043D36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7954DA056A36854809781517E8DFBF975CB8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "47975E5E0BC6134B7D0A8C87CD0B430499A9",
                        "defaultText": "언니가 의심하는 건 이해하지만,\n파라트라스의 말이 사실일 수도 있어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CAADBCC2115BE64B224B8113DA559A83B923",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77B2CA0A67D5D8473B496EC676A2372ABB89"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "91037E4A6CB524407138CC751E9D01DBD26C",
                        "defaultText": "파라트라스, 마그놀리아에 원하는 게 뭐야? 응?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3D61342D1CB643498D4B8FA726F853E88D36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBE6CF9F242D7340134AE937F24891C3840E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67A3D811289E024E9B0BD065EB0737C0844A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4E1783493EC8F34F0E593EF6C4CED5C3C72A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "51327D2314E7B14AD88A8F35674576CC10C5",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7BE4A6B878B33241D63931F59EC96D3733A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "339EF43E37F7434E1349AE166FEE9DE53D2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D267358E359F42461D5BE11670D0D4648030"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "F10753EF93E2D748435A6E7195F914E0D6C3"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "80954C6C4C9CC34ECA899603DA0AA2D7BE11"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "7C73B13B9E6C2445504B9DC68E91FC4D3940"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EC8D6B62A501646C258EB7719C4DD266610"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "93A0E66C85403147B978A482BA7096BCCD6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DA4240895173C048A8486CD743C21E8716E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D85C3B000F23464ADA2A22A150C89B48FB3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F85C4D752BEFE045878B7C02BBE90A3CC76B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D1A546FE7B19534901986E264BDC07DF9A5E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DBEC25694D6F7340FE6A62671DA4EEA75FAD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E7FDF06774093840878B1B388F7806F1517C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BE328C82E38124FA04B74C8475687DF88FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "817C40E92A7A8842AE7ACD82063171D7CE27",
                        "defaultText": "... 더는 죽이고 싶지 않아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EDCEEADE6CCE06408F68C569527453A3FB9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19B1F9773098164A294BF063DE0A26CA7D6B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 11,
                "uid": "02E9FACE5D18744AC95812A203672A91713B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C038C52A2854E745E96B1385E338B43C68AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB6E22E66DB5924A777B5BE053D9A5E214D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "939D0E7A01F5F045993A51C7197C3030F2B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8D1835F3BBD2340096979B813BD414FE214",
                        "defaultText": "그 무고한 생명들... 그 무게를 감당하기가 너무 힘들어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACF2654B5BEC164B2E4952662B5B0DE7DDB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3794B5EB1F8FC14E31596E357FCAE812ADC9"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E8282C654F9FB843EA3A5965F1D5EA5328E1",
                        "defaultText": "별로 괴로워 보이진 않으시는데요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F0BD139B50841947058B9D02EC306C1EF39D",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E7B67F2C4D6A2444F63914694EB3AF67CE85",
                        "defaultText": "이해합니다. 부디 힘내십시오."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D585B2AF5C1B814E438B3C3693753E7A1D14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "no pain",
                            "stay strong",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "9465B0DD3ADA7242760949A4938750E0BEB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FE5B3F828BDFD7458F58F9E1BE6671B4E28E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "no pain"
                },
                "indent": 0,
                "uid": "71321EB5339D634340587CC65C8EB29C5112"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EE9EA512D71E949526B0664E4371701AC4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC4CA3BE06884748131838A57831D2E32308"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A5BE1D712F5E148213AE3626A93BD15304E",
                        "defaultText": "칫, 참 ‘사려 깊기도’ 하네.\n나도 감정을 억누르려고 최선을 다하고 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "46E1D83B2D7915437B6AE370BDF15CBA14A2",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of comfort",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B751180A23A726486A1B0A0436459A35FFA9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "stay strong"
                },
                "indent": 0,
                "uid": "464B7D8882688540B56B1658BA22099968EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            5,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6CEAB9A996A4604BB55831451061BF06358A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "590DF4986205A846803A3745C6B86F0F5AF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E1DA55DE105B504E552A7AD28E27CC9A7076",
                        "defaultText": "염려해 줘서 고마워. 정말... 감사해.\n나도 최선을 다하고 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "82A652478743154B1A28C637FD1B80321ABE",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of comfort"
                },
                "indent": 0,
                "uid": "756E8D6D4AEE024D066A7191E64A168D894C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE8180B55138E544F61A2A4066B4FB60CB42"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAECEB4418CC1447A31BF3E15BBAF8174F0A",
                        "defaultText": "이 감정 때문에 마왕을 제어하지 못하게 될까 두려워.\n마음의 평화를 찾는 게 무엇보다 중요해."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "37AB9F91483FC24A501905B3EF5B94E39CCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5C77DE48AB50442EB5A67F623BF36959CB8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8CD3A0158490434DF77A6786907842846D61",
                        "defaultText": "그리고 지금 내가 안전하다고 느낄 곳은 하나뿐이야."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6BFA286F7245E34ACF185DF9F0824D91EA06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD188AF49ACE424EEF9B0BE6E986586A0D61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABE9050987870641C89A0208A7550D098763"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41192E31537DB846A3487100791B44D69419"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A8877C42F7ED64DB528A4524BD394FC8469"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE98CB36485FF04DE94A74E10520CB99C10A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E5EE5A2133E6A54DAD0A0B02759AF24314E6",
                        "defaultText": "라줄리스."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "409A7D316AF4614D61194C01C205CCA5BFB2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "765D37727D0841428D7A58E4A60FAE8558AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B41B5F892DC4D344BA69E19189A4ADB94714"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "41B19E03666BF246DC19F7B8EEE6E4763395",
                        "defaultText": "5대 강국 중 하나였지?\n이런 기본적인 걸 물어서 바보처럼 보이기는 싫어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4DDD96F666D7614F6B4B6086102FBD7C4F39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D9FD7155249984894198091720B741FADBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2DBFC5D42B09343AF8A708789C15A6B55C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BE2F90B1646F9455E590298DCC91D21DDB9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4B3E8B8063F104E2A6859D923EECE8AB25B",
                        "defaultText": "라줄리스는 엄격한 반전법으로 보호받고 있어.\n무니도 그곳까지 추격 명령을 내리기는 망설일 거야."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA371781628072447A6891A921BD16E08149",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C09824F44C7FD141715B40660AA5AA2CF215"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56E576EA6738B84E3A59891367FA3D28745D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48D9AA5586955749AF399A320A4B8525425C",
                        "defaultText": "하지만 라줄리스는 멀어.\n도착하기 전에 호이카데가 널 다시 잡으려 들 거야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCE32DFF44804643999961826A23A6DD147A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80038EE22EF5844D66699290CDCD00387F67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03E540775516E84FD9499057B0C86D4933C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4BF0C5F5AE2774BE17BA7B6CE9F5146F4D2",
                        "defaultText": "그래서 네 도움을 청해야만 해."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B5C8AEDE0C712843838A6B403C46FD0A5B4C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28452DDF1EBDA64CC45BB0263D1CB9AB063E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9664E0FC60ECF447E818EAF8A6D8A2599DC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ECDE4CA58BC8F2499029FEA67FFD06F65A6A",
                        "defaultText": "지금 널 도우면 역설적으로 선전포고가 돼.\n무니 여왕님도 국경 통과 허가를 요청하는 전령을 보냈어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CEC9E96675EC344CB25A7789BF82193FE63A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49D52F3C675D554FC07A1A945355E1E943A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA9E4C6C3AE4374F20691242FED3FE1B98B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96FA6222036C91464498EBD495482DB23679",
                        "defaultText": "알아. 그래서 아무것도 기대하지 않았어.\n시간을 빼앗아서 미안해."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "90B9636A3C36974A5D99763233AA5FA0FFFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1879EB3068B15643C77B71A50319BFC332B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7860D7107CFCC744F54B3B489D8B514723A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD9DEEC87ABD404054181E22D585895E4EFA",
                        "defaultText": "하지만... 네가 정말 결백하다면 이렇게 보낼 순 없어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CE65412966476840DC4A66673AC482DE5E28",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DB6CFBF188A974B9B3BBF684B60B90EBA24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "049357EB1DB66645D71AFCE5292232C54B73"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "917268AC1C98E44DB10A9BB3D173CB74DE21",
                        "defaultText": "... 무슨 뜻이야?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F143C0E6085B647F479F534701A64A5F759",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67BEA7FD26ADE749380A7B11566C5135D1DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FA83F2546BF9548AE1AD4F7A68C136D8FF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0DF9355269CAC647CB78A213869CCF3BDDDC",
                        "defaultText": "믿을 만한 전사 몇 명을 붙여 줄게.\n그들도 세뇌당한 척하면 호이카데는 트집 잡을 수 없어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0FC381BD2B998443A2382557CCC20257649C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AE442923B2E6840EF7AB198C9E344E40D96"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "620BC4EB1C3B1842716BE7A3F1A74E5FC2E1",
                        "defaultText": "하지만 전쟁을 피하려면 마그놀리아 통과도 허락해야 해.\n그러니 다시 싸우게 될 수도 있어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE65F0BB89761343E24A18F1DA76D2C1F3BA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E3ADC4C1B2C3341761854563EAF56F85369"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B154958510FA814AC15AAEE654DF69D62F68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BCEB31067C0C224FA62A9D225FD4653A6040"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7DE8F1C87B8994412F58E484BFA0096F5C0B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line27_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D7C6748674F35460A3B4107DC18A51998C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F54DC68B3532C64C0E2A7A8872F60124E6F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67FAC03166F0F145993A1819DA1236E9E72C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79476F400D9BA841C79A40A7C420F9BF625B",
                        "defaultText": "이건... 감히 기대했던 것보다 훨씬 큰 도움이야!\n정말 고마워, 여제!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA76E3720A99A64B052B1157E4E9D184F6A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7FD252B78E8C64F0239A6775D2CA7828283"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08A5D5B7260FF348A918DF1808F5831D6B90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F397A9802D95204C8518BA86360CA564C54F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E360F78052B9A3438C48FE152204E352EE04",
                        "defaultText": "뜻밖에도 모두에게 편리한 해결책이네요.\n참으로 훌륭한 해법입니다."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EAB8FE7203F00649382A8773E0F8E8C41B4F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACAE8EA988C1B442484894B2D360D460556F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D767937858EE4493B4A8B98D4D8E8EF5117"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "134ECBA363F0864C5539FED33F399932B320"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A71BBA0C26D81747493A4857EDAC0ADB0BE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F89776421943C14B203A3DF3E2CEA33C43DD",
                        "defaultText": "역시 우리 언니야. 열다섯 살에 제국의 수장이 된 천재지."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F083893253064846F959F037AD9AF4BCE356",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93C408537ED040455329A979E2D035BC0719"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "55E9227645E1744BF30BD0790E7D43A7EBDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BEA51957301B74F231BBB72654D708CAD0B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A6E695C3DA5D44A9F4AF798AA0F029C2E70",
                        "defaultText": "헤헤, 칭찬은 그만해.\n난 그저 마그놀리아에 가장 좋은 일을 하는 거야."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F70F8DFF19C4E14C105B050481326CE03360",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B0E97176D5BB94A5B9BE84772C7F3F13464"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D525F49B49572746216B00607B805F19FFAC",
                        "defaultText": "파라트라스가 진실하다면, 난 무고한 그릇의 임무를 도운 셈이고,\n아니라면 호이카데가 도망친 범죄자를 잡게 한 셈이지."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6D62F7D6269A140B32AD596A49E10E9AEA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22B469348B277540101B87B7E01572EEDB20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ED89E6901F32442978814895B8E54446ED1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B140277A3A9D524EEA1A74581D0D93E4DCD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E28BE7A84095904E211B1AB8A2DD98A491EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C50BBC71B821742EB7920E93CEA609450B1",
                        "defaultText": "그건 그렇고, 넌 어떻게 할 거야?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C398BB6905FB6458B9B4B474BB6545B5C5C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4403F2862D52D74AC31B472407F4E29D143B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "BBF010A5447E574BD559F3C7255F98A62076",
                        "defaultText": "저요? 제가 할 일은 하나뿐입니다..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "97C4932F3C85414CA7482A45347753637016",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C50AB10629A98541D5884562A7F2405C33F7",
                        "defaultText": "파라트라스 님을 따르겠습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C2305ACA7DF0384E03791194F7A2EA51D0A1",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B47F5B9258E1B947E0780136E4513B6FF7B9",
                        "defaultText": "뭐, 제게도 임무가 있으니까요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "71C642F35F28654E6B7BB814F3D51D39FCD9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only answer",
                            "only answer",
                            "only answer",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1303701E3EB7E946181A14986C6E39F9D9F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B04B7748420730417B591278F9BF62240490"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only answer"
                },
                "indent": 0,
                "uid": "31E0EB93486AF34CCF5A933457A6F8C8F555"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC61B8853985E94CDE899748C26953B7E101"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2DE5967771F8649115800A1E8E6AB70446E",
                        "defaultText": "좋아. 네가 파라트라스 님을 따라가면\n우리에게 일종의... 보험이 되겠지."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "125D6C920E723442807968158549601ED5FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46ED01589B257842B93821235A7D3BC676A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A80AD5E4857013436E480F22FB28AB2D614F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E2A78F876BC8134E2838DD94364866689511",
                        "defaultText": "그렇게 봐주니 기쁘군."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9554E5D20681144A9C4BF5F750A652D862F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E3A060A658B244C1F4AEAA8B69DDE0368CE"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "Name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BFA40A459C8E1041028BD9144C1A06E53597"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D35BC40369FC145B929E0810BD8E67D8408"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C5B6D66816656451E6A4C21870BB0A2F180",
                        "defaultText": "그리고 {LT:1}, 네게 확인할 게 하나 있어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "09118E026B24314B8F893B922703EAD98769",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12860CB14FFC7046D64A76514300DF4CF2BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "720B9FC8725E484A0D1BC1B15148309D0BD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9EB531972A5C6149051AB667CBF639D4ACD2",
                        "defaultText": "응? 그게 뭔데?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0B83AF55254E048D1693450B2260A96FB4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCFE0F443FFEA345A7495D17C82EA60A0EDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "61D8087C765F6042868BACE3E7AA937E53EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EF4CD1639C8D243BB3AFFB83E8B831B7B0D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "250E975E75E3C544605BDE58F5E857E17F30",
                        "defaultText": "네 검에 달린 마나드롭...\n그거 정말 마나드롭이야?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2DB194BE7E89654B073B4F59BA7FC834E10E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6C6CA1C39EE92443B8AE7546E39AEDD3B19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BC11BD85C0F17453138BAA4787708C6D944"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2FD2ECAF7DBEB043E32905B431BE59640B2C",
                        "defaultText": "음, 아직 어떤 주문도 기억나지 않아서 확신은 못 해.\n하지만 다른 무엇이겠어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C854DCC730147340769A6E69834364A93509",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8774C77D988B3843857AC8360023593E7CB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EB44F315CB6394B84381C0804F5BA2ECF2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97771BB23101C84ADF1962855D66D26B4350"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5955ECC28E582242845B79B451DDEA5F45AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAC0978D168E0649C2884216AFCD682CD03B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line24_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FB0048126E399047903B00B42C5AFC894E34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "00D42BEA718F1747AE4B0786011C83D18A73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5843676635FE847B35B84A2135C8F9C616F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BFD3F4095518C54D5C495173289A40141163",
                        "defaultText": "흥, 역시 우리 생각대로군."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "333A17E4492496470D0AEA526A60906D874C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6461204930B6E14C2C6B4190AEF1E59AB333"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EEC7150E82FCE246BC1B5731BC4E698A425A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A93046239408A340052A2DB6C22FEA951954",
                        "defaultText": "오르니에르 경. 여행 중에 그 물건을 본 적이 있습니다."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C01D38835292E4486B8B955150ACE276CECE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "445CA4C665F156485E4B3493DC000F6B001E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BEEBF0D23D693449147AE1E3504C11996DC2",
                        "defaultText": "기밀 정보입니다만...\n계속 방출하는 마력이 조금 특이합니다."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "52051D488C0FC644FD5B80E44AA1C00C8B04",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D18E16CD319C74411169D865B019DDC7ED37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "50DC72E58F722144B24A3E179FE6C47585B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB25395C11E8A949D968DA4110A302D6F27B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "E3-Phoebe_line13_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "415EBC79667FD64CDE68D543CDE127BED12C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "56FEE9BE76B15740AC3BEB65984DEA87A114"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA43CAE77A64334D84384A483C5AE0FA064B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9F6CE24B1C5796411B1AE76788127C647937",
                        "defaultText": "확실해요. 그건 마나드롭이 아니라...\n{SP:1}{C:1}마나크레스트{C:0}예요."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "577BF51C9E3B474A2F69E4E7F650B5FD8A69",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBBC19C03146404DB419A2B84721AF571C47"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4150A622524B2844927991F684FE02CB5EEE",
                        "defaultText": "마나... 뭐라고요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FFE4BA082A652648D59A0663D8A67EEE7610",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9AC72AFC607CB2468A4A0B20543C6BE96678",
                        "defaultText": "그렇게 특별한 물건입니까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9B88204336CFE14E3119B2E2045E12A5F1E4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7C14CC5E3EDDC643FE7966E8A156A64306E2",
                        "defaultText": "드디어 나도 주인공 보정이 생겼군."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69BE2AD265274144F93850E1DB021E95DE58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "a what",
                            "nah",
                            "nah2",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "3856C2A13182A94AE0996611D7F8057C0A1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "74E95D4E0CACC540014BC8A91D726EEF8CBD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "a what"
                },
                "indent": 0,
                "uid": "54DB08EF81D3F846AE28BC654458E5DFB3E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70D65D6B5DA16844BC78AD7762D83D57CDBA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A99AE2B863EB948A149DDD6054C7F588DED",
                        "defaultText": "마나크레스트."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "30AF8E8E4D6C8043486879C76A5BACC62FBC",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "final answer",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "4A2EC1283211E24C153B3301E66E23D7DFAE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "nah2"
                },
                "indent": 0,
                "uid": "58236E4E9BB9D74035792D78ABAA233CBC83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            4,
                            2,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19523EE577EFB0489A1890B7B7BB1637F3AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "791D8BAD5350A64E1D48094279D05B3E2BE0"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sarc\n+ str"
                },
                "indent": 0,
                "uid": "8A7B02928AA6A248C24A259658BF9DDB01AC",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "nah"
                },
                "indent": 0,
                "uid": "558F03A820BA6244FA58CB00954D1DECCD20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7C33F533F16454BBC19423216DCC128917F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6CE0D9B0E95624F3638CE33F2BB24CA5877",
                        "defaultText": "너무 우쭐해하지 마."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F98F566364AAC0465D19ADE1CF0C56678904",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "final answer"
                },
                "indent": 0,
                "uid": "5CB10CF42286574B8939D6E67AEA825A6421"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7168B80F6228D044DD5A8FA4673A39FC6078"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01B3A98A7C58D6439B79E4612BA01616052F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8D110394BC3C9424D3B342198C8171C0BEA",
                        "defaultText": "정말 그럴 수가...?\n마나크레스트가 존재할 거라고는 생각도 못 했어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EC17FD014D7BB24811899926598373737AB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A51B67F578B315400A688989F1AD6C469EC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55FA84752B82B1432C5A965853870B2D75BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48DB1A0C6B2427469F3997810207ADCA8F10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "778212082D294645FF8BEA51FF51690EE369",
                        "defaultText": "우리 정보망은 타의 추종을 불허하니까, 확실히 말할 수 있어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8F0DE47E35C51347C24A9F122D6F4F1CD9E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3DE7FE858D2244AC06ACEE65B061CF8812D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0EBA4B9D627E964ED97AFB641E551AEEF291",
                        "defaultText": "동생아, 너도 일행을 따라가.\n그릇과 오르니에르 경의 마나크레스트를 더 조사해 줘."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "39E0F95D6786A04BFF3BF321B342527980A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B860D5C578722845A728A904408B2237BEEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CA3918A8BE910455D19FB901964FCB3040B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "959D436F835CE1458A4B804228E83458A86E",
                        "defaultText": "이번 주 계획과는 다르지만... 어떻게든 되겠지."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F85468BA6443A34C320A9B43FDE69274791E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EB025FB3B53804E4F189C056FABD3118B57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "000CA4C02C451340FA5A13D8C185450E1866"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AED28368222DE24B3C2B0617F4C93055F009",
                        "defaultText": "잠깐, 마나크레스트가 뭔지 설명해 줄 사람 없어?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2C92FFC7E45D8491C0BB5D3CD264EF29069",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA94CCA0230F404E926A38D59400D5B85C08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BEB641B5978B644805B64F51761E6C29B22"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E310327675A58643F80B39C09EFAD067DCE7",
                        "defaultText": "곧 출발한다. 준비해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "822728AE3DADE642D919DA6338F41C8276EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B391800C4A8D00412049C431F82BBBAA133B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47F8F6B1950F534B54498124A1B9D36C8F8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A7B730D087FAC44B7F08F2111908F429F78D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D629EF073BA5974DE16B5F4705406DCBF028",
                        "defaultText": "저기요? 나도 설명 좀 해 줘!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A00527F86E58644A745810E7775C27A92E4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D065B84353F0A143F248F9C24D94B577FF79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9EBFC140D9C244B276BFC626D0C3EFC1134"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BBFBDC38D9416465F6AE575F72584055685"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "C595C2DD860CD3476E7A3726EA01DCBA3D26"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2719C6D85D86534D708A58083142A52E365E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B44A0F7A2C32A146F619F8B8C66B52BA11C1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "9C68FC5249359142964BE5085E7E556023BD"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "they all leave"
                },
                "indent": 0,
                "uid": "A5D69C903AE2B941012B28F366DD53B0D805",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FE06FAFA146AB540D46A2282F15F755437B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "983263AD1B9E6146C58A0205DA96523C8228"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F4BFC3AD6572A743543971B4EB3282751DA7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C14DF6E7260AE84E767958721F3B8FDDFC8A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line5_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F5D1F3B6037CE1430A4B36655F85BBB8CDD2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "110380127A83E84E8E2AF92409EB847B20A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6A1DD54520308457D7BE68797AFCB32609D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9BA148A492995465D6BD384CF54748ECD3D",
                        "defaultText": "저기이이이!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FFADE5B23A55984F8F380C713A7D25B872DA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6BB4A9C46BA83241975BE0818D0CC55D3079"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CACD7FBF8F52D9474E8AECC41519496B1471"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AFD127542F24042A6281EE13F961DBA3BEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7687BBB27DC7A246700AAAC4369723C53976",
                        "defaultText": "하아... 수수께끼가 또 늘었네.\n정말 신난다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C57F5438887054EE469D41204F671342BBB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6B8764C06292844BAD2BC598DF935CD90690"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FB507477B18924A4429C421F287D3BB2D6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7FDE9FEF9FC1724F560ADA801DCF74DF0223"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAA69C2452A51441D4384913835107ACD67C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9A71BD454113F24C435A3A55B9972715D847"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B60994801E8AA540314AF9F45806739FBB8E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D31EAA511478F842C6093B81179E3BC7C8C5"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "A47917EE0994D142F19812B768BF23A8275F"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Special debug for Kalevala ch4",
                        "index": 275,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E86829180E7B24AD12B5269C31ACCCD272D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "E643CA3C24B7934F8E083C717D3308010C39"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "6E1A57D05D0E404BE6797E44DD6238D8DB9E",
                        "name": "SAVE BETWEEN CHAPTERS"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BC24E2934519E0490319B8D6D0A73951CC42",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "Name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}