GS.dataCache['AF6B191E05B0F9431E4A971168D479957C76'] = {
    "uid": "AF6B191E05B0F9431E4A971168D479957C76",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-11 P1 Kung",
        "type": "vn.scene",
        "parentId": "F508C5263CB486488129D1571D6ED73AA9B7",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 0,
        "localizableStrings": {
            "17DCB2299640354F0C2884177CE1471E73CE": {
                "t": "Are you ready?",
                "d": {
                    "cid": "78F198A87CFC77486A5810754442C8E47971",
                    "eid": "2E6A2C472DD481428A694F45A7C7ACE87A1B"
                }
            },
            "26E8066A650ED4458B5A816676B552694197": {
                "t": "Yes, let's go.",
                "d": {
                    "eid": "5FF8FFBC3071384A2B0961A347FCE93B7723"
                }
            },
            "4BC440562279A3418D7976536A30E90D0F49": {
                "t": "{C:2}We still have something to do.{C:0}",
                "d": {
                    "eid": "D9BA4C948545C54170787485CD87C679ED14"
                }
            },
            "3EA8014681AAB749ED7A0262B9BB3CA12FC8": {
                "t": "Great! Follow me.",
                "d": {
                    "cid": "78F198A87CFC77486A5810754442C8E47971",
                    "eid": "D48F351F85E7034B874B14A9A0C03AD5E8DA"
                }
            },
            "9F84DA7829A3D94D0A5B2A61652BE2D3CED0": {
                "t": "Take your time.",
                "d": {
                    "cid": "78F198A87CFC77486A5810754442C8E47971",
                    "eid": "0B9FAA862EEA824A0F9B52F16753214BD6CC"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "CD5C5F9B7D3201430018E1C2EF9C8F0EBEDB"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "78F198A87CFC77486A5810754442C8E47971",
                    "duration": 33,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 2,
                "uid": "90724B9A616EB54E3338CDD9A70F9C0B4CF2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 2,
                "uid": "39A731AC670024436A99BEA6E5ABD6EFA42A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EA62F0872628049C0687835276B84E1B669"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "78F198A87CFC77486A5810754442C8E47971",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AEAED49073B7A34B4C29F20018F3387C13A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "78F198A87CFC77486A5810754442C8E47971",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2319424D3BEA0148097B27C7193D7B2A8409"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "17DCB2299640354F0C2884177CE1471E73CE",
                        "defaultText": "준비됐소?"
                    },
                    "position": 0,
                    "characterId": "78F198A87CFC77486A5810754442C8E47971",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2E6A2C472DD481428A694F45A7C7ACE87A1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7A1B5240F6A61427C789A41DC3C960B4A8B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "26E8066A650ED4458B5A816676B552694197",
                        "defaultText": "네, 갑시다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5FF8FFBC3071384A2B0961A347FCE93B7723",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4BC440562279A3418D7976536A30E90D0F49",
                        "defaultText": "{C:2}아직 할 일이 남았어요.{C:0}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D9BA4C948545C54170787485CD87C679ED14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "letsgo",
                            "notnow",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F11A9FE92067A44B496AC5768636633D65CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9D9CD3522012564A2678D38486326FB392A3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "letsgo"
                },
                "indent": 0,
                "uid": "543FD0F105205141FE48E650CEE8C41F9AF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "78F198A87CFC77486A5810754442C8E47971",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "591BA2B61116414364781B9491525AC7629B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3EA8014681AAB749ED7A0262B9BB3CA12FC8",
                        "defaultText": "좋소! 따라오시오."
                    },
                    "position": 0,
                    "characterId": "78F198A87CFC77486A5810754442C8E47971",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D48F351F85E7034B874B14A9A0C03AD5E8DA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "166792706791214553982E6522424D171FB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "57FDB2FA62D39241EB4A6A454842A3C34E78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE2143A982FD704A6F0848C955E429E1EF1F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "F54FABF9365A4046154AD007A39A6FC9E838"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D54A6685A4CE44D0D9B0D98E6DD1C66FFDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            5,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "12D3A2762E447340A208B874DB110965A437"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "626559B94276E6456A5A8404CBA7B187F115"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "99F360655D74F048190A9FB66FC8236C0FC0"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "C279BB2D175B874BCD7BC957EB3EC9643B97"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "689E13E85E57B84A209BC4928216D89907DA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Good Hot Springs event?",
                        "index": 192,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "09DF55A4698D54497B6B5FE373853422A7E4"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "1DA9A6C7449D034DB2886F719A1364D6E82A",
                        "name": "C8-12 After the hot springs"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "BA1A792E4A78D1429888AE35253371DBC313",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "F07BFDA334CDE54AD258FA278F164341E165"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "54712F9D78637342EC287958D630ECF050B3",
                        "name": "C8-11x Hot springs (Exploration LUCKOS)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3D4CA48737205441195A5E38EF0C84284B57",
                "expanded": false
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "notnow"
                },
                "indent": 0,
                "uid": "A32088F13DBAB948E019907333FD7709A9A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "78F198A87CFC77486A5810754442C8E47971",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1643F91402C0F3404E9AABC2FA0F20E6C651"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9F84DA7829A3D94D0A5B2A61652BE2D3CED0",
                        "defaultText": "천천히 준비하시오."
                    },
                    "position": 0,
                    "characterId": "78F198A87CFC77486A5810754442C8E47971",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B9FAA862EEA824A0F9B52F16753214BD6CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BDF971A964FE0484538419184FD8CC6F7FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49CAC3A874A4B148442ADA85CFFAA7E3F06D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "409C401A03C52449D7390E2939C5B6DE6349"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "78F198A87CFC77486A5810754442C8E47971",
                    "model": {
                        "name": "LazulisArmorMerchant.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Lazulis",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 702,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 765,
                        "y": 406,
                        "zoom": {
                            "x": 0.47,
                            "y": 0.47,
                            "d": 0.47
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 2,
                "uid": "147EA5BD597D434B7D6937C93FE98EF650D3",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "78F198A87CFC77486A5810754442C8E47971",
                            6
                        ]
                    }
                },
                "indent": 2,
                "uid": "9A91BAB490DD3346B93A56D2C89FF8301E5A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 31.200000000000003
                },
                "indent": 2,
                "uid": "E55C9FD057FC5747574AAC066CF25CA4E18B"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}