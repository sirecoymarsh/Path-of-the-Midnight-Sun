GS.dataCache['7FD20BD43FD9E641B7983FB23DA01592AFF3'] = {
    "uid": "7FD20BD43FD9E641B7983FB23DA01592AFF3",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-1b (Talk) Suzaku",
        "type": "vn.scene",
        "parentId": "DF8BAB6145BEB846567B9D3341D445F10851",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 7,
        "localizableStrings": {
            "F6435A186D35534D9F79DE128BBEE490E4CA": {
                "t": "A lot happened since we first visited this palace. Don't you think?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3329FD01713622434A5AFA03C2C20F420074"
                }
            },
            "F91443703FF46545EE6A6E751CB3AFDBF0CC": {
                "t": "Yeah. As far as I'm concerned, it was also my first time entering such a huge building.",
                "d": {
                    "cid": 0,
                    "eid": "BB79DFF80152F8402B1B72C37BB13099202D"
                }
            },
            "A4C8016D18BDC143397958841910B3735702": {
                "t": "At least, for what you could remember.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7BB010350AB2C74EDB1A53F1BA5E6F3BEC37"
                }
            },
            "177A60E16BA0F145C64AC487AD48CB3E660B": {
                "t": "Heh... Yeah.",
                "d": {
                    "cid": 0,
                    "eid": "116433A262FAA241DA387DF96980563957F4"
                }
            },
            "5D57999F956AD343905A6407AB173051E2FF": {
                "t": "You know, that time I saw you in the forest, when I was on the run...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AC1097C36430854AFE29DFE433EAFB855FEF"
                }
            },
            "27E94DFE6E10474B7E795F77C98D1BE3309E": {
                "t": "...I thought you were a strange and suspicious guy.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "52C662075F6DC840CE8BDD68C142953845A8"
                }
            },
            "F4F2C30F55557146B55BB0A6639AB9AA4C0A": {
                "t": "Haha! Straight to the point, huh?",
                "d": {
                    "cid": 0,
                    "eid": "31750478819EB84A7C09EE8856F5395BEDD3"
                }
            },
            "12174E4F91617646069A0586CECA65405670": {
                "t": "But honestly... in your shoes I would've thought the same about me too, Lady Faratras.",
                "d": {
                    "cid": 0,
                    "eid": "7545E409809EF045F638CC338482C9D173A9"
                }
            },
            "AC466D6A8EF0D245790850C33915628BB258": {
                "t": "Tch, it's nothing to laugh about. You were in such a pitiful state.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "64DFFFA65C842742F5282057867228B29485"
                }
            },
            "11E43F6E8F6BF442E07AA657C49511AE21C3": {
                "t": "Acting all high and mighty when you couldn't even remember where you had slept a couple nights before.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "921EF9FD906FD84007684C99492F55BE08DB"
                }
            },
            "EB2C54B952B2B74A5A0967C4CB2D7B70A395": {
                "t": "What else could I have done? Started living in the forest hunting boars and wearing bearskins?",
                "d": {
                    "cid": 0,
                    "eid": "73989A5451A5B0426D28AC234859CA8AEB4F"
                }
            },
            "0723AADC42EE324F269B51C5F315B7FD2039": {
                "t": "You're always like this. You always laugh at your own misfortune.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D01C8E28267EA54F6E79CFE8D3B6E73CEEC0"
                }
            },
            "BA74135979A5D44E51690871EDD05E00E234": {
                "t": "Even now, when you've just discovered the sad circumstances of your childhood...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "595255CC4319094A123A7017B62D12E048EB"
                }
            },
            "4801C96D474D3843C238217262DB78BE70D3": {
                "t": "And the frightening reality that your entire bloodline might be demonic.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F941B7757B897640A9683B516C779D2E201F"
                }
            },
            "93B5E08B801FF844FE5A1A7533C1C5B87266": {
                "t": "Frightening indeed.\nBut who knows?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "2DD7F8EA450F294F444B7407E9243B636647"
                }
            },
            "40425A8434A1374B5458C8C113D182EC7EB8": {
                "t": "Maybe I don't like to feel sorry for myself.",
                "d": {
                    "cid": 0,
                    "eid": "AA082E678BB9F44022181FB6187AE2805CEB"
                }
            },
            "0128EDB25DCFE645AC4A1BA639E95E323ACD": {
                "t": "But you ARE upset, aren't you? I know you well enough by now to understand that.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "46E64EB9582F3844FA19BB43103253BB0393"
                }
            },
            "5D453137343C3242E14800B8218D9CEC693A": {
                "t": "Why don't you let it show, then?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9E28990F4FEB344896689E13229DBA6E4169"
                }
            },
            "117C891745ECC44FE38BFBE75AAEE46CDC3A": {
                "t": "You already have your own problems, Princess. In comparison, those of an orphan like me are trivial matters.",
                "d": {
                    "cid": 0,
                    "eid": "ED9D4A30803BF54D88592E25D421AE3B047F"
                }
            },
            "697D323E1BAD804E4D8AB09472A5B6584BC3": {
                "t": "You're not wrong.",
                "d": {
                    "eid": "4FE7A55D858D524F6E2B7981A9EACC65B761"
                }
            },
            "0249E87768B3C34F6C7A96D3378126E6B40A": {
                "t": "Are you underestimating me?",
                "d": {
                    "eid": "519D4A093EAB974F734B8D14DE898C010E5F"
                }
            },
            "7D38F3266C2A674A2A0A455406D73831C2CB": {
                "t": "I'm here for you, too.",
                "d": {
                    "eid": "BCDEDE356C69B54FBF7A78B7BF50F7A63F15"
                }
            },
            "64C5D1A93FF2B643446AAD3822FEB3E43762": {
                "t": "Heh. See, everyone has their own priorities.",
                "d": {
                    "cid": 0,
                    "eid": "20AEF3645EA80944015A81767AC55F9E3C13"
                }
            },
            "E14A88AA6293F443C028BC60DDEB915B5065": {
                "t": "I was just trying to be nice to him...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "138C3B4F6EC5E843F37BCAD6EAA2607FA0D9"
                }
            },
            "D4A0CF883D5AF548DD6914137665E9FBFD7F": {
                "t": "But I certainly can't force someone to confide in me if they don't want to.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4CE44F4F834F9148328A7525D968711108EC"
                }
            },
            "A5C7C9888725884F5D8B8531D195CCAE8393": {
                "t": "Too bad. I really wanted to talk to you about these things.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4880D29010A87747F08886701A9BC0A2980B"
                }
            },
            "7E5F61741F90E845120B9F45FEF4FC5C3954": {
                "t": "I'll be fine, just like I know you will.",
                "d": {
                    "cid": 0,
                    "eid": "44FC86640226844E3C68A12960D023517839"
                }
            },
            "4B344DFE42A9F7461B6932527691CC2C19D4": {
                "t": "Yeah. I guess that's how our relationship is supposed to be.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F8724452851D5245575972C49CCC4582C316"
                }
            },
            "B4599A972FBBC6443088C3571972B3291147": {
                "t": "Apparently...",
                "d": {
                    "cid": 0,
                    "eid": "A5D82D648F07114ACF18DD065182B898514F"
                }
            },
            "DF027E3B6A449648254830D99D2EBF9A03ED": {
                "t": "What?",
                "d": {
                    "cid": 0,
                    "eid": "D5864FCE133A764CC69890E4E5F2B7357901"
                }
            },
            "37E58DCF465E7543EC7B47105384096188EB": {
                "t": "I can handle my problems AND yours. You're clearly underestimating me!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AE4AE80D22E3964CCF396DB345575C36B4AB"
                }
            },
            "155738D867ABA54A75296DF715E7C336DCD4": {
                "t": "Lady Faratras...",
                "d": {
                    "cid": 0,
                    "eid": "D35166401BB54444B5583F08E65BF540521E"
                }
            },
            "B6521F1817FAC44E425B53B4D2C6DE9B8E13": {
                "t": "You're being melodramatic by pretending to be strong, but deep down you're suffering, aren't you?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B09981A64CBC2044D0192612B5050385ABBA"
                }
            },
            "64FF9FF08886D34ABC8A32B4AB5CF494251B": {
                "t": "You were hoping your memories would come back once the truth was discovered. But they didn't.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3D519A861B0A3246F739815472C2141F203D"
                }
            },
            "E1CDCBFD8034794444287057EEA19FD4446B": {
                "t": "... ... ...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "ADEBDD321C0A2146C459BBF1A94121A8FC6E"
                }
            },
            "33ADBAB15E51A04A432AD92315287551CA37": {
                "t": "I can understand that, because I once had similar feelings myself.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A73661F95A36594571787AF042AF26E94108"
                }
            },
            "76923A168E7C144DFB784BD77E680BBF1FE7": {
                "t": "You know... My sister told me a while back that I'm honest with myself.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "74509A2139070547D468E5D5B468C5CDF95A"
                }
            },
            "B4CC56E645DBA040A64B363135D505D8DB2E": {
                "t": "Shiori told you that?",
                "d": {
                    "cid": 0,
                    "eid": "E0C70C00664668406B68F21724F4E5AFD7BC"
                }
            },
            "22BF58B34BEA2149659B6103EFD1AECD3610": {
                "t": "Yeah. She told me that when I'm sad I just cry, and when I'm angry I just yell.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4905AB9078F60142331AD966049F46195208"
                }
            },
            "BBAECE7B543D734E6F2BBAE95FD2762AB49E": {
                "t": "Pffft... Hahaha!",
                "d": {
                    "cid": 0,
                    "eid": "E7BFCEFF24E4F54980896AE6FF25EE92A516"
                }
            },
            "83EA42DE520308418A1B9D883A4DD4C2466F": {
                "t": "What are you laughing at!?",
                "d": {
                    "eid": "36A4A1516B504144126A0DB53AF10B7454D2"
                }
            },
            "241BE554445998458289D89217602DB1E083": {
                "t": "You're about to get an Oblumbra in your teeth!",
                "d": {
                    "eid": "14315F993C4C9843C23B9E63C8AB008A32E9"
                }
            },
            "59AB8E6A20F526498058A599806C8ECB0931": {
                "t": "Sorry, sorry. I just find it hilarious. You used to be the complete opposite of that.",
                "d": {
                    "cid": 0,
                    "eid": "893A3CD94C22D44D151BFAE8525815FDF1F7"
                }
            },
            "54FB4C3D0E9E3940E0486402D3E53CEC12E9": {
                "t": "Hey, I've learned to open up more to others!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "155F939460D9A84CC34A1666377E41BA259D"
                }
            },
            "4CBE8817670C6446F49B0E860DBACA31F66A": {
                "t": "And... to be more true to myself, Faratras, instead of just being the Vassal.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "65AC3D5F33D6F64D3C289377E9BF79122ECD"
                }
            },
            "FFC82DE85759D843DC0A745385E98863C257": {
                "t": "... ... ...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "F0D864BD3734C74C5239E536B7A6DA4A45C0"
                }
            },
            "FD01747F30EDC742881B8B077C68E55B94CF": {
                "t": "I'm glad. In my heart, it was what I had always wanted for you.",
                "d": {
                    "cid": 0,
                    "eid": "210BD4DA44C533473D4B92F30F5FE23E5AB3"
                }
            },
            "41AF211C41C6524E8C6B1D2307595C68F8F0": {
                "t": "I know. I get it.\nYou've always been--",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9B2794C83DE97648401826E590D84DBBCD43"
                }
            },
            "CD2356956C77424E182A4560353D4BFF96FC": {
                "t": "Listen to me, {LT:1}. Is it really crucial for you to know your past in great detail?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9790FB794211A345564BED521FDE15768A77"
                }
            },
            "46D3519B3133F24C770B31265594A745AC4F": {
                "t": "What do you mean?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "16A8266B2340C24A10799DD991D5B0731E9C"
                }
            },
            "A854AB452B15724423899294CC8E3A037BCD": {
                "t": "Maybe, just as I thought of myself as the Vassal, you too have clung to your 'old identity'.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5E81B67430D8424A30780AE8D4BCAC9FAD37"
                }
            },
            "E738D39E88BE394898685C34F69D623B56D5": {
                "t": "But I am Faratras. And you are {LT:1}, here and now.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BEA1A24728BB36403978F9221E5621AD8BAF"
                }
            },
            "E4F7FE603BA2934D3F6A2A735CABA488F9B9": {
                "t": "... Heh.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "A1A5BAED46454147F5880EE274E8236A97CB"
                }
            },
            "7A4196804CC2174E0E4817824B879745E69E": {
                "t": "Yes, you're right. Thank you, Lady Faratras.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4869FD0D1FB8674801881057EC545321890B"
                }
            },
            "D72539908330A1415F1B1B24201843F0B259": {
                "t": "I will... I'll think about it.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "688141D11A5AC140964A5115F0F461D8EB8D"
                }
            },
            "4135FDA71152624FF148C076D0B5AB88575D": {
                "t": "Take your time.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B359E75D39E5A049BE9B7DF824274BFB798B"
                }
            },
            "C801C2C02A80934869796E88A391CDE943A6": {
                "t": "I hope this gets him on the right track.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "65C5A2951D72A541EF589202D152D372FC8B"
                }
            },
            "5CB6AE46282E90470C882C452027DDDF9105": {
                "t": "He's been by my side all this time, and the least I can do is help him in turn.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "879EAAFB3484804751494DF31429E4927452"
                }
            },
            "D75C3BDA12E6B842503AEC38CC3D0472216F": {
                "t": "Oh...",
                "d": {
                    "cid": 0,
                    "eid": "0D05328E80883444677B93E433D516E6DAB9"
                }
            },
            "9E117EC01FAD164E0389E8214DAC65A9971D": {
                "t": "Heheheheh!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "3AF21EC1629CE24B8F5AA4B85FBBA3A68C65"
                }
            }
        },
        "livePreviewDisabled": false,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "C346DE1A3922C349738B2A24C5502E848934"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            4998,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B12187E29BCF840CC4819548072FD8F5740"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96FF46F348819743F2788386E045F8CB7F4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            12,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF645B91660C274F26085DE02495BDCD3C6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E83286C1CE7F34DA42A9D73643CCEC3A97F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "466EAA9F00CEE242B629A698F4843A74B32F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2229CAE0E324541695A8A864A93AACDB12F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5F00B438288554DD64A847433610320E7B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6435A186D35534D9F79DE128BBEE490E4CA",
                        "defaultText": "우리가 이 궁전을 처음 찾은 뒤로 많은 일이 있었네. 그렇지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3329FD01713622434A5AFA03C2C20F420074",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA19896B033AC34A495B7D7019B9513DE158"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "7F0ACAD567B3964CAF58E819CCBD532C6C3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "1AC066E3518C494BC23933D30FBC0986E1FE"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "532DADD43FEFD94C9B185543492DE2DC69C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17290285390109418639D111A3CDF68BDFB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F91443703FF46545EE6A6E751CB3AFDBF0CC",
                        "defaultText": "그래. 내가 기억하는 한 이렇게 거대한 건물에 들어온 것도 그때가 처음이었어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BB79DFF80152F8402B1B72C37BB13099202D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88CDAB3180FBF64CAD98FBE595FB216187C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F905AA2779A267432C68B959D7EE6E290275"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4C8016D18BDC143397958841910B3735702",
                        "defaultText": "적어도 네가 기억하는 범위에서는 말이지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7BB010350AB2C74EDB1A53F1BA5E6F3BEC37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CED6B3FE7D8259454C3B86A124EE7225821B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1A90AE84027C54FEA580B95AFC240E51088"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B52069D03167E54F315952D05B0B72EA9503"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C968E0F57C7E44530493F174DF6F65876BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "177A60E16BA0F145C64AC487AD48CB3E660B",
                        "defaultText": "헤... 그래."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "116433A262FAA241DA387DF96980563957F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "170D8FBE712D56450C3AA184D7C72BD5355E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96D9BC48782AB6425A19ED337D9D03391D46"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D57999F956AD343905A6407AB173051E2FF",
                        "defaultText": "있잖아, 내가 도망치던 중 숲에서 너를 처음 봤을 때..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC1097C36430854AFE29DFE433EAFB855FEF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01671CC58300014FBD1ACBC6F10E1197CD3B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "27E94DFE6E10474B7E795F77C98D1BE3309E",
                        "defaultText": "...이상하고 수상한 남자라고 생각했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "52C662075F6DC840CE8BDD68C142953845A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C1460877547834A8C59D648162592099760"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "611E47B8592EE04A661BD9D67960D8EBFBEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "223FAD46060D254ED96810D77C1FA3A2F797"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3073B56018E3114C785B17A63100F35E9701"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4F2C30F55557146B55BB0A6639AB9AA4C0A",
                        "defaultText": "하하! 단도직입적이네?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31750478819EB84A7C09EE8856F5395BEDD3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92245A3F5A46074CF66A3446D4989E82E421"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12174E4F91617646069A0586CECA65405670",
                        "defaultText": "하지만 솔직히... 나라도 똑같이 생각했을 겁니다, 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7545E409809EF045F638CC338482C9D173A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2A9C84B6A51D1486C6944B659ED357A589B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E2D7B7E5BD13644F98AF5D7CA50F59E76D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC466D6A8EF0D245790850C33915628BB258",
                        "defaultText": "쳇, 웃을 일이 아니야. 넌 정말 비참한 상태였어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "64DFFFA65C842742F5282057867228B29485",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B36B7B6A43F3034BB12988B2175727FED8F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "11E43F6E8F6BF442E07AA657C49511AE21C3",
                        "defaultText": "며칠 전에 어디서 잤는지도 기억 못 하면서 거드름만 피웠지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "921EF9FD906FD84007684C99492F55BE08DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "153B26C1701FB14A6B4BBAF33E77B075D0C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9507081E7D6AA244A68809F32C78E3B0F2AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A1E1E39807019476A5A84029A077C0D34D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7A433C2668FE846301AB9975A2790C184DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB2C54B952B2B74A5A0967C4CB2D7B70A395",
                        "defaultText": "그럼 뭘 어쩌겠어? 숲에서 멧돼지를 사냥하고 곰 가죽을 입고 살까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "73989A5451A5B0426D28AC234859CA8AEB4F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1103D3640C3861454A5AB3E5BF5B63A2D420"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30ACC73F2C4B494ED238B588C28807F0D359"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0723AADC42EE324F269B51C5F315B7FD2039",
                        "defaultText": "넌 늘 이런 식이야. 항상 자신의 불행을 웃어넘기지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D01C8E28267EA54F6E79CFE8D3B6E73CEEC0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A087C22A3A4AD3482A6870D282A38D2FC44F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA74135979A5D44E51690871EDD05E00E234",
                        "defaultText": "지금도 네 어린 시절의 슬픈 사정을 막 알게 됐는데..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "595255CC4319094A123A7017B62D12E048EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98B7C0F332E0A4449C88E5C2C728CDA06BD2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4801C96D474D3843C238217262DB78BE70D3",
                        "defaultText": "네 혈통 전체가 악마와 관련됐을지도 모른다는 무서운 사실까지도."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F941B7757B897640A9683B516C779D2E201F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F767383C4F166444F85879B448478E9BB578"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9DBA1B09FB83441CA7AD8974CCCAC6526D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EBA8AA006CB024E559BDF010BCB32B87E87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1AC7DF74754214E111A3711765700538EC6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93B5E08B801FF844FE5A1A7533C1C5B87266",
                        "defaultText": "정말 무서운 이야기지.\n하지만 누가 알겠어?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2DD7F8EA450F294F444B7407E9243B636647",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D78ADB4B51272141283B0204D57BDFDB39BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40425A8434A1374B5458C8C113D182EC7EB8",
                        "defaultText": "어쩌면 난 자기 연민에 빠지는 걸 싫어하나 봐."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AA082E678BB9F44022181FB6187AE2805CEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A4C3DA95141C14C5F5B8712D64AFFBCE36A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2256BBD8851DB6444C6B8CA4D8A8D7021E8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0128EDB25DCFE645AC4A1BA639E95E323ACD",
                        "defaultText": "하지만 속상한 건 맞잖아? 이제는 나도 그 정도는 알아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "46E64EB9582F3844FA19BB43103253BB0393",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9219A3F57D84B34131798636E6480ACFE3FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D453137343C3242E14800B8218D9CEC693A",
                        "defaultText": "그럼 왜 감정을 드러내지 않는 거야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9E28990F4FEB344896689E13229DBA6E4169",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEF7991846CF82474389E0066E14FEF4FB28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D19691B4053F841A84BE2F5014C4FFCF9C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35E488083C51B84F078A90A6B65B00854FDC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "117C891745ECC44FE38BFBE75AAEE46CDC3A",
                        "defaultText": "공주님에게도 문제가 있잖아요. 저 같은 고아의 일은 그에 비하면 사소합니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ED9D4A30803BF54D88592E25D421AE3B047F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2449AF51DC4B54BB079F296DCAAEE76496D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "697D323E1BAD804E4D8AB09472A5B6584BC3",
                        "defaultText": "틀린 말은 아니네."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4FE7A55D858D524F6E2B7981A9EACC65B761",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0249E87768B3C34F6C7A96D3378126E6B40A",
                        "defaultText": "날 너무 얕보는 거 아냐?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "519D4A093EAB974F734B8D14DE898C010E5F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7D38F3266C2A674A2A0A455406D73831C2CB",
                        "defaultText": "나도 네 곁에 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BCDEDE356C69B54FBF7A78B7BF50F7A63F15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "bad",
                            "good",
                            "best",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCC1E46815C6174E5B5BFC33D7B7F282DCF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C3DA510007BE7245A0598E4324942835D49E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "bad"
                },
                "indent": 0,
                "uid": "8EF1DA239B3CD3444E28C757D4FD22428B9F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "1) ---aff +cruelty"
                },
                "indent": 0,
                "uid": "A389A5623F07C44BDC8A6A82F4EB67B61EA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            0,
                            15,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF68205D44966649396A10707DF4B3786694"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A01F0585A04D44A8C7A69428FE79C6BA5A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            9,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED6AFFE814C894459A0A8CE5C0463057F444"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DBB422B3055F048440A0C756DDFDA3641F6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64C5D1A93FF2B643446AAD3822FEB3E43762",
                        "defaultText": "흥. 봐, 사람마다 중요하게 여기는 게 다른 법이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "20AEF3645EA80944015A81767AC55F9E3C13",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99EC842266DE7249A52A12F3C43772BA12AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "244895CE3837B6472A4A294496F5C7D1093C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E14A88AA6293F443C028BC60DDEB915B5065",
                        "defaultText": "그저 친절하게 대해 주려던 건데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "138C3B4F6EC5E843F37BCAD6EAA2607FA0D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03C6565E3F1409466788C9E7E75F13D88531"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4A0CF883D5AF548DD6914137665E9FBFD7F",
                        "defaultText": "하지만 본인이 싫다는데 속마음을 털어놓으라고 강요할 수는 없지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4CE44F4F834F9148328A7525D968711108EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB75E0616C55414D2D4A52E1B31EE4601941"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59E7F824430AD6420A2AEE36D2F9AD852225"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5C7C9888725884F5D8B8531D195CCAE8393",
                        "defaultText": "아쉽네. 난 정말 너와 이런 이야기를 하고 싶었어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4880D29010A87747F08886701A9BC0A2980B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FA45D9E6F9031437F6A77C7B9B2C675B32E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDD435D4754A9542E74AB8850466872666C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "941659476338414B95482F155A337F28A399"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3181A9D0F6EE049849B21052640537AB0ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E5F61741F90E845120B9F45FEF4FC5C3954",
                        "defaultText": "난 괜찮을 거야. 너도 그럴 거라는 걸 알아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "44FC86640226844E3C68A12960D023517839",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AA9FCAD59A273484A4B7DE415BCD76FEB1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB4C59583C5725422B99B802C43E464F89B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B344DFE42A9F7461B6932527691CC2C19D4",
                        "defaultText": "그래. 우리 관계는 원래 이런 건가 봐."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F8724452851D5245575972C49CCC4582C316",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A708ED751D32B345D67828915702FCBBBF2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC7F041C3141D846469A8134C58E545B0962"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4599A972FBBC6443088C3571972B3291147",
                        "defaultText": "아무래도..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5D82D648F07114ACF18DD065182B898514F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF4CBE803F2966408F987CC7BE6C5373AC4A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "bad end",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7203E9845AE2E14DE94B949835D179E88704"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Fa interested in Orni",
                        "index": 193,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D16AFC0837E80444A339B506CBC65D7FB4CB"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "7397A57D144EA145BA1B87730FEA414AD90E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "good"
                },
                "indent": 0,
                "uid": "CDA622604831624C6999F9E3E0B887260794"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "4DDF36006CA3E34DAD0A8960DE5E1B58EAAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "95CBCD458341204DC08848B4B407ABF77112"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C726ECCC0E53714A9E69BAD2F6FF191DE1ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F00FE4339A644458A8A77F6B61A8160BCD0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF027E3B6A449648254830D99D2EBF9A03ED",
                        "defaultText": "뭐?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5864FCE133A764CC69890E4E5F2B7357901",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1953BBBA4EADF440D549D7A75E4127A8DA87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76A041C231174849B03B2FF719CB737395C2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37E58DCF465E7543EC7B47105384096188EB",
                        "defaultText": "난 내 문제와 네 문제를 모두 감당할 수 있어. 날 너무 얕보는군!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE4AE80D22E3964CCF396DB345575C36B4AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5903B7D37E99784C0A99FC75FE16866C3E5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "528944472B8D204B7848A5D51BFA4341E123"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14B181E6319F624A532B27D95C4C9A29A9D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "645804DA79B97645691A638841E01A404784"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "155738D867ABA54A75296DF715E7C336DCD4",
                        "defaultText": "파라트라스 님..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D35166401BB54444B5583F08E65BF540521E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD8B5E8102BD28463A392B74A1528BEAA62D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "89A08FBD3F1247400A7ACAE219BFEFC63139"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "best"
                },
                "indent": 0,
                "uid": "F56FDB41458DD3440E0A2B84437C6DBF45B3"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff -cruelty"
                },
                "indent": 0,
                "uid": "DEED2CEF781B5643884B0C919D77098A3DEE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "D807B3F949472040A13A9426AD2C1B06D180"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA4FEEC382D824414C688073BC4B5459BCAD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57F156351A36B447A95B2AB312657FC0F8F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FFA62A9128F354EEF4A1C8423167895A345"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "870290EB6D6325442669906776817BCEDE9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D75C3BDA12E6B842503AEC38CC3D0472216F",
                        "defaultText": "아..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0D05328E80883444677B93E433D516E6DAB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4097811F8B5A014BAF183168FFD1A0C73DAE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "18DB90EF4E80064E1B7826C4CE2BFF8DA911"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E8B4CB44B50624AFB798F108A8305D4B57A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6521F1817FAC44E425B53B4D2C6DE9B8E13",
                        "defaultText": "강한 척 과장되게 굴지만 마음 깊은 곳에서는 괴롭잖아?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B09981A64CBC2044D0192612B5050385ABBA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A15E0CA07577F84D6D893ED27524B050D011"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64FF9FF08886D34ABC8A32B4AB5CF494251B",
                        "defaultText": "진실을 알면 기억이 돌아올 거라 기대했지. 하지만 돌아오지 않았어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3D519A861B0A3246F739815472C2141F203D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DE96BDE3629354B6B286223E19636275A66"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D6E511F3FEE0645B039417243657155C56D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07DFBEE47B783843B35B2FE7C10E3656DDA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E1CDCBFD8034794444287057EEA19FD4446B",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ADEBDD321C0A2146C459BBF1A94121A8FC6E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "416CD6DE4C94984459897436594C23F49804"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8CD38D365AFD8416B29D412393691080715"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33ADBAB15E51A04A432AD92315287551CA37",
                        "defaultText": "나도 한때 비슷한 감정을 느꼈으니 이해할 수 있어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A73661F95A36594571787AF042AF26E94108",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "245DDD82743C04499918CD544B9DCF762F63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D45F2992C31F24CDA3A2661B312BA2DE415"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76923A168E7C144DFB784BD77E680BBF1FE7",
                        "defaultText": "있잖아... 얼마 전 동생이 나더러 자기 감정에 솔직하다고 했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74509A2139070547D468E5D5B468C5CDF95A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23954C66857BF349DD5A35140E2A9A1FC43A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16FBCEB25A53944FDE1AD9F93ABAB81E2E38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DD75F4C20A5324E139A92957BEBE916208C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4CC56E645DBA040A64B363135D505D8DB2E",
                        "defaultText": "시오리가 그런 말을 했어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0C70C00664668406B68F21724F4E5AFD7BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "393A49048EA3A74CB82B7841DDE79F9A1210"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28726A806A62414E3F4B518518A5710232A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22BF58B34BEA2149659B6103EFD1AECD3610",
                        "defaultText": "그래. 슬플 때는 그냥 울고, 화날 때는 그냥 소리친다고 했지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4905AB9078F60142331AD966049F46195208",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEB9B7E581A9014D453A3B6687D1BA2863C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02B3DE6B4BD4224BDF8A7929EB87CC3D5BBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC8C96775EFF1648425AA8A47C00500DA9EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C931CE37877CB144B07AE8143710F4FE9BDA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BBAECE7B543D734E6F2BBAE95FD2762AB49E",
                        "defaultText": "푸흡... 하하하!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7BFCEFF24E4F54980896AE6FF25EE92A516",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "249F42A15063344B105AD302E8A7350C04AD"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "83EA42DE520308418A1B9D883A4DD4C2466F",
                        "defaultText": "뭐가 그렇게 웃겨!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "36A4A1516B504144126A0DB53AF10B7454D2",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "241BE554445998458289D89217602DB1E083",
                        "defaultText": "그 이빨에 오블룸브라를 박아 줄까!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "14315F993C4C9843C23B9E63C8AB008A32E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B7C57261DA0114B6E58F541729730A1AAB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "82E1203F1CD1F24F6E69DAA023FC89E349C8"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "9612ADEE899E6749624A2816CC67CD6B27E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4746D1B16B4B424BA28B9496A1EFE3D09C3C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "59AB8E6A20F526498058A599806C8ECB0931",
                        "defaultText": "미안, 미안. 그냥 너무 웃겨서. 예전의 넌 완전히 반대였잖아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "893A3CD94C22D44D151BFAE8525815FDF1F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44841F186364E545A04B26B7110126C54C32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2813AAB90D60264F302A29D3C07848B1E1EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54FB4C3D0E9E3940E0486402D3E53CEC12E9",
                        "defaultText": "이봐, 나도 이제 다른 사람에게 마음을 더 열게 됐어!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "155F939460D9A84CC34A1666377E41BA259D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EEAD91576AD134D5D6A20305F99CF482BA3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CBE8817670C6446F49B0E860DBACA31F66A",
                        "defaultText": "그리고... 그릇으로만 살지 않고 내 감정에 더 솔직해졌어, 파라트라스."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "65AC3D5F33D6F64D3C289377E9BF79122ECD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "516503BF5AE16942296A2969D5C7266006FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F50ABE143EDE174CE938D9067FDBF6AE1249"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFC82DE85759D843DC0A745385E98863C257",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0D864BD3734C74C5239E536B7A6DA4A45C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57C09A6234E2D2457228D21725D6CB80E1C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC9594E78F8C474FA3595CD58DAE3181C695"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD01747F30EDC742881B8B077C68E55B94CF",
                        "defaultText": "기뻐. 마음속으로는 늘 네가 그렇게 되기를 바랐어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "210BD4DA44C533473D4B92F30F5FE23E5AB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6533128311E1434A3F285562E6FEEC0696B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB62845261B72045587AB0B6CB9FEE185AB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "41AF211C41C6524E8C6B1D2307595C68F8F0",
                        "defaultText": "알아. 이해해.\n넌 언제나--"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B2794C83DE97648401826E590D84DBBCD43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "030DA1536DEF444B1D7992B8C582586655B3"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C2335108DF4304560693C022406896EE2F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C6C3542738141431F0A451553CF65B6E0E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD2356956C77424E182A4560353D4BFF96FC",
                        "defaultText": "내 말을 들어, {LT:1}. 네 과거를 아주 자세히 아는 게 정말 그렇게 중요해?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9790FB794211A345564BED521FDE15768A77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B157C0707781D14DCE79B9884BF338125821"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3247169C5757794E413A8E78C509E0582838"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43CDC6576D82C5420E1B83A61065C1FA010B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46D3519B3133F24C770B31265594A745AC4F",
                        "defaultText": "무슨 뜻이야?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "16A8266B2340C24A10799DD991D5B0731E9C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ADEE4B2765C8764B7B3ACB12B6AAA713E202"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB42A515103536425A784742674DADC25441"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A854AB452B15724423899294CC8E3A037BCD",
                        "defaultText": "내가 스스로를 그릇이라고만 생각했듯, 너도 '옛 정체'에 매달려 있는지도 몰라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E81B67430D8424A30780AE8D4BCAC9FAD37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7693B1089D2A642245B7001C10F1617FFA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E738D39E88BE394898685C34F69D623B56D5",
                        "defaultText": "하지만 난 파라트라스야. 그리고 지금 여기 있는 넌 {LT:1}이고."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BEA1A24728BB36403978F9221E5621AD8BAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFB54E06529B9346439A96D11FB11061CE7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65FE7BFA19245440D12A59B3B4F973064311"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "572F55A126975243198A5CF6BB2AA30932E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06B0F3F789B8264050989DC83DC34C634935"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4F7FE603BA2934D3F6A2A735CABA488F9B9",
                        "defaultText": "...헤."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A1A5BAED46454147F5880EE274E8236A97CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB5F6D197EFAF7492768D3E1AA389D2143D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9E117EC01FAD164E0389E8214DAC65A9971D",
                        "defaultText": "헤헤헤헤!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3AF21EC1629CE24B8F5AA4B85FBBA3A68C65",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAE81A0E65AA0041AA7854669F86ECCC985A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            9,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77718486520D8344502A14362806B536F40C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7A4196804CC2174E0E4817824B879745E69E",
                        "defaultText": "네, 맞습니다. 고마워요, 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4869FD0D1FB8674801881057EC545321890B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5109A898DBE944CC968B5A349254B7EFCC9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D72539908330A1415F1B1B24201843F0B259",
                        "defaultText": "한번... 생각해 볼게요."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "688141D11A5AC140964A5115F0F461D8EB8D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB4D5B1A409C314CFD792876644E3CB859AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A5A32B952157448E68B25B3B8865D01C6CE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4135FDA71152624FF148C076D0B5AB88575D",
                        "defaultText": "천천히 생각해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B359E75D39E5A049BE9B7DF824274BFB798B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B7BBC8A1AB5E94DEF782FF2148410CAA763"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29C0A35F2CD8194F042B17882563501949CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C801C2C02A80934869796E88A391CDE943A6",
                        "defaultText": "이걸로 그가 올바른 길을 찾으면 좋겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "65C5A2951D72A541EF589202D152D372FC8B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D37FD2CD8AA674441B6B2056F92F0832DB30"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5CB6AE46282E90470C882C452027DDDF9105",
                        "defaultText": "그는 줄곧 내 곁을 지켜 줬으니, 이제 내가 그를 도울 차례야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "879EAAFB3484804751494DF31429E4927452",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "61CD3C4F8F97184429889BB47ABA217D32FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC3FBCD1710B684321082354B171883BF594"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE1ACC1862E6044824696E5525F756B6E9F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67A887ED9E6C7546743BAB52B544379C052B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "bad end",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7E22479343E6B14B8C693B477B56D44899B0"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Fa x Nini moment in 12",
                        "index": 199,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A5535EFD3ED8F240BB6A999367D2C1152689"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "0E3B95EF1D2EB147655BDBA8C8B47737836A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "8BE50CDB6FE38349CF2BEF60A90B4EA77B63"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "72B338FE362D044DF12B4AE30875DF23DF6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            1,
                            6,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "841B52E46D465645820BE46655798A29143E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "A32382DD3937644A927B578178555BC0ABEA"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F15FCDD17C356840655BDE74480AD2980A06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "8EF9D6C012F50046219A87D17484417CFA47"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B56809BC72E1754E9B8B7EF56AFC65F93FD5"
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "bad end",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}