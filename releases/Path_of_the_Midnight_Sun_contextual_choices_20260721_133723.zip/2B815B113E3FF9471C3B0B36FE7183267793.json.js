GS.dataCache['2B815B113E3FF9471C3B0B36FE7183267793'] = {
    "uid": "2B815B113E3FF9471C3B0B36FE7183267793",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C7-01c Pre-map",
        "type": "vn.scene",
        "parentId": "29443C361804F14D425936946606B75A2F6D",
        "chapterUid": "0F52095B7D21614CFF6A4784A9F9BE129CC6",
        "order": 2,
        "localizableStrings": {
            "6F855B4F456CE14B911AD3047BEB66064410": {
                "t": "Puff... Phew... Ah!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "A2331DD2580DC648D079D9C192A8330DD536"
                }
            },
            "6669EB74136AB3453858AA43641F1CAE7DD5": {
                "t": "Cristoph? What's wrong?",
                "d": {
                    "eid": "DFEE063756D1F548143A09538E13EA4160E8"
                }
            },
            "1D0DDDF16F90F741BB78F6D6F44F0B8EF993": {
                "t": "You have to come immediately... I've found it!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "E458C32E77EBC1466A891647A0F65F5F92D9"
                }
            },
            "219C2DF11E7791461999DB6758D56B6B6E34": {
                "t": "Found... what? Spill it!",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "86A818AD47C2394E0E2B9FB5683CD2E62149"
                }
            },
            "818FE059101BF2486A3B3E47C6668D347248": {
                "t": "I... I'm pretty sure I've been through this area before. And... there wasn't such a thick forest down there.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "BC991D2985CF70409929825745DCB9C45497"
                }
            },
            "AB2D3F814254794E4F1AF9E7BC53D000E16A": {
                "t": "He's still a bit tipsy from before, isn't he?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D59BB8925A79D44F386B7E15699A0725AADF"
                }
            },
            "E055937D5F36094E3C2A16A20E4DEFB82E9E": {
                "t": "Can this be...?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "6136E7C28E34F541FC989E77545078B4860E"
                }
            },
            "FA98A236568D144A0C68E02338338D04DEBD": {
                "t": "It must be the Demon King. According to the legends, he had the power to create and destroy at will.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "9DB16C0E4FF4264C210A3B894FC394B36958"
                }
            },
            "132A00F96404E248FF4ACF64C6F24A8837E8": {
                "t": "Prince Hellios, are you aware of what you're saying? If that's true, then Lady Faratras...!",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "2C7C675531C57248D468B191A9721A722A6C"
                }
            },
            "A4F682AA745DF4445B29ECA7AB235FC4DF18": {
                "t": "There's no time to lose!",
                "d": {
                    "eid": "FFFB7DA09952454DEE3BE372FDEC98C06A75"
                }
            },
            "89FA47FE5DEDF6440E781C055F147086FEED": {
                "t": "This is bad...",
                "d": {
                    "eid": "1A2BFD3518736649AA7A23B8A0CDA67D426B"
                }
            },
            "B7AB45144DEF434B014AB4470FB78C880902": {
                "t": "Indeed. Lead the way, Cristoph!",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "E782EA985EDAA847DD790CC03AFBBA18FFC0"
                }
            },
            "889BA0C255F59348CB1AFA656F987B7F5D84": {
                "t": "Roger!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "16F480206D74D44D3568707860F6CEE03A25"
                }
            },
            "FE207A02165097439A5A30F6A929F1EE5ECB": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1A13447D44EB714123689144EB1AD51E3D53"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "in the forest"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD74E7C363DDF84C2C882F73C388A78A5A2E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5B46BECD2EE5A149B74B3634BA3E462BD6E6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "4A416D6E9CF1384D2A2BBB256A7945B347F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "D64D4EE00301B342D2780D515B11088BECBB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "7F07924A6D9D91404318D1B4FE131955AA5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            20,
                            1,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EE22F9E3219264F1D297CF74568AD0D78A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA3C4D384215A94113092A06314284D35E93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "178B9D6F21FB074D732B790735DF4091DF06",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F61F84D2139BF44C6D4AA754A10B2AF7FF30"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "C7E5A26668E52049884985E427133DF39CE9"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7CDA848225DA7643A27AA235A4263B79F127"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "3BAB10FA3C193344950B85065FD9A8332034"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "2D020C1916A3814359783A811324EF00AF65",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "0FCC16EC8F14214F211BD711C5EF156BDE65",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "34B36BF78B1E054A7C6B6F54C18EE51CCC82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C3983C6735FF14AAC1A36162A9B591E841B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7FC6748B360FC24CDD0A0F18DD02414C0400"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3913AD1324FB164EAD4917C12B0E95F4072F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A73D7223C42034E869AA504B31431A8312F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8EC6280D75CD724B9B2B1D16DA6E9C118A3B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F855B4F456CE14B911AD3047BEB66064410",
                        "defaultText": "헉... 후우... 아!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2331DD2580DC648D079D9C192A8330DD536",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC7F4C8D4C80314B0A196E3602ED3BC7CA85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC6579775BBB0143B758D999EF089CBB727F"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 42,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "45F10EBE64FAB84CE2280CB458840539C01D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "9BDF381D8021C34DF0587B91AF140F2CE432"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6669EB74136AB3453858AA43641F1CAE7DD5",
                        "defaultText": "크리스토프? 무슨 일이야?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DFEE063756D1F548143A09538E13EA4160E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "choice",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "7736E13C8DC8D347A28ADBF6927423F0FBDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E1B0394537FBB44139194FF69BAC906020AC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "choice"
                },
                "indent": 0,
                "uid": "47BA780264B872408A790A03562D3FAF72C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5CBCED909674B240D9791BB54D1E8486FEFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6DC7FC092F20D6404B1A12A60772022A6D38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE29DFD6116E4048566B8C86BF3E753EF62C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AEEA0B27FD883497D799B8424C49B300A6C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D0DDDF16F90F741BB78F6D6F44F0B8EF993",
                        "defaultText": "지금 바로 와야 해... 찾았어!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E458C32E77EBC1466A891647A0F65F5F92D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19363D888977784B176BC7B3A1C77ACADA03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74F8AE266728E5456D59067410E0CA353047"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "656B19E17BD839459469A8F79929F38AFF16"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "219C2DF11E7791461999DB6758D56B6B6E34",
                        "defaultText": "뭘... 찾았다는 거야? 어서 말해!"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "86A818AD47C2394E0E2B9FB5683CD2E62149",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "869DA79B4A71D34C3D080ED3214391EB57BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8541CC2B6EFF024561885BC2D058B49159B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F30F77937062844425A2CC6C5791606D827"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "818FE059101BF2486A3B3E47C6668D347248",
                        "defaultText": "나... 이 일대를 전에 지나간 적이 있는 게 확실해.\n그런데... 저 아래에는 이렇게 울창한 숲이 없었어."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC991D2985CF70409929825745DCB9C45497",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD6484BB8CD10648D79AB329517567B3814E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC0648114A7532462398F9A4C02BC12B1C6D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AB2D3F814254794E4F1AF9E7BC53D000E16A",
                        "defaultText": "아직 아까 마신 술이 조금 남아 있는 거 아니야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D59BB8925A79D44F386B7E15699A0725AADF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70B6F22E476716407D5BDB7425B8201E034A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EB66DEA2DE28244F14B3FB80DF3E14B88F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "E63A902C5070D048AC2947158F736EFAE88D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F97F4D2F60FA1241E99BC437B0B52DB56540"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E055937D5F36094E3C2A16A20E4DEFB82E9E",
                        "defaultText": "설마 이건...?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6136E7C28E34F541FC989E77545078B4860E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBF837EB35778247421907F5C30080F5D2FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FB0FB317C8117408A4BBBB5F75923E018F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "BAABCFB95CB7D94C8B3A36A4A7274A425986"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4FC44695219B445AB6889E6283509D1F411"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A59B569B712FE04EC15B4D5010A0859192A3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE207A02165097439A5A30F6A929F1EE5ECB",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line28_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A13447D44EB714123689144EB1AD51E3D53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A33D04E112486543013923B33D09E2B75CF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81FF9F9524228044AF1BDC05FFDCCBEB5D0B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA98A236568D144A0C68E02338338D04DEBD",
                        "defaultText": "마왕의 짓이 틀림없어. 전설에 따르면 그는\n원하는 대로 창조하고 파괴하는 힘을 지녔지."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DB16C0E4FF4264C210A3B894FC394B36958",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53F428E268EC824E8649DE64E23092879C7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D90E0F527BAA744A7280B029CEB53B3EAC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "132A00F96404E248FF4ACF64C6F24A8837E8",
                        "defaultText": "헬리오스 왕자님, 지금 무슨 말씀을 하시는지 아십니까?\n그게 사실이라면 파라트라스 님은...!"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C7C675531C57248D468B191A9721A722A6C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "99730C0D4E5CC14C7C28D737B9E58560C2A7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A4F682AA745DF4445B29ECA7AB235FC4DF18",
                        "defaultText": "지체할 시간이 없어!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FFFB7DA09952454DEE3BE372FDEC98C06A75",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "89FA47FE5DEDF6440E781C055F147086FEED",
                        "defaultText": "큰일이야..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1A2BFD3518736649AA7A23B8A0CDA67D426B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "choice 2",
                            "choice 2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "A69381211C8D9246D62852827758322EBD19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F046DBDE75E937437039CB128AC55E6537FD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "choice 2"
                },
                "indent": 0,
                "uid": "CD02B30D6F567741866A40D8E5D21D2F4E3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "872A9FCE7A3F2242625A91D0F22D6B93580E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7AB45144DEF434B014AB4470FB78C880902",
                        "defaultText": "그래. 앞장서라, 크리스토프!"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E782EA985EDAA847DD790CC03AFBBA18FFC0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "380858D391474441043A6F96AA0477EBAABB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "60E4C7FE24E77242D359BFE4072861C466FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAF29ADD4D41C94AEE5B79145A1AD203D14D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CD069C51654074D01693206F0D4D4A13541"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AAD4C8A30DFA441FA5B2EC180240D15A0B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "889BA0C255F59348CB1AFA656F987B7F5D84",
                        "defaultText": "알겠습니다!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "16F480206D74D44D3568707860F6CEE03A25",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BBCA6DB6487CF3416F7829A9DEF8CE866BF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D229534A3D86B649631B7628AD125803DDDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "25410D9C1E3C7447DB8A9086BC4FF199FC7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A494B497873194F360ABBF97AFF297AC3B0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "85180AFE52F9B6409C5AA312D337B291CD38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0213DEAA4677424B11083006D102713A43BA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "139A538D54BB064CBF287A88DD87EDAE393B"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "DFDE4B4717DBD34EC55837A85D9C18600FCD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "817B5D365D4D954E8949F8927FDC28B82F87"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "DF2BAAF3473A214ED98B34E452B83205D437",
                        "name": "C7-02 MAIN MAP (Dark Forest)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "55C285B525F5C740E088EAF2B9E094ABEAF1",
                "expanded": false
            }
        ],
        "livePreviewDisabled": false,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}