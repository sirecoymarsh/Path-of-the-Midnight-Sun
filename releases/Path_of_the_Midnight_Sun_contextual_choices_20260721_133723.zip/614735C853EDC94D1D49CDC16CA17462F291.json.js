GS.dataCache['614735C853EDC94D1D49CDC16CA17462F291'] = {
    "uid": "614735C853EDC94D1D49CDC16CA17462F291",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C9-02 (Talk) Hoikadians",
        "type": "vn.scene",
        "parentId": "C018A55C22E45843DC795711AF6DC121CB71",
        "chapterUid": "B73FC0E12D36244CA65A5C38B3C3733E5786",
        "order": 6,
        "localizableStrings": {
            "F13472E693FEC441A98B9CD86AC3D5497607": {
                "t": "Do you have a moment, Commander Saai?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "095D549D93F483458F4A000289BA09AC8028"
                }
            },
            "03603AA102371047DF2A2255A9EE62F8D25D": {
                "t": "We only spoke a short while ago. Why do you insist on coming to me? I won't go back on my word.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "B53F6BB93326454C7A1975533911CB529D2C"
                }
            },
            "F204AF824AB51946BB584A52C2B16A00C257": {
                "t": "I know there is no way to change your mind. I was just wondering if you could tell me about the state of the castle.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "82FC243E35683148FF282F058D62858FA09E"
                }
            },
            "FC88757A653B454CB00A70D1C5CAEA9AA78B": {
                "t": "How is Lulu doing? And is Lyvonis always caught up with training? What about Linobaldo, always after the ladies?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0865C7B12372094FE2692EC2E19C25BED298"
                }
            },
            "E4192C48433824490A7B1081087BFF995B73": {
                "t": "I have no intention of revealing information to the enemy about the state of our capital and its inhabitants.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "BC923E5F7FF7A144DF5A4A453FAF2788CBD5"
                }
            },
            "4A33F9E6471991484E88C90636DDD96C271E": {
                "t": "If you're so interested, let me just tell you this. We've spent the last few weeks performing funerals for the people you've killed.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "0E21012C1D5018497A78CD3466CF7B44B181"
                }
            },
            "85F785E96CC5024DC43AEF2472211B2A004D": {
                "t": "... ... ... Sniff.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "02623F8E1F9AA545DE590ED5B31BADE81A9A"
                }
            },
            "39841D758FCE944FB648DF7532A7C97CADCF": {
                "t": "I need to be... strong... Don't think about those families, Faratras! Clear your mind...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "081E3E097DB234495639D1A60B9FBF311429"
                }
            },
            "5D94CF9A0E7EA74E6C78C845F8AC0E497DBD": {
                "t": "Don't you think you're being a little too cruel, Saai?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "3936FE9C5F72814B742B1C32FD419F68C301"
                }
            },
            "89F61A422CB1614C3A2B1FF380AFE4F7DB7D": {
                "t": "Didn't the idea of you hurting the Vassal's feelings even cross your mind? What if she's no fake?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "3C4BA70155F20148AC3B0D2485B6BCE194C4"
                }
            },
            "18DFEA755882A74C1C1BCF07742943EAB027": {
                "t": "Even if she were the real Vassal, she has still stained herself with the blood of her countrymen. She'll have to answer for her actions.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "DF5496F86448944ADF7A72F5D8BCD446C283"
                }
            },
            "DBAF9EAD178AE340DF8A7CF09117CB903E20": {
                "t": "To what extent can we blame a noblewoman, guilty only of having fulfilled her duty to the end?",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "237973C35B5E5047232A1BB35BB158E4F3BB"
                }
            },
            "933461B4389017438A18B555610F1DC28290": {
                "t": "For me and Cattleya there's no doubt about it, Lady Faratras is the one who paid the highest price here.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "1DAA70EC104D144498883E63610AE5E21EDF"
                }
            },
            "0A905AA422F0B240EE9AA9588B0DA0703BEF": {
                "t": "Captains Menmus... and Cattleya...",
                "d": {
                    "eid": "37C1592A8B8B464AC56A93F91075F4E720A4"
                }
            },
            "70B717358C4B53429D2888C7CF9954BA8B48": {
                "t": "Everyone, I...",
                "d": {
                    "eid": "5632D4D81913E642654819926273D2AA80C1"
                }
            },
            "80F8BA6375426144032B0A01A38EE9A73680": {
                "t": "What a shame. You two were overflowing with potential. One day you'd have surpassed even me.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "48A4580E35DEA046974A108325F5F2BCA0D3"
                }
            },
            "856A96652873C54A5588C17511D6ED2B227D": {
                "t": "And yet... Here you are, having betrayed your queen and your country to follow the insane ideals of a bloodstained princess.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "1035FBB667162748D66997614E4C9CD0A7FE"
                }
            },
            "B26E49CF3A484241986910A1AC3183C7A958": {
                "t": "Everyone is free to choose how to breathe their last, Commander. It's what gives value to our lives.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "E30E7D213EF0F14E3C2A0759DCC8126F5C19"
                }
            },
            "C6D732CE8ED48645FF2A1495FB10464D3782": {
                "t": "It's like Menmus says. Our blades serve what we believe is right. And after fighting Lady Faratras, we wanted to believe in her.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "65E420891DE16248BF4A43F8C143B1E352AE"
                }
            },
            "BEDFB4C87650124C6359D2F2A90626699733": {
                "t": "You're one to talk, Cattleya. You, who lost your lover in this conflict.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "F3ECA9147410F448792ADC570EDA5AB66571"
                }
            },
            "C58CA1E54C6D8248DF7835759A359525A11D": {
                "t": "... ... ...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "6722F8100C749349072A4E36ADEDE75E106F"
                }
            },
            "298EDE80212637498F19C15780E150076F69": {
                "t": "Stop fighting, please. The soldiers of Hoikade shall not turn their blades on each other.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D81AFFB10449D34BC8698DB370B721E054FD"
                }
            },
            "C3D96B1697347742647A20D5A6F8640ECB64": {
                "t": "This is the teaching of the supreme Vergil, one of the Legendary Heroes. You haven't forgotten it, have you?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "017E387E32A85143444B01D6C8150141D24F"
                }
            },
            "0F3EC5856B21D64D454AEDE7F11911F5B158": {
                "t": "The supreme Vergil would certainly have disapproved. An excellent point, Vassal.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "F4C5F5A8857C75495F392491FB6F45231DAD"
                }
            },
            "6E88D8235892564A479AF620A4F78A18DF76": {
                "t": "Hah! He may be one of our heroes, but he too has failed to protect our countrymen.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "CAD4A18B4B77C94AED896946EC8DC386EE36"
                }
            },
            "99E04EC312E7B441344BA4D4F8C1781BBE9C": {
                "t": "The losses suffered in that battle were too great because of an oversight of his. And his heart has been filled with resentment ever since.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "828233C15B34D84F4F4892F5CDC798F8F13B"
                }
            },
            "222F8BB779ACD34AD5485958E47C68862879": {
                "t": "You're being too strict again, Commander. And I dare say that the supreme Vergil is also strict with himself.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "31BF3DE18AAD724845388AF77606A423BE0D"
                }
            },
            "1BE5225D93740747148862B3855BB3EA92A2": {
                "t": "Perhaps some of his men could have been saved, but in return how many lives did he take from the yoke of the Demon King with his courage?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "637D6CA2167C2143ED5A13D4FD812819D20B"
                }
            },
            "F4EF3A197F54254C6069D08181B92448E26B": {
                "t": "The same applies to Lady Faratras in this situation. Wouldn't you say we should learn from history and give her the benefit of the doubt?",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "43A843EA6D4D52435409A53441F7F93D00A5"
                }
            },
            "D9553022649D0949C3083D78E41FBC3BE336": {
                "t": "To be compared to one of the Legendary Heroes... You honor me, Captains Menmus and Cattleya. Thank you for your words.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F04727C04C07A74B4899D154579CD703DF5F"
                }
            },
            "F6510E0E697C96430E3A5DD38AF1AF873B09": {
                "t": "An undoubtedly fitting comparison, since both you and him have failed to reach the optimal solution... the one in which no one dies.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "AAF8CE033971324BAE495901E0B5F9E3AF03"
                }
            },
            "4D0CED0A96A4E34B8E3BBC214D4402E31C36": {
                "t": "You are dishonoring the memory of the supreme Vergil with these slanders of yours, Commander Saai.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5454E1BB4BE57440E32925B8035168BBFF1C"
                }
            },
            "5DFF3EF05F0C3244C54838C5E979D646725B": {
                "t": "Don't you realize he has been dishonoring himself this whole time? These days he's running around rambling, getting drunk and depressed.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "5ECA0710175C8748FC1A6679D460D9666FF7"
                }
            },
            "532631C133BD6140AE1B6351C5F2DD539732": {
                "t": "After losing his dominant arm during that battle, he's hardly able to wield a sword. And he can't control magic because of his mental state.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "6249FC3C6D91D64B807A3D854CF77961C4BA"
                }
            },
            "E8B9D15997A945403D28082450A0E671A66A": {
                "t": "That may be true, but it doesn't erase the good deeds he's done. Don't you think it would be like seeing the world in black and white?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "ACD93296219F8741B93AE6611B09BA4D6D2D"
                }
            },
            "3A64EAD03D563648390AB2F4156BB4C8D494": {
                "t": "Not really. And I quote Captain Menmus - everyone chooses how they breathe their last. This is my credo.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "B26424B50D30F4408B78765462F8B78FFAA2"
                }
            },
            "CA27F72D92E4754F49298071B61069EFB107": {
                "t": "It's pointless, Lady Faratras.\nCommander Saai has always been... unshakable like this.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "F8207F013B89864AA18BFB455601A2981D12"
                }
            },
            "8AC7F0BC7E87D345A2496174171EAD0EA568": {
                "t": "That has always been his strength, and the reason why I admired him so much.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "02DE6B63434F6645163874A5F579BF54AF03"
                }
            },
            "D7A9128D7F47C24622399B34C531DD76D82B": {
                "t": "... ... ...",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "EF09ECD029245948F868D7276B325A09FC6B"
                }
            },
            "DC4CB7528317724E621852911C2FDBD9DBE2": {
                "t": "I hope the day comes when we all come back to believing in each other, my dear soldiers.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "603A403F7A7B8246A77BBFF8772892BF8010"
                }
            },
            "974C0519559B124ECA0AB882479D1C376582": {
                "t": "And that's the main reason why I have to do my best and redo the seal as soon as possible...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0064ECBB33FA924EA148FA53F55C1DFCD9CB"
                }
            }
        },
        "livePreviewDisabled": false,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "You unlock this if you've got Cattleya & Menmus in your barracks"
                },
                "indent": 0,
                "expanded": true,
                "uid": "6BA10BC555E673434A295E914979D6122AC3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "0A10CC0E161EC14B406A8289663A82D9A6BB"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "023CFADC6BABC748CA4BD8A6D50084A69CFC",
                        "name": "21 - Menmus"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "ED698D2B443C994A8D6A4F92345475933263"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "20E1AA6749DAC5489B097FE9C30DD6EC8FE9",
                        "name": "22 - Cattleya"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "B424366D3F35834977180EA7967A997EF141"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "model": {
                        "name": "commander.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 307,
                        "y": -332,
                        "zoom": {
                            "x": 1.9,
                            "y": 1.9,
                            "d": 1.9
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "213480412642534A53697B34F8D978F33636",
                "expanded": false
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6D63D3465C76624C5B188A11B9F9AB0F1C77"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -20,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E8FB5BC98441684D9D58B4B24BF1994F71A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9900EDA8951494BE76AE25889AA54DD71E7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 75
                },
                "indent": 0,
                "uid": "327877C18C29634C571A62D755259588D138"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21627F6775DCB04A81592495672FB2B636F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52BBE46C6897584DB109E8237ED2CB942D06"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F13472E693FEC441A98B9CD86AC3D5497607",
                        "defaultText": "잠시 괜찮으신가요, 사이 사령관?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "095D549D93F483458F4A000289BA09AC8028",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC2BABE3887330495449B0E388DAD0713F66"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "42AA5445571D4242D21B33E8588E458A557E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA1EA3045BFCA24B4089EFB408CB494868AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03603AA102371047DF2A2255A9EE62F8D25D",
                        "defaultText": "조금 전에 얘기했을 텐데. 왜 계속 내게 오는 거지?\n나는 한 말을 번복하지 않는다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B53F6BB93326454C7A1975533911CB529D2C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9FC56472C87E74C1D6B72283761104EEA74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "158208546826224AED9B7D78184268EBA51B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F204AF824AB51946BB584A52C2B16A00C257",
                        "defaultText": "마음을 바꿀 수 없다는 건 알아요.\n그저 성의 상황을 알려 주실 수 있는지 궁금했어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "82FC243E35683148FF282F058D62858FA09E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D31B55C517238041285A6FE6959E6102B386"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC88757A653B454CB00A70D1C5CAEA9AA78B",
                        "defaultText": "룰루는 잘 지내나요? 리보니스는 여전히 훈련에 빠져 있고요?\n리노발도는 아직도 여자들만 쫓아다니나요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0865C7B12372094FE2692EC2E19C25BED298",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1A3B79A73DA0948786B5FE868F8A98ABAD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACEAF0C731A41844F59A96F53AA657ADD6F8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4192C48433824490A7B1081087BFF995B73",
                        "defaultText": "우리 수도와 주민들의 상황을 적에게 알려 줄 생각은 없다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC923E5F7FF7A144DF5A4A453FAF2788CBD5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC715C6A4B270241223BD97570B6D1381AFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A2C93366E861842493A46023A2D737F24DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8EDA6AB6A98A1472B7B6BE12BDB6447EE42"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A33F9E6471991484E88C90636DDD96C271E",
                        "defaultText": "그렇게 궁금하다면 이것만 알려 주지. 지난 몇 주 동안\n우리는 네가 죽인 이들의 장례를 치르고 있었다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E21012C1D5018497A78CD3466CF7B44B181",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDA2853622642244742BF159A49DF14BD211"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            1,
                            2,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B7234537CA0214D275AC105CE62D130FE2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7CBBF8A4515594386384D240D2E2E02CABF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85F785E96CC5024DC43AEF2472211B2A004D",
                        "defaultText": "... ... ... 훌쩍."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "02623F8E1F9AA545DE590ED5B31BADE81A9A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C15B65268F0A054E049A7F211011892C4E51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46DCDEEB3CB552425B49BFA9B5FD0578F4A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39841D758FCE944FB648DF7532A7C97CADCF",
                        "defaultText": "나는... 강해져야 해... 그 가족들을 생각하지 마, 파라트라스!\n마음을 비우는 거야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "081E3E097DB234495639D1A60B9FBF311429",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D49A16183472144B73952C66C9CE36CDD5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27204BBF6475A1451D6BF226569DAA5BD655"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D94CF9A0E7EA74E6C78C845F8AC0E497DBD",
                        "defaultText": "조금 너무 잔인한 것 아닙니까, 사이?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3936FE9C5F72814B742B1C32FD419F68C301",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5F4CE0D8796984FA3486F73E32D1F902D81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B9AB51E0EA19644068BABC07A65E3987F12"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "she appears"
                },
                "indent": 0,
                "uid": "19DB8C3945A5684EA70B3E97C9480C836425",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DA00F4254A7635431C693284C11758B3C38E"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D80624A778BD024A6C2916216CA336A4EFD4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "E55C32FC63DF684DDD2AEEF418B60C6346ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5627E9327C86A74F142AF61323B13527CE3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AAA66204F3E31412A8A79E70139980B88DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FB4838183629248261A09682D977F364C8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9E96F3A33FEA44DFA2B7C37CF7B16ACE78A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "89F61A422CB1614C3A2B1FF380AFE4F7DB7D",
                        "defaultText": "그릇의 마음을 상하게 할 수 있다는 생각은 안 해 봤습니까?\n가짜가 아니라면 어쩌려고요?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C4BA70155F20148AC3B0D2485B6BCE194C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5F7B94F394D9546025AE437C7DABEF5DB07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1F2A1392A93954C8C7ABE059EA04E416C8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A3FA10713678145B54A6423B9E157C6487F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18DFEA755882A74C1C1BCF07742943EAB027",
                        "defaultText": "진짜 그릇이라 해도 동포의 피로 자신을 더럽힌 건 변함없다.\n자신의 행동에 책임을 져야 해."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF5496F86448944ADF7A72F5D8BCD446C283",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE5F0F5F27F7774E612895E3851AF8D7A087"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D17C35F613DB144C170BF10959FE352E3BF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B9F0C623B73F64CE59BB0E83CFA471A113C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20CA69F187919043664890117F13B8038BA9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DBAF9EAD178AE340DF8A7CF09117CB903E20",
                        "defaultText": "끝까지 의무를 다한 죄밖에 없는 귀족 여성을\n어디까지 탓할 수 있겠습니까?"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "237973C35B5E5047232A1BB35BB158E4F3BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6412EF147128114BC28BED27C9A9FA8C9516"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FC126986106494BD8494DF40BCA72C8732B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E666AC86739B044D054A1E27C7939457635C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "933461B4389017438A18B555610F1DC28290",
                        "defaultText": "저와 카틀레야는 의심하지 않습니다. 여기서 가장 큰 대가를\n치른 사람은 파라트라스 님입니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1DAA70EC104D144498883E63610AE5E21EDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "43F546F141A822459A8A5200177978C5C45F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0A905AA422F0B240EE9AA9588B0DA0703BEF",
                        "defaultText": "멘무스 대장... 카틀레야 대장..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "37C1592A8B8B464AC56A93F91075F4E720A4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "70B717358C4B53429D2888C7CF9954BA8B48",
                        "defaultText": "다들, 난..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5632D4D81913E642654819926273D2AA80C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "fake choice",
                            "fake choice",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "176A6F786BD26644A158ED56E60B667FABB8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CE7468DD61CCF942388A7C7872F164B8A9A2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fake choice"
                },
                "indent": 0,
                "uid": "825B39F646C3E64CE37A4903789FD29EE713"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A918C7D54C9A2449D59AFB24AA1714D30448"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80F8BA6375426144032B0A01A38EE9A73680",
                        "defaultText": "안타깝군. 너희 둘은 잠재력이 넘쳤다.\n언젠가는 나조차 뛰어넘었을 텐데."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "48A4580E35DEA046974A108325F5F2BCA0D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE707A4127A3034C042A6D480236A956EC66"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA73FF696EB6714F1A7A73658720B7A2A861"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "856A96652873C54A5588C17511D6ED2B227D",
                        "defaultText": "그런데도... 너희는 여왕과 조국을 배신하고\n피로 물든 공주의 광기 어린 이상을 따르고 있군."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1035FBB667162748D66997614E4C9CD0A7FE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF697754513A804F582B4CC27256ECFE1E78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CFFD9B0462046244C5189DA8EFE589A28664"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B26E49CF3A484241986910A1AC3183C7A958",
                        "defaultText": "누구든 마지막 숨을 어떻게 내쉴지는 스스로 선택합니다, 사령관님.\n그 선택이 우리 삶에 가치를 부여하죠."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E30E7D213EF0F14E3C2A0759DCC8126F5C19",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5C2029F1C07E345592811E96086B4418E05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1CB3103446C28473C6AB1A3006A9257A69F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39FE4CC26BFDB745802A04A10932C6163FD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6D732CE8ED48645FF2A1495FB10464D3782",
                        "defaultText": "멘무스 말이 맞습니다. 우리의 검은 옳다고 믿는 것을 섬깁니다.\n파라트라스 님과 싸운 뒤 우리는 그분을 믿고 싶어졌습니다."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "65E420891DE16248BF4A43F8C143B1E352AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E9058D61D85D84AFC3926C22663730284A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39F75C8361C5554E9E8BD8600F4380EED29D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BEDFB4C87650124C6359D2F2A90626699733",
                        "defaultText": "네가 할 말은 아니지, 카틀레야.\n이 전쟁에서 연인을 잃은 네가."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F3ECA9147410F448792ADC570EDA5AB66571",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D306B06F87EF38483A185B662F3796357AC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "40CD275016742547BE7931A420C7CA06CD1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8184E463662EB149B27BB8C0098C5B7BC293"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "14BC482786779145986B9C578F4376EFBA60"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C58CA1E54C6D8248DF7835759A359525A11D",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6722F8100C749349072A4E36ADEDE75E106F",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "D22F2D99437C124DD4898BA9C221F3179A0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3153EF4597548746DF5AC582BDECB255F4EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB6CF0C55E0267484C89FDC210A678E262D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "298EDE80212637498F19C15780E150076F69",
                        "defaultText": "제발 그만 다투세요. 호이카데의 병사들은\n서로에게 검을 겨누어서는 안 됩니다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D81AFFB10449D34BC8698DB370B721E054FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3652A31561B5834E6B486901637D6DCD77A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C3D96B1697347742647A20D5A6F8640ECB64",
                        "defaultText": "전설의 영웅 중 한 명인 위대한 버질의 가르침이에요.\n설마 잊지는 않으셨겠죠?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "017E387E32A85143444B01D6C8150141D24F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "45E8FA1421AB984D847B24128E496818C2F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BBF73F87CB5174EFA292C41972B99D1D21D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "FCCAD1FD1D7A92483A0BCF95881963D51792"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Show Legendary Heroes CG\n\nnote that the Z order here is special@@@@@@@@"
                },
                "indent": 0,
                "uid": "21C0465127F3974E648B8466513047B857AB",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "0D0D8D5F5F8B774891283D81CEAF2414352C"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 200,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_00.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "335A46111375944CAE8A80020AEBEEF05F32",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Minerva",
                        "index": 110,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "098CB6EF7B5E5640DB7B0F26392CA6C7CD24"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 201,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_01.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "6C40ADD5726FD64A3578B615BE05BD2184EE",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "BF465E9B78D57247CB780759B990501A0073"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 201,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_01_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "8622136D5DE7B8400F8A14C78C5297CF4B96",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Georg",
                        "index": 111,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2338E5A33FFD314C9F4BFA9845A362C35D8D"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 202,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_02.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "1C01954B3808704DF00949386571852A7BC3",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "7E2E87F94DE943456979CC07DEBE59EB707B"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 202,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_02_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "C4DD184E6C4EA24E406AE4E37E390D53BDFF",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 203,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_03.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "D0B8F5522D069347BF3A95C2C8F9075DF9C5",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 209,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_03_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "6EBED72D1BAAE446053B24F31EB170949E8C",
                "expanded": false
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 209,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "63BAC1277C960943D198F7156771A01071F0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Zander",
                        "index": 113,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "654E386A6A60D145094AED485154EBB5EEA8"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 204,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_04.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "1F056462193E1348D32B25258EE816233AB0",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "20D5D2B6131CC64AA1485758859598E87878"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 204,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_04_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "4C7BBA107217144B643BB1045A29854AE10F",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Valoria",
                        "index": 114,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "146F0DA37283C4403A497D90885219DD48E4"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 205,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_05.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "FF7F913216ED8848C76AD371D623A4F25BB6",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "6AE444394C7057453F1927A84B0FE42304C2"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 205,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_05_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "555439532D9C8140214B6B1188E95B04F6E5",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Zephira",
                        "index": 115,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "58D02E3470790748F518DED69F6719D10A1E"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 206,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_06.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "DDA138801657474918184CE1ECDA01A2D7C2",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "803D24C04D92474C365A5188ECC4B1C058AA"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 206,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_06_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "D1DE5788731492439708BA31F39A2E338E9A",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Melody",
                        "index": 116,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F074CCEF42CB674B165BD3F92167ED71BA87"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 207,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_07.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "DA8F80321F2FF7410549F4E75A782549C8EF",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "FA7DCF436E5B22432E7B9CC77111E311F0CE"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 207,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_07_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "63CFE6ED7F93B74D506B8748B2A1DDBD341F",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Unlocked Legendary Astra",
                        "index": 117,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C0BDD6D95FAC014FF06A8685021D59B94C41"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 208,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_08.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "B97E24F69C8692415D58C4B9D26DC8C67954",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "20B925912A17B547D7787ED81AE5FAAEC54F"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 208,
                    "blendMode": 0,
                    "zOrder": 4998,
                    "duration": 72,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Legendary Heroes CG_08_alt.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 12 CG",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 1,
                "uid": "1BB6500B0FD382479C581E6254973B114696",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Show Legendary Heroes CG, focus on 2nd Vassal"
                },
                "indent": 0,
                "uid": "C04950F81F820049025AA047BEEF080613E9",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 0,
                "uid": "EF5F63662E47F5489F2A54D3884B442BD276"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Unlocked Legendary Vergil",
                        "index": 112,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4FDC672A5B5FB74258491399FE9A9349600B"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 203,
                    "duration": 72,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "FB57BC7C7ACF2347ED3AA3677084F7917492"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 209,
                    "duration": 72,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "D0B4EF4C236DD04B101B5B426A46229121C7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "A4A8500F14D1584368888FA17703D8986C07"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 203,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "38FFA45762D8F74EF18975C86DCD7FAAC503"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9B67FF01720D3446129A125FD9C7952ADC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "500D4CF761D382465039798630ACA8DFE728"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0F3EC5856B21D64D454AEDE7F11911F5B158",
                        "defaultText": "위대한 버질이라면 분명 반대했겠지.\n훌륭한 지적이다, 그릇."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F4C5F5A8857C75495F392491FB6F45231DAD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6C55C543229764D38982700EB0D3F48D32A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85402E30393A394EF52BD642C3FB7D020730"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E88D8235892564A479AF620A4F78A18DF76",
                        "defaultText": "하! 우리 영웅 중 한 명일지는 몰라도\n그 역시 동포들을 지키지 못했다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CAD4A18B4B77C94AED896946EC8DC386EE36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49DB855B0C22624C214909E5F0521C5DD5FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99E04EC312E7B441344BA4D4F8C1781BBE9C",
                        "defaultText": "그의 실수 때문에 그 전투에서 너무 많은 희생이 생겼다.\n그 뒤로 그의 마음에는 원한만 가득해졌지."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "828233C15B34D84F4F4892F5CDC798F8F13B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F3C57338BECA14DAF3B0503F0E4A1D0941B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BC772463BAE434EC73BF957267E6A55E40C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "222F8BB779ACD34AD5485958E47C68862879",
                        "defaultText": "또 너무 엄격하게 판단하십니다, 사령관님.\n위대한 버질 또한 자신에게 엄격하다고 감히 말씀드리죠."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31BF3DE18AAD724845388AF77606A423BE0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "584019726EB0914A8F3848C33CBFE779A7C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BE5225D93740747148862B3855BB3EA92A2",
                        "defaultText": "그의 부하 몇 명은 살릴 수 있었을지도 모릅니다.\n하지만 용기로 마왕의 굴레에서 얼마나 많은 생명을 구했습니까?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "637D6CA2167C2143ED5A13D4FD812819D20B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D2442F82451E5410838DE97C756AC62C808"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0E2C2F58D0F4847286A53726E2FB75BC9DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4EF3A197F54254C6069D08181B92448E26B",
                        "defaultText": "지금의 파라트라스 님도 마찬가지입니다.\n역사에서 배워 그분을 일단 믿어 봐야 하지 않겠습니까?"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43A843EA6D4D52435409A53441F7F93D00A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6AF5CDA22354840C148F6877D3C5ED2DBD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23D66F557652E242B15A81570F3069C29CB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9553022649D0949C3083D78E41FBC3BE336",
                        "defaultText": "전설의 영웅 중 한 명과 비교해 주다니... 과분한 영광입니다,\n멘무스 대장, 카틀레야. 두 분의 말씀에 감사드려요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F04727C04C07A74B4899D154579CD703DF5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A7FC6DE22757242496A82C269E3DAD8EBC7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7869FDB214F8094B554AB8237B92236E93D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6510E0E697C96430E3A5DD38AF1AF873B09",
                        "defaultText": "둘 다 최선의 해답, 즉 아무도 죽지 않는 결말에\n이르지 못했으니 확실히 적절한 비교군."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AAF8CE033971324BAE495901E0B5F9E3AF03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B53A1B016206F047C46A533166572E3FEE04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AEFA53498A34B8478D3956A9D7CE07730BC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D0CED0A96A4E34B8E3BBC214D4402E31C36",
                        "defaultText": "그런 비방으로 위대한 버질의 명예를\n더럽히고 계십니다, 사이 사령관."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5454E1BB4BE57440E32925B8035168BBFF1C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6C85217814B8346D679FD96680E1AEDF055"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B37537492B9856409A4B0794AA0B09E1F515"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5DFF3EF05F0C3244C54838C5E979D646725B",
                        "defaultText": "그가 줄곧 스스로 명예를 더럽혀 왔다는 걸 모르나?\n요즘은 술에 취해 우울해하며 헛소리나 하고 다닌다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5ECA0710175C8748FC1A6679D460D9666FF7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1429FC9E30EAE344F8183718CCA72993B8CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "532631C133BD6140AE1B6351C5F2DD539732",
                        "defaultText": "그 전투에서 주로 쓰는 팔을 잃은 뒤로 검도 거의 못 쓴다.\n정신 상태 때문에 마법도 제어할 수 없지."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6249FC3C6D91D64B807A3D854CF77961C4BA",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "exit CG"
                },
                "indent": 0,
                "uid": "00A44F1B5B1EB84E31986CD223396CEF94E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D427033E6D7EB542D31AFCD1617A387CFCB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DDC6228D2D49F641072B180177D2A71F6706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC188FD20FC8634FDA1B50C737129DAAE586"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "A05AF6740C3B98442E4B22B318839A49DE60"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 200,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5046D1B0553DE94B7C3A6205749FB0448FBB"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 201,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E17056458A2B3448EA2A49B30F7DE5A2B7E5"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 202,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "33BC31DB620DC649A80B1145C34B3B09317E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 203,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9CF7577C6BF6324BFA98EF05D5A170043F63"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 204,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BE34AC8B1BC8A449B07A03F227EB05F81759"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 205,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D0A2F59A7C2B2847D80A71F7E4B118A43E65"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 206,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "DFE974726718B74A096828E48D3A609C0F03"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 207,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7CEEAEAA763B174D50989474855E9ACB29C3"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 208,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "DBDA4F0256E5824DF379C94545DFCFDCBB4B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 209,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "AFC4DFD625C90141085AF8C4B8A9CE7C33C6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "7F31B8CD865A7140BE399A12F09F5CCC130F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53C0CEEE8273E34D1039AAA195B3C4DAF2C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "251EF0112BCF1947066BBD08032A826D69ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8B9D15997A945403D28082450A0E671A66A",
                        "defaultText": "사실이라 해도 그분이 이룬 선행까지 사라지는 건 아닙니다.\n세상을 흑백으로만 보는 것과 같지 않겠습니까?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACD93296219F8741B93AE6611B09BA4D6D2D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "749D2DA734C0B14E36889CD9DE7545103361"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "648B96A62C01514E0F586468F1CA18ACA5C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A64EAD03D563648390AB2F4156BB4C8D494",
                        "defaultText": "그렇지 않다. 멘무스 대장의 말을 빌리자면\n누구나 마지막 숨을 어떻게 내쉴지 선택한다. 이것이 내 신조다."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B26424B50D30F4408B78765462F8B78FFAA2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4883B4A1743CD641F97A5306092AC8791C37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "839C90B1637C27450B0AFF37916DD69A530D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE4013665C87A8408C8B7932F851F864B4A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27FFB2040334B4443C18B3C7685D51A2AA49"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA27F72D92E4754F49298071B61069EFB107",
                        "defaultText": "소용없습니다, 파라트라스 님.\n사이 사령관은 늘 이렇게... 흔들림이 없었어요."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F8207F013B89864AA18BFB455601A2981D12",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "906D31EF7B33B54099895DB0F2FC393918F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E636A422629E064BC95BBDB50236BCC203A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8AC7F0BC7E87D345A2496174171EAD0EA568",
                        "defaultText": "그 점은 언제나 사령관님의 강점이었고,\n제가 그토록 존경했던 이유이기도 합니다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "02DE6B63434F6645163874A5F579BF54AF03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "635128BE5922144F089BCB63DA885F20F9AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F488082F83F0B5449F2BDA079BAE9D5347FF"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "489AC2A0239B63454048820106E495A12F6E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D7A9128D7F47C24622399B34C531DD76D82B",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF09ECD029245948F868D7276B325A09FC6B",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "FFE47C06816E054E4E3A184655789409F5FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C741635A4764D74B927B19103A703AD3D97F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EFAA60D411FB34D28182D7824A4032A5B8D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC4CB7528317724E621852911C2FDBD9DBE2",
                        "defaultText": "언젠가 우리 모두가 다시 서로를 믿게 되기를 바라요,\n소중한 병사들이여."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "603A403F7A7B8246A77BBFF8772892BF8010",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B8053AC4788D4438D3B7AC8273AE8CF8F43"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2C4AB195F1BE0476C995B344E9FBD92E0AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "974C0519559B124ECA0AB882479D1C376582",
                        "defaultText": "그러니 내가 최선을 다해 최대한 빨리 봉인을\n다시 만들어야 해..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0064ECBB33FA924EA148FA53F55C1DFCD9CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B09B93640C3A2544635BBBB165FADF099176"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "E691BA0F53800143BB084338C63651C227A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F8986E04AB2C24842087D06D381C06C47A3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "C76C6FF01FF4934CAA88E084EF5D178BD47C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            7,
                            2,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "369560BA3410D54E66886975775F511EE111"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "A0937C5F34EDB34BE949ED382F5940AF1410"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D4F336A323D04249AD7AC9D4CAD8055DD2F7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "0579711F4C90314F2448A3757A9E56831F11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DFBBE7F8546546463B79A3A87BDF1EC62B91"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5A490D964817934E172860916742154B8CDF"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}