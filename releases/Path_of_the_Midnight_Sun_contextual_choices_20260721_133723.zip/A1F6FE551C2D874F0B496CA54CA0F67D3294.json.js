GS.dataCache['A1F6FE551C2D874F0B496CA54CA0F67D3294'] = {
    "uid": "A1F6FE551C2D874F0B496CA54CA0F67D3294",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5-01 Rya's briefing on Manacrest",
        "type": "vn.scene",
        "parentId": "555C26067448B148177A8258764AD85D121F",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "6252F0C880B976461F79C525BEAA2BE04DA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CEEBA5D0EA7D342511A56B380DE016A8B8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "45918E0E12BBF148635A9360998958409EFE",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6A1F1553C2FD34FA3194037C785CD999BFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1E8C396462160048620BB661717B45EFC46C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BA9E71F526C30642EB3ACE605E48DAF72C4E"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 1
                    },
                    "targetVariable": {
                        "name": "lv",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4DAABD726215A448996967681D80633C2428"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4A0CF92C25B5824EA83AA1646591B16B2AE1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "lv",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2603F9918CE7594E470B3F82C3AF27F2C0FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            {
                                "name": "Numero Multiuso 15 bis",
                                "index": 174,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "5EE144510F08E84C793A48A0047A174BB188"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E033ED036F3A8846B56BBF2798CBC798C91D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            7,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FAE34EC44E41444834BEFD75AB0F9760A92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6190FE1C2E16674D7B7BE636788066C1715C",
                    "parameters": {
                        "values": [
                            10,
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "2697AEA39EB5414B677BFEF54C3B822B769D"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 9
                    },
                    "targetVariable": {
                        "name": "param",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DFBFBFAF17C53446458944D1ED40518901AD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "param",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 8,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3443F1E11A68534C200AAAF3E814C0CE9654"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 9
                    },
                    "numberValue": 8,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "4AE23A705A08934CCC4AB43737696E81A812"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C842763305C484A626880A42760CBD28355"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "F496864221CC8240FE69594589564E71BC02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDBCD5806D537340138ACB521869CF6D4D2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "267326A7883D6446A24885545F67133B0E4D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "1C444E745047B24C132AF855C41891E6B5CA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0998FBEC7DED5442A4888738F18C09F43D2C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "552425068531D8497F3ADE61D04F2EDB88A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A11DBB88505E454C9288C8B056FC7C0DA3D0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "CAC711DE14E64842038BA0779C40B7EE9418"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B46FF3604C0BF4483319BC9629A926915389"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration/FOOTSTEPS",
                        "name": "CONCRET (ARMORED).ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 1,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7989441D5F928547C73B7F27EBC1F8A1D2FA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "A2A2260A7013F340C7999088E981EF6139B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61F4F83F03312743E978A5328231552AB0A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F699FCF48B29A24FA41980975A89063F1865"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF1CAFD08D70234F522BF4B4CD81A9DDA65C",
                        "defaultText": "그렇게 피비 여제와 다음 계획을 정한 우리는 곧바로 출발했다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "A6203BCA92BA12430729D920B7A926E731EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBAB9F7B337D63403048F6A1EF2C4CE6E332"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9827F055E353540D64ADE54648BB5F309EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "792D8B8E7CE116406178BBB7D9D10C95674B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9B60A3CF3630E44D8158477328729312F194",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "568FECC75F93F24EF33A9924D1BD66CA28FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46C3737B62EEB249985B27D2341BFEB473FB"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -25,
                        "green": -25,
                        "blue": -25,
                        "grey": 0,
                        "tone": {}
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DC5C7BCE1BBE6541999AD3D523E2513465A2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "BF289C864C7E074BAD58FAC57A6FD8029936"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0253E9242DBE0248529A38D000C093BEE2A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C82D2C76405F634712192766AB01742C98A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B5B1B1CE35FCC24CD968CC87294D935A8DC9",
                        "defaultText": "호이카데의 눈을 피하려고 밤을 틈타 행군하느라 한숨도 못 잤다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "1ACFFE7F83C2104A3258B8005DE6C0A40619"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AE6D6D15D5EF54AC77BA6992AB52F461F45"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC94D31885A88146FA4A8660CF698FED6EA1",
                        "defaultText": "수많은 생각이 머리를 스쳤다. 그릇과 새로 만난 여행 동료들, 그리고..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "3DE200E945715744A36BAC759588EE03B13A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "843FF2651910444F6C4B2E6538CE0ED97FFA"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration/FOOTSTEPS",
                        "name": "CONCRET (ARMORED).ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "41238DE677F2234BC35849C51007C46090A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6D190C48A7CF141B84B5D95EBF544507E20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C400EB520184840B399B6078F8D05D248E1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "1C5A22C27D92E84A494934A1CBED6CE7E34F"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "575CA6DC4C58C7415E7BD733B65C3146981A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9AF2D99B35ECB84C378B6135A31780CBF4E0"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC88664D9F0965466D79BC165E6E4908FF9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F214CF9B2922714E217A5B01B7C8584453C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52F7C10781A4664A466A4CF01EE473C57CDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A823598371EF849E12965E3E097FCEB4DB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "332BA1C536C9F243F01B8360A53348ACC1A9",
                        "defaultText": "그래서, {LT:1}?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5548567B32228542BA990A011E0E006A3551",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FADCBD721BE4448A788A525F61B54774CF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "547ED3B37174E141892947264FDA0AE05151"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "89FCA3F72C8F9549373A1608DF7522372497",
                        "defaultText": "... 어째서인지 내게 주어진, 아직 정체를 알 수 없는 이 힘..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "4AD22A834BD2404254189E788F8F5FA49866"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4227340422C1247463B6164308A34DE9E20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26B676B52858A7450A7929D9267F5F7AF649"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87337CAD0816084ACD3B365118E46268C9E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD3732DE42F2F1409A38B1416CD50354A73C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "458F65CD58D0F14CB4797092EC17BDAD7AC6",
                        "defaultText": "이봐! 쓸데없는 생각에 빠지지 말고 집중하라고 했잖아!"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BD8056B11361E3497F083925026DA82D6B31",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D92732837E533486C399979CD1170A88E6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7A635EA73F1902482F48F6A8A0C35B7873C9"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D0019D127EB4E4462B0A51783447463DC4FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6CF2DA1D84F23843699964453D3FEE3FC2A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B65D588C1A1CB742739B33B3C626CECC8432",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C15-2_line144.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15A649523265084F2679811261F81BEECDD3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1CFE1281599D5542673B2DB2C43F7E927867"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6095C9071765984C3799D1C93DE47BD86EEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "923CE0FF4A19244A382BAA2872AF41335AD1",
                        "defaultText": "아-아, 네! 알겠습니다, 리아 공주님. 죄송합니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "751375E118BF414E796926C28CDFA80AADD6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B68A16C74114A7418C899AA11798AAB11501"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1D5AC1896A6044AB94B6785BB29E699189A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1086FCD4920635490D6978168C522F17DEC8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "050E72D725A8F6463B6A91119878D838A32F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B57501152800449137AEC5482959E010449",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9C30F6BA07B2A34223886AA330BA1E93C416"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0EB39E0DB4D6447F6A4C364D304C4EF72C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E26DCC3B0FC5844B03691FB0CC4390AC287D",
                        "defaultText": "그냥 리아라고 불러. 오랜 세월이 흘렀고 넌 기억상실까지 겪지만,\n우린 예전에 친구였어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D7190BF31084874E862943C3003AACB8C5DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB51F17C23D09343E9895818B7BF4851B92C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2E1325D93643484B233A9135AB81169780CD",
                        "defaultText": "알겠어, 리아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "24642BB67DD29142357BBD498FC0390EF169",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "292EA1E94EE7A44DD8789CF207AFECC78EE3",
                        "defaultText": "내가 널 지킬게, 리아!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F1E5A74E8773E2490B7A98454EB4A90E91F4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E76C6423510C80476F3A4494AF3D12549C45",
                        "defaultText": "그땐 내가 인내심이 대단했나 보네..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "715C2019772B0045305AA2F6AF3B71D91DD6",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FCFD0A36455FE04D855A5807AC3F3140DBA7",
                        "defaultText": "우리가!? 친구였다고!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "06A0A6377D950445D7486620FCE26E3B4890",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "kind",
                            "protector",
                            "silly",
                            "silly2"
                        ]
                    }
                },
                "indent": 0,
                "uid": "878190F76B6A544D524A2CC9B830EF43098A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E97B2A0E2274A84828590A117C086180ECBC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "kind"
                },
                "indent": 0,
                "uid": "423C8E771A86414F277B4AA8C9D424EE04D7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ aff"
                },
                "indent": 0,
                "uid": "D9783EA4144D914EE468B1181DC1C21CF681",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D21861AF9199664A174BD7E198C80F3FE63A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B85DCFC3E6C93459F48D4C9E8FADA6895ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C25A1FD6ED7D64AE03899067659A51FF66B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "059858EB071E15478A3BE061BC634448A1F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D29574526855464F207B7FE9A9F19386C52D",
                        "defaultText": "친절히 대해 줘서 고마워. 잃어버린 인연을 다시 쌓을 수 있으면 좋겠어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74FD89B969CC174AE23B6633C95D34D0651F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4E5EF040C047945CD1B01C21F72FD0C1F23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5679610A5793A4487E0BDA721FAA23639197"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1C825A64A18B5413D18FAA925433FCA8A69",
                        "defaultText": "나도 그래. 최선을 다할게."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BCD90E3E39BC3742637BD3A6A76E1E77C88A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "170BDACF11BD4442528A53626BAD4622CA83"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sanity"
                },
                "indent": 0,
                "uid": "FC00BB75311E1142BA1AA172B952B934B3A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            1,
                            6,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "7532D3B56FE46944FC3B4080A2FE35056D6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA4635D25053F649F96A38C6B9A9447F1747"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9F4F36B3C19C74EEF7B9DE7D5A73F02CDDC",
                        "defaultText": "새 친구가 생기니 기분이 좋네.\n기억을 잃은 뒤로 늘 외로웠거든."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E21C78D411620642E9989187F92CEB784F26",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1512F52D0090D04B278AEA676E5167595791"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62DB9E0A3601B44E7C8B1B17ABCD0A97EDDD",
                        "defaultText": "리아와 크리스토프는 완전히 ‘새로운’ 친구는 아닌 것 같지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C6E057FF8AB14441DF9B0B31E1C9CEA9F6F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "158045B1253AE145970ACDF8053B4A99957C"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of rya choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "520B4EAA10596847C7788E034829332B63DD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "protector"
                },
                "indent": 0,
                "uid": "6F2034734221E44321898E29DFFF0A9B5658"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27328C51578DC341778BC874FEB8491C15EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ACDAD072259A24CEA78EF05DE067D139459"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77A11C8A1E13964D99294AF0C55D84ECEDFC",
                        "defaultText": "그게 낫네. 하지만 날 지켜 줄 필요는 없어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CC2F90A998BA30478C69DD433052FA9B24C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34A459B64A2E374ABE7A2B25E63DA9409ED3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E053DE22607B1042531BF227FB56FEFCF682",
                        "defaultText": "내 몸은 충분히 지킬 수 있어. 그리고...\n남자들이 잘난 척하는 건 싫어해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "04AE93199605C64E2C2A8844AC6AC6B1CC25",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0727D5540263849D98A2F32050D559561A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63CF3F7040ABD04A45488F30AF59FE13D70F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "479472F683B8A64A8D7929B8B31E93239E50",
                        "defaultText": "어, 그런 반응은 예상 못 했는데."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8A9344C50618B9484C9BD9A707698DCB5884",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E29400164498240997AA11542536D01E7FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29C6893A1910F2405C48E557235AEDBCCA87",
                        "defaultText": "그래도 이 대화를 억지로 이어 가지 않는 게 낫겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5DD2BB736F70A64FB4594B2828656E259AE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32F27F6067AA9647E818B302DC11B923324B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5549B4377E4FF040C56BE0473333EB5BA195"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2510C3F85C9AC74D9F6B48A0DD6ABB957EAE",
                        "defaultText": "기분을 상하게 할 생각은 없었어. 앞으로 명심할게."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9CD57F81406BC245CE18F5972916D4695739",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B04BBC2F9A39644DE30AE797C7D09D5D9D3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D805E7DE2F0C51475959FB6168889BE5BF65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B912438037E3024F9129A8D028FD0090136C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2AAE61B695C764D2A7925A0B8FA693C6202",
                        "defaultText": "고마워, {LT:1}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D942E34B237B6645B20BD9C8A7E3025738B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C31E1848782155424D78D2D9C05DEF303D98"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of rya choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "32B7717E61793346371A91B14EE83D802BE6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "silly"
                },
                "indent": 0,
                "uid": "D96345437C39984B0A2B93F86F12F0B6F98A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sarcasm, advance to silly2"
                },
                "indent": 0,
                "uid": "2803550531BFF842244932106CC4E0FBE62F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "7227F17A835B954DB4199454327458E3AD59"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "silly2"
                },
                "indent": 0,
                "uid": "C38B229512AA4344DC8B26B1BF4D51BAF6A8"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "- aff"
                },
                "indent": 0,
                "uid": "3BAA77A25A1FC840927BCBE56DB15834AF50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            1,
                            0,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63687AC82F83A043F838051539907006C240"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D528A78A23BEB04ECE8A188611B1E8527546"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42815A7F096DE3490E69294399589968C51A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EE4A73F561EA54D794A5FD48484EF0C8EA9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C96F4717785717434E2B47E23BB2155D2537",
                        "defaultText": "칫! 머리를 얼마나 세게 부딪혔으면 이런 비꼬는 바보가 된 거야?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2AAC2D8B7ECF4941744B96505928E08101A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "065F49C555840347583AD740D10B001ED3B8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F50E4ACF68F4174ECF39D987BF099FB0B70A",
                        "defaultText": "내가 알던 사람의 흔적이 아직 남아 있기는 할까..."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7CBD0C084B92564B670B21613FD85A66347C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44BD64620A2350403779FEB6E97F1DAFEEB5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of rya choice"
                },
                "indent": 0,
                "uid": "C083608F342E424DD27962C416E96E6E9BBA"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "red text for Manacrest"
                },
                "indent": 0,
                "uid": "06C8583D881C2645647A86E642D623C39F02",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "927508F18DE60846FC8A1E950C1C6C749D62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7A8EC6B930275479A1B4FF587654F3F9C65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "826ECA472D6AF5421E496EE19B72B2FF9FB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8890F24E5D9C974E3B083817E594DC033D41",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line28_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B61392958C539846D71ADE5255B4A371BAB2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D9EF8A1B1019824BA18A9287BEEEDE135AA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "457D6A0E58EDD74911193374BE946ACFC910"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "19F4A68A30DC984559797252B87FCE242BB8",
                        "defaultText": "아무튼 본론으로 돌아가자.\n네 마나크레스트 말이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2A7F75C9E68814AE2384FE422AF52864E7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27EF33B504A2564EBE1B03E2F353112D801D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF1884234287D441B39BE3614507DCEF6B36"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7218A50E58A1A244B60B20F7321ACE3C69C3",
                        "defaultText": "내 기억이 맞다면, 이... 특별한 마나드롭은\n{SP:1}{C:1}마나를 저장할 수 있다{C:0}고 했지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "99B5ED365AF22942E98B0712C9DA36461F19",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F420057575809143216A9E014AEF88E5DB07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1ABCC13D46A8314F394B93D11374B490CA00"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5ED1A40F0D1B45493E194B5099EDD2D6BE0F",
                        "defaultText": "원래 그렇다고 해.\n아까 뭔가 느껴졌어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3755E63D3C9CE448A7899752136133BCAEE1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D3D6D7A827EF841AE2957D48CAD6EB13EA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4271B6B949FA74B810AA5C60FDF926A7FD2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9BB523C6826D648AE8B7D0585CD15002C2D",
                        "defaultText": "솔직히 말하면 제대로 신경 쓰지 않았어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A0AFB7B9A0D784E42783516198749BAA821",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "798D626598D520446C9B6DC54C8592232741"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AE85E745FFDA949FB6B54B1F48EC16CCBF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57AA41946D34C3454A0B83909916F464534F",
                        "defaultText": "음, 아무것도 못 느낀 것 같아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7E06EF0F105C734BA2286209F10700384065",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06287B3B096C164B907B2997CD20038481BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C254D92E008B65441848A7860E2E0CF4230D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9DBBF75A29CD7240694B9727D708CAD97AC3",
                        "defaultText": "하아. 좀 더... 실증적인 시험이 필요하겠네."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "89E6C13C977AE14D788A11C821074E09ACEC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3B028177D97854F5F187DF588C9E1B298D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1AF8EFEE6BB81348F22B7504AA27F657072E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48D1FBB20FA6E74B1E8BEE65309328DC9D99",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line4_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DEFD52779622143D38AC3575F2260F4DAC1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B1B29E9C7010944D069997574456DE055ABF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30F125976606F5469158BD97D484C3393D17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B60F5A4200BA34F602B9327015810E5427E",
                        "defaultText": "저... 설마 날 때리려는 건 아니지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "73E6F3806AA805419A8B0D21E46DE25D4503",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "405FF8731799984C779A8A95F25979D16128"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F2B48473CDAB5437D294DA1BFC9AF5A6660"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "31F5EFDE12C40843B438E389C44D8620ACBA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AFD337E4DAF12453A686DF6F0C7585A59D1",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line21_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5121F8DD6159D34F5F8A7F414A91339682D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ED3574FF75B314497C7BD753667D135C3408"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2CE29DB2C8AD340A058F8919281651A36B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA89B9336615834D260A5D54E2E1DB705247",
                        "defaultText": "그러면 분명 속은 시원하겠지만, 그럴 생각은 없어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "491F0AF06BA768498D0BE715A8B640E0A18C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A8FDE41827AB4487589C0A578E887902BB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "658D82A27EF8D44F8F389CD05C0F6AE741EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23C528E50DD7F1413E18E9A4853392B76862",
                        "defaultText": "리아도 꽤 빈정댈 줄 아는구나..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6384B65D869F924DE71A51B07C99DE93FFC1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "404DAA190845A84D026AFD07C3AD119F613D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F204A8939795934C8A891D22ADF1DCE182D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "442A914F667FB341609BB8A9282F07F90C46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6B801BB66AD88453A89F382E6ABB4922B15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93D7638E6152C7489B5A73C1BB5BD8C1CF94",
                        "defaultText": "주변에 핀 꽃들 보여? 이맘때면 도살나비 떼가 몰려들어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "312462B58B4CF8402E48BA0687D9B9E67687",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97DB878B63DB824EDA8A2CF5835CD767D855"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDB1E81B114DE940161AC39292710CDE8250"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4110DF45BAC114D919BF4D2E7A10E70AF09",
                        "defaultText": "나비? 나비로 뭘 하려고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "815A65667F13354E893A81059FF9AD8D8246",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "744DC1EA7AEBB8492C7AF4B769390A89D08C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02791D2C6605B14EE538DE351D12E36426B6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "FF7DE7AC42CE1242BD2B9F67B072C4F2B919"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "721D3F194F1DC7425B586681CADFFF589FFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA3BADD18445204BE918B319A2A3A084A76D",
                        "defaultText": "{SP:2}{C:1}도살나비{C:0}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D0DF778132B9241AB697B760B456DE4C1E5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BFD335D868AA1459F3B4391DAABA5C048DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96E158C17DEDB6464E6A284452DF9BBD2841"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C23DE4F34D2E0241214B9AC36CB422A5E020",
                        "defaultText": "도살... 나비..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B1C52B52380297422B4831072498773C1426",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BCE97B01E95D046BE881126AB138D3E0711"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E3CF6FF9E6EA247E26AEA7298D58925B5B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73C9C4CE34007847A67A214332A20107977C",
                        "defaultText": "자세히 보니까 평범한 나비처럼 생기지는 않았네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A90212EC714875479288C118F8EC280300E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C34134D83DB56644AF8908E5AD1576F23E21"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44320AD43A89B94FFB48CB040B1DAFD4EACA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D034EDD9738E8942334998D19359BCD0D050"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B7F485B58DE044BA27971E7CAF08447FB88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E176754A57404849B63AD3365B6A677055EF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01285ED73886A64BCA9896B82278A85D4602",
                        "defaultText": "하아, 어쩌다 이렇게 둔해진 거야? 검을 뽑고 따라와."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1733AB67974C9849BC58BB449D508D54E7E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6EFF45F8DBF0743444A46D19A998278A296"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B46BFAF362A7724C2E0B4C18E93B22A0177C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8DBCBA722A4A444C822B53522E59BEA66534"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "02D64B4F725F9442CB8A6E824AAC5B6FF855"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1
                    }
                },
                "indent": 0,
                "uid": "D7284DC19CC4A34E3C4B0BF1D982E53033BE",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "12B26AF2429D4543726B3DA9B23245FCC0A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E12E4C495F8BD249642A2FF531FCBD80EFC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56233BED3E69354A0F5AB0364D50497A4859"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "887384EC4188874EC55BC515A73BFC3411F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "442B8FEB11E3434E1A4B2CA697E847C84BD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC2E12385ED8F34A994B37E706851F917958",
                        "defaultText": "잠깐, 리아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0261BACE8B19D445240A836214AD8F584EE0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8B84D1CD186DA644128B146259A751EC929D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "53EC640F7AA3154C867931E9E6615A3D556A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F495D1D235929043F658D5F1B6C24CD13E92"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "095DCBC28A6A0743F18B94612A1750CD2CD3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "8F5CC9F22AC77648620BB32712CD18B83BA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "44B40C0B5F23B64D866BC36581F367AEFD46"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 39
                },
                "indent": 0,
                "uid": "0E488C5783202643DC5AD155FD5DEB55DC74"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "unsheathe sword"
                },
                "indent": 0,
                "uid": "5686312F5DEC684893581469D2A2A4CABC41",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "550F33904286A74B194BD5825EB7A05694FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CFCC6231CFEC74F81885E8069A053FBDA88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1AB648C6B1CD947131B4892CDC407469CAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9A085F59945714E7A3830B8FDBE5080DF9A",
                        "defaultText": "내 인생에서 가장 이상한 벌레잡이가 되겠군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F4E6B67C2374124C196B8700E93C37770985",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "17611C2F5F375644651BD200FD14DA3DA69C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "17D5F85257BD68434C7BBE936D10712B1170"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "60B4CE9671E18341E858F378819E43DB9E10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0F6B3843F6A11410719C482B71163ACF2C1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "5AF33C3E7C3DA349D2684546AEAE84A26D3E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CAB4306E3011B842FE19DC75071EDB7C398D",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "1C9A6DA6855018432C0A3E966A1B4F4E1310",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "163BAA3E5E9AE64DDC3A662089917DB66E73"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "6F7D07B9656B15421D58FB388223514B2896"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Unlocked Manacrest?",
                        "index": 100,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "67DE6D4D007233449319C27879BC0F958DAD"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Punti Mana MAX",
                        "type": 0,
                        "value": 10
                    },
                    "numberValue": 9999,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "BEE7AF356BFCC94BE06B5941E2CF1145BFA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C8F8ED264A57A44DD5880D754A4DA3A5F145",
                    "parameters": {
                        "values": [
                            "A72EB1E0432086453B182A04C5BAED5666F7",
                            "96E75C357588624215597679212778272D6B",
                            100,
                            "4A9095A39FDDF14F180BE8756612262A4AE6",
                            27,
                            "7AF652131CA6A04D35882C780401D7C913E1",
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7BDF419734B054CDB8A46A72DB09F067D24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "AB9888C61A474143AB49A232F0D529FA9A24",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28B3687F8BF1734CE13AC8C07188922E6720"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            0,
                            "A72EB1E0432086453B182A04C5BAED5666F7",
                            21,
                            1,
                            "6FC1ECC751CD1646E479AA83E16EF52832F0",
                            21,
                            3,
                            "8F79335995A3354904599D01A7716E53AFC2",
                            22,
                            5,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "CAB08D053AFD4343AC786E0239A623F15AA9",
                            "Graphics/Avey's Battle Backgrounds/Magnolian Plains.jpg",
                            "0130AF490DF5934612891A4097CDBEC27118",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "00D9DF3B2D847347AA0A0229925C8F2149EC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "64AE49A64C86264CB788A3C181344920E4A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C8F8ED264A57A44DD5880D754A4DA3A5F145",
                    "parameters": {
                        "values": [
                            "A72EB1E0432086453B182A04C5BAED5666F7",
                            "96E75C357588624215597679212778272D6B",
                            28,
                            "4A9095A39FDDF14F180BE8756612262A4AE6",
                            27,
                            "7AF652131CA6A04D35882C780401D7C913E1",
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B447E701587E64C988844754D2AD4E031D8"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "CAB08D053AFD4343AC786E0239A623F15AA9",
                        "name": "C5-01b Battle! Manacrest tutorial"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AB6EAEA8064DB847183B4C366966AB37E123",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "F07EE25C3FEB574EE69B4DB4CD0131746A02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DA8362F86F6834411999467127AA6C49CCE3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "4798E62D492D6447735A2147C2EDFD667403"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the battle"
                },
                "indent": 0,
                "uid": "5E78DC51489C9144A708BEB4CDDA75282666",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "A355DCE83BBCA649708A5748FB947046EADE",
                        "name": "C5-01c Post Manacrest tutorial"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "202C0DC636CFD247AE6A7624578B0C21F974",
                "expanded": false
            }
        ],
        "localizableStrings": {
            "AF1CAFD08D70234F522BF4B4CD81A9DDA65C": {
                "t": "And so, after having established our next steps with Empress Phoebe, we departed immediately.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A6203BCA92BA12430729D920B7A926E731EE"
                }
            },
            "B5B1B1CE35FCC24CD968CC87294D935A8DC9": {
                "t": "We didn't sleep a wink, marching under cover of night to avoid being spotted by Hoikade.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1ACFFE7F83C2104A3258B8005DE6C0A40619"
                }
            },
            "CC94D31885A88146FA4A8660CF698FED6EA1": {
                "t": "Many thoughts crossed my mind. The Vassal, my newfound traveling companions, and...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3DE200E945715744A36BAC759588EE03B13A"
                }
            },
            "332BA1C536C9F243F01B8360A53348ACC1A9": {
                "t": "Well, {LT:1}?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5548567B32228542BA990A011E0E006A3551"
                }
            },
            "89FCA3F72C8F9549373A1608DF7522372497": {
                "t": "... this still unknown power that for some reason has been bestowed upon me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4AD22A834BD2404254189E788F8F5FA49866"
                }
            },
            "458F65CD58D0F14CB4797092EC17BDAD7AC6": {
                "t": "Hey! I told you to focus, not to get lost in pointless thoughts!",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "BD8056B11361E3497F083925026DA82D6B31"
                }
            },
            "923CE0FF4A19244A382BAA2872AF41335AD1": {
                "t": "A-Ah, yeah! Sure, Princess Rya. Forgive me.",
                "d": {
                    "cid": 0,
                    "eid": "751375E118BF414E796926C28CDFA80AADD6"
                }
            },
            "E26DCC3B0FC5844B03691FB0CC4390AC287D": {
                "t": "Just Rya is fine. It's been many years, and you even suffer from amnesia now, but we used to be friends.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "D7190BF31084874E862943C3003AACB8C5DC"
                }
            },
            "2E1325D93643484B233A9135AB81169780CD": {
                "t": "As you wish, Rya.",
                "d": {
                    "eid": "24642BB67DD29142357BBD498FC0390EF169"
                }
            },
            "292EA1E94EE7A44DD8789CF207AFECC78EE3": {
                "t": "I will protect you, Rya!",
                "d": {
                    "eid": "F1E5A74E8773E2490B7A98454EB4A90E91F4"
                }
            },
            "E76C6423510C80476F3A4494AF3D12549C45": {
                "t": "What incredible patience I must've had, then...",
                "d": {
                    "eid": "715C2019772B0045305AA2F6AF3B71D91DD6"
                }
            },
            "FCFD0A36455FE04D855A5807AC3F3140DBA7": {
                "t": "US!? FRIENDS!?",
                "d": {
                    "eid": "06A0A6377D950445D7486620FCE26E3B4890"
                }
            },
            "D29574526855464F207B7FE9A9F19386C52D": {
                "t": "I appreciate your kind response. I hope we can rebuild our lost bond.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "74FD89B969CC174AE23B6633C95D34D0651F"
                }
            },
            "A1C825A64A18B5413D18FAA925433FCA8A69": {
                "t": "I hope so too. I'll do my best.",
                "d": {
                    "cid": 0,
                    "eid": "BCD90E3E39BC3742637BD3A6A76E1E77C88A"
                }
            },
            "A9F4F36B3C19C74EEF7B9DE7D5A73F02CDDC": {
                "t": "I must say, it feels nice having some new friends. I've always felt so lonely ever since I lost my memories.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E21C78D411620642E9989187F92CEB784F26"
                }
            },
            "62DB9E0A3601B44E7C8B1B17ABCD0A97EDDD": {
                "t": "Well, Rya and Cristoph don't appear to be completely 'new', but still...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C6E057FF8AB14441DF9B0B31E1C9CEA9F6F1"
                }
            },
            "77A11C8A1E13964D99294AF0C55D84ECEDFC": {
                "t": "That's better. But there's no need to protect me.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "CC2F90A998BA30478C69DD433052FA9B24C7"
                }
            },
            "E053DE22607B1042531BF227FB56FEFCF682": {
                "t": "I'm perfectly capable of defending myself, and... I dislike it when men act all superior.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "04AE93199605C64E2C2A8844AC6AC6B1CC25"
                }
            },
            "479472F683B8A64A8D7929B8B31E93239E50": {
                "t": "Huh, that wasn't the kind of response I was anticipating.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8A9344C50618B9484C9BD9A707698DCB5884"
                }
            },
            "29C6893A1910F2405C48E557235AEDBCCA87": {
                "t": "It's probably best not to force this conversation, though.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5DD2BB736F70A64FB4594B2828656E259AE4"
                }
            },
            "2510C3F85C9AC74D9F6B48A0DD6ABB957EAE": {
                "t": "I didn't mean to offend you. I'll keep that in mind for the future.",
                "d": {
                    "cid": 0,
                    "eid": "9CD57F81406BC245CE18F5972916D4695739"
                }
            },
            "B2AAE61B695C764D2A7925A0B8FA693C6202": {
                "t": "I appreciate it, {LT:1}.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "D942E34B237B6645B20BD9C8A7E3025738B4"
                }
            },
            "C96F4717785717434E2B47E23BB2155D2537": {
                "t": "Tch! You must've hit your head quite hard to turn into this sarcastic idiot.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "2AAC2D8B7ECF4941744B96505928E08101A0"
                }
            },
            "F50E4ACF68F4174ECF39D987BF099FB0B70A": {
                "t": "I wonder if there's still any trace of the person I used to know...",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7CBD0C084B92564B670B21613FD85A66347C"
                }
            },
            "19F4A68A30DC984559797252B87FCE242BB8": {
                "t": "In any case, let's get back to our main topic of discussion.\nYour Manacrest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A2A7F75C9E68814AE2384FE422AF52864E7C"
                }
            },
            "7218A50E58A1A244B60B20F7321ACE3C69C3": {
                "t": "If I remember correctly, you said that this...\nspecial Manadrop can {SP:1}{C:1}store Mana{C:0}, correct?",
                "d": {
                    "cid": 0,
                    "eid": "99B5ED365AF22942E98B0712C9DA36461F19"
                }
            },
            "5ED1A40F0D1B45493E194B5099EDD2D6BE0F": {
                "t": "That's how it should be, yes.\nDid you feel anything earlier?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "3755E63D3C9CE448A7899752136133BCAEE1"
                }
            },
            "F9BB523C6826D648AE8B7D0585CD15002C2D": {
                "t": "I wasn't really paying attention, to be honest...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4A0AFB7B9A0D784E42783516198749BAA821"
                }
            },
            "57AA41946D34C3454A0B83909916F464534F": {
                "t": "Umh, I fear not.",
                "d": {
                    "cid": 0,
                    "eid": "7E06EF0F105C734BA2286209F10700384065"
                }
            },
            "9DBBF75A29CD7240694B9727D708CAD97AC3": {
                "t": "Sigh. Maybe there needs to be a... more empirical testing.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "89E6C13C977AE14D788A11C821074E09ACEC"
                }
            },
            "7B60F5A4200BA34F602B9327015810E5427E": {
                "t": "Er... you aren't going to hit me, I hope.",
                "d": {
                    "cid": 0,
                    "eid": "73E6F3806AA805419A8B0D21E46DE25D4503"
                }
            },
            "EA89B9336615834D260A5D54E2E1DB705247": {
                "t": "Although that would certainly be satisfying, I think not.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "491F0AF06BA768498D0BE715A8B640E0A18C"
                }
            },
            "23C528E50DD7F1413E18E9A4853392B76862": {
                "t": "So Rya can be quite sarcastic too...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6384B65D869F924DE71A51B07C99DE93FFC1"
                }
            },
            "93D7638E6152C7489B5A73C1BB5BD8C1CF94": {
                "t": "See the flowers all around us? They tend to attract swarms of butcherflies this time of season.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "312462B58B4CF8402E48BA0687D9B9E67687"
                }
            },
            "D4110DF45BAC114D919BF4D2E7A10E70AF09": {
                "t": "Butterflies? What are we doing with butterflies?",
                "d": {
                    "cid": 0,
                    "eid": "815A65667F13354E893A81059FF9AD8D8246"
                }
            },
            "BA3BADD18445204BE918B319A2A3A084A76D": {
                "t": "{SP:2}{C:1}Butcherflies{C:0}.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5D0DF778132B9241AB697B760B456DE4C1E5"
                }
            },
            "C23DE4F34D2E0241214B9AC36CB422A5E020": {
                "t": "Butcher... flies...",
                "d": {
                    "cid": 0,
                    "eid": "B1C52B52380297422B4831072498773C1426"
                }
            },
            "73C9C4CE34007847A67A214332A20107977C": {
                "t": "Now that I take a closer look, those don't seem like regular butterflies.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A90212EC714875479288C118F8EC280300E8"
                }
            },
            "01285ED73886A64BCA9896B82278A85D4602": {
                "t": "Sigh, how dense have you become? Unsheathe your sword and follow me.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "1733AB67974C9849BC58BB449D508D54E7E9"
                }
            },
            "CC2E12385ED8F34A994B37E706851F917958": {
                "t": "Wait, Rya!",
                "d": {
                    "cid": 0,
                    "eid": "0261BACE8B19D445240A836214AD8F584EE0"
                }
            },
            "D9A085F59945714E7A3830B8FDBE5080DF9A": {
                "t": "This has to be the weirdest bug-catching attempt in my life.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F4E6B67C2374124C196B8700E93C37770985"
                }
            },
            "B65D588C1A1CB742739B33B3C626CECC8432": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "15A649523265084F2679811261F81BEECDD3"
                }
            },
            "050E72D725A8F6463B6A91119878D838A32F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "7B57501152800449137AEC5482959E010449"
                }
            },
            "8890F24E5D9C974E3B083817E594DC033D41": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B61392958C539846D71ADE5255B4A371BAB2"
                }
            },
            "48D1FBB20FA6E74B1E8BEE65309328DC9D99": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9DEFD52779622143D38AC3575F2260F4DAC1"
                }
            },
            "2AFD337E4DAF12453A686DF6F0C7585A59D1": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5121F8DD6159D34F5F8A7F414A91339682D7"
                }
            }
        },
        "numberVariables": [
            {
                "name": "param",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}