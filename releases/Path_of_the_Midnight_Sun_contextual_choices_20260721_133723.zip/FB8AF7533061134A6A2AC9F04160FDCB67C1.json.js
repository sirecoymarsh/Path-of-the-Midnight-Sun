GS.dataCache['FB8AF7533061134A6A2AC9F04160FDCB67C1'] = {
    "uid": "FB8AF7533061134A6A2AC9F04160FDCB67C1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11B-3c P1 Old Man",
        "type": "vn.scene",
        "parentId": "389AE54A57B99848C91978E5A1120CB378BD",
        "chapterUid": "8A78B92E5A59F446F05823F4DB00C78A28B3",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7103EB8287AF754C2F198B079181B434DEF4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B2C9927E430D834E3F1AC4874557DE379787"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7A2A07DF53C7904D005AADD6D62A75A0D910"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98599F8496019643573B5DE50EEBC23A3D74",
                        "defaultText": "안녕하십니까. 5분만 시간 내주시겠습니까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "BA0BFE3E38B0B44B66686A43AB2A831A6180"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7B777C9A1E73C14E2B0997940C1DEAEFDDC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC0567A641A2F44276591A826198693A3DDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB383B24882033446B499E57B3A31287AF41"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "43A03ADF3E08924BAE187B126A2BA488A490",
                        "defaultText": "흐으음..."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "029B800577201645FF1B54B70C5D76BBB223",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "989840A673DB5945EC59EF98D1E5960105C2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "413D4E5D1DEE474DD09A6F639FFEEE963559"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "skip 1",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "3E84F8611DF161475119F046681F5907F6E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB6CE6248C7C334F950B97B8FB0D8BFDBA5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "423A637342045646EF4ACBA0BD7D21044E7A",
                        "defaultText": "인근에 악마 세력이 있는지 확인하기 위해 조사 중입니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "55C47652752C284B077BA3C915484410CA04",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7848BFF4AE8D243552A88F1553E7FE144D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89E4A2248245D343FF9A1814F60B4D55C552"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B49064EE7C6C6249B39B86E42D4B07BEC098",
                        "defaultText": "“악마 세력”이라고 했나?"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9BFD5938118321443059AE78F84FD2A4CBD7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB195F70639C24498D7A876226E9322C6D7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "77245DA413C3C14275197C37721A5BA00642"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "72BF5E052062464D2B299695AEE2348EBCD3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-OldManMidbar_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "751916C6420A114C024AB7820D917DDF302D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A3D2663C5815F641433AE20734287FAEEB54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "474F02D35D2A05478748D3D77AD2D49DBEBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18E6428C5A3FB040916A47B70F5CB0D728E0",
                        "defaultText": "사막의 모래언덕은 계속 움직이고 오아시스는 말라 가고 있어.\n자연이 미쳐 버린 것 같다고!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E8A60D048E6A384C2F5BD32758D05C755E53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66E4F7E508BB684A412A17921174A9A7E7E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01DEE3CF68DE474F511AF6F62D2962DC7A49"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7BAE5F9F6F70824A1A19EB2709CDCE4DD04B",
                        "defaultText": "아야! 아야! 알겠습니다..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A2A1A7E0202A246A06AAF26E1CFC3C11054",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E53AD4B45AB80744DA4B29A7D13719D050E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "49F9DEFC2AAD714E6B2AC00355C194CCB0E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B60A01962893A1473A7B71B60B17EB5D45D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF7B7B8147DC824C5A298B49841D121B9100",
                        "defaultText": "그리고 그 저주받은 안개... 그래, 마나 재앙 말일세!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C3CA882279ADA84E8A385F121DA828BD08F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A79904D90C82284FD74A6E7754FD221A763B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5EB90929428BE84E483839C4FB60856A436A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if Tarmen first"
                },
                "indent": 1,
                "uid": "8C5DCE8332CB0240D60830A0685209542019",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10BC60CD7DF9E74BE14823D163909B807CE3",
                        "defaultText": "어쩐 일인지 사라진 것 같지만 재앙의 흔적은 남았어!\n그때부터 우리 땅에는 괴물이 득실거린다고!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "465F2D9A26AEC442574B3779455526F5316B",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "1CE311C9408FD140443BC1822FF384313075"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "70EA1EFA785A5541B55BD6B38F5CA30D7C98",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC71055E37E626409D692F71758ADD677F5E",
                        "defaultText": "그게 돌아온 뒤로 우리 땅에는 괴물이 득실거리고 있어!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B3EE0ADB555E7848055836E3CC247E0F755C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57E83AA96C882749E3789C664D4E49416309"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1618F38D10867449955960436BB7BAADBD03",
                        "defaultText": "그릇은 대체 뭘 하는 거야?\n이런 재앙을 막는 게 그 여자의 일 아닌가?"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C7533542D4A41403379AD79BD93356D71BA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3A996989B8E314E1178B4E610AC278FF42E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F97A47110D23348A70A7A142825D4B00AE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EFA8838C378FE0468F8B10D7340A142A608D",
                        "defaultText": "아야! 그러게요... 저도 궁금--"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C92809BE9F5D25447D48B8E3917370542BCB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CBBB2AB8981434C697BC432DC1C4086F955"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "595419843E85F3417968E2A45FBA193B984F"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 18,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "060D4C270A1731474338AB73C7A1D6E75309"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "62CDAFEA6FC999438A1821B1F5A1BE24B674"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line4_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E120F9E53A4E5483C18EBC662C5CFEEDE9E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0D214B9447B5904DA01A46E62126729C0BBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB8E153925931241A3680D368B3AD12EFBF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "00CC5B832944C0488D3B2E53D2AF6E26C8B2",
                        "defaultText": "아야!!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BD80E584976F14F1A19DDA50C901D675706",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A64A50866CA8D54B99189EB62CBB58219D8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1071DD6A3B4DB24453593962515099B19BCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB41C5A28820C148537A87D0A045CB0A7373"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C583972586CBA444FA39ECF11E10BD6628B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89005F728ED4444177797A500FEE93C97950"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3262F3448140745CF7B34B96849D9FA3186",
                        "defaultText": "흥!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8F34B21A2763A4435D0B36C5123D4CBC88BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E192CAFA0B2B36469218EA229B2F8EEEDEFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43DEE43D1607974411986475C8EF9CDE8FB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3F3ED1130862141FA4AC0B3054300CF63C9",
                        "defaultText": "이미 얻어맞고 있는데 팔꿈치로 찌르지는\n말아 주시겠습니까, 파라트라스 님?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8B63AFCD64FE9645152AC3E48DB42CA0BC06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D1C42E2656576469C58BBA6CF3B2C94A3B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07B07B7D9EE08341AA3AD1D6AC0556E2112D",
                        "defaultText": "그런데 왜 이 장면에서 기시감이 들지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "09979C4E9771A2469E4BECE8A76712173455",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3EEA3FB56B0A34A345B03E089D7DBE6688E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D51022C6D30F4466F89A300162E505120E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9F0C85A6417854B38384853BD8048369F9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C842597D5879854552284728EED87DC5714C",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4872882F19A3A749FD28D8E247CC7671FA8D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4E2E72392275342A29932732F68607679FA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEA4BB977888E4426C990253E8502FE26EEB",
                        "defaultText": "죄송합니다. 그릇의 무능이 이 상황을 만들었다는 건\n분명 부정할 수 없습니다."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4430A97C40BA284D227A89E51B2EEAAC0B86",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC2A7EF64000094E225AB7171361A628F810"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "771F03755049074730597688DFCD93ADBEED",
                        "defaultText": "하지만 저희는 이곳에--"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "078AB8F351A53149E1096C44B3F354495354",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "74AAA19E431DB8411D8AF8B45D7456AA5C42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "F896ED3800B1C249C63A10A295CEF5959BF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "921310E81843D84FD3688E55CABFEE66461B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "E0A07E4C694C594A74580A78C6D8ABCCD3F9"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Door_Wood.ogg",
                        "volume": 100,
                        "playbackRate": 126
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9B9F56E66022024BAE1AEFD414BFD565A9FB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "90EEC5F73652694A058A1C95B3625C3C6A49"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "knocks on door"
                },
                "indent": 0,
                "uid": "213047E6604DB640463BC0E2078196D54E75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16A933C980CF524B9F28A8767AD3807A770C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C0A68C94C97E84D6A5A3DC25E92519E53D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D9AC2020492F145426834E4000141BBE5E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "075ECD2B7FD18648FA197590C85ADD1BFE4E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01DBDA415BB30840882826B27DA753F17E47",
                        "defaultText": "이번엔 또 누구야!?"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "546582A37061554A973B9A169766FC7BA1C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22573AA85C36D6482E4A481594741DF5E9D4"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "BEF6F27C11391743A2881DE13DBE2C766C0A",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7606632F7B35294638688BE57B1326143138",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Kabeer"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2AB0543E4C45F744E46B40D4050046E63CC7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9EFDAC5C116D574F5F8978377C88A1A3A607"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "E3-Kabeer_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "88C8CA4D2E1C174A9889DB775B1B17C2C988",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "30D93A3B87C5B7485B799561F02CA5DE0525"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86AA27E74FCB9448EF19FA71C9878E8182AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8FAFC33E4F33C2479C5B2874429BB6B7945A",
                        "defaultText": "실례하겠습니다..."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB888C781AA6974BA88A9A15925FE676EA45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1606A4906300A8473E8A0CD26C5E0FCE7767"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8C0F81D2C77D7452D2A38E3234173CDC0D5"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4999,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1450,
                        "y": 576,
                        "zoom": {
                            "x": 1.7,
                            "y": 1.7,
                            "d": 1.7
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "DB9989451B3B1441D118CDF82452EB122BF6",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.6,
                    "idleIntensity": 0.6,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "5A6EE4E25CE8264A27281F83D4E51F4DC04D"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "PARAM_WINGS_AUREOLA_ON_OFF",
                        "value": "0"
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "47B746FC3A40184C686B32B98A6D4F175AA2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "90143A2B306BA24E842AC9D0B219B66B0E46"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -980,
                        "y": 576,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 14.399999999999999,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8ADEFB8989CA634C700ACEE7D1CF262A8EAC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75BF1E007CA0874258199568D7C6484BCF17",
                        "defaultText": "움직이는 모래언덕 현상을 조사하고 있습니다.\n혹시 관련된 정보가 있습니까?"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC46027E0930B5433538E9848AD265D8574C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02A8DFBF82759641088B4AF3DF2D27C74BB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D00A3F4418F9B54DDE482D58217B258EF8B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D896B66F5EAAC640C149E17274FEFE17953E",
                        "defaultText": "요즘 사람들은 대체 왜 이러는지 말해 줄 수 있나!?\n난 아침 낮잠이나 즐기고 싶었다고!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0569BF7B144F834CF45835164EF288467CBE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3691EFF66D4C6543DE5A4598BD9AC19C3124"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEB8DAE124BC354EED6BCE595834DC99D13B",
                        "defaultText": "없어. 됐나!? 난 아무것도 몰라!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "54F7A4A228A4524AD81BE1789816C60253DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "273A1A8935E11744D95BEA841B2F69A78342"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8A9AD2717749642A18AF6B5E1711B01885D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B220E72876BA4943A01A2B35DA25DFB9F291",
                        "defaultText": "악마의 영향에 관심 있는 사람이 또 있다니? 우연이네..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0A550315310B914E5F3824F5D08712230693",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98E786A61A0174478588DD62AE653E8A02FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6F51A7734EDD744EE18ECE778FE5B64953D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD90464A88AC5345684878B759BE38D999BF",
                        "defaultText": "“우연”의 가치를 믿다니 꽤 흥미로운 분이군요."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F9A5BB100E14454BC878B6B47DA021D5E53B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "35C2DB300A27E34F733B5731DF99320C1AF3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1747E6969BC8A34C2B699EB754DEAB9DE8A8",
                        "defaultText": "멋진 옷이네요. 어디서 구했어요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "48A484D825BB9646EE390E91514E97B483B4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E54B91898DF1784B384B8F485C086FC9F508",
                        "defaultText": "우리 전에 만난 적 있나요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6A4C583746F57643CE9A0F873B663AB6DC77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "sarcasm",
                            "normal",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F3E3D059AD0A74C271AAFE53CAD15CF4D1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "537A48451965754A870A5CC91550D9AFF5BB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sarcasm"
                },
                "indent": 0,
                "uid": "A41232626E23674CF869F81574E7BAC4F882"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "776F4B3220BFB346844BF234E109B14048D5"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5EC2DDE790F0684C153B43D0B908B294A244"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "870D9C7B2AA3B6474F697EC8AB1F9971899C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 65,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E128C89343DB74B8A48B1778F8692D725C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A619E011F760148490B9C07CB74D41E4357",
                        "defaultText": "당신의 유머 감각은 희망의 등불이 될지도 모릅니다.\n그 또한 단순한 우연이 아니겠지요."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B0C8BAA412048849DC8844D842BAB1A07B3E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5F37EB4655C8C7468B1AB7350F38425F6C12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            3,
                            1,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A4274CF318ED284DD64835814704E0A8D3A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DDA37B8D3EB9954B5378E4701F59D63511E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "064EAF185A4872423848E6935E8718EB9C33",
                        "defaultText": "무슨 말인지는 모르겠지만 칭찬처럼 들렸어. 헤헤."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "084C6146212730411548F2F2B094D3FB2768",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "4362ACA28F808340424B5DA830BA976BFF33"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "either?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5760754A6528F84B655884B99CAB763B5E75"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98E0E5639430C24A04188DD77DC6FD642547",
                        "defaultText": "왜 묻는 거야? 미드바르 서커스단에 들어갈 생각 있나?\n아주 잘 어울리겠는데."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5190CD022E9277437538932947744BFBF064",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BC22B00A266573421C7B8EE1970AEA91A8E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            1,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4F34FA217C8A364E1A4B0F63BD43764EEA62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4A97B1C382FB344E766A0A546E25A3F65202"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DEE489F472B51842B7487D93A16996453AFE",
                        "defaultText": "완전히 역효과였네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D23A438C5B07A74E9E2B15C1DBBB133198A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "870951E90351844BFD38A53608F1532BB7A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33356BDA2C00A445C85AC46478445DADE322"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13A3FF155B8B104B2929EB763E6604F7B9CA",
                        "defaultText": "그런데 왜 계속 “우연” 이야기를 하는 거지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B81A62AE7447844A8A5BE342BDB5D8D9BE31",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "134083CE7F6B83490559F3F008245F34890E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D20E4B924DB454E591B7384B6FB052CA1A0"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "92258DE711B7F14365397253B8B04E96123F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "normal"
                },
                "indent": 0,
                "uid": "59499A8A4F89D343204BC3D45798A34270B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77D5F2E01BC4674D1E69E9D3B931BB6A0472"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60E5F8EB389AF34D617BCAC37DDAA709D254",
                        "defaultText": "당신을 본 기억은 없습니다. 만난 사람은 보통 기억하는데.\n하지만..."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD5DAB4C86AFD34B8D5B31D3F5A8361543BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36B04BD96C63D24A4A188370B4771B67B5B0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "DDAEA60B4097074ED3793D4274FCB50220DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "472DE2B65BA7F04CD5081937BB01D9723ABE",
                        "defaultText": "전에 만난 적이 있는 것 같은 느낌이 들어요..."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "98EC16A489D6F247883806D13A44CA7F22E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D444D32874BD444B8B494E7595697C95985C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD29501E413CC1435B899085A369E85995C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DAFCB365D6F594B9E88D2337B9D1602FAF4",
                        "defaultText": "흠흠!!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E064E574417A374AA64BE0F453EE0C0C7147",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF6F60E08570344E111AAAE29AC4A6AC5E86"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1403C5968C034547CD88E7362EBC7A62A24C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "828CB6A44E34C740B668C2E2E9388C248DA8",
                        "defaultText": "아, 제 무례를 용서하십시오.\n이런 일로 귀찮게 할 생각은 없었습니다."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4CFB155C5594E448884BE9D312F227D4F53D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FAC68BF6B41D8497F4AA771E855E01E7E5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FFA723C7A554742A8685EC3E57918199E60",
                        "defaultText": "그저 지나가던 길이었습니다. 그럼 실례하겠습니다."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "193ACBD43114954AF75BF1326E208E3E375F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C1F6DF02797924DE20B02D61D8AE50AEA1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "38710C017CBF614B986B9A129A05A23FA44C"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1450,
                        "y": 576,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 14.399999999999999,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "894F558E5352E244203ADC210998FA61F145"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 0,
                "uid": "A21AA48C4E62E940BA5AD8C6072061B2DEAA",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB66474C802908481E3B415892E8B156F5AE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "DC74332787557744D129ADC8419B569A1C61"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Door_WoodImpact.ogg",
                        "volume": 100,
                        "playbackRate": "105"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A88D5D6B8BC2E64EC148DBA8BDCCB5584657"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 87
                },
                "indent": 0,
                "uid": "64069AA92D4A784E143B9C55996113ED9CFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "97743A035EE7D14DC52943F03C3AA43EE1C5"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C36C95064E63994A5A08B146AC59DAE776EE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen"
                },
                "indent": 0,
                "uid": "76591D607C75734B5C797111D2732789BF86",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA11DE6A8874F0484738DB85384BF03752F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6562125079DC434317381725D82717663E3B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "either?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "03601E9C8A3CC74AF569CEB823E729FDC686"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "141A92FF72FD6347339BD020E8F52C4EF1D9",
                        "defaultText": "서커스단에도 꽤 잘 어울릴 것 같아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DEC896D173AD074E2A8868D688B8BB6F922B",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "CCB0905A668D7143531993503EA59D8D8238"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C25BE033FDA034F344BC7F4B7E95F5C35F2",
                        "defaultText": "저 사람도 서커스단에 꽤 잘 어울리겠군."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E0258D2E9725F546541954B44AD056B5062F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F01259B3F5508459638BF175EC8E3F51DAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCA6EDDC29E9F74D453B5217E443E2AA4477"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C23BAB1B4864F644806AE9E7B8EC75FA7656"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AB7018276A4A774DF55A1B2687B82A3A5AAE",
                        "defaultText": "동의해."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C793EA2F99CBA947733A9EA08560EED18EF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0762682192EC34EAA49BF83F22511D46087"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4ECBB56C08E2704C96488148FAFEB96B4CB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "60B7BFAC44F42447D628AE52029FD047E4A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E98D5F7852D3684E69196F91498524525500",
                        "defaultText": "이봐, 젊은이."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A4B699061F3DB144E348E8C9517B98520189",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E17E3F7271EFF649F668A4E33B819597F2BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D931383E88E7A84233898B6462415F66AB5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5CB570681EDB14C370A02C52A638CEC6FEC",
                        "defaultText": "네, 저요?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "120CA23A75D4714AC4284237F643CB813F99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E5C5DC5628DD54F862954A7940909A3710B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C8D5BAD2C27C14BA62BCB36E8B513CEF61A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E8523D95E74B04E192B9684DB5509B0253F",
                        "defaultText": "여기 바싹 말린 낙타 육포 같은 얼굴을 한\n젊은이가 또 있나? 내 말은!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFA56A105C2FD643B6794FF6048EE23B41C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3162A19115786409B19ECD22C0D82067ED7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37625C4A77DBF743C84B6A17C379B703816A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37BC4E489798224D5F9A3D6356A6DEC456D0",
                        "defaultText": "노인에게 알레르기가 생길 것 같아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "348869474899E2438B791A22073CFB94B136",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8F68CB04F2AA549555AA5C315F05A269588"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FD3162F52154840FE0B8E73976D5E635B3C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "skip 1"
                },
                "indent": 0,
                "uid": "72E342F5246CD242F5382FC1B7211619585F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "432EF579493F0448B68ABB44A2BABE0911D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "063352443F9D3849556A3D75737BFC019321",
                        "defaultText": "자네 얼굴을 보니... 옛 친구가 생각나는군."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4EADD0527EF70740725BDD45A39FE9E70901",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF71A05E6B1718473A5B8F41D478BD55559C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02024DAE6E9CD84E93789277DBD92AEFD6DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21DA0C2A47123549C16B2963064224289FEC",
                        "defaultText": "...친구요?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F59064165555F749F80876B147A2393BAA4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EB0534F2F28B64013593387401575E336BC"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A49532E768F6824AFC7A9195C1EF6027CFA3"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "skip 2",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "0143034511FCE14D5A196E83417409428D2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDE7B25E7DCC064A50782E9924CF0D782499"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "0B25827F3F9894474E4A64067F02BCD39692"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FAB7F0F9D45254DF70B150561E0EF982C60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8954FDDA5AE8C6443C181DD1B36627119BC9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E6D28F2A4EFF6741C08A88B71FA66ED84CA1",
                        "defaultText": "이분이 친구마다 “바싹 말린 낙타 육포”라고 부른다면\n우리와 잘 맞을 것 같아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE05A0757C4AE345E52B84B7487C169C64A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7956F39435C533403A7A7423F4FDC536B7A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10B2938F55D74548D88B05E4102F8DEC67B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6EC7BD52A14994A095A2C62634230781523",
                        "defaultText": "봐, 이 아가씨는 알아듣잖나. 자네보다 훨씬 똑똑해."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A73FA5748C0924C7D388AC196070E847986",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F78FBFE80B865643EC799D966CA888066C00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08400846732EA744F2494CE26AFEEB209279"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F512C73756E7574D7A1832B55EC5718537FF",
                        "defaultText": "좀 봐줘요..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C58F65AB68FAE4467F7B20016469F85FA5F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "473D9CC197220649B18B7EB4C5CB45B7D1D8"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "skip 2"
                },
                "indent": 0,
                "uid": "CA2C2CC85D16E24F2F7A572764D5D43BBB10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B7C69198DC5994DFF9B02E6D8DE4FAFD786"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "102E8F8179D18847DF2A2DD82AEF3B9177AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "160B0D5C825CF847E049C3548ED7AB5D9991",
                        "defaultText": "그 친구... 이름이 뭐였더라? 너무 오래됐어.\n아마 {SP:2}{C:1}60년{C:0}쯤 전이었을걸."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE01F46773A74342248BAA91DFD4CF75C576",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DD823262AD1354EC868BF56142B55E15449"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F45EFDDC760DC640145AD73577E8B4C501B1",
                        "defaultText": "하지만 자네와 눈이 똑같았어.\n미드바르인이 녹색 눈을 가진 건 드문 일이지."
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DD077F6F173FE647599BBCD5CFA486B6C316",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "36F883C95DC05545122B203724227F8D578F"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "skip 3",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "19C1F31840C7924AA34B9B41D8E7E2D07E35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6A9ABA37FC3D241C59ACBC3C5309B972638"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5FCE21B56A617430789405251F6985F823D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A39C7E213FDE34C3E28B58706996FCDBF10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8C21BCA0E4101456D780E61DB016DEEBE5C",
                        "defaultText": "이봐요, 난 미드바르인도 아닌데... 아마도."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "93292F944EEDD54877981502B5A2C9C75AFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B1EB05E3890D744723B827327D0746A8298"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "834554343BC9664B252AB2E30A241250E208"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B962A9F44A3B24453A5B5EA5AEB49A7A3EC3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "45171DD95DC8F64670890C372D0B65490C0A",
                        "defaultText": "나를 늙은 바보로 아는 건가!? 훠이, 훠이!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79E97C8C189F9945232B9970C655AEF9C22C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B867B0E330570445359D751AE935056E6E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E6525D6E8E4DF748E95A9CC3C8B3C7B760B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line5_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3866908934779045519A1EF5226898AC6975",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8EC96FBD65D43748A36A03F49AEE6C64417B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE47FE2F600E9646002B03C28E37509F969F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CADF89D24E68D24065795265C81CB7B8EBA1",
                        "defaultText": "아야!! 또 이러네!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "57741DD37000784BB34A03840DAED499D671",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DB5E89F3879044AA5787DE13C1967D6ED8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8C1FA90C8DED27407769A878D381E2B6DA9D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A09BDB238E6C54D2048B5D87257B107BEAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7E5C0961099F14EB42A9133C0EA39161E79",
                        "defaultText": "오래전 내 가장 친한 친구를 쫓아냈듯 자네도 쫓아내 주마!\n훠이, 겁쟁이야!"
                    },
                    "position": 0,
                    "characterId": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DA2820052BB22450D48E0F21C4CA0A82E94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B34B49C55EA4424509989670024871D22379"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA88400B3F2652446B494AD533AA29CAF6D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E830D01E529295443A8B0E9392C9C0BC0169",
                        "defaultText": "알겠어요! 알겠다고요!!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FC86F46D7F7598469D187A3673AB577569A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "715310696752D740450B6FA2A4377F2786CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "528EF78B117D384087796329BC47ADDA5096"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            801,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F5839B21BC5614D0B1B7ED28562859E262B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            10,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6637912F8991814FDD491FF3DB7A80446DE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8A6847D50C5F241ED8A4E730E22E20CEBBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "086191649EC417456B590E08E107F5F82C16"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            13,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21C7999910AF7945D468BEA4AC682443132E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1D7E71E4EF1B2436F1A1FF441C1CC6832C8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "F010EE31337D044D014AB5593FA53BE6F6B9"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\n\nRya is the main character"
                },
                "indent": 0,
                "uid": "BA52F96D9880A545C449A70655E0A89B76D2",
                "expanded": true
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BF56A02836AF3741968BC3523740A1CC1F86"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2730CFEF4A445547B9594506317C9D8B080B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EED192C25F4B743666A48283678349D1684"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5B490A17C7CF64463598477980E10C3DFE5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9F3958A6978F7425559D1787EA171780C55",
                        "defaultText": "그나저나... 그게 무슨 소리지? 내가 미드바르인이라고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "821D2719480128453D8AB022D3A915123B7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69D3AEA824F8C04C9488915806B82F76EB3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC814599746B05416F999B0603FA69794321"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EBC6AE984FE54740D9280648E1EDCABC337F",
                        "defaultText": "넌 분명 미드바르인이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3898EE7B962E7741338A86B5E2BEEFCBD896",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9B6F07534A9734F042AC8246D07317A211B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C3703777E1921460C48357485BAC60EEAD5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C08245067A8F3345754B1057AAB6F08B893D",
                        "defaultText": "뭐? 어떻게 그렇게 확신해?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0AB8AD6D620CA64AA518553460161CDE787A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1E3F3E755B57245862A865613D50FED14D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "128397C21494A34B679AE964BAF23C29820B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8055FA58859CF4441D19FC91ADCAAC081981"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F153EAF941737541214922F574717293DBE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF1355553C5A334FEB7934B4CA647050C1C5",
                        "defaultText": "불친절한 빈정거림처럼 들리길 바라진 않지만...\n피부색이 네 혈통을 드러내고 있어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B309FA567737F141DB794589867573CD83D6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B251653F9816954C9C6A18A895F346E9DECC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1496DD43FAC97440B79B9769852143AE353"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5D321FD6F84D14DA12B34504BE362C8484C",
                        "defaultText": "아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13C3E7984416D84B3D184EC8B701E772353D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2797A0DC96C9484F245BA7A3BF858485E963"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            11,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B49B8DD1C6A6744C34816337EDE47A38EBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FA355BD3300B54CC31BC9765EC054256BA9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "471409E13EC0D14C439BA7E487FFC579DA5E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E24E861B61A45844780AAB31599674D9E154",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6024E7B38314884A173805C1AC84FB761BEE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CEBEFDE300B9843E03B0E44BA0689990422"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8AA0A996DD9924E9C7A45A38EBA7F920B5E",
                        "defaultText": "정체성을 찾는 사람치고는 자기 성찰이 부족하네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7C26F2DD92A81945C23AA97443AC62AC6AB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14384AC6198C744B3D1B5064D781E44EB0CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33BD5A7C79E8834AD34BAF593372E585EC53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69CFC4476434824D1B3B2F028A05FDDD31E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34FF1B8E83991644756873D5D838028A874C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FCF1D75199E55642D28942D6891F9E401613",
                        "defaultText": "저 말이 맞아. 그리고 마음이 좀 편해진다면 말해 줄게.\n나도 네가 미드바르인이라고 확신해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "990696108C434749084BB533B811A35BB554",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DFCA6CF2E152843D5483A9202FB323E4B37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33EDACD87BFD474A7B69B842188E1051467D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4DC7C1A22E631543A5787025D8E8B399385F",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "35F3B24A4B2E3445703B557742229BF7D59E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A50C45B17741141CE0BDA884C8B5E38636A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43F581BB81C397426D68058724D6FB0D2F46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAF8830C7F7BF5453B6AB2480742420E6D58"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C28933719672164B8439108115BD8B373EFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D02C01289BEE148904ADFB1DC06352E5656",
                        "defaultText": "이제 그만 붙잡고 있자. 이 주변에는 더 많이 아는 사람이\n있을지도 몰라... 아까 그 남자처럼."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7FC983502D785440D9693BF98F168D0DB662",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "skip 3"
                },
                "indent": 0,
                "uid": "65B50B628D02C44E8D5AEC47CDB87C042B0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "087C3D1272260247F94BD966F395417F79CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA568DDE482F1443246ADE447FEC643046FA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "431F4BD91CCFA647BC2B1773F89DC1A540C1"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "r",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2A6D8B2684B7324C886AA714977BE1E36A03"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "733183CD487F224AAC89F035FCAE5DD8EF2C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "C5DBB6C7549AB8464C6940F8CE4199A334C1"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "39A751C03E845641F5585D9384B7E664FD31"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "9C5E72C81A1D7742292963111D0A18F6582F"
            }
        ],
        "localizableStrings": {
            "98599F8496019643573B5DE50EEBC23A3D74": {
                "t": "Greetings, sir. Do you have five minutes?",
                "d": {
                    "cid": 0,
                    "eid": "BA0BFE3E38B0B44B66686A43AB2A831A6180"
                }
            },
            "43A03ADF3E08924BAE187B126A2BA488A490": {
                "t": "Hmmmm...",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "029B800577201645FF1B54B70C5D76BBB223"
                }
            },
            "423A637342045646EF4ACBA0BD7D21044E7A": {
                "t": "We are conducting an investigation to verify the presence of demonic forces in the vicinity.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "55C47652752C284B077BA3C915484410CA04"
                }
            },
            "B49064EE7C6C6249B39B86E42D4B07BEC098": {
                "t": "\"Demonic forces,\" you say?",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "9BFD5938118321443059AE78F84FD2A4CBD7"
                }
            },
            "18E6428C5A3FB040916A47B70F5CB0D728E0": {
                "t": "The desert dunes are constantly shifting, the oases are drying up. Nature seems to have gone mad!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "E8A60D048E6A384C2F5BD32758D05C755E53"
                }
            },
            "7BAE5F9F6F70824A1A19EB2709CDCE4DD04B": {
                "t": "Ouch! Ouch! I understand...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "6A2A1A7E0202A246A06AAF26E1CFC3C11054"
                }
            },
            "CF7B7B8147DC824C5A298B49841D121B9100": {
                "t": "Also, that cursed fog... yes, the Mana Scourge!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "C3CA882279ADA84E8A385F121DA828BD08F6"
                }
            },
            "10BC60CD7DF9E74BE14823D163909B807CE3": {
                "t": "It seems to have disappeared for some reason, but the remnants of that calamity are still here! Our lands have been crawling with monsters ever since!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "465F2D9A26AEC442574B3779455526F5316B"
                }
            },
            "DC71055E37E626409D692F71758ADD677F5E": {
                "t": "Ever since it has returned, our lands are crawling with monsters!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "B3EE0ADB555E7848055836E3CC247E0F755C"
                }
            },
            "1618F38D10867449955960436BB7BAADBD03": {
                "t": "What the heck is the Vassal up to? Isn't it her job to prevent these calamities?",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "3C7533542D4A41403379AD79BD93356D71BA"
                }
            },
            "EFA8838C378FE0468F8B10D7340A142A608D": {
                "t": "Ouch! Indeed... I wonder that too--",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C92809BE9F5D25447D48B8E3917370542BCB"
                }
            },
            "00CC5B832944C0488D3B2E53D2AF6E26C8B2": {
                "t": "Ouch!!!",
                "d": {
                    "cid": 0,
                    "eid": "0BD80E584976F14F1A19DDA50C901D675706"
                }
            },
            "A3F3ED1130862141FA4AC0B3054300CF63C9": {
                "t": "Could you please refrain from elbowing me when I'm already being clubbed, Lady Faratras?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8B63AFCD64FE9645152AC3E48DB42CA0BC06"
                }
            },
            "07B07B7D9EE08341AA3AD1D6AC0556E2112D": {
                "t": "And why does this scene give me a sense of deja vu?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "09979C4E9771A2469E4BECE8A76712173455"
                }
            },
            "C842597D5879854552284728EED87DC5714C": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4872882F19A3A749FD28D8E247CC7671FA8D"
                }
            },
            "EEA4BB977888E4426C990253E8502FE26EEB": {
                "t": "I'm sorry. The Vassal's incompetence certainly led to this situation, there's no denying it.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "4430A97C40BA284D227A89E51B2EEAAC0B86"
                }
            },
            "771F03755049074730597688DFCD93ADBEED": {
                "t": "However, we're here to--",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "078AB8F351A53149E1096C44B3F354495354"
                }
            },
            "01DBDA415BB30840882826B27DA753F17E47": {
                "t": "Who's there, now!?",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "546582A37061554A973B9A169766FC7BA1C1"
                }
            },
            "8FAFC33E4F33C2479C5B2874429BB6B7945A": {
                "t": "Pardon the intrusion...",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "AB888C781AA6974BA88A9A15925FE676EA45"
                }
            },
            "75BF1E007CA0874258199568D7C6484BCF17": {
                "t": "I am conducting an investigation regarding the phenomenon of the shifting dunes. Do you have any information on the matter?",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "DC46027E0930B5433538E9848AD265D8574C"
                }
            },
            "D896B66F5EAAC640C149E17274FEFE17953E": {
                "t": "Can you please tell me what is wrong with everyone these days!? I just wanted to enjoy my morning nap!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "0569BF7B144F834CF45835164EF288467CBE"
                }
            },
            "EEB8DAE124BC354EED6BCE595834DC99D13B": {
                "t": "No. Okay!? I don't know anything!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "54F7A4A228A4524AD81BE1789816C60253DC"
                }
            },
            "B220E72876BA4943A01A2B35DA25DFB9F291": {
                "t": "Another person interested in demonic influences? What a coincidence...",
                "d": {
                    "cid": 0,
                    "eid": "0A550315310B914E5F3824F5D08712230693"
                }
            },
            "FD90464A88AC5345684878B759BE38D999BF": {
                "t": "You are a rather interesting one, to believe in the value of \"coincidences\".",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "F9A5BB100E14454BC878B6B47DA021D5E53B"
                }
            },
            "1747E6969BC8A34C2B699EB754DEAB9DE8A8": {
                "t": "Great costume, where did you get it?",
                "d": {
                    "eid": "48A484D825BB9646EE390E91514E97B483B4"
                }
            },
            "E54B91898DF1784B384B8F485C086FC9F508": {
                "t": "Have we met before?",
                "d": {
                    "eid": "6A4C583746F57643CE9A0F873B663AB6DC77"
                }
            },
            "98E0E5639430C24A04188DD77DC6FD642547": {
                "t": "Why are you asking? Any interest in joining the Midbar Circus? You'd fit right in.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "5190CD022E9277437538932947744BFBF064"
                }
            },
            "DEE489F472B51842B7487D93A16996453AFE": {
                "t": "That sure backfired...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D23A438C5B07A74E9E2B15C1DBBB133198A2"
                }
            },
            "13A3FF155B8B104B2929EB763E6604F7B9CA": {
                "t": "Why all the talk about \"coincidences\", though?",
                "d": {
                    "cid": 0,
                    "eid": "B81A62AE7447844A8A5BE342BDB5D8D9BE31"
                }
            },
            "60E5F8EB389AF34D617BCAC37DDAA709D254": {
                "t": "I don't remember ever seeing you. And I usually remember everyone I meet. However...",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "CD5DAB4C86AFD34B8D5B31D3F5A8361543BB"
                }
            },
            "472DE2B65BA7F04CD5081937BB01D9723ABE": {
                "t": "I FEEL like we've met before...",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "98EC16A489D6F247883806D13A44CA7F22E0"
                }
            },
            "8DAFCB365D6F594B9E88D2337B9D1602FAF4": {
                "t": "Ahem!!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "E064E574417A374AA64BE0F453EE0C0C7147"
                }
            },
            "828CB6A44E34C740B668C2E2E9388C248DA8": {
                "t": "Ah, forgive my poor manners. I had no intention of bothering you with these matters.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "4CFB155C5594E448884BE9D312F227D4F53D"
                }
            },
            "4FFA723C7A554742A8685EC3E57918199E60": {
                "t": "I was just passing by. If you'll excuse me.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "193ACBD43114954AF75BF1326E208E3E375F"
                }
            },
            "141A92FF72FD6347339BD020E8F52C4EF1D9": {
                "t": "He wouldn't be such a bad fit at the circus.",
                "d": {
                    "cid": 0,
                    "eid": "DEC896D173AD074E2A8868D688B8BB6F922B"
                }
            },
            "AB7018276A4A774DF55A1B2687B82A3A5AAE": {
                "t": "I must agree.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "C793EA2F99CBA947733A9EA08560EED18EF3"
                }
            },
            "E98D5F7852D3684E69196F91498524525500": {
                "t": "Hey, young'un.",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "A4B699061F3DB144E348E8C9517B98520189"
                }
            },
            "C5CB570681EDB14C370A02C52A638CEC6FEC": {
                "t": "Huh, me?",
                "d": {
                    "cid": 0,
                    "eid": "120CA23A75D4714AC4284237F643CB813F99"
                }
            },
            "6E8523D95E74B04E192B9684DB5509B0253F": {
                "t": "Do you see any other young men with a face like a dry aged camel stick around here? I mean!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "EFA56A105C2FD643B6794FF6048EE23B41C4"
                }
            },
            "37BC4E489798224D5F9A3D6356A6DEC456D0": {
                "t": "I think I'm getting allergic to old men...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "348869474899E2438B791A22073CFB94B136"
                }
            },
            "063352443F9D3849556A3D75737BFC019321": {
                "t": "That face of yours... reminds me of an old friend of mine.",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "4EADD0527EF70740725BDD45A39FE9E70901"
                }
            },
            "21DA0C2A47123549C16B2963064224289FEC": {
                "t": "... A friend?",
                "d": {
                    "cid": 0,
                    "eid": "F59064165555F749F80876B147A2393BAA4A"
                }
            },
            "E6D28F2A4EFF6741C08A88B71FA66ED84CA1": {
                "t": "If this gentleman calls every friend of his a \"dry aged camel stick\", I think we're going to get along.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "EE05A0757C4AE345E52B84B7487C169C64A3"
                }
            },
            "C6EC7BD52A14994A095A2C62634230781523": {
                "t": "See, this lady gets it. She's a lot smarter than you'll ever be.",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "9A73FA5748C0924C7D388AC196070E847986"
                }
            },
            "F512C73756E7574D7A1832B55EC5718537FF": {
                "t": "Give me a break...",
                "d": {
                    "cid": 0,
                    "eid": "C58F65AB68FAE4467F7B20016469F85FA5F0"
                }
            },
            "160B0D5C825CF847E049C3548ED7AB5D9991": {
                "t": "That friend... What was his name again? It's been so, so long.\nAround {SP:2}{C:1}sixty years{C:0}, perhaps.",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "EE01F46773A74342248BAA91DFD4CF75C576"
                }
            },
            "F45EFDDC760DC640145AD73577E8B4C501B1": {
                "t": "But he had the same eyes as you. It's rare for Midbarnese to have green eyes.",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "DD077F6F173FE647599BBCD5CFA486B6C316"
                }
            },
            "A8C21BCA0E4101456D780E61DB016DEEBE5C": {
                "t": "Hey, I'm not even Midbarnese... I think.",
                "d": {
                    "cid": 0,
                    "eid": "93292F944EEDD54877981502B5A2C9C75AFF"
                }
            },
            "45171DD95DC8F64670890C372D0B65490C0A": {
                "t": "You take me for an old fool!? Shoo, shoo!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "79E97C8C189F9945232B9970C655AEF9C22C"
                }
            },
            "F7E5C0961099F14EB42A9133C0EA39161E79": {
                "t": "I'll chase you away just like I chased away my best friend long ago! Shoo, pusillanimous!",
                "d": {
                    "cid": "8C1FA90C8DED27407769A878D381E2B6DA9D",
                    "eid": "9DA2820052BB22450D48E0F21C4CA0A82E94"
                }
            },
            "E830D01E529295443A8B0E9392C9C0BC0169": {
                "t": "I get it! I get it!!!",
                "d": {
                    "cid": 0,
                    "eid": "FC86F46D7F7598469D187A3673AB577569A8"
                }
            },
            "F9F3958A6978F7425559D1787EA171780C55": {
                "t": "Seriously now... what was that about? Me, a Midbarnese?",
                "d": {
                    "cid": 0,
                    "eid": "821D2719480128453D8AB022D3A915123B7B"
                }
            },
            "EBC6AE984FE54740D9280648E1EDCABC337F": {
                "t": "You definitely are one.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "3898EE7B962E7741338A86B5E2BEEFCBD896"
                }
            },
            "C08245067A8F3345754B1057AAB6F08B893D": {
                "t": "What? How can you be so sure?",
                "d": {
                    "cid": 0,
                    "eid": "0AB8AD6D620CA64AA518553460161CDE787A"
                }
            },
            "CF1355553C5A334FEB7934B4CA647050C1C5": {
                "t": "I don't want this to sound like an unkind innuendo, but... the color of your skin betrays your blood.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B309FA567737F141DB794589867573CD83D6"
                }
            },
            "D5D321FD6F84D14DA12B34504BE362C8484C": {
                "t": "Ah.",
                "d": {
                    "cid": 0,
                    "eid": "13C3E7984416D84B3D184EC8B701E772353D"
                }
            },
            "C8AA0A996DD9924E9C7A45A38EBA7F920B5E": {
                "t": "For someone searching for their identity, you aren't very self-reflective, you know?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7C26F2DD92A81945C23AA97443AC62AC6AB3"
                }
            },
            "FCF1D75199E55642D28942D6891F9E401613": {
                "t": "She's right. And well, I'm sure of your Midbarnese origins too, if that makes you feel better.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "990696108C434749084BB533B811A35BB554"
                }
            },
            "7D02C01289BEE148904ADFB1DC06352E5656": {
                "t": "Now, let's not indulge any further. Perhaps there are more informed people around here... like that man from before.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7FC983502D785440D9693BF98F168D0DB662"
                }
            },
            "A3262F3448140745CF7B34B96849D9FA3186": {
                "t": "Hmph!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "8F34B21A2763A4435D0B36C5123D4CBC88BE"
                }
            },
            "CADF89D24E68D24065795265C81CB7B8EBA1": {
                "t": "OUCH!! Not again!",
                "d": {
                    "cid": 0,
                    "eid": "57741DD37000784BB34A03840DAED499D671"
                }
            },
            "4DC7C1A22E631543A5787025D8E8B399385F": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "35F3B24A4B2E3445703B557742229BF7D59E"
                }
            },
            "BEF6F27C11391743A2881DE13DBE2C766C0A": {
                "t": "???",
                "d": {
                    "eid": "7606632F7B35294638688BE57B1326143138"
                }
            },
            "6A619E011F760148490B9C07CB74D41E4357": {
                "t": "Your sense of humor may become a beacon of hope. That, too, is no mere coincidence.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "B0C8BAA412048849DC8844D842BAB1A07B3E"
                }
            },
            "064EAF185A4872423848E6935E8718EB9C33": {
                "t": "I have no idea what he's talking about, but that sounded like a compliment. Hehe.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "084C6146212730411548F2F2B094D3FB2768"
                }
            },
            "5C25BE033FDA034F344BC7F4B7E95F5C35F2": {
                "t": "He wouldn't be such a bad fit at the circus either.",
                "d": {
                    "cid": 0,
                    "eid": "E0258D2E9725F546541954B44AD056B5062F"
                }
            }
        },
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "sarc",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "either?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "r",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}