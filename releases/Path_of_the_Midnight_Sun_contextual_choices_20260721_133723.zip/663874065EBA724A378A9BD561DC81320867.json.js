GS.dataCache['663874065EBA724A378A9BD561DC81320867'] = {
    "uid": "663874065EBA724A378A9BD561DC81320867",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C9-02 (Talk) Hellios",
        "type": "vn.scene",
        "parentId": "C018A55C22E45843DC795711AF6DC121CB71",
        "chapterUid": "B73FC0E12D36244CA65A5C38B3C3733E5786",
        "order": 5,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "F4B1E2F28A6C724D695B85F873471EA6F221"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB1578326D9D25445C1B5C3303D4732F5131"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            750,
                            0,
                            4998,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E89657D808C5343CF59E733871D38994B4E"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -20,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "481A4EC1817B114C7B59C1E782D4337F8A36"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 75
                },
                "indent": 0,
                "uid": "CFC5304C6C5C2649CF39CDE6D3ED40D07702"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E6005CD28858148C7481DC6D74AD92846E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EA0151060E20347B81B8BA523B484B4634E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E9C9BB72929E38468D193AD5243624450E29",
                        "defaultText": "생각에 잠긴 것 같구나, 파라트라스."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2F2B1B4D976D71450229F3133DA01BEA56AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B9DAD196A11F84A2359EED453F5006F9B56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "171BF7F884F0F94C4F38B2445B903B8E3D60"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "16A1E328731C9742E6780D59632E7800E6F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3C48CE79B41084F2E89DC53900742274588"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "540938DC8CC5344ECF2B8813820BCB8D7A88",
                        "defaultText": "아... 오빠였구나."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BCFAC1CF62730847F15A08C78B35FC3677BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "931C8B9F6BB16843274ADF33B46E47DF8FEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C5FC3D93D47B048334A85574E7ED31C3724"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC5D33187759404AED1A10307A05F78E6A93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5B09C133141BC74A5F88C364BC470026BDEE",
                        "defaultText": "평소에는 내 천막 앞을 서성이지 않잖니.\n무슨 걱정이라도 있니?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "223855B1106EC848429A0DB455849952D1F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BDD010B0F32284B1289B9C63034F85DEFDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07D5943B4619C84FAA5A07354E2189C237CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C20D6B731E24764DBE79A912C4747A68E9F4",
                        "defaultText": "사실 앞으로 무슨 일이 일어날지 생각하고 있었어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB1DB6628B19414A20689F78EBD117341108",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "048D03B54250E44ECD58ECB7E5FFD9FBC2DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E18E54F27E72C74AFC7AEFE8CB1989289DA1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA84E5238AFAF641A5198F032AF00D9F86C2",
                        "defaultText": "네 봉인을 복구한 뒤를 말하는 거니?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A76E41A50C07764F291AA32021976D86CDA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC5A34267D8D26442B4A1127585D3946036A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5049D4D43A6C374A817952D09EFF06DE297D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE8F52E8190F2744518A6AD6CF9C4846C16B",
                        "defaultText": "응, 맞아. 봉인이 멀쩡하고 내가 지배당하지 않았다는 걸\n증명하면 호이카데로 돌아가겠지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C717BE3A3CC5B14E6738403473A8242743D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55D6EA6667EEA344050A52469511EB0AEF61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79A4C6E19CF8444CDD38C550EFFA435F3786"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A1BA73E59831844D45806B0CF7889E99E61",
                        "defaultText": "이번에는 어머니가 내 말을 믿어 주셨으면 좋겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B92FB10C09D3F6461F99AE03B7E79DFCC6F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5430DAF275565946D60A9022041034474F5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF7615793837F8477168EE29C20FE6E24F0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2783FE6831251444906AE6259DEF6D4500C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1BF34C411F87343B07A4F980886DA4E7A5B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5171591397584041E3583507938DE06DF49A",
                        "defaultText": "적어도 사이 사령관이 함께 있다는 건\n호이카데의 의도가 선하다는 징조겠지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C82C4DD47F69D4450C7B0964A25006A8CA43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0A9CC1783D1E84C68592E65B556612D238E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "415485A79C33454FF80B1F3667E7C917C8FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C06D82743882474D2F58F75175793D7FB068",
                        "defaultText": "응. 그리고 결정적인 순간에 오빠가 곁에 있을 거라 생각하면...\n용기가 난다는 건 인정해야겠어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "05DD76433698484F6E1939C570808A28D2C9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84E7D3DF3928324C2A1B6B89EEAECB573C61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A19BDD2D9E32964E0849F3B3F48AE7439071"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEA99F04336D544DAD881494CE29A1ACD2D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FDCE59172A95845957BA79861B925B84C3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "094F216696BAD04AA78939574EC83A92C81A",
                        "defaultText": "정말? 어째서지?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B83E35F9873F74AAB3B1B099B641F376626",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87E00BDB2E603349E17B7FA87921F819963C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E83EBEBF3887F64F47694E76877229DC1621"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "478554B552FF464A28688E3644FB0FC809DB",
                        "defaultText": "헬리오스는 만난 뒤로 늘 나를 위해 싸워 줬어...\n수없이 내 목숨을 구해 줬고."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "020C1F5E6D70E044DC6A6E72A35A82A5803E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "314A5B3F5669C245357B72471C515AB9B0C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA3029A5838F434F678AAA626DF759EBD83C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "676879144FBE50487059802412B4CD4B23B0",
                        "defaultText": "나는 버림받은 사람처럼 홀로 도망쳤어. 하지만 돌아갈 때는\n친구들과... 있는 줄도 몰랐던 오빠가 함께할 거야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BB2A3A243D67134EC62863C318027D9C9AFB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "334C05343505E740E9787432131E9CB19339"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A531A6543B9694623883009D6E4CF11ECAA",
                        "defaultText": "내게는 그것만으로도 이야기할 만한 승리야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "19419EC956420147847B1F725CC2EA831A43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B386EFD57F2716432D181FE042D80130AEF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0187789D708643C32A5BC9B0C970747932"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C084A3E420B9714BBA0A1A042F2E94A246DE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A380D8CB071D56477A281B5738EA6FE946DC",
                        "defaultText": "참... 묘하구나. 나는 늘 너를 내 세상의 중심으로 여겼고,\n네가 태어난 순간부터 줄곧 너를 알고 있었어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E39D446C8CDEF1427D7881D5131AB1377078",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "435AFA1D58770149480B14D4808D89FFF401"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD991AB19A9A344EBA586C98CA880C1D48B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E39F27605BC31149296BD9338309D9733112",
                        "defaultText": "하지만... 네게 오랫동안 존재조차 알려지지 않았던 오빠가\n네 삶에서 중요한 사람이 될 수 있으리라고는 생각하지 못했어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA70A3C700A1554B6C29DC44B97FF629521A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3688C727122FC24B8279F591D42A7D65E016"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4C95F29C28D30148D068203548EDADD0526B",
                        "defaultText": "오빠도 내게 정말 소중해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8CB227B842A83145D5183906EC4CBD217B47",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "26D1A27B223BD64462293D881830B15CA00A",
                        "defaultText": "아직 너무 앞서가진 말자."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E261B88D9C8F314647499F713A06720565F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "important",
                            "stop",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA64BC2A5C19E342B28955B826529D4F8A2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2F5866128399744E933BCBA397BFA8D10FF8"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "important"
                },
                "indent": 0,
                "uid": "AFA238C485D8214E825BD4A39D180F37241D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "BDE96AC73630E54C667B47A17DFBEB438668",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            5,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF9AA701264E7344B53BAB242A895889E390"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7141022290783542E51AFF755B7027695706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B3BF42E41F2F54EFB497921E6DEC2A22544"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E92EF8A9E865243E539FA0791601AF63988",
                        "defaultText": "그 말을 들으니... 더없이 기쁘구나."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F51D58FE29059146182AF847DBF16637D65A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA2F680E810FE54F6B29E9C6BC2ADEAE712E"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "E876B0D25B4AF6403D3B3709D9968D61C06D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "stop"
                },
                "indent": 0,
                "uid": "69840C0D1225F34894195B02C29365C40835"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3497EAAC13319248AA9AF148C43126BF4708"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C328110017F6D8463928350058384EA3B0A6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E1344DE396EA14F604A1BD2B32EAB435E9B",
                        "defaultText": "아, 미안해... 파라트라스.\n내가 네 말을 잘못 이해했나 보구나."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E495EEA742FFC142587B0C22A1E7737A6086",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "333414C482C9884650692384DDBD0A0C69E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8420A5B1ED121481D6B2467205F811DF882"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A442131C18B4A44BBD38A1E478A4D80977F5",
                        "defaultText": "우리 사이에 유대가 없다는 뜻으로 말한 것도 아니야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "797B393A3D322543A7385457B63F5085CE30",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBC5DA7C611E9147A838DB121A725DFCE2F4"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "ABB6D4F4344E15486439A50362DDCB4F1C5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C709FFCF4F4B7542A34BFFD44E93041E5D32"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0EB97231A7D1743119B1558DFAABFACE3E4",
                        "defaultText": "그저... 우리 관계를 어떻게 느끼든 간에\n내가 오빠에 대해 아는 게 거의 없다는 건 사실이니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC81AF4C79FC23414B7BAB12CDBACEF0BD96",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B68187BA17E9B14B9C399F71A6EA7C380548"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D185FC6A7582744B002A54B1FBF8C2F03D99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E51E470A8C5127432968F6617B4457FD0BC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4E765778D4A9249761B1E06D6391D784441"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53A63B4495BBF54B327B2A7733CF34CF0967",
                        "defaultText": "이해해. 그렇게 느낄 이유는 충분하니 무엇이든 물어보렴.\n한동안은 이런 기회가 다시 없을지도 모르니까."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6CB3A3880400414FFA39FBD358FD515797AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12DAAEE8147D5849E7587BE83E6CB32B8052"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "355CE8460D99C34E68387A218B4D12CF34AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54346C913605864AC538573031B650AFFCDB",
                        "defaultText": "생각해 보니 봉인이 복구된 뒤에는\n오빠와 이렇게 이야기할 시간도 많지 않겠네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AA883229972D0647A71A1654911EF6C1FD42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "140BC4012D14C94B6479D51362CB30C46AB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA9C398039E3F34B342A4CA2F1867E657F0D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0DB04DE89BCC84E037841659DDF71AFCC64",
                        "defaultText": "얼마나 이어지든 이런 시간이 있다는 게 고마워. 그럼..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3425B01270FD7543B0888261F2869AA6957B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B37BEB72C5A0446553BD4A49ADC185A7985"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "This is a multi-choice. You won't be able to progress until you select all of the options."
                },
                "indent": 0,
                "uid": "967A1B6438A1F1434F38FD0706E5819A40E2",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CE9FAA9B512FD5488F0A0346CFA0AAD2EA81",
                        "defaultText": "호이카데를 어떻게 생각해?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1B2B4BF2EFC9441731B0FD6EBB8BA3F6EE3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "096E65346451514DE93832476DB13BD72F3A",
                        "defaultText": "꿈이 있어?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF782F593E3AD74DAC4B2E34F4FDF423D955",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "68EA45F64E3F5149024B84488AF05AF87626",
                        "defaultText": "사랑해 본 적 있어?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "ED81EB626DBD244D02790147B5A82CF6819D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "hoikade",
                            "dreams",
                            "in love",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD8F0AAE564EE746431B2F0658FC7106458F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "show multichoice now"
                },
                "indent": 0,
                "uid": "5162F46D1246E74F8859E547CBCCE642E455"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F4E9ECCB7A15C749373BA6F870A709D100EF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A1B3551026E8D543DC1958E59281EEC68F19"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "hoikade"
                },
                "indent": 0,
                "uid": "DB8DDFD28B5754433E2948D8C69020D97DE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "120A783A256A5448C19A9A53EB4F47030C2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "491EF2A849124145307B6571706307044150"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95FE28814BF9B440747A7EF65146FC60A84C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54975C0A8608F748D3090662B6BE92B45822",
                        "defaultText": "호이카데... 말이니? 흥미로운 질문이구나."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "06B738122667624AF04A0A52CCC9083610DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "844F5BCE4D1CF744561BAB8254A5E35BA302"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BEA0ED42E6573400E4A8918D1D06B3EAD8A",
                        "defaultText": "한편으로는 내가 태어난 나라지만, 다른 한편으로는\n지하실 말고는 호이카데에 대해 아는 것이 없어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3DF023605CB1C1477968FE2172C5E3407258",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2A784932F590644BF2A0EE1C27C662DE070"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFD001EA30C9F5443D4B68C5F5CC876688B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09AC2C7F5B48A34887291272E4B2AA7B41B6",
                        "defaultText": "오빠가 겪은 가혹한 환경을 들을 때마다 마음이 아파.\n그런 식으로 가둬 둔 사람들은 정말 끔찍해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3B602952278A1945048A9C49753CF380F7BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45E5C1AA1526B24DC44A5465AF3C5CD97C56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2482D7DB2A33414BE969C2A3BA5CCA98FFD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB5ACD1E331F414AE15B7B871EC4E92E8A51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0452EF77876F84F5C593B135022C84E70A2",
                        "defaultText": "사실 한 명뿐이고 너도 잘 아는 사람이야.\n하지만 끔찍하다는 데에는 동의해."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A6EFF3CE860D8848526B7395FCE585864651",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5EE0BDC780B2948AF5B885262CF4E5324C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74C30F0631602343F2690061379C12EF51E7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "foreshadowing"
                },
                "indent": 0,
                "uid": "3EC081E0748B514A7F08DD64A5F9F60B5D7D",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1C2CDED54AD5D6477789E3E33C36BBB286DC",
                        "defaultText": "그럼... 무니 여왕님이지? 돌아가면 그 일도 따져 물어야겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "503C190A5032524B0C3AC0A126E42A39BB69",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E61B8F744D1804CCA8B1977B685F8305A33"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "391DBF1513158440FC394A585043818C7BFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "285413EB33F2974A07596CE2D3AE10D0CCBA",
                        "defaultText": "너는 전형적인 호이카데 문화를 누릴 기회가 없었지.\n애국심도 그리 강하지 않을 것 같구나."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "179493744DAD0248C8393FD0D3BA3B64F60F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9767170B5CDC1740CD99ADD4116B7B17D41B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B60BB21C7254274E0F5BD556EDED749F6D58"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C422000E4621A54F768BCBF765C6637BAF01"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61FE3A591C94D248812809D8B67811F8C6F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9971BC95397724450B8B5C4937491C242343",
                        "defaultText": "맞아. 좋은 교육은 받았지만 책으로 관습을 읽는 것과\n직접 경험하는 건 전혀 다른 일이니까."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "299802D91E9AA341AF5BA5942AAA89341007",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E218F86388B704E174A2E256DE0AEA7FB20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1CB3832F4F45E64FF48BD2C110897FC03E56",
                        "defaultText": "호이카데를 내 고향이라고 느낀다고는 못 하겠어.\n그곳에서 “살아” 본 적이 없으니까... 무슨 뜻인지 알겠지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "720BCAE05DC76341988B2972BC8B2EAD9B7E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4494965A2F6728403B49A7E7C06C05D46755"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8378F14E30D7614D6A5A3765CC550644163C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A886C3A5D363548D03844707DE9C0BDC6F9",
                        "defaultText": "알고말고. 그럼 사랑하는 오빠에게 호이카데의 아름다움을\n처음으로 소개해 줄 수 있기를 바랄게!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D14F26722F4AE1440E393614CF735A21E294",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9045D5F3213D549856B01D35262FB9FAE1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EAC788B1C9AA243904BC3001125F89F5F49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC2CA653612D524B086A0490C0EB3875C67F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75AF203E52CC714DD518D252D42DB49DCA22"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3371414B988F03488779859490ACCD8F5B08",
                        "defaultText": "헤헤... 기꺼이 그러마."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3BDC3B271E442847FC8BC7C2B1C1B4BE91E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4679033323037342AE7B930780E1CB18342A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Risposte Choices",
                        "index": 258,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF8659393FC64347CF7855A49D8F264C53CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF32704F59DF3742FF2A86E58DC40046373B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54CFA80F542FB94F0D89A3F3A569735FB91A",
                        "defaultText": "적어도 앞날에 대한 계획 하나는 생긴 것 같네.\n다음에는 뭘 물어볼까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5744B54A344EA3461C3B62A46E2E2533D07A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "4289480941184343433BFE513F95A7D74605"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "show multichoice now",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "EE5267127371E6473658C093C8F0341946DD"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "CE6F724574347543B52AA5B54F45D47DB2A2"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "conclusion",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "E50A616C37F4B742006AEAD3AE9F56F443EE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "dreams"
                },
                "indent": 0,
                "uid": "163ABEA57F01734CD42BEC52F00DD2E821C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B41F48BF2A4EB546504B066651F7EB52C1D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2125D578215A1144CA0A8DB2BC46E5FD1E7E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "74B5BDD38BC642413F584233E228F294DC5C",
                        "defaultText": "꿈이라... 오랫동안 생각해 보지 않은 것이구나."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EC19D3EB85C0C843851A0026066A76B9452B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55F212204824B54E5A6A041277EAE4B13742"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB1FA87F2A60A84386093BE708D0DC162638"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9F7A17444F3764FEE88A215EADC8F29A58D",
                        "defaultText": "그 말은 적어도 예전에는 꿈이 있었다는 뜻이네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A4382D7723CA1740F2387E156CD69FB3BBB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E150A4C43DA0640FF785FC2A4B1EB1332BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA13B6B6562EB84A6E2B1754AD20C9CFF9AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C55195426952D94D1B384E85AED7DFDE0BED",
                        "defaultText": "물론이지. 자유의 공기를 마실 수 있기를 늘 꿈꿨어.\n하지만 그보다 전에도..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "773F198649FB19461269CF63E83D8287EFE8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8D8931183EF7649D71B53E122BC2D3BCEFD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 0,
                "uid": "D799351E4FE97347828A32A573ED2B035DFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05531BC36CC3094A5879C1E7CDB596C92926"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB30E7A416DA474812191DD19D5EC3FDF4AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F5DCD4CD667DE94D5E5A67715B0087EE3061",
                        "defaultText": "그래, 어렸을 때는... 그저 사람들을 도울 방법을\n찾고 싶었어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "68EC3A6A4456034A2D887E639C60219598A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB93FA9B59F2A34D7F69AF778E496CA7C980"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68F84C121395A74C285A0F84E42AD64E0369"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3E766028C9FD748B35A8D046E58E9F3FF9B",
                        "defaultText": "“사람들을 돕는다”고? 조금 막연하지만...\n결국 우리 둘은 비슷하네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E2FDFD580EA7D646FC388122653F3AE1FC25",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB0E5A1E72AE6147A71B99A842E5D3456EAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BAB7C5EC51FA284BE718DCC168609F214A68",
                        "defaultText": "...다시 생각하니 아닐지도 몰라.\n나는 지키겠다고 맹세한 사람들에게 상처를 줬으니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C653F4FC8C4765450529EB698DC9E11A9A33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8675F30A1969E2446048A55241EF46AACCAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C17131829E6348312A2FE16B71154EDE4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0386AA360B776478E8A221669DC8D12B414"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80899AC44BD873440C1909F12900554A0326"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B15219300036A64A6E3B6610304C84601119",
                        "defaultText": "아니, 네 말대로 우리는 비슷해.\n네가 그렇게 어려운 선택을 해야 했다는 게 비극일 뿐이야."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2B6379E55D3A24C7E0B1AB1E3264D70CF50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49A2BBF789CEA145C38B8B51F7E815E61221"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37F7113854C3C141C08940754B128969E316"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0CEB8AD06152B848086806D3A2BDDAED48C7",
                        "defaultText": "그 선택이 세계 평화로 이어진다면 충분한 의미가 있어.\n내 죄를 용서받지 못해도... 나는 만족할 거야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4CB889AC4414364FF2594FB75E81E69B0C94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "465F27BA67CF0846B428E7B0FCA9CF40B37A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2B26D8022C695409C0A66A29C6F0CAF3B75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1109DBD3208F554B163B0132F97D6BF70ADE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B3FBA686CB5F64ADA1B7C04BAE65E8DD741",
                        "defaultText": "그렇다면 같은 짐을 나눠 지게 되겠구나."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9119AB405F7C1346D44B8B776173EFA6CE17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D5FB7958821F444072B6A35A7293C1CBA30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACC0C49C4632A446340B71D6713334E4041D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "303E12556482A640631AD1E6BEA1217107AB",
                        "defaultText": "나를 돕겠다는 뜻인가? 헤헤, 오빠는 가끔 정말...\n속을 알 수가 없다니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97A6BFF83B510641020B2D846F8D14BE3D68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94F0D20D2825D2469B2AD270CD40116FCB53"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Risposte Choices",
                        "index": 258,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1F4A2D6852BEE146F3281B24874EEE033E60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6EFEE87C0D14654EC998D811895306023F99"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67C9A52E71033842A7584393905ED551E898",
                        "defaultText": "그래도 오빠에게도 그런 숭고한 꿈이 있다니 기뻐.\n또 물어볼 게 있을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CA11896F6939B542123A21C29BF060DC238E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "8B0264045E727143D929B5329F103DF74E57"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "show multichoice now",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "85376DBC4382624D157AA6D834F01A4F636D"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "4C1400A958FD984382284470BAF209AA9E85"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "conclusion",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "AB42910E6559F544AC288F83F24865B6C810"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "in love"
                },
                "indent": 0,
                "uid": "90EEBBCC4B7171458F7AD7B982D5C03E3B3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4BB55AB698BB7489A7818D59BF1F29CD312"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13D5D68E4412194DB85B44734E8C936F10FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7DC9EC21938E14FC45A09971D961E3F92DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5750D1B79581264D5C6AC0C3F5B693777724",
                        "defaultText": "나는 아주 오랫동안 갇혀 있었어...\n누군가와 사랑에 빠질 시간이 있었을 것 같니?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB55DEFC68D205407C7A18F6C4F0E7E1BA76",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E86E8702D2B4647498AD9C7286F1100FD2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "992B3589221EE141440A67C2BADEAB1FDB4F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "51C469EC264D944D09680F91A85D35793FBE",
                        "defaultText": "말을 더 잘 골랐어야 했네. 다시 물어볼게.\n사랑에 대해 생각해 본 적은 있어?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B89A7EE7AEB0848379A6CC04653C83B483F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E0400EB0BDC314D649A15B3741F562ABF50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B548A0825446F4485B591B05C291B950B096"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B92757FF397E52464A2862986F363734DF67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "685FC0C01DEB794B082A19C78C989AB010DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8D09BD16DB6A946FF18FF74C44159BA2F11",
                        "defaultText": "그걸 묻는 특별한 이유가 있니?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC8B73779FB73545E2480DC8D468FF362B05",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "908275176B51A849E03A4564188568DA6A51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03E25A8C4ADD484BA43B6B02C753A0D16827"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8F0C9C868AD184C6A28E9395A09C6930AC0",
                        "defaultText": "굉장히 방어적으로 나오네... 헤헤! 정곡을 찔렀나 봐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF19658754F4E2481F9A0C757E098FECFF8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D038805A270C744F882901B1EA1AA65DC441"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04A44AA928B1184B5479CB24F1F3B2157A7E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "433D1681892A224E637893A33BBC632BC828",
                        "defaultText": "오빠의 감정을 더 알고 싶어서 그래. 그냥 가벼운 대화야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A977B80D5C20F447339A05635BF60D049091",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "822C5A576560614E779B14433A588A02886A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "530BB157698063425F4AA3040A5DF876A17E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58E22E827B97D24DA73ACC38369318181B38"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D8BFA666DD4F743F14A3994FBFD6358E9D8",
                        "defaultText": "물론... 이해해.\n좋아, 네 질문에 대답하마."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F386960563C125452A6829E4E743BC99E8B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C98030078296D646BC18C351CF1D55FFFC0B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "931BA0743C13C54BB289FFE4B0CAA00E7C66",
                        "defaultText": "사랑은 경이로운 자연의 힘이지만\n동시에 무서운 양날의 검이라고 생각해."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9664283A5E9F044482788DD5B932942900BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F3E5BA394A2624E63499C12DD4C0118282F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BE50373541E39467D5B3AC39857A63F87F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "328B27C456298847129B38F4B1B57FB20363",
                        "defaultText": "그건... 꽤 비관적인 생각 같은데?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "723B75A769682043AE6AC3A32431731F773D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FB22F7468BB51479039AF18B909F87E5DE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5FB9C1788516144FA8AE78877BA1F48594F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B6F0E2345FBF9443C78E1E60178D553A0AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A32F18541E16E44F1029ED03A6ABD3BC8C05",
                        "defaultText": "그렇게 생각하니? 사랑하는 사람을 잃는다는 건 내게...\n견딜 수 없는 일이야. 그 사람이 없다면 삶은 의미를 잃겠지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E9BB46F25893E747B61AB5E2335B48E55041",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "678CD3C61F204844EB7A3F750FDC5DC4C119"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FC310C11698A8469B5998A542167AC6EBB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C88E5A851A2BE44BC58A0B80CF6E76CE0D71",
                        "defaultText": "내 얘기를 하는 건가? 헤헤, 여동생을 잃을까 두렵다고\n인정하기에는 너무 부끄러운 모양이네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "877E622570C8E747DF689FD342F6BEE99CF9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1F8069F36F6B14B9C585CB8F4A1D2D6F654"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FF131DA7B8DA44E21197492C110BF6E416E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDAAF9969982C848A14A0745A9CF7A003272",
                        "defaultText": "걱정하지 마. 그 사람은 영원히 오빠를 사랑할 거야!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2934D2265925904B362936021E163D2D127B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7E9BA75305D844E65797B40545B1593B2B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CF933432761174B8C19ED983500C176EEEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BDBA566137DB344778802B77DB1655D5374"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9DA912B1C4A834DE00A3447C8BAFAE700A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0722E148867374DF169E8A717D1E291D1C8",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF9DC8F73126884CB64A84237B266DDDFB37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9C2C3DC954201431B0B6D4507BC6BD12112"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5C9361A9281B54358696403D94937BFB58A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F70CA0A036FB549F82BEC11A88E5BE54809",
                        "defaultText": "고맙구나, 파라트라스."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D827C84867D4944203BC109F960DF75634A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F735006162FD4249FD7B39336065EB380BED"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Risposte Choices",
                        "index": 258,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A51789C39B2E7042AA2B4442220F61ED1BD6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9862AE6701F2674CAF7B64A6FC93DC8BC0D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77351FC69F53F544F04A68F387B745C99C65",
                        "defaultText": "좀 더 긍정적인 생각을 기대했는데, 그래도 흥미로웠어.\n이제 뭘 하지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C721554F4291124BB35AD33766ABBB2D285C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "6BDD1081461CB748A3591BC5652A35763E93"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "show multichoice now",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "3E5B94BE22927341082A3B65A9B80926A4AE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "conclusion"
                },
                "indent": 0,
                "uid": "2D894B959C0D2643A08A2FA5B93CDF42042F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "84B36B000E28E74822583BF433014DBFF23B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D46579E214E6F04F6A78320254ED0FADA409"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBA4D7372EC2C24C6529D7D5EAFCB29829C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B94AE336E70C64CF239BF02C4ECB2B125C7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "59302940345D66436B6BF5B426081CA8748F",
                        "defaultText": "아무튼 오늘은 이 정도로 하자. 오빠와 얘기해서 정말 즐거웠어...\n뜻밖의 모습도 아주 많이 알게 됐고!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14C774A47AD6894BD73A7208C3E9DA57BADB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DD3DFFA78104248DE385EF194A6D4FB2D92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "255E0C891D8BA2436919CF885A8EC4553E05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DDF245091D5754DFF3903E1C087224C1E69"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "539B8A6D60CD964DB518AB43B162FBBE862D",
                        "defaultText": "무슨 생각을 하고 있니?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "21BEF71228745546C04975220C6343025052",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0154010950511847DF1BD317B10866E1D764"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0509332189F274C6A38E717ECDF291D1721"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8BA08322D62A8413A7AC1B4BAD120E76A65",
                        "defaultText": "별건 아니야. 그냥..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "255366702F66E147A82A36A36D0659DFFB07",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D5DE7008A7AA54D194890A15F5D21E08D54"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+++aff"
                },
                "indent": 0,
                "uid": "A189BA9434CF364C8C3AA321FA05CD7DC8D2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            3,
                            1,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17D4E27E9F6281446E79069721D89EDCB4F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DBBF6C89141584B2048C5191F3519B46B1C",
                        "defaultText": "앞으로도 오랫동안 이렇게 앉아 이야기할 수 있으면 좋겠어,\n헬리오스."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C6FC632B48E0254DB479DC726AB0A3FC5D48",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D2AEE269A9B914FEF49A5C10B844366114A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B5144145D300547515B7BE30E1E49CC2A6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "501F9C872DBAE7465D79EBA5A2B58963722C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77DD4F635BE9B347405BBE24BC7E4598511C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F013D5642B0164F5F38DD601907D352922F",
                        "defaultText": "성소에 도착하면 마침내 있는 그대로의 모습을\n서로에게 보여 줄 기회가 생길 거야."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "049C114178E051489238B9F98DA63DBDD7B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "604609FE139DB14C682B76F6912DB040C61D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "960DAFA04A58F4414668567286243C094BFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2475103B43885341F179B36454491942D964",
                        "defaultText": "정말 좋겠다. 적어도 오빠 앞에서는 더 이상\n“그릇”일 필요가 없을 테니까!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "71E83E767226F548BE7B473608465956D8D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DC7D6AC5E46F4455F6AEF28C1C422C19F0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D88237240CED7471E5A71E2495FEA0C8134"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F2EA16111C8C640A15A7ED71FE69FA02FAA",
                        "defaultText": "그러고 보니 룰루와 함께 있을 때 느꼈던 따뜻함이 떠오르네.\n그때가 그리워."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A177E5C06F82484D282B09242DA0993B1731",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3843C58E9CE399453208E293E71B502AA501"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "480199F9597F484E4E194246BE9D6F7D6464"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B87C82B2801B6942683B87E6608608FEBAEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8FC9B835503D484D155906A3FB26CB812BB2",
                        "defaultText": "그날이 몹시 기다려지는구나, 사랑하는 동생아."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7DB9C04F00AC014F9299E00806322EF9B92C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE9756C11B737348A2795D8157496085985B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB7E0C4143ADB7491C8965B23A96D305EA63"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "B1E06F603851F5440768C476CDA1B4F878FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            8,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2BD893E4678924D5E5BB975DA9DCCC21EA5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "B865896803B695494C6B6AD65DBF9E05983C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            1,
                            5,
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            "",
                            1,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AF3F53E8B4DC742586AE1C4BA31AFAC6A3E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "FFA7B13B6694A141971836D6210D47E4E1B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DFBBE7F8546546463B79A3A87BDF1EC62B91"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "94ED28295158744FB19A6511560B6354DA8B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B84B0F6F7CC822487C09F346305C718F3498"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "C723B6A802C63343464905659FC6EA97C275"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Fa's meaningful talk with Hellios",
                        "index": 195,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C4161A553485F5467359BC188ACBDF470257"
            }
        ],
        "livePreviewDisabled": true,
        "localizableStrings": {
            "540938DC8CC5344ECF2B8813820BCB8D7A88": {
                "t": "Oh... brother, it's you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BCFAC1CF62730847F15A08C78B35FC3677BF"
                }
            },
            "5B09C133141BC74A5F88C364BC470026BDEE": {
                "t": "You're not usually given to walking back and forth in front of my tent. Is something bothering you?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "223855B1106EC848429A0DB455849952D1F1"
                }
            },
            "C20D6B731E24764DBE79A912C4747A68E9F4": {
                "t": "Actually, I was just reflecting on what will happen next.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DB1DB6628B19414A20689F78EBD117341108"
                }
            },
            "EA84E5238AFAF641A5198F032AF00D9F86C2": {
                "t": "You mean, after we restore your seal?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "A76E41A50C07764F291AA32021976D86CDA6"
                }
            },
            "FE8F52E8190F2744518A6AD6CF9C4846C16B": {
                "t": "Yes, exactly. I guess we'll go back to Hoikade, once we're able to prove that the seal is intact and that I wasn't possessed.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C717BE3A3CC5B14E6738403473A8242743D8"
                }
            },
            "2A1BA73E59831844D45806B0CF7889E99E61": {
                "t": "I just hope Mother will take my word for it this time...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B92FB10C09D3F6461F99AE03B7E79DFCC6F7"
                }
            },
            "5171591397584041E3583507938DE06DF49A": {
                "t": "Commander Saai's presence bodes well for Hoikade's intentions, at least.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "C82C4DD47F69D4450C7B0964A25006A8CA43"
                }
            },
            "C06D82743882474D2F58F75175793D7FB068": {
                "t": "Yeah. And knowing that you'll be by my side at the moment of truth... I have to admit it gives me courage.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "05DD76433698484F6E1939C570808A28D2C9"
                }
            },
            "094F216696BAD04AA78939574EC83A92C81A": {
                "t": "Really? How come?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "9B83E35F9873F74AAB3B1B099B641F376626"
                }
            },
            "478554B552FF464A28688E3644FB0FC809DB": {
                "t": "Hellios has always fought for me since we met... He saved my life on countless occasions.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "020C1F5E6D70E044DC6A6E72A35A82A5803E"
                }
            },
            "676879144FBE50487059802412B4CD4B23B0": {
                "t": "I left on my own, fleeing like an outcast. And I will return with the support of friends and... a brother I never knew I had.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BB2A3A243D67134EC62863C318027D9C9AFB"
                }
            },
            "1A531A6543B9694623883009D6E4CF11ECAA": {
                "t": "This, to me, is already a victory worth telling.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "19419EC956420147847B1F725CC2EA831A43"
                }
            },
            "A380D8CB071D56477A281B5738EA6FE946DC": {
                "t": "How... curious. I've always considered you the center of my world. And I've always known about you since you were born.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "E39D446C8CDEF1427D7881D5131AB1377078"
                }
            },
            "E39F27605BC31149296BD9338309D9733112": {
                "t": "But... I didn't think that I, a brother unknown to you for so many years, could be of any importance in your life.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "BA70A3C700A1554B6C29DC44B97FF629521A"
                }
            },
            "CE9FAA9B512FD5488F0A0346CFA0AAD2EA81": {
                "t": "What do you think about Hoikade?",
                "d": {
                    "eid": "D1B2B4BF2EFC9441731B0FD6EBB8BA3F6EE3"
                }
            },
            "096E65346451514DE93832476DB13BD72F3A": {
                "t": "Do you have any dreams?",
                "d": {
                    "eid": "CF782F593E3AD74DAC4B2E34F4FDF423D955"
                }
            },
            "68EA45F64E3F5149024B84488AF05AF87626": {
                "t": "Have you ever been in love?",
                "d": {
                    "eid": "ED81EB626DBD244D02790147B5A82CF6819D"
                }
            },
            "54975C0A8608F748D3090662B6BE92B45822": {
                "t": "About... Hoikade? Interesting question.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "06B738122667624AF04A0A52CCC9083610DC"
                }
            },
            "1BEA0ED42E6573400E4A8918D1D06B3EAD8A": {
                "t": "On the one hand, it's the country I was born into, but on the other, I've known nothing of Hoikade but an underground room.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3DF023605CB1C1477968FE2172C5E3407258"
                }
            },
            "09AC2C7F5B48A34887291272E4B2AA7B41B6": {
                "t": "I'm always sorry to hear about the brutal conditions you lived in. Those who kept you imprisoned like that are awful people.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3B602952278A1945048A9C49753CF380F7BD"
                }
            },
            "E0452EF77876F84F5C593B135022C84E70A2": {
                "t": "It's just one person actually, and you know her well. But yes, I do agree.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "A6EFF3CE860D8848526B7395FCE585864651"
                }
            },
            "1C2CDED54AD5D6477789E3E33C36BBB286DC": {
                "t": "So... Munie, right? I'll have to question her about that too, once I get back.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "503C190A5032524B0C3AC0A126E42A39BB69"
                }
            },
            "285413EB33F2974A07596CE2D3AE10D0CCBA": {
                "t": "You never got to enjoy the typical Hoikadian culture. I assume you are not very nationalistic.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "179493744DAD0248C8393FD0D3BA3B64F60F"
                }
            },
            "9971BC95397724450B8B5C4937491C242343": {
                "t": "You assume right. I had a good education, but it's one thing to read about our customs in books, it's another to experience them.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "299802D91E9AA341AF5BA5942AAA89341007"
                }
            },
            "1CB3832F4F45E64FF48BD2C110897FC03E56": {
                "t": "I can't say that I perceive Hoikade as my land, because I've never 'lived' there... If you know what I mean.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "720BCAE05DC76341988B2972BC8B2EAD9B7E"
                }
            },
            "4A886C3A5D363548D03844707DE9C0BDC6F9": {
                "t": "I do. And well, dear brother... I hope I can introduce you to the beauty of Hoikade for the first time then!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D14F26722F4AE1440E393614CF735A21E294"
                }
            },
            "3371414B988F03488779859490ACCD8F5B08": {
                "t": "Hehe... I'd be happy to.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3BDC3B271E442847FC8BC7C2B1C1B4BE91E9"
                }
            },
            "54CFA80F542FB94F0D89A3F3A569735FB91A": {
                "t": "We seem to have a plan for the future, at least. What can I ask him next?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5744B54A344EA3461C3B62A46E2E2533D07A"
                }
            },
            "74B5BDD38BC642413F584233E228F294DC5C": {
                "t": "Dreams... That's something I haven't thought about in a long time.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "EC19D3EB85C0C843851A0026066A76B9452B"
                }
            },
            "B9F7A17444F3764FEE88A215EADC8F29A58D": {
                "t": "This implies that you have had dreams, at least in the past.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A4382D7723CA1740F2387E156CD69FB3BBB5"
                }
            },
            "C55195426952D94D1B384E85AED7DFDE0BED": {
                "t": "Of course, I've always dreamed of being able to breathe the air of freedom. But even before that...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "773F198649FB19461269CF63E83D8287EFE8"
                }
            },
            "F5DCD4CD667DE94D5E5A67715B0087EE3061": {
                "t": "Yes, when I was younger... I simply wished to discover a way to help people.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "68EC3A6A4456034A2D887E639C60219598A3"
                }
            },
            "F3E766028C9FD748B35A8D046E58E9F3FF9B": {
                "t": "\"Helping people\"? That's a little vague but... all in all, we're similar then.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E2FDFD580EA7D646FC388122653F3AE1FC25"
                }
            },
            "BAB7C5EC51FA284BE718DCC168609F214A68": {
                "t": "... On second thought, maybe not. I ended up hurting those I was sworn to protect.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C653F4FC8C4765450529EB698DC9E11A9A33"
                }
            },
            "B15219300036A64A6E3B6610304C84601119": {
                "t": "No, you're right, we're similar. And it's tragic that you were faced with such tough choices to make.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "B2B6379E55D3A24C7E0B1AB1E3264D70CF50"
                }
            },
            "0CEB8AD06152B848086806D3A2BDDAED48C7": {
                "t": "These are choices filled with meaning, if they will lead to world peace. I may not be forgiven for my sins... but I will be satisfied regardless.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4CB889AC4414364FF2594FB75E81E69B0C94"
                }
            },
            "4B3FBA686CB5F64ADA1B7C04BAE65E8DD741": {
                "t": "We're going to share the same burden, then.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "9119AB405F7C1346D44B8B776173EFA6CE17"
                }
            },
            "303E12556482A640631AD1E6BEA1217107AB": {
                "t": "Does he mean he'll offer me his support? Hehe, he can be really... enigmatic sometimes.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "97A6BFF83B510641020B2D846F8D14BE3D68"
                }
            },
            "67C9A52E71033842A7584393905ED551E898": {
                "t": "But I'm glad to know that he has such lofty dreams too. Is there anything else I could ask him?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CA11896F6939B542123A21C29BF060DC238E"
                }
            },
            "5750D1B79581264D5C6AC0C3F5B693777724": {
                "t": "I've been imprisoned for so long.... Do you think I'd have had time to fall in love with someone?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "DB55DEFC68D205407C7A18F6C4F0E7E1BA76"
                }
            },
            "51C469EC264D944D09680F91A85D35793FBE": {
                "t": "I could have chosen my words better. Let me try again. Have you ever thought about love?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9B89A7EE7AEB0848379A6CC04653C83B483F"
                }
            },
            "C8D09BD16DB6A946FF18FF74C44159BA2F11": {
                "t": "Is there a particular reason you're asking?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "DC8B73779FB73545E2480DC8D468FF362B05"
                }
            },
            "B8F0C9C868AD184C6A28E9395A09C6930AC0": {
                "t": "He seems so defensive.... Hehe! I think I hit a nerve there.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DF19658754F4E2481F9A0C757E098FECFF8F"
                }
            },
            "433D1681892A224E637893A33BBC632BC828": {
                "t": "I'm curious to learn more about my brother's feelings. It's just some small talk.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A977B80D5C20F447339A05635BF60D049091"
                }
            },
            "1D8BFA666DD4F743F14A3994FBFD6358E9D8": {
                "t": "Of course... I understand.\nAll right, I'll answer your question.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "F386960563C125452A6829E4E743BC99E8B7"
                }
            },
            "931BA0743C13C54BB289FFE4B0CAA00E7C66": {
                "t": "I think love is a wonderful force of nature, but also a terrible double-edged sword.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "9664283A5E9F044482788DD5B932942900BD"
                }
            },
            "328B27C456298847129B38F4B1B57FB20363": {
                "t": "That's a... pretty pessimistic view, don't you think?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "723B75A769682043AE6AC3A32431731F773D"
                }
            },
            "A32F18541E16E44F1029ED03A6ABD3BC8C05": {
                "t": "You think? For me, the idea of losing someone you love would be... unbearable. Life would lose all meaning without... that person.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "E9BB46F25893E747B61AB5E2335B48E55041"
                }
            },
            "C88E5A851A2BE44BC58A0B80CF6E76CE0D71": {
                "t": "Is he talking about me? Hehe, he must be too shy to admit he's afraid of losing his little sister.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "877E622570C8E747DF689FD342F6BEE99CF9"
                }
            },
            "BDAAF9969982C848A14A0745A9CF7A003272": {
                "t": "Don't worry, I'm sure that person will love you forever!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "2934D2265925904B362936021E163D2D127B"
                }
            },
            "C0722E148867374DF169E8A717D1E291D1C8": {
                "t": "... ... ...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "EF9DC8F73126884CB64A84237B266DDDFB37"
                }
            },
            "1F70CA0A036FB549F82BEC11A88E5BE54809": {
                "t": "Thank you, Faratras.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5D827C84867D4944203BC109F960DF75634A"
                }
            },
            "77351FC69F53F544F04A68F387B745C99C65": {
                "t": "I was expecting a more positive view on the matter, but that was interesting regardless. What now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C721554F4291124BB35AD33766ABBB2D285C"
                }
            },
            "59302940345D66436B6BF5B426081CA8748F": {
                "t": "Anyway, that's enough for now. I really enjoyed talking to my brother... I found out so many unexpected sides to him!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "14C774A47AD6894BD73A7208C3E9DA57BADB"
                }
            },
            "539B8A6D60CD964DB518AB43B162FBBE862D": {
                "t": "Something on your mind?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "21BEF71228745546C04975220C6343025052"
                }
            },
            "E8BA08322D62A8413A7AC1B4BAD120E76A65": {
                "t": "Nothing in particular. It's just...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "255366702F66E147A82A36A36D0659DFFB07"
                }
            },
            "3DBBF6C89141584B2048C5191F3519B46B1C": {
                "t": "I hope we'll be able to sit and talk like this for many days to come, Hellios.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C6FC632B48E0254DB479DC726AB0A3FC5D48"
                }
            },
            "6F013D5642B0164F5F38DD601907D352922F": {
                "t": "After we get to the Shrine, I'm sure we'll finally have a chance to show ourselves for who we really are.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "049C114178E051489238B9F98DA63DBDD7B1"
                }
            },
            "2475103B43885341F179B36454491942D964": {
                "t": "That sounds great. I won't have to be the 'Vassal' anymore, at least around you!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "71E83E767226F548BE7B473608465956D8D4"
                }
            },
            "4F2EA16111C8C640A15A7ED71FE69FA02FAA": {
                "t": "And that reminds me of the warm feeling I get when I'm around Lulu. I miss those days.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A177E5C06F82484D282B09242DA0993B1731"
                }
            },
            "8FC9B835503D484D155906A3FB26CB812BB2": {
                "t": "I can't wait for that to happen, my dear sister.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "7DB9C04F00AC014F9299E00806322EF9B92C"
                }
            },
            "E9C9BB72929E38468D193AD5243624450E29": {
                "t": "You look thoughtful, Faratras.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "2F2B1B4D976D71450229F3133DA01BEA56AF"
                }
            },
            "4C95F29C28D30148D068203548EDADD0526B": {
                "t": "You're very important indeed.",
                "d": {
                    "eid": "8CB227B842A83145D5183906EC4CBD217B47"
                }
            },
            "26D1A27B223BD64462293D881830B15CA00A": {
                "t": "Let's not get ahead of ourselves now.",
                "d": {
                    "eid": "E261B88D9C8F314647499F713A06720565F8"
                }
            },
            "7E92EF8A9E865243E539FA0791601AF63988": {
                "t": "I am... immensely pleased to hear that.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "F51D58FE29059146182AF847DBF16637D65A"
                }
            },
            "1E1344DE396EA14F604A1BD2B32EAB435E9B": {
                "t": "Oh, I'm... sorry, Faratras. I might've misinterpreted your words.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "E495EEA742FFC142587B0C22A1E7737A6086"
                }
            },
            "A442131C18B4A44BBD38A1E478A4D80977F5": {
                "t": "I didn't mean to imply that we don't share a bond, either.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "797B393A3D322543A7385457B63F5085CE30"
                }
            },
            "C0EB97231A7D1743119B1558DFAABFACE3E4": {
                "t": "It's just that... despite how I may feel about our relationship, it is true that I know very little about you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DC81AF4C79FC23414B7BAB12CDBACEF0BD96"
                }
            },
            "53A63B4495BBF54B327B2A7733CF34CF0967": {
                "t": "I understand. You have every reason to feel that way, so feel free to ask me anything. We may not have another occasion like this for a while.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "6CB3A3880400414FFA39FBD358FD515797AF"
                }
            },
            "54346C913605864AC538573031B650AFFCDB": {
                "t": "Now that I think about it, after my seal is restored, I won't have much time to chat like this with my brother.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AA883229972D0647A71A1654911EF6C1FD42"
                }
            },
            "E0DB04DE89BCC84E037841659DDF71AFCC64": {
                "t": "I'm grateful for times like this, for as long as they may last. So then...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3425B01270FD7543B0888261F2869AA6957B"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}