GS.dataCache['C389390B1B86E8496D39FC963E547914E02A'] = {
    "uid": "C389390B1B86E8496D39FC963E547914E02A",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C002-03a Meet Lyvonis at the training grounds",
        "type": "vn.scene",
        "parentId": "A82A81ED63F1A5455A887F81F814BD41F19C",
        "chapterUid": "8F0F11BF32BEA44F8D6871B6601039C7CB03",
        "order": 6,
        "localizableStrings": {
            "9FAC7E9280FEE440E6883677AE950E45BFF4": {
                "t": "I trained for so many years here with Master Alvano...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "339EFF9334EFA3482E88D279972074EFC63D"
                }
            },
            "C8D5694D66D961447B4B011454AE4D9DB273": {
                "t": "I still come here every now and then to train the shaman troops, but not as often.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E6D9A37872F2C14F712A2B14AD083642AB39"
                }
            },
            "064CCC725FB07340768B417715BE4AE7E66D": {
                "t": "At long last, you've arrived.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "B1E7ECAF2ECAE8444B78B4A97089F953F41C"
                }
            },
            "7BC02ECD2C27B544EE897DD966883E53C1F9": {
                "t": "Uh oh...{W:200} I would recognize that voice anywhere.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3AB0FFFD4AFAF2453F39B2360F6F5F7376E3"
                }
            },
            "779D6AFF5C4FA34624593ED45832A8239DC2": {
                "t": "You're late, you know?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "40E7E8F75402634348492C628396FC48A8A0"
                }
            },
            "9401DBAB27C60140418AE1621CFD0A9A8CB9": {
                "t": "Actually, I'm not.",
                "d": {
                    "eid": "9187BE6999A788438D8B81A158061EFF85E6"
                }
            },
            "9FA19FC41C05394510883528DAB5E22204D4": {
                "t": "I'm sorry...",
                "d": {
                    "eid": "CABB85C909C2B547BB1AC9F592033A7E0332"
                }
            },
            "4D5C2D7E9ED69846E1281D742A3FD5573234": {
                "t": "You liar!{W:200} I can't believe that someone as inconsiderate as you is the Vassal!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "0FFC90808A7D6241A168CE92ECA712EFEF8F"
                }
            },
            "8C2C269C323DF842103BAFF8853190B07C69": {
                "t": "Watch your mouth, Lyvonis...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C32CD27E4CC9D94E0D88B067A0948EC5303E"
                }
            },
            "9277A30C6E6883491C8AE51763C78D3F061D": {
                "t": "But I hate to admit he isn't wrong...{W:200} As the Vassal, I should be paying more attention to these things.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2CB00D376AF16142BD4B73420005D423A533"
                }
            },
            "8B896F937127F443E00AB912BCA64BEE1E63": {
                "t": "Tch...{W:200} I hate to admit it, but you're right.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "22E44D3E63CEB145311B4D786EF56C735B72"
                }
            },
            "2CB9A5A29E3B1440330BA125ACACCBD81FFA": {
                "t": "I won't fall for your traps that easily,{W:100} you know?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9117605A98EBD649EF2801E6C87530ABE0E7"
                }
            },
            "18DD001A476C96412B88B002B0543FDE7960": {
                "t": "Hmph!{W:200} Instead of apologizing, try to be on time in the future!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "6216C086572BE445798822E96DBEAD8A4991"
                }
            },
            "977C8BB58DC7744988083044581C3C26158A": {
                "t": "If I were the Vassal,{W:100} I'd never let any of my people wait for me.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "B77876348C34224944283228BE71E7E55FC6"
                }
            },
            "E99B78FA56D8A048BF391E01A42D8214E4D3": {
                "t": "Understood.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DBB0F4AA9270994F125A8EB20B0C6D823328"
                }
            },
            "CA3C0E6D11271547D668C0B9057DB191C973": {
                "t": "I hate to admit that he has a point.{W:200} Being a commendable public figure is part of this role.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E60C2B788C74634CD98A9E43768AD61A6E1A"
                }
            },
            "09EB888A8527D444331873387A3A76206532": {
                "t": "Tch...{W:150} Why do you even apologize?{W:300} It's disgusting how humble you are.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "33F9CFB46E09614A059913D5A179CC3F079A"
                }
            },
            "2396BA056BB5014A8B9A0EB1C01E0AF98010": {
                "t": "I may not be late, but it seems I've done something to upset you. {W:200}For that, I'm sorry.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E9548A712BC1A340EC6A3FC4C2EC57EEFF2B"
                }
            },
            "765A0888628557497D3BDA37C52B8D005610": {
                "t": "That's not true either... {W:200}Just stop it. You're irritating me.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "EAD934AE420552480F89A32803EC448071C1"
                }
            },
            "301A8E5B7380F64BD20B7F0339D2C2BE3061": {
                "t": "As you wish.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4466E55F10BEF24EF83824425AC6FBAD24C3"
                }
            },
            "BE2F88326B84F347005883C4475686CEC915": {
                "t": "He's always so competitive with me... {W:200}But I really don't have anything against him.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "27F00E653C7B234ADB7A0F491003B04D42FD"
                }
            },
            "4383E7AD7E726443055967569503D1755BEE": {
                "t": "... {W:100}Whatever. {W:200}Are you ready for your training, Lady Faratras?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "7180413E7A47384318398008116A869A5B31"
                }
            },
            "D7BB797583E29348AE9994A644D745AB17DB": {
                "t": "Of course. {W:200}I wouldn't be here otherwise.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C0C522B92967A44D3C8B49F25A5F835EF422"
                }
            },
            "53772DA86071E4447C79D0870EDAC4F7FE44": {
                "t": "Then show me the power of the Vassal.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "18316DAA67787448E38B6E10D6F2CA0B26F4"
                }
            },
            "801E02F2870A7845149A1A0489D62BBA15D7": {
                "t": "The same power that kept the soul of the Demon King imprisoned for 21 years!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "5ACB38CD8A05A146087A37C304D45D7A34F2"
                }
            },
            "8318844E529D134F6D19EC7041ECBF791A5E": {
                "t": "It's not merely \"power\" that allowed that, Lyvonis.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "96E9222405B971423458E1975D97DAD242CE"
                }
            },
            "7C00B3470E05B840A38B84E1F4B858ABB7B7": {
                "t": "It took an awful lot of hard work,{W:150} and everyone's support, too.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EBFF113325B3A847E85922D899520FCCD0BD"
                }
            },
            "1B6D84C464A5314443494D331F6D7406E614": {
                "t": "And I'm sure you're able to understand that as well,{W:150} since you're the only {SP:1}{C:1}eligible substitute{C:0} to become the next Vassal in case I fail.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "956B1C9F3EFBA84F5C1A68D6DD3034117AF6"
                }
            },
            "B72EF4127E272842275BC5872A6BDDF21122": {
                "t": "... {W:100}What could YOU understand, Milady?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "9373081A1A4E564F5A7AB037D2F574FABF95"
                }
            },
            "8A9B787D74B371430F2BE5E8440D8C526A44": {
                "t": "You were born privileged. {W:200}Surrounded by riches, blessed by powerful magic.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "21C2D2BB5B54B0456E4A8C59B7417B673C92"
                }
            },
            "73BF3BD333750442A79B7AE29F6F3E64C6D7": {
                "t": "You may be right.",
                "d": {
                    "eid": "74BEF85D69CFF64B0448E36831514921F4A3"
                }
            },
            "2A706691688233484F38D5E8BBD82466DB85": {
                "t": "It's more complicated than that, trust me.",
                "d": {
                    "eid": "1D7A20528A4DD1462869FAA747A38173B5C7"
                }
            },
            "A2C0007124A1034E443972D7659E819B1C1A": {
                "t": "A peasant like you would never understand.",
                "d": {
                    "eid": "FD4B8E50297EE74B819B27147E4E3467E02A"
                }
            },
            "4F1C3F430CD8A149436A0520B430C772BA10": {
                "t": "So you admit it!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "2193B0247F0A7749A80911A36CA4066E5F0F"
                }
            },
            "7291FDD91D99E5461A982235FB02FDD86566": {
                "t": "There's no point in disputing that. {W:200}It's true that I was born a princess, and a powerful mage.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "26F7227A90CC434ADE48AA8181E1165D26B4"
                }
            },
            "A78FF3AC898C66489E1BA518C0CFFDB35CAF": {
                "t": "However, {W:100}saying that my life has been easy because of that would be a severe mistruth.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5EE49FF21F8805455F68CD75AB4B6C4B95A2"
                }
            },
            "563C74312EDFD74D388911C1C2018E46C47E": {
                "t": "As if!{W:300} You didn't need to climb the ranks, nor train hard every day to acquire more power.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "6A9BBC5864A3A3409799FA28C9C0470EAF74"
                }
            },
            "691182C22A8E964B9A6BA396BDE500CBAAFF": {
                "t": "I beg to differ, {W:100}but I doubt you'd listen to me anyway.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A1289E5178EF894ECF6A5771440C2522D0D1"
                }
            },
            "AD2655E7140198429D0B4D7765C033CCDE44": {
                "t": "You're looking down on me again...!{W:200} You'll pay for your insolence!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "E1494E884A79E54A781A0BA112A0995D8614"
                }
            },
            "0773958A30258443159A8B31F36B49CD60DA": {
                "t": "Quite frankly, {W:100}you brought this upon yourself.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D1F96E1010640443F82A1126D1D8F271D5D9"
                }
            },
            "7EADAA7178D4A945DE1B01E4A897AE3DDB9E": {
                "t": "You haven't been respecting me from the beginning of this conversation, {W:100}despite the difference in our roles.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "58841C173893854DC0589817A813714479EB"
                }
            },
            "84BD64DD49CC3143D539FEC2D027370647E9": {
                "t": "Enough with this nonsense! {W:200}If you're really that good, then prove it!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "B8849CFD41DA814C3A489225D3C3AADC1DAC"
                }
            },
            "0D8373C8299F6743018A0A0701D93CC85FC6": {
                "t": "Come forth, shamans!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "34EEB65852C8674B3B8961E67468347BCEC9"
                }
            },
            "C77F38C3808BD24CF71BFF374FCB7287F285": {
                "t": "They've got names, you know. {W:200}Not just \"shamans\".",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AF596B598EAE954B870AD80586A87895B393"
                }
            },
            "3AB0F2ED744547405279EC834590E49ABAB0": {
                "t": "Soon you won't be lecturing me anymore. {W:200}It'll be clear to everybody that the superior Vassal is me.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "11E86EDB62866642967B5EC9AB37A9CF0975"
                }
            },
            "E753FF5C8BD38240FD4989F09F6D1B60539D": {
                "t": "Sigh.{W:300} I wanted to kickstart this training a bit differently,{W:150} but oh well...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0C1E80E5757D4743547A8227F2A5B5955F2B"
                }
            },
            "412AC1799361F64C8E98FB56155042303DFF": {
                "t": "Here I come.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1D6255A96C94A348B09A5E88310B2145762B"
                }
            },
            "07211D485000E040BF5846B2B835CD19906C": {
                "t": "Ragh",
                "d": {
                    "eid": "78F72BF744B0F94D7F6BA131CDE81D149A9B"
                }
            },
            "B028B0178FF4D149A2792B50463CD218C0F7": {
                "t": "Nasca",
                "d": {
                    "eid": "1A1179F784893748086ABC2203A5778125DD"
                }
            },
            "7737CA123E07A440805AFDD729059FDDC74A": {
                "t": "Well...{W:100} that wasn't too hard.{W:200} But I didn't come out unscathed.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F7859125280D4441B87827B56B3C9252CCCD"
                }
            },
            "B4056F041FA4C0416139CBC2BC4B9171C9E2": {
                "t": "I think this is the best time to drink the potion that Marie gave me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "227F5E6C7376564B6A285B1646C4FD8044D0"
                }
            },
            "C0A3E93113455440287BE695A0C6EC2BF818": {
                "t": "Much better already.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2BAB28075CE0B344E8397C47BEC4BFDE0A73"
                }
            },
            "BA828AFE54B8D7460C6817F75752BB2BCD83": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "AD18104717D85244C69B5F05ECDB82EEB25C"
                }
            },
            "3929F3D83B6A2148B46B1753A9F42E0E7957": {
                "t": "It... can't be!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "7A6C771C3B55B24FD64A1AD3651AFEE18D33"
                }
            },
            "99876AFC7F7DF14AA509A58645748D32F697": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "47F3BD7E291D56414B1B8935D5A9C16A0B82"
                }
            },
            "FAB289EE4A3FD3415189BAE70A92C324A6A2": {
                "t": "This training is supposed to be useful to you too, as the substitute Vassal.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "62A93A6354DFA4445D0B11C3F8465045F2B3"
                }
            },
            "664D0284347B1345E05B2954D8FDE6A61C6E": {
                "t": "So, no need to look so defeated.\nWhy don't we train together instead--",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "422BDDE3693B014E984A3E43674A3381974B"
                }
            },
            "5EADF3397A7784439B1A4F260CF059A359C7": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "06B34FD536EE844A21984822A69659E5D21B"
                }
            },
            "7EFC48FD3B73E24E32190F381C6749FF89F1": {
                "t": "I refuse! I don't like your style.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "BA33DC265039D649D22A0BE2C1A4C46EDE14"
                }
            },
            "1F8A34D153EE414B0B7986789D5693BFE294": {
                "t": "Sure, the way you use Shadow magic is superb.\nI admit it.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "938738D13ACFB84EBB6B94242D56A0FCA0BD"
                }
            },
            "7D6520C039F7A542B609ACC7101BD19AF5C5": {
                "t": "But that precise control requires a lot of time. In exchange for great offense and defense, your movements become slow.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "3E9235E9645B10419B689599DBD6C7805F2E"
                }
            },
            "F4C1F8CA82F523496F58525050472396D039": {
                "t": "He may be arrogant, but he's indeed insightful for having noticed that.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E4546F4B5DC036491C6931A5C91E7EC4A63D"
                }
            },
            "A9D26D044B3D7646DA9B9F60B782D5CF0FB2": {
                "t": "That's true. And?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DCE0023C5AF25745A38AEB329C28052EFA89"
                }
            },
            "0AF9935C525EE8490669A3072C57AC36C407": {
                "t": "Therefore, your magic wouldn't be able to keep up against a great number of enemies.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "4F08ED4383F2244ED449E0C608D879187B30"
                }
            },
            "0BD35B15532F904F7B8BEF586091452D9748": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5B031C8743698248A95B7BE61015BF743BE3"
                }
            },
            "BAAC8A937644C14E97487965B5670ECC49F7": {
                "t": "You'd be suppressed before even being able to move a finger.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "4A15AAF76EFD504554482D702042739934AF"
                }
            },
            "DA6EE0E84005B04F1C398B81A1F8A5315936": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "82B3959C6CA4F9449A3B0D3129BE1AF7CCA9"
                }
            },
            "F7C5CE5D786565457B6AFA9349F1FD8FE974": {
                "t": "I'm well aware of my weaknesses, Lyvonis. Which is why I also came up with proper solutions.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F67B01CC7019F243E95BC29271FB55EAC538"
                }
            },
            "CA3C6A376DDAB343DA09D92080C3F820C965": {
                "t": "I'm now able to cast {SP:2}{C:1}Neregis{C:0}.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "701266F974DEC247D45A873996D9AD67E4DB"
                }
            },
            "7FFB293B66057742CF68AB94C1513BA79103": {
                "t": "... You're kidding me!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "DBE0BA76157D46451B6982A275414C3E9B7C"
                }
            },
            "33587CFF2A1B564F458A7142A5A9D8E18B00": {
                "t": "It's the truth. And I'll show you, if you wish.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7677ACDF8F39434F6D5AF06384E58124EBC8"
                }
            },
            "09BC62AD7692C3477A4B67896D8C39219C6A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "3DC423DB29E3F645AB19A9D8229DC532CA54"
                }
            },
            "9E0BDB191BA8A94D402A7045344AD329F0E3": {
                "t": "Y-You're just bluffing. Time for the second round!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "3007294B7DED9648397A88996486A67B446C"
                }
            },
            "45FC1D2E0D8EC942EB4AE84674D27B24CD04": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "72B3565C2E1CE348A67A16F3C54A0FC442EB"
                }
            },
            "143A4C1529A4D846E96B2463F5A5CAF552A9": {
                "t": "En garde!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E075935287D886402B1B4876BEC34D9E2FCE"
                }
            },
            "5718D71A0C30134E4A6BC240B42EAA128B31": {
                "t": "Neaw",
                "d": {
                    "eid": "A940FD474C318648F39A83C2CCC0B19E206B"
                }
            },
            "6AA9E3068FFD524D112AFE737F8040C651B1": {
                "t": "Nolk",
                "d": {
                    "eid": "874E4803823D5640AF7956660BC6793D1AD5"
                }
            },
            "396C727C76DB304D2879F800AB5B378175E8": {
                "t": "Roger",
                "d": {
                    "eid": "4D11AC608F86074E855B1257F07D8A7D453D"
                }
            },
            "016E6CFF7811054CF059A1320882217786E2": {
                "t": "Shaman",
                "d": {
                    "eid": "39BFB2B96971E24E93894D9473A0FD6D54CD"
                }
            },
            "565AF1E44EAA774A5C1915642FB047E7FC4F": {
                "t": "Soldier",
                "d": {
                    "eid": "55992B93050F7245F0080A1520C3553DC999"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "DD5B475D6760B343655A6E087E79C5BF3938"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F608207974B8340B25A2A77D124C1F96276"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 10001,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "D046C8CD43B9344F251BDFE0D97D8A434BA2",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "885E727E44F381488E2985B2825E9F8CA0BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2840B09D0870D3410C6B35417206B69A37B7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "5797E56B632E1441913A33C598F657245279"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "69E3FC256D630746035999B1870F61D23F3C",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C175C9005577C545A77BEEC85FE78E4E500D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Identificativo Suono",
                        "index": 159,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6ABA32C20C8B07434108173319637D6A3A61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "1EFE085C1293664BE74882747E0FAD965890"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "BFC727FA4C8E614921898F72441568553025"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "C419C1CC0150E745F46B1B44CC2039A5D948"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10001,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9C6B7B8864F7724AB1882B892F4B27B5B706",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "694FEC4437DB2643176A977121071C1EF9DF"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "650BA5364C55794A0468B81440B7C6127ED0"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spend time (during travel?)",
                        "index": 96,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2DE620C04501334817186957355426B729D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            {
                                "name": "Tempo d'attesa",
                                "index": 32,
                                "scope": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            },
                            250,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "57E8B4F9443D4341D688C5D1E6A9013C7E7F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 1,
                "uid": "1F6C3AD47D2AB2480729E74360DCAA95710E"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "PREVENT LOADING EXPLORATION?",
                        "index": 97,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6A273E8338090549636B9814301C9A7CAF32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "20C025C57399464AE62BFEC14507578D0CC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "316DF61A2488D548FE786907C79F5A382AB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21BED946486F864B3A4ABD9607AA209A469F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9FAC7E9280FEE440E6883677AE950E45BFF4",
                        "defaultText": "알바노 스승님과 여기서 정말 오랫동안 수련했지..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "339EFF9334EFA3482E88D279972074EFC63D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B97B23D9DBB754AF1484F72B1D530A06DEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8D5694D66D961447B4B011454AE4D9DB273",
                        "defaultText": "지금도 가끔 주술사 부대를 훈련하러 오지만,\n예전만큼 자주는 아니야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E6D9A37872F2C14F712A2B14AD083642AB39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08B629529B59414BA03930149DC2D54D5831"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BF1F0B37E37E849901901594A1B841E6A53"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "064CCC725FB07340768B417715BE4AE7E66D",
                        "defaultText": "드디어 오셨군."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B1E7ECAF2ECAE8444B78B4A97089F953F41C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77E6F2A5609F5148C61822713EC038AD1459"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B60C642449AC1044FA6A9AF4462A04DDA352"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "610AFE14895E79406458A281E076FE1C6793"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7BC02ECD2C27B544EE897DD966883E53C1F9",
                        "defaultText": "이런...{W:200} 저 목소리는 어디서 들어도 알아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3AB0FFFD4AFAF2453F39B2360F6F5F7376E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14BEFCDA707DF449A1887A57D3406CFE178E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98C7CC23682D214B1B0A18047B0CB3E284A9"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 100,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 299,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 51,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "A6A3837950413941030B15A6AC71D8053BC9",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "CAA3589E5199F94E6179902205B6E8192DFD"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2826E7AC7F5A8342F238B992A2A507F44CAF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "0AA7FA499F95E442A33B841243FC9D50A7A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A960A0BD58724744A28A6229F96CBA199F13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B9C15CC596E6741F3097BF6A894F268CF1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "634C02BC48BD8648943965E960B5BF4FC100"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "779D6AFF5C4FA34624593ED45832A8239DC2",
                        "defaultText": "늦었잖아?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "40E7E8F75402634348492C628396FC48A8A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EFBCB513843F142EB3B9D629F13D8569B82"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9401DBAB27C60140418AE1621CFD0A9A8CB9",
                        "defaultText": "아니, 안 늦었어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9187BE6999A788438D8B81A158061EFF85E6",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9FA19FC41C05394510883528DAB5E22204D4",
                        "defaultText": "미안…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CABB85C909C2B547BB1AC9F592033A7E0332",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "not late",
                            "sorry bud",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "E98184D784BC00492F79D6F4812C43BC6820"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7CFFA50C1A3728490D7B5BC281BF4FE7AE89"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not late"
                },
                "indent": 0,
                "uid": "82B74A737011F545E27AD992917499956CC5"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "MINUTAGGIO TOTALE",
                        "index": 249,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 615,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "51F44EE45F5666464D3B8565F0A87AF0989D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "not true not late",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "F888D0874E72E54C774B54510A0590D2FC17"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "actually i'm not -- but she's late"
                },
                "indent": 0,
                "uid": "8641A2D04A0F644C4B2A875655698FB46F80",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "49666AF39B98F14E0D083FB1E4F8EB272FFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9159D545281678400D18F5884271673E322B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D5C2D7E9ED69846E1281D742A3FD5573234",
                        "defaultText": "거짓말쟁이!{W:200}\n너처럼 배려 없는 사람이 그릇이라니 믿을 수가 없어!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0FFC90808A7D6241A168CE92ECA712EFEF8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E410D65246BF2749932B12236821128B90DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90F475271BACD340168973B6D100E101CBFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C2C269C323DF842103BAFF8853190B07C69",
                        "defaultText": "말조심해, 리보니스..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C32CD27E4CC9D94E0D88B067A0948EC5303E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4358D0C74D91547469B43C2F99F95DFB452"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            1,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BA04C6D0FF4134238587537B8B30BE6CC8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "070D876A23E5E84C202B8044829F22CF20EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9277A30C6E6883491C8AE51763C78D3F061D",
                        "defaultText": "하지만 틀린 말은 아니라는 게 싫군...{W:200}\n그릇으로서 이런 일에 더 신경 써야 해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2CB00D376AF16142BD4B73420005D423A533",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB309D5B4C6245492C4A1F68560172A7FB1D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of q1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9ABFA3EE7389E34E749A3EA40D1853EA10AC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not true not late"
                },
                "indent": 0,
                "uid": "721376230E8B344F907A2D40EFBC6666BC5B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "actually i'm not -- and she isn't"
                },
                "indent": 0,
                "uid": "0A57A1C9105592494E5B78E734BA97F68396",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B03D4EAC6FDB17486E1833F7D3DD2023F6DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A58F19DE1662F849192972194307741AD22B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B896F937127F443E00AB912BCA64BEE1E63",
                        "defaultText": "칫...{W:200} 인정하기 싫지만 네 말이 맞아."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "22E44D3E63CEB145311B4D786EF56C735B72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E19524B10F6B2457C483E5230977785A275"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9074E7B59F031945F559F307304CEC6EF5D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2CB9A5A29E3B1440330BA125ACACCBD81FFA",
                        "defaultText": "그런 수작에 쉽게 넘어가진 않아,{W:100} 알겠어?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9117605A98EBD649EF2801E6C87530ABE0E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A419D7C5F38C34F1A4858A579952DB75E33"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of q1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "D0691F461033964A000BC287FB64271BCED2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sorry bud"
                },
                "indent": 0,
                "uid": "DDB5775F8591B140A17B4D775FE65E36FF12"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "MINUTAGGIO TOTALE",
                        "index": 249,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 615,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1398D1AD195BA64FD80A9748407A41D4A683"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "sorry not late",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "893D91BA34546442734B60B4CDF69EE35A96"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "I'm sorry -- and she's late"
                },
                "indent": 0,
                "uid": "A37DD3D88039234E79299B16870F18BF6F24",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "arrogant smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AAB7E9AC4ACF544776797342585CFC105A79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABB137A3003987448E4BE9B19A8869A50821"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18DD001A476C96412B88B002B0543FDE7960",
                        "defaultText": "흥!{W:200} 사과할 시간에 다음부터는 제시간에 와!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6216C086572BE445798822E96DBEAD8A4991",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90251C5984DC2240319ABB074B2264017A1A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "977C8BB58DC7744988083044581C3C26158A",
                        "defaultText": "내가 그릇이라면,{W:100}\n백성 누구도 기다리게 하지 않을 거야."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B77876348C34224944283228BE71E7E55FC6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1613A7E2C4D524F479AF9E0DA63C7E88475"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B63BEE611C8D340163A4BB6147CBA08BC10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E99B78FA56D8A048BF391E01A42D8214E4D3",
                        "defaultText": "알겠어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DBB0F4AA9270994F125A8EB20B0C6D823328",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89A0EEFD6A3DD84BDD0835E8521F9EF22BB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "124AD4AB4CE5344F629A0FF2EA2C6CFE2F3F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA3C0E6D11271547D668C0B9057DB191C973",
                        "defaultText": "저 말에 일리가 있다는 게 싫군.{W:200}\n모범적인 공인이 되는 것도 이 역할의 일부니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E60C2B788C74634CD98A9E43768AD61A6E1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB3D21E75379C9460A49BC85E4D5DE84D578"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of q1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "8917AC586029054C955892F246C4F2190223"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sorry not late"
                },
                "indent": 0,
                "uid": "4B8EFE8936A6F4461E4BF032FA2E9FD938E2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "I'm sorry -- but she isn't"
                },
                "indent": 0,
                "uid": "C4695D6687ACE64C9A185F712DD32CDC3A43",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7322B4BD61E2E44F4C3AE1B59C787020FDFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDE815CB356188413958454903F8524E3392"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09EB888A8527D444331873387A3A76206532",
                        "defaultText": "칫...{W:150} 대체 왜 사과하는 거야?{W:300}\n그렇게 겸손한 태도는 역겨워."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "33F9CFB46E09614A059913D5A179CC3F079A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00DA09BD4861144B0448DE776B8CD3EF407F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE1EEA6E6F97474C086A3DC3B68C98F3ACC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2396BA056BB5014A8B9A0EB1C01E0AF98010",
                        "defaultText": "늦지는 않았지만, 널 화나게 한 모양이네. {W:200}\n그 점은 미안해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E9548A712BC1A340EC6A3FC4C2EC57EEFF2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8E24D26938D7141925B8204B5849328627B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C4C96D83B8AC244602AB4D3C9F0D874293E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "298C4F4E88691245BC7810D123CDAAD2FFE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "765A0888628557497D3BDA37C52B8D005610",
                        "defaultText": "그것도 아니야... {W:200}그냥 그만해. 짜증 나니까."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EAD934AE420552480F89A32803EC448071C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26D595530553224BC118DCB899E9055FD390"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "653CB00C664CD14B047A47D5F30977493F43"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "301A8E5B7380F64BD20B7F0339D2C2BE3061",
                        "defaultText": "원한다면."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4466E55F10BEF24EF83824425AC6FBAD24C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C62B72DE8B0BA54C61396415A5F9281F910C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3EDB3362EDB4349431878B84184C8F1E349"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE2F88326B84F347005883C4475686CEC915",
                        "defaultText": "늘 나한테 이기려고만 드네... {W:200}\n난 정말 아무런 악감정도 없는데."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "27F00E653C7B234ADB7A0F491003B04D42FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF608E5C4FAAA047504BD88281744CC55778"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of q1"
                },
                "indent": 0,
                "uid": "24D94B8164DDF14D6E486A3267A9E8F20BC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2CDBF283768144D236922763531B1BCCED5"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AB10125231AAE749AD5AC262776548BA2B5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FFAD954350C62433A3B2864B19FD824ACBF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "comment - end of all"
                },
                "indent": 0,
                "uid": "2A95C33363AB014C3128E8D88ED59A973073",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4383E7AD7E726443055967569503D1755BEE",
                        "defaultText": "... {W:100}됐어. {W:200}훈련할 준비는 됐나, 파라트라스 님?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7180413E7A47384318398008116A869A5B31",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9B31C554694294C8D2ACFF9D2E109EBA2CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68C3F1CC1C168542CF692EC7AB154C78776E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D7BB797583E29348AE9994A644D745AB17DB",
                        "defaultText": "물론이지. {W:200}아니라면 여기 오지도 않았어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C0C522B92967A44D3C8B49F25A5F835EF422",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F69460A3300F374D478B58C4BB1F36380CF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "720098C930DD214AB46A59D333DBD01751FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FA8DCD06A35D64D4B393FF56F55363CA35D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53772DA86071E4447C79D0870EDAC4F7FE44",
                        "defaultText": "그렇다면 그릇의 힘을 보여 줘."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "18316DAA67787448E38B6E10D6F2CA0B26F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D9C02F848E326467F1BB27767EA1720E856"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "801E02F2870A7845149A1A0489D62BBA15D7",
                        "defaultText": "21년 동안 마왕의 영혼을 가둬 둔 바로 그 힘을!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5ACB38CD8A05A146087A37C304D45D7A34F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED8FF60E3A69A342C81896E33D1AB37196A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0185F15259D85242C42BB727D8EA2664E54E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8318844E529D134F6D19EC7041ECBF791A5E",
                        "defaultText": "그걸 가능하게 한 건 단순한 '힘'이 아니야, 리보니스."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "96E9222405B971423458E1975D97DAD242CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81A66BF17511854EF71ABBA8E2B9C1705668"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C00B3470E05B840A38B84E1F4B858ABB7B7",
                        "defaultText": "엄청난 노력과,{W:150} 모두의 지지도 필요했지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EBFF113325B3A847E85922D899520FCCD0BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3E2EBBF7BF42041B33BE1B739B6FC540375"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B6D84C464A5314443494D331F6D7406E614",
                        "defaultText": "너도 이해할 수 있을 거야.{W:150}\n내가 실패하면 차기 그릇이 될 수 있는 유일한\n{SP:1}{C:1}적격 대체자{C:0}니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "956B1C9F3EFBA84F5C1A68D6DD3034117AF6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA694462694B5549835B0A943F39F303BD01"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "arrogant smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AEBB01319E75F440A68A203258C4585828C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50978CCC80A2C541C3398FF32A0BAA7E5ADF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B72EF4127E272842275BC5872A6BDDF21122",
                        "defaultText": "... {W:100}특권 속에서 태어난 당신이 뭘 이해하겠습니까, 아가씨?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9373081A1A4E564F5A7AB037D2F574FABF95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6724FB7D580EE6487B380DF28F37863B687E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "442201888BC10047273BCB56555B9B6089E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A9B787D74B371430F2BE5E8440D8C526A44",
                        "defaultText": "넌 특권 속에서 태어났지. {W:200}\n부유함에 둘러싸이고, 강대한 마법의 축복까지 받았어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "21C2D2BB5B54B0456E4A8C59B7417B673C92",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A3ADDA36FAF974D400BCC39A0FA0EBFED36"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "73BF3BD333750442A79B7AE29F6F3E64C6D7",
                        "defaultText": "네 말이 맞을지도 몰라."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "74BEF85D69CFF64B0448E36831514921F4A3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2A706691688233484F38D5E8BBD82466DB85",
                        "defaultText": "그렇게 단순한 일이 아니야. 믿어 줘."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1D7A20528A4DD1462869FAA747A38173B5C7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A2C0007124A1034E443972D7659E819B1C1A",
                        "defaultText": "너 같은 평민은 절대 이해 못 해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FD4B8E50297EE74B819B27147E4E3467E02A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "you right",
                            "complicated",
                            "peasant lol",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD92365513382245F68A5DA47D8B66D757BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "83FA154A56CD8140F749C08483C39DF93277"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "you right"
                },
                "indent": 0,
                "uid": "E7D675B23CC9A644184B9916AD1A4BB7E1A7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "1"
                },
                "indent": 0,
                "uid": "C85A43840482154C2A1AF2419F24CD6E978F",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "38D7B9BC1F010243F2290B84577B01852767"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D315601714C43469B9B0E97AE6F2EF153E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F1C3F430CD8A149436A0520B430C772BA10",
                        "defaultText": "그럼 인정하는군!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2193B0247F0A7749A80911A36CA4066E5F0F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C22455C6B61654E985836D43EBFD6E54008"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E14271BF29FAD74A743B6DF2DCCEEC61845C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7291FDD91D99E5461A982235FB02FDD86566",
                        "defaultText": "부정할 이유는 없지. {W:200}\n내가 공주이자 강력한 마법사로 태어난 건 사실이니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line35.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "26F7227A90CC434ADE48AA8181E1165D26B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32612BC06A12624EC7396F41B8916A173AF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A78FF3AC898C66489E1BA518C0CFFDB35CAF",
                        "defaultText": "하지만,{W:100} 그것만으로 내 삶이 편했다고 말하는 건\n크게 잘못된 판단이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5EE49FF21F8805455F68CD75AB4B6C4B95A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C81DF5E921B4614A947A790554BD5BFBD171"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of q2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "F6C0D26B6174C34E2978EE044E882DC28059"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "complicated"
                },
                "indent": 0,
                "uid": "336ACFC2364E574E32492B266C33F7AF8976"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "2"
                },
                "indent": 0,
                "uid": "C8F4896C8DCBB540EC3943B2D9DA65A47A9F",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "22DC1F381D06B847DD2A45D2856F6BC17D54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B73E2353553D6545B46B6EC225CCC93A71FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "563C74312EDFD74D388911C1C2018E46C47E",
                        "defaultText": "웃기지 마!{W:300} 계급을 올라갈 필요도,\n힘을 얻으려고 매일 고된 수련을 할 필요도 없었잖아."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6A9BBC5864A3A3409799FA28C9C0470EAF74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EEB21BF1039674975387B28269C042CA724"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5761806B327C1045687AC1A9A90CAF3516BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "691182C22A8E964B9A6BA396BDE500CBAAFF",
                        "defaultText": "내 생각은 다르지만,{W:100} 어차피 넌 듣지 않겠지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A1289E5178EF894ECF6A5771440C2522D0D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90A8A8547152B1458B596ED26C26822869A4"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of q2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1B65CA50295C4445011941973848D8713236"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "peasant lol"
                },
                "indent": 0,
                "uid": "05BE39562158C847E14A1C832DBFF00A9C66"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "3"
                },
                "indent": 0,
                "uid": "B669E7373F75574FB83863E5FC66FACB91B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "066AB11182D6A942F338ADE55EC810D9A95C"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "405306FD8E030849A1192036C93A4EA6CE81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6CBE6E703D286409C18C7D3B591CBCE3794"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD2655E7140198429D0B4D7765C033CCDE44",
                        "defaultText": "또 날 깔보고 있군...!{W:200}\n그 무례함의 대가를 치르게 해 주마!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line39.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E1494E884A79E54A781A0BA112A0995D8614",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3C994215B24C548753B6A27699B02FD50AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71A4895298FA22490F9B3AA2BB59CB0F4A25"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0773958A30258443159A8B31F36B49CD60DA",
                        "defaultText": "솔직히 말해서,{W:100} 자초한 일이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D1F96E1010640443F82A1126D1D8F271D5D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B81594A539D1D14BA06825E206B4CBEBA82D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7EADAA7178D4A945DE1B01E4A897AE3DDB9E",
                        "defaultText": "넌 이 대화를 시작할 때부터 날 존중하지 않았어,{W:100}\n역할의 차이가 있는데도."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "58841C173893854DC0589817A813714479EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12469A628607874AE2093051F96D90E20843"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of q2"
                },
                "indent": 0,
                "uid": "D59C74DC656B6444A17A85080AEAEB88BEC2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after"
                },
                "indent": 0,
                "uid": "337470B83F34A94BC86B24E57425FE1EB3DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC309B464C8AE5427E4AF10609FEC8319094"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84BD64DD49CC3143D539FEC2D027370647E9",
                        "defaultText": "허튼소리는 그만! {W:200}그렇게 잘났다면 증명해 봐!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B8849CFD41DA814C3A489225D3C3AADC1DAC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1CB1AB78CE7E544B858B4685E239AD09EDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D8373C8299F6743018A0A0701D93CC85FC6",
                        "defaultText": "나와라, 주술사들이여!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "34EEB65852C8674B3B8961E67468347BCEC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A615ABB03ED77644468A95163DEE1524FABB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BDAD38667EFE745A79A60804D52B09F56EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C77F38C3808BD24CF71BFF374FCB7287F285",
                        "defaultText": "저들에게도 이름은 있어. {W:200}그냥 '주술사'가 아니라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AF596B598EAE954B870AD80586A87895B393",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2420695A5501B1422E69CB72D9CFBF336BCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AC8BCFC5BF4314CD06AD348BCF821838999"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3AB0F2ED744547405279EC834590E49ABAB0",
                        "defaultText": "이제 곧 더는 내게 설교하지 못할 거야. {W:200}\n누가 더 뛰어난 그릇인지 모두가 알게 되겠지."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "11E86EDB62866642967B5EC9AB37A9CF0975",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FF3D19467E9884D47182216E68FAB397D8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29F408884D9172442B1958D83B265ABE3C49"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E753FF5C8BD38240FD4989F09F6D1B60539D",
                        "defaultText": "하아.{W:300} 이 훈련은 조금 다르게 시작하고 싶었지만,{W:150}\n어쩔 수 없지..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0C1E80E5757D4743547A8227F2A5B5955F2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DD3C16241096274015596F72D8DA64812E7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5106ACA2FD69543CD79D423B3772222D29B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50B127539CC980455758E482B22E7C31EE98"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "412AC1799361F64C8E98FB56155042303DFF",
                        "defaultText": "간다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1D6255A96C94A348B09A5E88310B2145762B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C4C0A34C13AB344508787975AC5E631847E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5C01E8D678398141C5299F04FA7F1E9F1435"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E7C356B87242047F91BE4C7452E357E2856"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F04CD2B1C3A844A38296666E61BA16389D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88D606723AF5A546DD282052902EFF1FC70C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Ragh",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "07211D485000E040BF5846B2B835CD19906C",
                        "defaultText": "Ragh"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "78F72BF744B0F94D7F6BA131CDE81D149A9B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Nasca",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B028B0178FF4D149A2792B50463CD218C0F7",
                        "defaultText": "Nasca"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1A1179F784893748086ABC2203A5778125DD",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "26C981D68B9CC140E49BD5B7ACA9EB06383B",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Ragh",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC65F6491E14C044976869A05B2BFF2F7590"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D9E9D4874BAE2844FB8848A58B6F7FF54EB7",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Nasca",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FECB78196325B44F8C1A8A520A1F7975591F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "BED5FA484575634D5C8B80F3980D8CE07638"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "33B26DBB1C6D07464D897F43BBE8AE4E03E3",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1400,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "A0484E3D1019E746A6889C3232ED18A2870C",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "57ED412098A836447B1B3BB34481DCA34614"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 0,
                "uid": "E744AC1C0238D447AD6A59D1F1419987D148"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "8C55586D0AE22841E57BA9035ED9F0829165",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "53F0C1747E1505411A7A45B6389935454918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            "26C981D68B9CC140E49BD5B7ACA9EB06383B",
                            2,
                            2,
                            "D9E9D4874BAE2844FB8848A58B6F7FF54EB7",
                            2,
                            4,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "D6F767E57EBE46449E895730A110B50B6065",
                            "Graphics/Avey's Battle Backgrounds/Training Grounds.jpg",
                            "0130AF490DF5934612891A4097CDBEC27118",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "48CE554C0F1D894AEF7BBC32D4001A1A13FD"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "D6F767E57EBE46449E895730A110B50B6065",
                        "name": "NORMAL BATTLE"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DE866DB16262454F8E6A1059ED0EEE566528",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "@@@@@@@@@ BATTLE 2"
                },
                "indent": 0,
                "uid": "A501DF1974E965461A8A992595170E0A5A0A",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "2D5C40B54FD419446468AA0176B45BAAC7FD"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "23BCFB641BF66346B24A51E97BE4EEE07421"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "A25D0A14145E3840971A72903D501DDA0AC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2245410872378649D04819B15F182B4649DD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "40C254BE459C274C4B4927E976FC7C605189"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B3496CB36DC68441210AB47698477E0196D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "160B15B35617A748764A6EA6A79638F069FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3CC25905A64B24F8E1BD49869A0F06CA356"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7737CA123E07A440805AFDD729059FDDC74A",
                        "defaultText": "음...{W:100} 그리 어렵진 않았어.{W:200}\n그래도 나도 무사하진 못했네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7859125280D4441B87827B56B3C9252CCCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4132BE6819C414C3A5BF2F73A03C9B52DDD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4056F041FA4C0416139CBC2BC4B9171C9E2",
                        "defaultText": "마리가 준 물약을 마시기엔 지금이 가장 좋겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "227F5E6C7376564B6A285B1646C4FD8044D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88E3B4964C965946E24A9F4756603E2C709D"
            },
            {
                "id": "gs.FlashScreen",
                "params": {
                    "color": {
                        "red": 196,
                        "green": 255,
                        "blue": 177,
                        "alpha": 255
                    },
                    "duration": 45,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4A09CB8F86D79547E6897418FFC268D93390"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            0,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A7CDC341F21F442BD1B94826AF52F43A9DF"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "HEALING ANIMATION.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C82E2F103DBC054DC368401938718551CF70"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "0445DB3529B2474F0B2A8F75CACAFE98ECBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1FA5A26175115741E67A57E056B51E86205C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0A3E93113455440287BE695A0C6EC2BF818",
                        "defaultText": "벌써 훨씬 낫네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2BAB28075CE0B344E8397C47BEC4BFDE0A73",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "609C04EA3AAE054BE21A5037EA9AE1105D08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "0E8B77714E18674091382BF1F3FD1D87C7DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "58CC8CD74B03444D1558BAE94C879EE7715D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE7C725042CC0440AB0B55F21761A0CCEA9A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "AD4B5DAA8D20C64CFE1ADC3097C2A2FFBCED"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 100,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 299,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 51,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "2584E26A126127434D88C0E784416396063D",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "F19815BD4932034B6C3AE1B87A0659128A46"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "120EB45D6D8DF74F23286042065DCC39E798"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 51
                },
                "indent": 0,
                "uid": "D3E11AC47711464768794BE8F3C678380A92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7E20E6461E7A734B777A18961FC132771A2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C357FA574721044FB17BE626DCB939132194"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D89B156B3E36A54146597EC8C046BD092DDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA828AFE54B8D7460C6817F75752BB2BCD83",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AD18104717D85244C69B5F05ECDB82EEB25C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E6D3ECAA827D214EB61A4985472E4E0BCB3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FCB38C542D41448CA78DCE6B669F8D29ADF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3929F3D83B6A2148B46B1753A9F42E0E7957",
                        "defaultText": "이럴... 수는 없어!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A6C771C3B55B24FD64A1AD3651AFEE18D33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70751DF21222214DBE0BBBC851313F176010"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C23EFF4A1B902843946B35D174676BCDC446"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99876AFC7F7DF14AA509A58645748D32F697",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line32_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "47F3BD7E291D56414B1B8935D5A9C16A0B82",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C432D89E9CD868455858CE166A200B5542FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "685727416620B641434AAFA6A11713B4FA5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FAB289EE4A3FD3415189BAE70A92C324A6A2",
                        "defaultText": "이 훈련은 예비 그릇인 너에게도 도움이 되어야 해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "62A93A6354DFA4445D0B11C3F8465045F2B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9445B5CB4CB1164E65289AE8A9CA6F41F418"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "664D0284347B1345E05B2954D8FDE6A61C6E",
                        "defaultText": "그러니 그렇게 패배한 표정 지을 필요 없어.\n차라리 함께 훈련하는 게--"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "422BDDE3693B014E984A3E43674A3381974B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AEAEC0A196AC24F122906018870A18E1332"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A38798B84DEE794AEF396E83315CC0F3C753"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7B0293B06480E4438F18A158E5FAFB344F08"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5EADF3397A7784439B1A4F260CF059A359C7",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "06B34FD536EE844A21984822A69659E5D21B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "35D422302C0FA8489B9BC322D1959BB5AEC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66C2118344ABA24AB2681D582FD1B7D123B8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 24,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7EFC48FD3B73E24E32190F381C6749FF89F1",
                        "defaultText": "거절한다! 네 방식은 마음에 안 들어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA33DC265039D649D22A0BE2C1A4C46EDE14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BAA3F53466B67455F284E13B98E481F5C75"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "09E009EF3DAE004A3F2A3A121B2142F4AB3F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F8A34D153EE414B0B7986789D5693BFE294",
                        "defaultText": "네가 그림자 마법을 다루는 솜씨가 뛰어난 건 맞아.\n그건 인정하지."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "938738D13ACFB84EBB6B94242D56A0FCA0BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0629F07B3CD063433349983441A4579AEFBC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D6520C039F7A542B609ACC7101BD19AF5C5",
                        "defaultText": "하지만 정밀하게 제어하려면 시간이 많이 걸려.\n뛰어난 공방 능력을 얻는 대신 움직임이 느려지지."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3E9235E9645B10419B689599DBD6C7805F2E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "147B63AA6455354BAD183FC8B726B6A2D6D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4F83A493B14F84EAC19C8174C0B28B51B33"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4C1F8CA82F523496F58525050472396D039",
                        "defaultText": "거만하긴 해도 그걸 알아차린 통찰력은 확실히 있군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E4546F4B5DC036491C6931A5C91E7EC4A63D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89E1D2A36955F54CBF1B883446800DBD14B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34B251BB82F23841A519FA95E4B184C39AD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9D26D044B3D7646DA9B9F60B782D5CF0FB2",
                        "defaultText": "맞아. 그래서?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DCE0023C5AF25745A38AEB329C28052EFA89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA109A993528A3417E7BA8F0551A59FE7148"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "arrogant smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "649349DB03EE324698582C428722E8D00ACE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BAAA1DB538968648C1682B71D9B55105C1DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AF9935C525EE8490669A3072C57AC36C407",
                        "defaultText": "그러니 수많은 적을 상대하면\n네 마법으로는 따라잡지 못할 거야."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4F08ED4383F2244ED449E0C608D879187B30",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC3908139338D94A257B4A35A8EC83E49888"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E958C782326F0641722AF118B147FD82ED4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0BD35B15532F904F7B8BEF586091452D9748",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line10_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5B031C8743698248A95B7BE61015BF743BE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1C6E13AD7166C74FA15A6B071B1F176F8435"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86B8CF2360EB874A938A93C62EA460700807"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BAAC8A937644C14E97487965B5670ECC49F7",
                        "defaultText": "손가락 하나 움직이기도 전에 제압당하겠지."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A15AAF76EFD504554482D702042739934AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D471206126BFF0493D6B45452606DF4AC754"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6DCD59B744F4448DB884DC3C862A0DAECE9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0B48011284CE98401D192FD4D1C6944D4F11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA6EE0E84005B04F1C398B81A1F8A5315936",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "82B3959C6CA4F9449A3B0D3129BE1AF7CCA9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "34CB2FF69660F44A649918B8203A52EEFB77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12DAEACA553A774C5B796C24019A46C1D662"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 21,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7C5CE5D786565457B6AFA9349F1FD8FE974",
                        "defaultText": "내 약점은 잘 알아, 리보니스.\n그래서 제대로 된 해결책도 마련했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F67B01CC7019F243E95BC29271FB55EAC538",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E803F3DD206D8245ED784CF79092B4D1A8A5"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "DE4A3D7C57BAC4432638EA883F134CD6F2BF",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "A4EE645063F23441146B3F06BE3DB1AA2971"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 21,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA3C6A376DDAB343DA09D92080C3F820C965",
                        "defaultText": "이제 {SP:2}{C:1}네레기스{C:0}를 시전할 수 있어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "701266F974DEC247D45A873996D9AD67E4DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B9DE3BB1904264AC44ABA175ECA0A664E0B"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "93BA75F38910464A577AAC949031A33AC737"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "CFB3C68A4D970543000B9A39B25674ED7FEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E8E892DE8546C54931989788D88BB944F0E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B975E987E56924B167831518E6F79ED53C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FFB293B66057742CF68AB94C1513BA79103",
                        "defaultText": "... 농담이지!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DBE0BA76157D46451B6982A275414C3E9B7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "529E03C08FF5B347B069B962875D5655B646"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31749A3588E138473A592202A166A601B38F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33587CFF2A1B564F458A7142A5A9D8E18B00",
                        "defaultText": "사실이야. 원한다면 보여 주지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7677ACDF8F39434F6D5AF06384E58124EBC8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD4935FA2F864147AC6B3CB521AF907599CB"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E63DAC072A2057422B2953440F060F908A2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F227973043621448FF1B1C863DD73F2BF6B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09BC62AD7692C3477A4B67896D8C39219C6A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3DC423DB29E3F645AB19A9D8229DC532CA54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "538D2BF38A36554627995BB7067E90D0AB11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C034B4C3110774CA8183DA404E5B8DAD211"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9E0BDB191BA8A94D402A7045344AD329F0E3",
                        "defaultText": "허-허세일 뿐이야. 2차전이다!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3007294B7DED9648397A88996486A67B446C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5D7B82AB00396048DC499AD7F0BB4A6540C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73DED6EB1352B5479C3B21E8644E9F5A499D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D8FAD9CD0166A7422D99B5D5AC4D8328F121"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "45FC1D2E0D8EC942EB4AE84674D27B24CD04",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E2-Faratras_line3_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "72B3565C2E1CE348A67A16F3C54A0FC442EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BEE4ADAD3B97014BF92B60E4C16F38F0B98A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "953F59C735153849A18B20248B3FE72EC9ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "143A4C1529A4D846E96B2463F5A5CAF552A9",
                        "defaultText": "각오해!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E075935287D886402B1B4876BEC34D9E2FCE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A1FF0A6B6BC0094A2089C13297E5041D6047"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4D0806078FE366423E194EC5D87377869976"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82283F67560D4643BC5AA16569AE0FDAB715"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD1413FD45BAD1413B4A48828BD4E8EA709B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Neaw",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5718D71A0C30134E4A6BC240B42EAA128B31",
                        "defaultText": "Neaw"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A940FD474C318648F39A83C2CCC0B19E206B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Nolk",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6AA9E3068FFD524D112AFE737F8040C651B1",
                        "defaultText": "Nolk"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "874E4803823D5640AF7956660BC6793D1AD5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Roger",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "396C727C76DB304D2879F800AB5B378175E8",
                        "defaultText": "Roger"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4D11AC608F86074E855B1257F07D8A7D453D",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "26C981D68B9CC140E49BD5B7ACA9EB06383B",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Neaw",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7E3B165E3A706346336A4D491F5FEA913199"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D9E9D4874BAE2844FB8848A58B6F7FF54EB7",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Nolk",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B63773CB4AAFF141611AB4E2F7DF006B933E"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "987DF8C62383324E6D6AA765AA1ED7E2AB43",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Roger",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4850B33759C7E744345998000D6F48202B7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2A71BBA83C1F64E9C5B1E02335E1E43ED4D"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69A7405D8EC4844D7A0B9D14D4FB72BCBDB8",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "4A4078B93964524CE5188BF8F8B818140351",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5D541CD63EDB984631798294A40B5BEDED97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "8C55586D0AE22841E57BA9035ED9F0829165",
                            "74EC1552250B024E480B2150C2EFA1E1BB7C",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7A858AD9845C794B5668C1E4BBE95D915C11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            0,
                            "26C981D68B9CC140E49BD5B7ACA9EB06383B",
                            2,
                            4,
                            "D9E9D4874BAE2844FB8848A58B6F7FF54EB7",
                            2,
                            6,
                            "987DF8C62383324E6D6AA765AA1ED7E2AB43",
                            3,
                            2,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "D6F767E57EBE46449E895730A110B50B6065",
                            "Graphics/Avey's Battle Backgrounds/Training Grounds.jpg",
                            "0130AF490DF5934612891A4097CDBEC27118",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "81C16B9F85087142CD7B7D408649530F182D"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "D6F767E57EBE46449E895730A110B50B6065",
                        "name": "NORMAL BATTLE"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B08269F14301344F1398F4C4BDA5998E33FA",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "88C314A90A8A994CB02942F818D33226767A"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Neaw",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "016E6CFF7811054CF059A1320882217786E2",
                        "defaultText": "Shaman"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "39BFB2B96971E24E93894D9473A0FD6D54CD",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Roger",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "565AF1E44EAA774A5C1915642FB047E7FC4F",
                        "defaultText": "Soldier"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "55992B93050F7245F0080A1520C3553DC999",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "26C981D68B9CC140E49BD5B7ACA9EB06383B",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Neaw",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A0C2E4887053824F76899A2796F29E7844CB"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D9E9D4874BAE2844FB8848A58B6F7FF54EB7",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Neaw",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7E97974905EBC347BC6A3C962724C91CA6FC"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "987DF8C62383324E6D6AA765AA1ED7E2AB43",
                    "param": {
                        "name": "Enemy Name",
                        "type": 2,
                        "value": "Shaman"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Roger",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDA6C57949DF324E1F5941695A2CD29995DA"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "F57622BF9FEBA74C4D9BA687ED8FD59EE2A8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "51BA425F1C2A1242340869635E48E303CD8D"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "CE6FC2231EEA124BA3486C33A50532B05547",
                        "name": "P2-03c After Battle 2 (Meet Alvano)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9BAB7FD04BE2074A85891551CAFDE5B9138A",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}