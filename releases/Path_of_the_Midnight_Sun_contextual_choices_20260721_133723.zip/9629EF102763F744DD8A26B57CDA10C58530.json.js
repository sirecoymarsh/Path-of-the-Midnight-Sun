GS.dataCache['9629EF102763F744DD8A26B57CDA10C58530'] = {
    "uid": "9629EF102763F744DD8A26B57CDA10C58530",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-03b P1 Hellios",
        "type": "vn.scene",
        "parentId": "16C7E427301522454D296B1387EED05F3809",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 0,
        "localizableStrings": {
            "55922BF28D10E74E269996F6FE665472974C": {
                "t": "... Do you have any business with me?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "482E68FE41E2F74E5D3A56E87B6C28B74183"
                }
            },
            "54A58F7D8AF2B94B0E9A3F267142303C6C17": {
                "t": "Huh, no, it's just that...\nWell, we've barely spoken since we met in the forest.",
                "d": {
                    "cid": 0,
                    "eid": "8EB4C41889FE174B02196B74BF3483D14F58"
                }
            },
            "55ED02133012224443498772A63FCB707F94": {
                "t": "I only speak if strictly necessary.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "1E20E02B1A7C524A1B988D8709959D548C06"
                }
            },
            "A98D4A1D6C2E424C879A82979276453675D2": {
                "t": "Wow, you must have many friends.",
                "d": {
                    "eid": "3EBA3285039D1042D578FAB494F32A554173"
                }
            },
            "13F9283150CF1448714A1CD31A124CD1B1F4": {
                "t": "Understandable, goodbye!",
                "d": {
                    "eid": "347867FE4299D44F413B4871F96CDCF10B0E"
                }
            },
            "E3FDEDDE824BA545F03B1425B8B4F5807E55": {
                "t": "\"Friends\"... That's a word that I haven't heard associated with me for a long time.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "0D79A68A51A0A7425B7B6E442C148BED2BFC"
                }
            },
            "AE38ED3A9B77774FC7795DE90AD28E95F0DF": {
                "t": "That... wasn't the reaction I was anticipating.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9115699D195CD244E82AB95982DCD26D26FC"
                }
            },
            "A50F14587D03B7442C6AF95115C90006CA99": {
                "t": "Don't you have any friends? Or family?",
                "d": {
                    "cid": 0,
                    "eid": "3A441A936BDD554FED2A0B9687ADA94B32E6"
                }
            },
            "045E0DC41FB7114CD1487B06C352949AFBDA": {
                "t": "Aside from Lady Faratras, no.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "0A72E2B85242404076293D016763A07CA555"
                }
            },
            "B2E116477DF1C7426449B546F547E2A79DF3": {
                "t": "Why did you even come to talk to me then?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "1C561623001EB746E95B29E48C8CB95A7F06"
                }
            },
            "96A98C471F4A7142174BF28616915AE03E71": {
                "t": "He does have a point... Better think of another topic.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EBFA6F7B2573634DDA3AB4D16BC29C25D46E"
                }
            },
            "D13B832C7184A24A1188DF05FDB809276E2F": {
                "t": "Umh, what's your relationship with the Vassal?",
                "d": {
                    "cid": 0,
                    "eid": "4F11519962A11548EC68B8B155A5DD09E187"
                }
            },
            "2665DE8F9E29394C9928C1B486F0C6F7862C": {
                "t": "... I believe there's no point in hiding it from you, since it'll soon become common knowledge among us.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "85C3EA93671AC741491A56161B8864CB0BF2"
                }
            },
            "599EF2B5776BE4426C9B1336D1C617394EE4": {
                "t": "Lady Faratras is... my half-sister.\nHowever, we'd never met before yesterday.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "9106ED1F77EEF84FD849BB686C6CA732CCEA"
                }
            },
            "A89BC53472FDE645699B1BC46F4BDC57D20C": {
                "t": "Well... you do look quite similar.",
                "d": {
                    "eid": "277F20C1751BC9452D39A6D0DA1D9C7159A3"
                }
            },
            "E0346E396F804742C659AD386A392D98CA49": {
                "t": "You both have red eyes.",
                "d": {
                    "eid": "E9C63CCF4AD3D8463779CCB16A160DDDCA63"
                }
            },
            "B3EB0B531C7564444A899238BE26F1F356F3": {
                "t": "I could never tell!",
                "d": {
                    "eid": "4741F3C57693F5423D581391CD3C09D19B85"
                }
            },
            "708B986E7CEB8642C99A66899EAC8270FAA5": {
                "t": "You think so?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "1B88104B830298428189A51078835D3BB652"
                }
            },
            "80AD311B90729344718BE710987019CBBD87": {
                "t": "You don't like the idea?",
                "d": {
                    "cid": 0,
                    "eid": "5F143E966C188847668BFAB50DD233720E8E"
                }
            },
            "705FE01149974842415A8F142B40CABB251E": {
                "t": "No, quite the opposite. I'm relieved, actually.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "CF35A1219483E74CB42BA7F4DE90A36C43A7"
                }
            },
            "93E7760E20B1764B8F59C412B2D53E1E009E": {
                "t": "I suppose that detail was quite obvious, yes.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "FA414F8E17A93641EE3B2FC56EA23350CECB"
                }
            },
            "8CF920321AFA6149A598F9196B2867F90FFC": {
                "t": "Although, you'd be surprised to know how many people aren't aware of the meaning of these red eyes.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "6109217B593C3743FC3AC562B55029B5CFDD"
                }
            },
            "D5C095847C9382466C0867C7B2F1A0D33BD7": {
                "t": "Hmph. I can't tell if you're serious or not.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "0BB6BCBD8AE4814AA02B7907880E24CB80BA"
                }
            },
            "7FADA44D1E3AF845275AB487C1EB2A568FB6": {
                "t": "Either way, I think it's good that you two finally found each other. It must be awful not to have anyone in this world...",
                "d": {
                    "cid": 0,
                    "eid": "719335CF2259574A412BFCE1ECD0025AF48F"
                }
            },
            "EF54D9807BD65240C57B9CD9E4092B5CBA18": {
                "t": "Are you talking from experience?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "2D720A8372737843356A91B4FC85700C4B1C"
                }
            },
            "A8C2769027A7E6493988D2A626D57A85FBDB": {
                "t": "Well... aside from Shiori, I don't have anyone either, now.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9AD6DF4171FAB54F07881BF359263C3FA6BE"
                }
            },
            "61671A0664B3164B06184675B91FB2E50E00": {
                "t": "I guess so, yeah. That makes us more similar than I thought.",
                "d": {
                    "cid": 0,
                    "eid": "2E4C46B9398D4441D74B2C1535B64554DCAA"
                }
            },
            "4FB226042881F44EB64B0DA3A7EADDD3DB62": {
                "t": "So it seems.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "D04AF16D46AB184CAB28DD92F0290B475208"
                }
            },
            "1BC7A29D179AF44807197FB10E7B6B14BF68": {
                "t": "Let's protect my sister-- Lady Faratras together, from now on.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "9FA2B66D605BA245A788F0B297A06A1ADA3A"
                }
            },
            "83C5B2CE109D664D189AD1D063E90EBCB8DB": {
                "t": "I'm still not sure whether I should protect her or not, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B9751F93137BE2445E88CD782FA1718D81C9"
                }
            },
            "5BE2CA614A973747D93BA9F14998E38755BB": {
                "t": "Sure, that sounds like a plan.",
                "d": {
                    "cid": 0,
                    "eid": "EE25AFEF7A2F57437C09A634C59C73D58569"
                }
            },
            "21689EF8037861479C9B71437C3DEE0F56AD": {
                "t": "Great.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "71FCE921696C91404929F1C479FEA03B3CE7"
                }
            },
            "38CFABE041D27841B53BFA934A797D969D80": {
                "t": "Hellios... he's a bit gloomy, but he seems like a good guy at heart.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "51B4F4C04F2E27410C1A5DE9E84E71805A01"
                }
            },
            "6B5CC4A6159C76484C98E917F02299C5559E": {
                "t": "It'd be nice knowing him a bit better.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F0001D514A3FF1412F68FB4555D922DD9F1D"
                }
            },
            "31773B308F54F74C850A06A1CAA5185B15AC": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "338168433B2E51439209CCB0E53FAFF9EA7A"
                }
            },
            "3D4829E68235424A330A5EA484E7375B524F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "70A3EB543619A44F321BC161DF18A5464278"
                }
            },
            "357599FF634E974103280038233CF641F5C4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1BF6CDF29BC48642BF19C8F697A364FDF1AE"
                }
            },
            "C5C59EA07AB87843EA893CC414031EFB3E66": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "590ACAC27DD8D447728B0FC61588706CE5C2"
                }
            },
            "3F8B6BE060A93544084B6BF0BD138BFAA25E": {
                "t": "Well, this has been an... unexpectedly pleasant conversation.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "342481BC9A61E34BC539E527413DF77206F4"
                }
            },
            "CED0CAB727DED64D507AAB7822125EB4C06D": {
                "t": "Look.\nThey're coming back with the empress.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5B1EB4006DDD71473A1B3691D211C1378DFA"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "3FB925066417E54FFF48ED661AECBDD44D90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "171BF7F884F0F94C4F38B2445B903B8E3D60"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6DCA12E81B1CB44331285567D2682D12EE4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            500,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "786113E251E2C04A3159EFA10AA1068AEB6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "332306EB2859924A602A6E832AE1DA792852"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A333FA94805519426C5B277205219AB8BF00"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31773B308F54F74C850A06A1CAA5185B15AC",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "338168433B2E51439209CCB0E53FAFF9EA7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "89B2B52D29587448EC5A682249D26C4A8B08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "808FC04059730740374A6846426C43731ED1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "55922BF28D10E74E269996F6FE665472974C",
                        "defaultText": "... 내게 무슨 볼일이라도 있나?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "482E68FE41E2F74E5D3A56E87B6C28B74183"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16FF231872B8F142F44A7574723F84CD000D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0993B60B8057F04C241B79C9ADC0BC5AAB3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54A58F7D8AF2B94B0E9A3F267142303C6C17",
                        "defaultText": "아니, 그게...\n숲에서 만난 뒤로 거의 얘기를 못 했잖아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8EB4C41889FE174B02196B74BF3483D14F58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C151308734F7D14F7C7AD5F7E900C85B17A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B30592055A73034212884505E6AB1D53516E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "55ED02133012224443498772A63FCB707F94",
                        "defaultText": "난 꼭 필요할 때만 말한다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "1E20E02B1A7C524A1B988D8709959D548C06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBAA553319ACF546048A1B827384345365E5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A98D4A1D6C2E424C879A82979276453675D2",
                        "defaultText": "와, 친구가 참 많겠네."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3EBA3285039D1042D578FAB494F32A554173",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "13F9283150CF1448714A1CD31A124CD1B1F4",
                        "defaultText": "그렇구나. 그럼 안녕!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "347867FE4299D44F413B4871F96CDCF10B0E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "friends",
                            "bye",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F36D448F829AC3487598FD44A7B09D46B889"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "84CB0E186036104E0C1A47C8C5C55E5EEA28"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "friends"
                },
                "indent": 0,
                "uid": "D4183B683A4311495A199CE39849D3C7DAE6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ sarcasm"
                },
                "indent": 0,
                "uid": "6BACD36F3DE0134A783896F4D546DDFB8739",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90950DB84D4AD641EF881B073C7CF304DEFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "948515050122734A1E6A9367F5A81C553B36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E1C308D7CE373470C0B06E525FB92840EA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "64A9ACD23395964B3608C0B5D962BEEAB10B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D4829E68235424A330A5EA484E7375B524F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "70A3EB543619A44F321BC161DF18A5464278",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "41C56D2F3E458242213A8934A4BA9A2F0B56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AE21DE368FCE24406683B0085C82BC71238"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3FDEDDE824BA545F03B1425B8B4F5807E55",
                        "defaultText": "‘친구’라... 나와 엮여서 듣는 건 정말 오랜만인 말이군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0D79A68A51A0A7425B7B6E442C148BED2BFC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4674C4C60DE9E44E4B993484066D923A0600"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "379901718D2A74437C689B23D8D38CA16392"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE38ED3A9B77774FC7795DE90AD28E95F0DF",
                        "defaultText": "그런... 반응은 예상 못 했는데."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9115699D195CD244E82AB95982DCD26D26FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE36C1FB870B57467F4BEEB311E8CBB2DD0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DD34F5A1438A64AB37A4092B9ED31D735D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A50F14587D03B7442C6AF95115C90006CA99",
                        "defaultText": "친구나 가족은 없어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A441A936BDD554FED2A0B9687ADA94B32E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A74783321CEB404CE66862983317F9B37832"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48B19AE573EDF045152A17E51179C201E486"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "045E0DC41FB7114CD1487B06C352949AFBDA",
                        "defaultText": "파라트라스 님 외에는 없다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0A72E2B85242404076293D016763A07CA555",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "AA61CA0F18CE75402A081BB3079AE073E1E6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "bye"
                },
                "indent": 0,
                "uid": "B89E83B0225CC849DB7BD505DD8D33402FD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            1,
                            0,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6D306EB1737D8467F7B0C66925E996C7EA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90AA3DC153E4D14612282C88B9EB36E92579"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14E96B105604A2481628CC6219A201F2648C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D23EABC6E9CE84EC03AF897282BD5C5BC2F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2E116477DF1C7426449B546F547E2A79DF3",
                        "defaultText": "그런데 왜 나한테 말을 걸었지?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C561623001EB746E95B29E48C8CB95A7F06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA1D154F30F5E245A0185FA2AB5153A4C5DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D297F66745720452A18FDF01AFD90189285"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96A98C471F4A7142174BF28616915AE03E71",
                        "defaultText": "맞는 말이긴 해... 다른 화제를 떠올려 보자."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EBFA6F7B2573634DDA3AB4D16BC29C25D46E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C731E659402842431B7A54428A8FE474C824"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of choice"
                },
                "indent": 0,
                "uid": "15FA154E7CC157446E485E43A8F65E18B13A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7DA0E3D132B9424311283C484F3F3AD5D993"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0636E99E8DC5734BB68883803E76B010CE58"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D13B832C7184A24A1188DF05FDB809276E2F",
                        "defaultText": "음, 그릇과는 어떤 관계야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4F11519962A11548EC68B8B155A5DD09E187",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE14F49685633340707B14E1E6E3BCF1A5CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8D6D4A833D9F64F32282D58D51F64A798B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2665DE8F9E29394C9928C1B486F0C6F7862C",
                        "defaultText": "... 곧 우리 모두가 알게 될 테니, 네게 숨길 필요는 없겠지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "85C3EA93671AC741491A56161B8864CB0BF2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E48CE781A060740F01809A4A7949ECB2911"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3767CE7197AA24E766B7146A30A6BC0B841"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61AD06D28776E544F878960959C59C2B1118"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "599EF2B5776BE4426C9B1336D1C617394EE4",
                        "defaultText": "파라트라스 님은... 내 이복누이다.\n하지만 어제 전까지 만난 적은 없었다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9106ED1F77EEF84FD849BB686C6CA732CCEA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCE11B513ED63049540B109870BF2A9062D9"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A89BC53472FDE645699B1BC46F4BDC57D20C",
                        "defaultText": "음... 꽤 닮긴 했네."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "277F20C1751BC9452D39A6D0DA1D9C7159A3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E0346E396F804742C659AD386A392D98CA49",
                        "defaultText": "둘 다 눈이 빨갛잖아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E9C63CCF4AD3D8463779CCB16A160DDDCA63",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B3EB0B531C7564444A899238BE26F1F356F3",
                        "defaultText": "전혀 눈치 못 챘어!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4741F3C57693F5423D581391CD3C09D19B85",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "similar",
                            "red eyes",
                            "never tell",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "939EC2891775A648F7480396984E3B51EB36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "88F79EEA03BAE3465C58B8B074A4401C7B67"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "similar"
                },
                "indent": 0,
                "uid": "CDABDD1308B2E446A14A16878CFE72089631"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "46DB1DB81EC01642D08B252339D686060BCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B00C319D6567B447056A6398FE80E99E9901"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "708B986E7CEB8642C99A66899EAC8270FAA5",
                        "defaultText": "그렇게 생각해?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1B88104B830298428189A51078835D3BB652",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59C196182BFE074A6B68019582F58FB712E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69858AE830EBE44D3F2B2C437FA0F4A61AE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80AD311B90729344718BE710987019CBBD87",
                        "defaultText": "마음에 들지 않나?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5F143E966C188847668BFAB50DD233720E8E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8287601B11BCD94F43891FB79731BA287453"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "112892F24C9663447E387E06C56CAE137137"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "66A0033E27ADC242AD88184145F3448CF87C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "357599FF634E974103280038233CF641F5C4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line23_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1BF6CDF29BC48642BF19C8F697A364FDF1AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "29F8303E712C8948B39834C69FEC9852D313"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "185EE8D435B6C341A0982938596EB88908B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "705FE01149974842415A8F142B40CABB251E",
                        "defaultText": "아니, 정반대야. 오히려 안심했어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CF35A1219483E74CB42BA7F4DE90A36C43A7",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "3B5F85567A5B254DB08A92572BA3E515FAE3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "red eyes"
                },
                "indent": 0,
                "uid": "3F96EC1D4AF16945E0280BA733C571287B2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "76620EA7557C434AA07A92100ECE77D979E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55099AC71524C245AF393896870014D52EC8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93E7760E20B1764B8F59C412B2D53E1E009E",
                        "defaultText": "그 점은 꽤 뻔했겠군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA414F8E17A93641EE3B2FC56EA23350CECB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "207FE1CE252AA74E2D5BBDB128A62C62EC88"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8CF920321AFA6149A598F9196B2867F90FFC",
                        "defaultText": "하지만 이 붉은 눈의 의미를 모르는 사람이 얼마나 많은지 알면 놀랄 거다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6109217B593C3743FC3AC562B55029B5CFDD",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "88BEB91201441244394B486015829E998D75"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "never tell"
                },
                "indent": 0,
                "uid": "FF8C84EA0ACE184CB4191E76DA97F8A0479D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "24BAEC3E7F6AB240985B7B450DD7E0041893"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B307C67F41248546E839D1417ADDB2392EC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A5753516B649242EC099FC867AE59934F71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5C095847C9382466C0867C7B2F1A0D33BD7",
                        "defaultText": "흥. 진심인지 아닌지 모르겠군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BB6BCBD8AE4814AA02B7907880E24CB80BA",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of choice 2"
                },
                "indent": 0,
                "uid": "DF7DEF2F70F22141AE983991000499B86EFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A135662933D1E544F12986021796B5C46FF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AD319BF59C29B243B1695035BCAE368D2084"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5C59EA07AB87843EA893CC414031EFB3E66",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line30_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "590ACAC27DD8D447728B0FC61588706CE5C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DE5681B504488448983BB4B5AEB0ED86BA5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A91AAC0F1C3201482148F237DBDD49A8A601"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FADA44D1E3AF845275AB487C1EB2A568FB6",
                        "defaultText": "어쨌든 둘이 마침내 만나서 다행이야.\n이 세상에 아무도 없다는 건 끔찍할 테니까..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "719335CF2259574A412BFCE1ECD0025AF48F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3C4017047AAE34E1199AAF4D72AEA64A988"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A808D019422D24C9E6B44D127F2D7BDAA4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "872EC9203601554F1A499494E287BB39484D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF54D9807BD65240C57B9CD9E4092B5CBA18",
                        "defaultText": "경험에서 나온 말인가?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D720A8372737843356A91B4FC85700C4B1C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2243B1FD7CC877426858BFF37F11D252861C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C81E54B6EE55040114A5A3222BBDEB9A19B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8C2769027A7E6493988D2A626D57A85FBDB",
                        "defaultText": "글쎄... 이제 나도 시오리 말고는 아무도 없거든."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AD6DF4171FAB54F07881BF359263C3FA6BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E640B6B2102F73438E1B649327BD0637F9AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD4BA4767869A54199599C76FC8B778A2C2E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61671A0664B3164B06184675B91FB2E50E00",
                        "defaultText": "그런 셈이지. 생각보다 우린 많이 닮았네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2E4C46B9398D4441D74B2C1535B64554DCAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A8A8ED77E2D65435878DAE464468A4B13A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BBE7DDB6C2ED74F03398915F255A77047A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "597D88EE65F0284ED369AEA7475C50FE4732"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FB226042881F44EB64B0DA3A7EADDD3DB62",
                        "defaultText": "그런 모양이군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D04AF16D46AB184CAB28DD92F0290B475208",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "294AE6294446B64DCF78B4C2F6C7590E97CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F959299B762FD34AE06B757845257FE68001"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "5547CE876E67394F826B4C86C36E5AEA3E0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D77C64C68CFA17410278C8F0B6562A5B8BC7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E67E5265E719248067A4880B5B54E624EF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F22027F97F5677486269764269BA82970A17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F8B6BE060A93544084B6BF0BD138BFAA25E",
                        "defaultText": "음, 생각지도 못하게... 즐거운 대화였어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "342481BC9A61E34BC539E527413DF77206F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2D26A370D33D140BB890E62DCCBE5B73BFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BC7A29D179AF44807197FB10E7B6B14BF68",
                        "defaultText": "앞으로 내 누이... 파라트라스 님을 함께 지키자."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9FA2B66D605BA245A788F0B297A06A1ADA3A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB2813AE380019466A7A843584A71C542588"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F22529511B76C341227AEBA1A789A8B7D6CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83C5B2CE109D664D189AD1D063E90EBCB8DB",
                        "defaultText": "아직 그분을 지켜야 할지 확신은 없지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B9751F93137BE2445E88CD782FA1718D81C9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F236887152EFA846874AE465AAED3731A303"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0F3510C0A26074B677ACE09ADAFD5507CB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5BE2CA614A973747D93BA9F14998E38755BB",
                        "defaultText": "그래, 그러자."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE25AFEF7A2F57437C09A634C59C73D58569",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07F8230D3D613247751862216227C0073D97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A18B3B7676A82462A48DFC4057902EBC7CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E520CC99535FE242D28994134229FB5093D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21689EF8037861479C9B71437C3DEE0F56AD",
                        "defaultText": "좋다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "71FCE921696C91404929F1C479FEA03B3CE7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8615C21F2D3B15458B0865353BC90BF3C0C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71FA84DA545E624D086BF1F3244A34A969CC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "F0EE949D26586247AC38F2C530F85B436795"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CED0CAB727DED64D507AAB7822125EB4C06D",
                        "defaultText": "봐.\n여제를 데리고 돌아오는군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B1EB4006DDD71473A1B3691D211C1378DFA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1694D7F299F6874945393862178949BBE16E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B41535DB0004B24D1F78BA84537CBD855E7E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "BE2016748ADCD941D34AB892C1F5AAB19038"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D02C5BC56CE4554A8A2B0122AF62B9F2D3B9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "99ED892371D49249AF29DA3589E7BF00E5D5"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Hellios exits the scene"
                },
                "indent": 0,
                "uid": "84CF9FEE70ADD6485759FB92DD1D8CC0DB95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9ADAC7216A4E6345D72BD8B8F50EE77E54E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFD695455E0F4340C4089CD399A98BD826AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "38CFABE041D27841B53BFA934A797D969D80",
                        "defaultText": "헬리오스... 조금 음울하지만, 속은 좋은 사람 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51B4F4C04F2E27410C1A5DE9E84E71805A01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4785820993CA9496B4AA4F4078EBB453301"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B5CC4A6159C76484C98E917F02299C5559E",
                        "defaultText": "좀 더 알아 가면 좋겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0001D514A3FF1412F68FB4555D922DD9F1D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A700021A6066D74B5E49D8D546BA2DAD37D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "114A771886A79445493A2251BAE1730B2DDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F7068F46B46D4406A1AB21860C8342156BA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "3722E21F69459249281B8C8230B46818052B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D19BCFC5546884AA958EAC1B90B9A4A502D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "33AAE3B1773A2448CE193E67D303B1983CE1"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "BE5A163286A552413489D7D448672301E5DC",
                        "name": "C4-03c Enter Phoebe (END)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0D9F63982947F445C65876C24C7302C4B7A9",
                "expanded": false
            }
        ],
        "livePreviewDisabled": false,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}