GS.dataCache['ADD4077E286EE646B78B4063B1B31B6BAA6C'] = {
    "uid": "ADD4077E286EE646B78B4063B1B31B6BAA6C",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-3 P1 Soldier (F)",
        "type": "vn.scene",
        "parentId": "2690908862AFF44F786BB6D5D43C993B900F",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 0,
        "localizableStrings": {
            "A4AF657D679B584DA9090BF7E55362E6AAFD": {
                "t": "Sabrina! It's been a while.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F219A0146125D542F66800B4AB614D24CA0F"
                }
            },
            "808BCDC2273903427D595EE0C995DC4206AC": {
                "t": "L-Lady Faratras...!",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "92488DBF82EF034F7A494EB88C4933CB8831"
                }
            },
            "BD91DCDE3913C843CD88CA63B308951B4888": {
                "t": "Come on. You're not still scared of me, are you?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D3CA681F443C574A4F0A35D1ED22776F791E"
                }
            },
            "F6CD16A481CD314F9858BC37CA8FEC45CF4E": {
                "t": "No... on the contrary. I wasn't expecting to see you again!",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "B2772F683843654FAE694D439B1608887772"
                }
            },
            "F9473DB86440334BA97906E436F79CB6F89F": {
                "t": "I got distracted for a moment, so I didn't realize you had walked in.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "F05BA0DC5DD8D7436128E0B05B3B75A5C9B2"
                }
            },
            "76CE0D2281DFD945467807F29FC41ED43F6D": {
                "t": "She shouldn't tell me she got distracted at work, really...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FEB50876413BA34AD369FDF847EFACA965EB"
                }
            },
            "F3D10F0A16E09241D14B8C48952F620DED8E": {
                "t": "But it's a pleasure to see she's the same old Sabrina. And that she didn't die in the previous battles.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F87EEA7594DCF246220A7FB4DE572620666D"
                }
            },
            "D0D819567E46B74BC78B64B6599472D6DDB0": {
                "t": "What's the state of the castle?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "2380BE1A790A5944E48B9B88499B78C687C0"
                }
            },
            "4B1B10AB45BC3549E07B49E49DFEBCEDFB48": {
                "t": "Everything is in order as usual, Milady. Why do you ask?",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "E4CF5AB154700948E51A99531FCDAA42900F"
                }
            },
            "468D0C626184F54D3E58DEE376D64215003A": {
                "t": "What about the Demon King?",
                "d": {
                    "eid": "E3B07AC85211954C78485891BCC8C32A6EE9"
                }
            },
            "E177F67D6403D148BD08B5A6E0CF2B8C1794": {
                "t": "Were you able to repel the enemy?",
                "d": {
                    "eid": "CCFA9C4B85D6644C6F2B69312A601E40ABDA"
                }
            },
            "14F978A66A18F147B25AA443FD6F3C53D81B": {
                "t": "You don't have to worry, Lady Faratras.\nWe managed to fend Him off for the time being.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "736FD4F62E26E443341BAA58A8FDC2DD35E8"
                }
            },
            "ACABEA754A4AC8487C984C583D68BB0CF68A": {
                "t": "We've all been waiting for your return. Together, we'll crush any threat to Hoikade's glory!",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "59FD5E6E3CF8464E25488CD17C7715826E37"
                }
            },
            "1FF4B8C408A2794D788B93F28007B2976DC5": {
                "t": "I didn't expect the situation to be so positive...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2838E30F54E26242BE083D57DD8C4A81F332"
                }
            },
            "5C99104C1CD631477F7802579553AEFEEB0A": {
                "t": "I'm... happy to hear this.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9EAC4F5719C50449431B2DC9FEE8D2B70409"
                }
            },
            "639B34BF105C874F3F2862B98B038521D5FE": {
                "t": "You trained your soldiers well, after all.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "2778F84F58D3744D09287F027E25385F56B0"
                }
            },
            "C2CE502B3A4582419F8BF8F6D32B8BE645F1": {
                "t": "Thank you Sabrina, I will continue to be a good guide for you all.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "23F6103D0837254D5C5B21237838F6201C1F"
                }
            },
            "508001FD92D35446CB0B56B445AC03554FE6": {
                "t": "Yes, Vassal! It's always an honor to serve you!",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "C3C322507C65334EDB7A178149FBC1642A40"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A8B706A7EC7874ABB2B5B54764BF934128C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "27726DFE5D8FA1484A394305CE62F06C3C90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3F54E34B1114264B224903730CE16E0A8DF4"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "3D23FAEA8C30B44B6E6AE5363A164C67F84A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1117B48D11BD07462D4A00D4D050B4C9C5A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4AF657D679B584DA9090BF7E55362E6AAFD",
                        "defaultText": "사브리나! 오랜만이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "F219A0146125D542F66800B4AB614D24CA0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "181BB1C04EFFF84FF75A654864248CA7EE15"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "350CCEC67BA3E64B5C087036C379141D40AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5749AB085C2D92411A580F124BD2F45A9AB2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "69DA9ACA489E77490E5A88F366505BE11FF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C1254F7F61A7F34700183E94B7FEFC8D8E00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FD2636A18A2D444FA0B0D214BA8FEA107AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "808BCDC2273903427D595EE0C995DC4206AC",
                        "defaultText": "파, 파라트라스 님...!"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92488DBF82EF034F7A494EB88C4933CB8831",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A3913003367834DA229CD214F8CDD67CBC0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C4509BE6B88E14BD059C4C3AD204A3F6755"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD91DCDE3913C843CD88CA63B308951B4888",
                        "defaultText": "왜 그래. 아직도 내가 무서운 건 아니지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D3CA681F443C574A4F0A35D1ED22776F791E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72591DF45A69A045114A28110C34382976B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DED02DF4DC2084B571B4231BE32AF58A432"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6CD16A481CD314F9858BC37CA8FEC45CF4E",
                        "defaultText": "아닙니다... 오히려 다시 뵐 줄 몰랐습니다!"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2772F683843654FAE694D439B1608887772",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58BF13834B7FF646B2895CF138FBFF0728B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9473DB86440334BA97906E436F79CB6F89F",
                        "defaultText": "잠깐 한눈을팔아서 들어오신 줄 몰랐습니다."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F05BA0DC5DD8D7436128E0B05B3B75A5C9B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EF699509BD7C84CD348C5262DC5F99D1BEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C1AC102A790841B65927A7768FBE5DEFE6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76CE0D2281DFD945467807F29FC41ED43F6D",
                        "defaultText": "근무 중에 한눈팔았다는 말을 내게 하면 안 되지..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FEB50876413BA34AD369FDF847EFACA965EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E2722340127D642FE1A1408019A7217F1DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3D10F0A16E09241D14B8C48952F620DED8E",
                        "defaultText": "그래도 예전과 똑같은 사브리나를 보니 반가워. 지난 전투에서 죽지 않은 것도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F87EEA7594DCF246220A7FB4DE572620666D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E5EF53B399110452B8917158CB8A159B743"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00A20069725DC54BC11A9077881C5074A2F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D0D819567E46B74BC78B64B6599472D6DDB0",
                        "defaultText": "성의 상황은 어때?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2380BE1A790A5944E48B9B88499B78C687C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "612B9B287F3BE6433E2BD4574BA8952889DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77697C035B1C3345F1296D66ABB9E8E8153C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B1B10AB45BC3549E07B49E49DFEBCEDFB48",
                        "defaultText": "평소처럼 아무 문제 없습니다, 아가씨. 왜 물으십니까?"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E4CF5AB154700948E51A99531FCDAA42900F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C19AE04119996344226A90544EF774B16D6F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "468D0C626184F54D3E58DEE376D64215003A",
                        "defaultText": "마왕은 어떻게 됐지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E3B07AC85211954C78485891BCC8C32A6EE9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E177F67D6403D148BD08B5A6E0CF2B8C1794",
                        "defaultText": "적은 격퇴했나?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CCFA9C4B85D6644C6F2B69312A601E40ABDA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC98C06B1B087349532A0F5360998AE6758B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "04E908838324614BC5283B44682AE3F052F1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "FD8585266D49B042E31B25B435A3B59EF59D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "598F22D4384ED94A678912D1251B772513C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CCA8A1CF6C132347FA7A13970C854D2F86D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line5_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B524ACC56CAAF54E7469B40488FCBABF7B55",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DD55C09C5328E244293BCD277ECB6D175E54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "396DF5090C7B144B5A582550AF92C55D682A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "14F978A66A18F147B25AA443FD6F3C53D81B",
                        "defaultText": "걱정하지 않으셔도 됩니다, 파라트라스 님.\n일단은 그자를 물리쳤습니다."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "736FD4F62E26E443341BAA58A8FDC2DD35E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEBB0A494A5953498258A394400E468B192F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "639B34BF105C874F3F2862B98B038521D5FE",
                        "defaultText": "병사들을 훌륭하게 훈련하셨으니까요."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2778F84F58D3744D09287F027E25385F56B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4935C77E7B48294657296BA12E62F55A1D4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "013D309510CF1444E75B7CC95E093E79EB71"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "9AE66D6D42092241927A29560C6F53CF0777"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0FA640A76FEB149C9295BE603A927B00373"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ACABEA754A4AC8487C984C583D68BB0CF68A",
                        "defaultText": "모두 귀환을 기다렸습니다. 함께 호이카데의 영광을 위협하는 자들을 짓밟겠습니다!"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "59FD5E6E3CF8464E25488CD17C7715826E37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE4ADD417360A247B358A163F7B73A5E9919"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FC580DE2BB8324BF05818C1122E54F34774"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FF4B8C408A2794D788B93F28007B2976DC5",
                        "defaultText": "상황이 이렇게 좋을 줄은 몰랐어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2838E30F54E26242BE083D57DD8C4A81F332",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA611FF563D6C544B77BBD637D7F152E76C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94A6B73124743943082A721913AAA26619F3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C99104C1CD631477F7802579553AEFEEB0A",
                        "defaultText": "그 말을 들으니... 기뻐."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9EAC4F5719C50449431B2DC9FEE8D2B70409",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7E2AD0F619E941494189A071A37ABEB1E1E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E48D45D5598A534806798AE618DF53F3B670"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2CE502B3A4582419F8BF8F6D32B8BE645F1",
                        "defaultText": "고마워, 사브리나. 앞으로도 모두를 올바르게 이끌게."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "23F6103D0837254D5C5B21237838F6201C1F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0C8EE7FE19648847A02A42A16E0C181BF020"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C8DF045F4E18C04B6F5BA455F1ED2E451C15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "508001FD92D35446CB0B56B445AC03554FE6",
                        "defaultText": "네, 그릇이시여! 언제나 모실 수 있어 영광입니다!"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C3C322507C65334EDB7A178149FBC1642A40",
                "expanded": true
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3C46AC503132A1414438BA6821311BF1FDF8"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "760FB014199D654F2809F1C88253CC00201D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8994C53261AB034688583552513B9F7FF37C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B7360484532E34D616AEE32629ECB6DEC1A"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}