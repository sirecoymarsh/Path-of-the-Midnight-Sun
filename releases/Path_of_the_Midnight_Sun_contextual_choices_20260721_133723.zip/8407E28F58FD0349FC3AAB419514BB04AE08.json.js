GS.dataCache['8407E28F58FD0349FC3AAB419514BB04AE08'] = {
    "uid": "8407E28F58FD0349FC3AAB419514BB04AE08",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11A-2b P1 Arlene (Shop)",
        "type": "vn.scene",
        "parentId": "96E6D4851B65E542343B4F677C5CBE962889",
        "chapterUid": "EF3BAE1B50D8764F0D184715C435B627D64E",
        "order": 0,
        "localizableStrings": {
            "EC7EF8271AAC9345F82AA5B2F6DD26DA67C7": {
                "t": "You...!",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "B39DB64C6CFD33480A3893140D63B5682C06"
                }
            },
            "8BE2DCFB3EA41643F09B70150780CA04642E": {
                "t": "Arlene! It's sure been a while.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "63AD731C8B2501471B88E245A6C5482CB8D0"
                }
            },
            "3148EC9C17DBE548CA39BBC8E0E103684D1A": {
                "t": "Hello. Do you remember us?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "EA9A54E28233F543A76AA571EBEC5F3FABB8"
                }
            },
            "EE679B1324199542AE2821C912E0BEDD1096": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F2722FF046C84442487877A1715B6DB95E5F"
                }
            },
            "DA99DC1486858941B819EDB629738954037E": {
                "t": "Kind of hard to forget a blind girl and an immature knight.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "2BB6EE0276BCC64FCC2A6A39DE830FACC4AF"
                }
            },
            "FF8E0AB32FAD174DCA886B6625FE6AB8B002": {
                "t": "Isn't that a bit... rude?",
                "d": {
                    "eid": "F49DE08F6206D443A75AC063F98D0833B868"
                }
            },
            "FBC3C8D97B197248868A16758DBD6B4D1AEB": {
                "t": "Hmm...",
                "d": {
                    "eid": "3B6E70016049664A943A434178FBDCCF0A71"
                }
            },
            "FD9CEEF736A1384FF27B36A9ABDEE08D2EBD": {
                "t": "Wait, Shiori. You were the one who taught me not to be quick to judge Arlene.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "DB70BAC13BB0F14B027B20C175E627B08EFF"
                }
            },
            "9284E6CE1F703946375BE8E1AFE427C16F5B": {
                "t": "That's kind of... ironic. You're right.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "728D189E1ADD2240E97904541E307A8791EC"
                }
            },
            "BB28ED8A220806496B2A4F966414E421AD98": {
                "t": "Arlene didn't use to be malicious, despite her sharp tongue. I should probably assume that she hasn't changed...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D0838194380CB141644A6BE05EA10A59CAAF"
                }
            },
            "0EE1D0FC43D4644F54698876F6E5FA485211": {
                "t": "What happened? Last time HE was the one who needed to be reminded of everything.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "239FB71F6A2AC348F078ADB2A9448945A51F"
                }
            },
            "471339F081CD2344798867B405F016845888": {
                "t": "And you... Well, you couldn't see all my wrinkles. Hah!",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "A2C802DA946BA44374696F794CABEEFDFE1A"
                }
            },
            "842687384019E448F568CCF676E2570B527F": {
                "t": "I agree that a lot has changed since then, Arlene. Including the current situation of the world.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "B4115AB1668FF84E205A4B481CA4334FEA2D"
                }
            },
            "7EF1766A098D6542842902D2B94709E75944": {
                "t": "Forgive me if we don't explain everything in detail now. I promise that when things settle down, we'll have a good talk over a hot meal.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D4C0B45A3C5DB344D60B54A0013842E47244"
                }
            },
            "7FF24DC139C961482A694AB7370F7F0F5EAA": {
                "t": "But now we need to know if you have noticed any suspicious activity. We think that a very powerful demon may be hiding in this town.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DC40F7A51D2F124F43192F86778725691CCF"
                }
            },
            "75485D83151C664B805A6736EC4AECAF5ECC": {
                "t": "Tch, worry not. It's not like I'm an old hag who likes to gossip behind people's backs.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "CDC03584476EF247623B1B1138938C2467EB"
                }
            },
            "C08B27B343D86843730909810E784CB4FBE6": {
                "t": "As for your question... The Church of Pylum was searching for someone here, a good while ago.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "86D94B879DE31444C539E483F1334B1B4C61"
                }
            },
            "67DC31BC68AD84450E7B7BF8177848741A56": {
                "t": "How long ago, if I may ask?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "64E537388FA51647367AECC292113F616B7E"
                }
            },
            "27D9A1EC86FC83417379B17781033D9551F5": {
                "t": "A little longer than two months.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "5CB25DC249F794497F78F893D3F5EBE676F8"
                }
            },
            "225BA9653FE8D540F70B4092BB902193E82D": {
                "t": "That's way before the resurrection of the Demon King, unless I'm forgetting something. Which wouldn't be surprising.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "923B8F6168182843F22949D3D0246A826DF8"
                }
            },
            "6F0C386E0010654834392D35EB97CE19086E": {
                "t": "For once, I think your memory is working fine. But how is such an old event relevant at all?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4DE6A5D8749E914CD81AD137301606F794AA"
                }
            },
            "FB3126AB628C174DAA8A7242547BCDDF44D9": {
                "t": "Not much happens in this town. That was the only event out of the ordinary... Other than the usual thugs and ratapults, of course.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "7C14BDEC62F77045D719E9166798CE102345"
                }
            },
            "1A83C122821415445908B154A2AB2D94515A": {
                "t": "But you can ask the man over there. He's one of the Holy Swords himself, he might be more helpful than I am.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "5CF666B83DD946423D799DD267D460E78743"
                }
            },
            "CEC555099A9458483B08FD45849BF7D3B355": {
                "t": "One of the Holy Swords... I see. Thank you, Arlene.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C77303CD4B0E33456568F575D7FC1A8E3884"
                }
            },
            "8F8D777F16D83148132ACA66D4C37AEEE4E8": {
                "t": "Hmph. Just do something about this mess. The lack of customers lately is very annoying.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "110371DE1A0E2343D3682908FF5FF1A7C753"
                }
            },
            "12CEC9177EE37844B459D862EA8D0DB8BD3F": {
                "t": "Do you want something? Make it quick.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "095AD244743C6846379A7B947FE02117DA47"
                }
            },
            "D26256791908F8440A0B22C08B4A28BA1E54": {
                "t": "Right, right. How many do you want?",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "9406188952864648745B9A99C761E1325465"
                }
            },
            "7D7A9C356061E545571B0EF5E0DACC5AB2EB": {
                "t": "Sigh. What now?",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "7E6A961A7D404648DC187E3746450B11921C"
                }
            },
            "409325233EABE24D02997E01AE6A1268BB61": {
                "t": "Alright. Enjoy.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "A3178A2C34694846E45AAC35E11D6E5D8A4E"
                }
            },
            "08D8D1D3399BD7449C4B0E125DD73F587C54": {
                "t": "As I said earlier, I'm not a charity. You don't have enough gold.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "300B4E7506B8574E2579E75210BFBC6F4D44"
                }
            },
            "0AD4729091B2974C2959B8B51C54FCE98B83": {
                "t": "See you.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "D53EF2A85D198641927844E1363887545BE9"
                }
            }
        },
        "commands": [
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 400,
                        "y": 400
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "E3BDB56A432C994CEB395976880B6CA021D6"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 260,
                        "y": -70
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "093FA1FD835DB3454A8A89A54383A3FB7118"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B914AF3B6064764E2B3BA3010A68E2EA88D1"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Shop",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "5AF3264518D040484468D707F0FE6DAAC18E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13CAC89D861FC8452E18CF47E895E9EC1BCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9D72976732547749FC8B6066EFC0515A3E14"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "76D3D7C182119843916A0E81652071250D09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C82F238973234042BB1909F316BA83BBD1C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9A3F6B708FCC444EA695B417317FCB46C83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC7EF8271AAC9345F82AA5B2F6DD26DA67C7",
                        "defaultText": "너희는...!"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "B39DB64C6CFD33480A3893140D63B5682C06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63B2A14060CC01445B2B6D606200D8D1D7B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "059DD2B245E9974FEA498B29F35426EF8B2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8BE2DCFB3EA41643F09B70150780CA04642E",
                        "defaultText": "아를렌! 정말 오랜만이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "63AD731C8B2501471B88E245A6C5482CB8D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AE732568CEB364C9B9839F1296CD575031D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F76384B3CFE2743E918BAC636A7A4C8E31C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50DD8406696392484C09BCF8ABC7F95CF6F7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3148EC9C17DBE548CA39BBC8E0E103684D1A",
                        "defaultText": "안녕하세요. 저희를 기억하시나요?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA9A54E28233F543A76AA571EBEC5F3FABB8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29765DD85657E94A1A796922B4E9B305BF2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "227AF44F1AD65647A4197C12C400D645164F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F9E75DF501E344BFF89F1838D2FA37C6A81"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE679B1324199542AE2821C912E0BEDD1096",
                        "defaultText": "우후, 우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2722FF046C84442487877A1715B6DB95E5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F821D3E262B94447A35BAF03923CDFC013F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8363007660EE0341C66A11B7364062AEE9B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29F731B858F08144E91A0B6257416429641A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA99DC1486858941B819EDB629738954037E",
                        "defaultText": "눈먼 소녀와 철없는 기사를 잊기는 어렵지."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "2BB6EE0276BCC64FCC2A6A39DE830FACC4AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "33A53C094361164BD23A2574DD4A983F5654"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FF8E0AB32FAD174DCA886B6625FE6AB8B002",
                        "defaultText": "그건 좀... 무례하지 않아?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F49DE08F6206D443A75AC063F98D0833B868",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FBC3C8D97B197248868A16758DBD6B4D1AEB",
                        "defaultText": "흐음..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3B6E70016049664A943A434178FBDCCF0A71",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "rude",
                            "think",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EEA3FEC31515743A03903B04D8C09B3646E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FB75FA3C07DA234F1B3B571174E5FD11E3C5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "rude"
                },
                "indent": 0,
                "uid": "2F0DD56255D7F74190699A331A6250177D67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94B846CB04FCD64B8419FBE61F60882AA2A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD9CEEF736A1384FF27B36A9ABDEE08D2EBD",
                        "defaultText": "잠깐, 시오리. 아를렌을 섣불리 판단하지 말라고\n내게 가르친 건 너였잖아."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB70BAC13BB0F14B027B20C175E627B08EFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "237325A12D6F774491381AD539D0020CCB40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D10AF3FD8F9F0841C26AD8674D69868C12E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9284E6CE1F703946375BE8E1AFE427C16F5B",
                        "defaultText": "그건 조금... 모순적이네요.\n당신 말이 맞아요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "728D189E1ADD2240E97904541E307A8791EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B08CA212AABC4474C28C17958EBF8FEABDB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "think"
                },
                "indent": 0,
                "uid": "983200E217A4174EEF68CA08BCA6C35959D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5FC8B964FE205494228488660D6AFEB5A43"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB28ED8A220806496B2A4F966414E421AD98",
                        "defaultText": "아를렌은 말투가 거칠어도 악의는 없었어.\n아마 지금도 변하지 않았다고 생각해야겠지..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D0838194380CB141644A6BE05EA10A59CAAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B08ED385A1B694ED8299093670CD8794C38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "F82A69E3627E2547A05ABBD40FB62A38CA03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6809DD6D434A7549CF788391614645F57B2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "19FD983D54032945DF987C258BE10C0C2838",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "719768A7822065428E69CC641A278EEF376E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00661BA48913E1418D1A6620703A4353B116"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0EE1D0FC43D4644F54698876F6E5FA485211",
                        "defaultText": "무슨 일이 있었던 거냐? 지난번에는 저쪽이\n하나부터 열까지 다시 배워야 했잖아."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "239FB71F6A2AC348F078ADB2A9448945A51F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DC0130F1EF6E14BF73BB0656B85856327B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EF13BBD1028D840305AFC32963A6E88D93D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "471339F081CD2344798867B405F016845888",
                        "defaultText": "그리고 너는... 내 주름을 전혀 볼 수 없었지. 하!"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2C802DA946BA44374696F794CABEEFDFE1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D2191CC036A4841E28B1FD5CE96F6731D8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "644521E1788AB44CE119F548404F0B4A37AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "842687384019E448F568CCF676E2570B527F",
                        "defaultText": "그 뒤로 많은 것이 변했다는 데 동의해, 아를렌.\n지금 이 세상의 상황까지도."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4115AB1668FF84E205A4B481CA4334FEA2D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B19EA27C884B884A62093EE53737C0822435"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D6AD878205404416259A578A49762BEBAC4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7EF1766A098D6542842902D2B94709E75944",
                        "defaultText": "지금은 모든 사정을 자세히 설명하지 못해도 이해해 줘.\n상황이 진정되면 따뜻한 식사를 하며 꼭 이야기할게."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4C0B45A3C5DB344D60B54A0013842E47244",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EFBFE9269B4A14B88184F29CA7858E5B85C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FF24DC139C961482A694AB7370F7F0F5EAA",
                        "defaultText": "하지만 지금은 수상한 움직임을 본 적 있는지 알아야 해.\n이 마을에 아주 강력한 악마가 숨어 있을지도 몰라."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC40F7A51D2F124F43192F86778725691CCF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32941D2A77D8D14D3658DF608A7A376E0357"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C71AFDA8881904455C38501835764C4A2B0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0377F571F56D746AE1B8466AAC51582A461"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75485D83151C664B805A6736EC4AECAF5ECC",
                        "defaultText": "쳇, 걱정 마. 남 뒤에서 수군대기 좋아하는\n늙은 할망구는 아니니까."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CDC03584476EF247623B1B1138938C2467EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8F984CA2BB0224E57199DA7B891C9A2F4A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C08B27B343D86843730909810E784CB4FBE6",
                        "defaultText": "질문에 답하자면... 꽤 오래전에\n파일럼 교단이 이곳에서 누군가를 찾고 있었어."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "86D94B879DE31444C539E483F1334B1B4C61",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4296756174C66746514BD03848EEFEF0B9C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F094BFB25591F346BA9B4AC332324890C6AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "F8742EDE9ADA374C5C199BF6066E2C07ACA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD24C5583F44314AD21B84832EF6E1E22054"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36EAB4BA4B35444ED68B5447297670050018"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67DC31BC68AD84450E7B7BF8177848741A56",
                        "defaultText": "얼마나 오래전인지 여쭤봐도 될까요?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "64E537388FA51647367AECC292113F616B7E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1963DD08FACF543A819C8E2A156D12DF016"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "729C93FA285008411F9A3122B1B4ADF1B57D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "27D9A1EC86FC83417379B17781033D9551F5",
                        "defaultText": "두 달하고도 조금 더 전이야."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CB25DC249F794497F78F893D3F5EBE676F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0D37D6B3C6CC3437139A73029F735E7FB1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F313A395132CD143964B0727161BF5C36377"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "19F04CD45522F44A8A7952C88A547E1BA861"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E8FD9582D63F640AC7B6512972FE9AC35F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6FA250337BBEE14A18099FC8A5270FD82938"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "56ADF29C587B194C537BBE525C72AFB28776",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "51492D240668844A751952A3F73B85BC3B0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4707A308823CD34CC52B2FE8A794C93A1935"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "225BA9653FE8D540F70B4092BB902193E82D",
                        "defaultText": "내가 뭔가 잊은 게 아니라면 마왕이 부활하기\n훨씬 전이네. 잊었어도 이상하진 않지만."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "923B8F6168182843F22949D3D0246A826DF8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74CF3C0A93D3C24B5C7B85177CEA9E4F6179"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ABA876998AE824D768B64162FE4652F5120"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "946888FF1B050644A45BA2A1E606F13F375A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AD74E043CF947451E4B27B51B83C7E5E97E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99E2B4B6610CE943AA296D592EF703F8785C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F0C386E0010654834392D35EB97CE19086E",
                        "defaultText": "이번만큼은 기억이 멀쩡한 것 같네.\n하지만 그렇게 오래된 일이 무슨 상관이지?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4DE6A5D8749E914CD81AD137301606F794AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C0869E02978344E413B3720BDF8E2B18548"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "483B850A76769848D60B147279642BB49CA7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FB3126AB628C174DAA8A7242547BCDDF44D9",
                        "defaultText": "이 마을에서는 별일이 없어. 그게 유일하게 특이한 일이었지...\n평소의 불량배와 래터펄트는 빼고 말이야."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7C14BDEC62F77045D719E9166798CE102345",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03EF2DAD957D26492B284C2688A4CB25B16A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "595822E73CC9264C14898BB6587FBEF33CB4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A83C122821415445908B154A2AB2D94515A",
                        "defaultText": "저쪽 남자에게 물어봐도 돼. 본인이 성검단 소속이니\n나보다는 도움이 되겠지."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CF666B83DD946423D799DD267D460E78743",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "974CCEE93B7A9645F36B70F2AE81BE8B17AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9512DA575585D845D928084829EE47901514"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEC555099A9458483B08FD45849BF7D3B355",
                        "defaultText": "성검단의 일원... 알겠습니다.\n고마워요, 아를렌."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C77303CD4B0E33456568F575D7FC1A8E3884",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D300DDE38B549148F27A4329AA63A0AC93C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B3A36FE8F449340699925F4EA5E44115A95"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9235F162934CB04A5C1BE2D395C1E5FD476F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F8D777F16D83148132ACA66D4C37AEEE4E8",
                        "defaultText": "흥. 이 난장판이나 어떻게 좀 해 줘.\n요즘 손님이 없어서 짜증 나니까."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "110371DE1A0E2343D3682908FF5FF1A7C753",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3BCCD02538A424F1E1BAC44634129DB19CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D1817A50ABFD2466C8844B9716B0E303C00"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A0D04AF01DA586480B699713369864F83A5B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 8",
                        "index": 167,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BB2F7DA85B9CF4435C394D881CDEDFFFBF6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "094FCCEA59B831446E5951C36BCE35C4DDBA"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Closing Event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "92C5ACAB2A5FC64E23280481C775DD822C03"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Shop"
                },
                "indent": 0,
                "uid": "F3A508A591CA984F2968A017EEBFA6BE6AC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15344F1169DD844D625B54C55FD0182DF443",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE"
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CD1E5315832F145B77A1801ABD61BEA8D6C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12CEC9177EE37844B459D862EA8D0DB8BD3F",
                        "defaultText": "필요한 거 있어? 빨리 말해."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "095AD244743C6846379A7B947FE02117DA47",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8C6A213E7AF5E746C31937045FBD07B15D7D",
                    "parameters": {
                        "values": [
                            "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                            "A61006745779B54F95583F031E23AAF3B85A",
                            "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                            "4BE0921B0375824E39486375D29E6D610E31",
                            "3A6470303809F6402069BCA779DE051805FA",
                            "A22335E58B019145941B83457E31F119B83F",
                            "EBA214B73A7445455719E0E9E91057954732",
                            "7FF18EB084AD054B434B622321F85E2DDABF",
                            "7BAEC95A702D664CF74AB71248751A8C1B8F",
                            150,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "884164F46DBDB243E378B8035D1247C56C52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "48504D765D9B054F023B0B558BB866C0CF69",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4B6448C07CAC184E0E9894852ACA7D142DFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "5C11C618154A624C74695842A76E24FD1F8B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "796737570D47B34BA15B12A355CE8882882B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Confirmation"
                },
                "indent": 0,
                "uid": "9ADEB0A855EEB1415948D9B2F3575C6B4FA0"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "TarmenArlene.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "standart.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E640FF422D95242DC2A7994D0BB73FA1A5E"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "49DADFAF9582F24609686659D665A4CB9FBE"
            },
            {
                "id": "gs.ClearMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 0,
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "680539CB7ED802469C7ADED3C7812EB8EE0A"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "CBBD5AE1285CE847C62B2520D25E7331A021"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D26256791908F8440A0B22C08B4A28BA1E54",
                        "defaultText": "그래, 그래. 몇 개나 필요한데?"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9406188952864648745B9A99C761E1325465",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Confirmation event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "8E7BA4CB28035340D51A8CA1092A2D9056E9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Cancel anything else"
                },
                "indent": 0,
                "uid": "F9DFEE399C5EA74FB20B2768E5D27D677ADE"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "TarmenArlene.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "angry.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "249A67E85C951743442812B1142C033B2CE9"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "CD3849665B39114E2B7BEC3265B2A23F7748"
            },
            {
                "id": "gs.ClearMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 0,
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A5584C246941054F0A7B54D8679414FEBB94"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "2BB0624C10859841D44952354012449FB064"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D7A9C356061E545571B0EF5E0DACC5AB2EB",
                        "defaultText": "하아. 이번엔 또 뭔데?"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7E6A961A7D404648DC187E3746450B11921C",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Cancel anything else event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "218B165D2E8294472A3BD1D835891E6EE8AC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Thank anything else"
                },
                "indent": 0,
                "uid": "0C0790779BEBE24B993814F4714EA996BD83"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "TarmenArlene.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9A29993041C1964FC08A1AF8644063A093B1"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "D1DA32001A97B54C20790490AFA89590FCC2"
            },
            {
                "id": "gs.ClearMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 0,
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "15C09A360AFA11430479D8D9F09CD8487EF4"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "1776C158100AB24C968AEB87C1D9543DFEE5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "409325233EABE24D02997E01AE6A1268BB61",
                        "defaultText": "좋아. 잘 써."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A3178A2C34694846E45AAC35E11D6E5D8A4E",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Thank anything else event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "E054116A62B3E54BD4090D37D81653C6EBEB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Not enough money"
                },
                "indent": 0,
                "uid": "4357EE0653D94641881BFFC378B124AB79AB"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "TarmenArlene.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "surprised.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0F2B44A44E940248F77888423837A0CC7890"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "57ACB66D2F4E3142F47BA0B71B04AED3B927"
            },
            {
                "id": "gs.ClearMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 0,
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "EDCC56258E3A634C724A5D29362569821763"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "C6FC5D985CD1E543BA4AEBA4B675D2877726"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08D8D1D3399BD7449C4B0E125DD73F587C54",
                        "defaultText": "아까도 말했지만 난 자선가가 아니야.\n골드가 부족해."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "300B4E7506B8574E2579E75210BFBC6F4D44",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Not enough money event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "76BECAC82FB7054CD56AB265A60871EEA1E5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Close Shop"
                },
                "indent": 0,
                "uid": "422E374E9FB926433029AFD9639387B18C60"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "TarmenArlene.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "standart.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "967914C156B7F34189788E43F96CCDF99C03"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 0,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "58710A145A12A146F02A6E075EF7F41B7DFD"
            },
            {
                "id": "gs.ClearMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 0,
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0255CF768E4BD446245BDD64EA0C39C5E3B4"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "Verdana",
                    "size": 40,
                    "outline": 0,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 255,
                        "green": 255,
                        "blue": 255,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 0,
                        "font": 1,
                        "size": 1
                    }
                },
                "indent": 0,
                "uid": "6A792064479EA34EB17AF58726A2CBC62476"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AD4729091B2974C2959B8B51C54FCE98B83",
                        "defaultText": "또 봐."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D53EF2A85D198641927844E1363887545BE9",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Close Shop event",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "663697677B90C146B078F868A690E552AC52"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Closing Event"
                },
                "indent": 0,
                "uid": "9E3923C57781F844F0485B03405743764D86"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "215FC7E85631A34BD339C3684C35C658A985",
                "expanded": false
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BF661082582EB14B9558B647B772DA95CC0A"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}