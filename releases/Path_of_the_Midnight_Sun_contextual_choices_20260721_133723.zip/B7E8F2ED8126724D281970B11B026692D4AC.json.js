GS.dataCache['B7E8F2ED8126724D281970B11B026692D4AC'] = {
    "uid": "B7E8F2ED8126724D281970B11B026692D4AC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-08 P1 Faratras (END)",
        "type": "vn.scene",
        "parentId": "E0C057DC7CC9C346F56A17C1CA188E4ADE97",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 0,
        "localizableStrings": {
            "869F502D6756A345A61B2569BA95E0DD59DE": {
                "t": "Oh, there you are.{W:300}\nYou're still awake, Faratras?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "124C7BF4109867419D394DE493A1E0903A53"
                }
            },
            "F002867251B0C8480C39780736773B947763": {
                "t": "Her emotions are always...{W:200} clouded.{W:300} It's hard for me to see her malice below the surface level.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DEEA0A910E1AB7428E88478369DDCF49DCB0"
                }
            },
            "05143DB8506E634736494D272B83C4EDA76F": {
                "t": "I wonder if this is a side effect of the power of the Demon King within her?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1EABB4658A0E4841231A46F1050F7F619A32"
                }
            },
            "7F79E8868160E545E53A8EB0E7B4A543D499": {
                "t": "You don't know anything...{W:300} *hic*",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F3F7F8F324B31944CC78D6C874FECA0BA751"
                }
            },
            "604168379CF7984AF66A2257BC2AE629CE1B": {
                "t": "Are you... okay?",
                "d": {
                    "eid": "1BC917405AF63646441ACB42228B3EEAA324"
                }
            },
            "F83920BA3436944A9058D221E7BE6DD3F948": {
                "t": "Wait, you're drunk?",
                "d": {
                    "eid": "B9B83953410568404D496F091F1141F4ECA3"
                }
            },
            "196F698329C27844A90B66C82EE2FFB2EDBB": {
                "t": "Actually...{W:300} I can't!{W:300} I don't know why, she's the first person whose malice is so...{W:300} strange!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "554C5DA089F9B042D77A079076046E7821FD"
                }
            },
            "E39BD4ED811F624C381822777A077EECFF11": {
                "t": "This is making me feel anxious.{W:300} She's there, but she's not there.\nI...{W:300} {SP:2}{C:1}CAN'T{C:0} see her!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FCD175A61B1BF74C106A45282B6EB841A1B9"
                }
            },
            "8D31F182363DD845C44984D3850A3DD538A4": {
                "t": "She seems in pain, but I can't see her emotions!\nWhat should I say??",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4A86E09250798145FC389E89124FAAC278A0"
                }
            },
            "8C6AC7BB537F5047F97BFB78E89FA2303B11": {
                "t": "There are many people who're here for you.",
                "d": {
                    "eid": "AC2EA38F5B28874B4A78A2383BDD00864592"
                }
            },
            "EE434BD1206C914A8B6837F70B9663CE391B": {
                "t": "The Vassal is very loved, and respected!",
                "d": {
                    "eid": "D63C46D03D9C684FBE888915034B0692E58F"
                }
            },
            "B080AB4F87553242C6392094137C5B9C2885": {
                "t": "Everyone in Hoikade still respects you.",
                "d": {
                    "eid": "609A4EBE6CA0B6461669171367A0988483FC"
                }
            },
            "59C9D78C2E12F449295978A84BC8628D490F": {
                "t": "I can't stop her emotions...! They're just overflowing... And they hurt me so much... Why?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1325B6BA60C8E349357865B3B0C1E386757C"
                }
            },
            "9C4AE3FA48C52846582B463766949AC9E682": {
                "t": "Please stop, Faratras...",
                "d": {
                    "eid": "796ED70432DC184478392E13239837D61A3F"
                }
            },
            "CEEB3B2051860240A08BE3E2A35A2AC46BE6": {
                "t": "Everything's going to be okay...",
                "d": {
                    "eid": "6C01D28E4887134F2E280FA2F5BE247D3FFF"
                }
            },
            "DE8D95D76E0BC8406B697844F624E4FCB746": {
                "t": "Why do her emotions feel so... familiar?{W:300} Can I... relate to her?{W:300} Even without... my power?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "804BA0162EA3A34810489DC8381F12F3207F"
                }
            },
            "5040236E3A6B5041C24A3336DA37084C5CFD": {
                "t": "It hurts...!{W:300} It hurts, please stay--",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "63B7CDC31149E64F3E385997C49567F9FA73"
                }
            },
            "A3F2E6021646C34CCF38E731045EA3FE4B80": {
                "t": "This is bad! I can't sense her anymore! What's happening!? Where is she? What should I do??",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "81D6A1EF2C21844608689623E4C35A22F788"
                }
            },
            "0A855FC8119FA24EC64BB915E6B3C2D3D694": {
                "t": "Faratras",
                "d": {
                    "eid": "EB9623EE40DA144F6A08434885D97128ACC5"
                }
            },
            "FED19F498FF5C645BA1B9831A84FEF839702": {
                "t": "I think I finally managed to sense her...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5C9C02671840D6498A394E53954982537484"
                }
            },
            "76AA05195BDD0248A9091DC583F8024EBD50": {
                "t": "Weird, it's not like me to struggle so much just to detect a single person.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "51BCD8409551F4476529BB55440DDD9C141E"
                }
            },
            "040119EF68706541CB190616C2CCD31DFCEE": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "85A850D543ECC642EC8BABD19484C87A270C"
                }
            },
            "D2FF264B4A4DE947976AC1B57E0AF4771067": {
                "t": "Despite how we found ourselves in such a sudden and dangerous situation, you managed to control your emotions.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "155465892EB9754C0C598DE84DA99AB33A68"
                }
            },
            "A4C8973E32B2654A613A79283A2C8645158E": {
                "t": "You know, it's not often I meet someone with such resolve as yours.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "BAEF004F668B324A008B93D843F306B5F970"
                }
            },
            "76E9DD407D2DA64DF23A96F6EC263C912E4A": {
                "t": "Faratras...?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "429D35EB4A8AF14160085775C069E41580FB"
                }
            },
            "0F64E3FA31154540C61B8FC5EB207B0C00DB": {
                "t": "Control my emotions?{W:300} *hic*{W:300} Please, don't make me... laugh!{W:300} *hic*",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7BE0A3A0503CF5476C2BB3E16BB1F72DE426"
                }
            },
            "62386F211BE1C84CB24B54C161C99FF60B34": {
                "t": "It's not something I decided to do.{W:300} I'm condemned to control myself.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B975CC128CFEF14F4528EBB604D0B12D784D"
                }
            },
            "0A3F7E8839D7C6435D793827BFDC9A30C2CC": {
                "t": "I'm not!{W:300} *hic*",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "59FC01B25670724D602981D1B97E5DEBAEB0"
                }
            },
            "A47D32E34968024B006AA742C1961B8AB49B": {
                "t": "I'm not drunk...!{W:300} *hic*{W:300} You're drunk!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F38EFD276169B54EF789EDC7A2FFD3846161"
                }
            },
            "94080F8A545912492A6B3865F29936ECD0A8": {
                "t": "I'm just...{W:300} a bit sad...{W:300} *hic*",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "37B90D385CB7D443453B0543A905371A875B"
                }
            },
            "9A54BAED223F384D6229BF47CEC24551DB02": {
                "t": "Can't you see?{W:300} You should be able to see the tremendous malice I...{W:300} carry!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6294394A8F88194F90583B11DD3B674E3B98"
                }
            },
            "2C644E043CA6A142F0895BE554BEA0B8921E": {
                "t": "Ha...{W:300} Hahahahahahaha!!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "21902FB03F93564CEE3AB326390B74B3875F"
                }
            },
            "853ECB65741405405A7B98D2968391D8B891": {
                "t": "Faratras, listen.{W:300} I don't know what you're talking about, I'm sorry...{W:300} Could you--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "00FAAC98934B5540A17BEA7143E601382547"
                }
            },
            "FECB285D58C85848F98B89768B38BD63F41F": {
                "t": "You must be{W:300} *hic*{W:300} kidding me...{W:300} I'm the Vassal of the Demon King.{W:300} My very existence... is a sin.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E70655277693E34C4C7AC1E2675D6E445726"
                }
            },
            "FBB141051B45614C29598DD88EC0173DBD62": {
                "t": "Our allies...{W:300} are merely escorting me.\nMy people?{W:300} *hic*{W:300} They consider me a threat.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "564F2EBD1683B547EC78ABF8CED49CFD37F6"
                }
            },
            "0027EBAF216CF640C22867B2258E749AED76": {
                "t": "I never had...{W:300} *hic*{W:300} many friends.{W:300} I've always been alone...{W:300} since the day I was born.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6074073D3A636348B34BA665E8F34BDFAAE5"
                }
            },
            "6B28F5E0364AA149F70BE731A1E8E4AEDB6D": {
                "t": "I have no father...{W:300} *hic*{W:300} and no mother.{W:300} My only brother is a stranger.{W:300} The only person I considered my family...{W:300} *hic*{W:300} was a queen as cold as ice...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B1541390306E0743038860609AD01D6EA8DD"
                }
            },
            "A63DCE95131B46427D9B056980F050199525": {
                "t": "But it was all a lie.{W:300} She used me and{W:300} *hic*{W:300} threw me away like trash.{W:300}\nAnd the people...!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4FECD6E9572FB146B96919E15E58E3E2C390"
                }
            },
            "A5825D214D3581423889FEF396B6FD1478F0": {
                "t": "No... They feared, not respected me.{W:300} When that fear overcame their false respect,{W:300} *hic*{W:300} they turned against me.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EA6835C4819C0446A518D346EA27D6ECF3E9"
                }
            },
            "39A4813C03B9F4497F4810C44203198AA070": {
                "t": "See? I'm just a mere shell...{W:300} for a power bigger than me...{W:300} Just like...{W:300} Master Alvano said...{W:500} before I had{W:300} *hic*{W:300} to kill him. Sniff...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C8CAB29C23CAE94362685AA8B0DCA737F36D"
                }
            },
            "AD178EE8278A2440D158E67337FEE3976EDE": {
                "t": "Sob...{W:300} *hic*{W:300} Sigh...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B1CAC7FE95A2B34F45586D58B9187B4726E0"
                }
            },
            "8BD1A9E12460274F872BA7728FBBFDB564C2": {
                "t": "Stay back!{W:300} Don't come near me!{W:300} *hic*{W:300} I don't deserve your kindness. Stay back...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EF23DA151943584B5E5B64B6D9B0F02DEB16"
                }
            },
            "1989424E963FC44143799920D461CE0AAE45": {
                "t": "W-Wait...!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8279570E0A41D34F632AD264C53BF78D31A3"
                }
            },
            "A3F6D21E1208444AED19B4213CFE5F72BD3C": {
                "t": "STAY BACK!{W:300} *hic* \nI don't need anyone any more...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DBD82C189691414AD609BF93C5636828BE81"
                }
            },
            "37A815971FAA414BCD5AC1B883AC051DC5E3": {
                "t": "Faratras!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9A291C4392D7B245F979591112706D2E6FBF"
                }
            },
            "452853B59DCBB5403F4835072EAB6679C427": {
                "t": "Where are you going in the middle of the night!?{W:400} Faratraaas!! ",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0DEC0E8E8ACE6646D46B047637A2B43E0C2C"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "F471F95149BD7640F43A0C00919221DDEFCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "15128DAB4C6308408F1B3760F05DDD01C53C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F6CEF6D86BEF94E264B8225C011679F7A26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            99,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB776F334CB72641D45BA9118C7EA4CCBC54"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "model": {
                        "name": "Faratras Overworld.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 184,
                        "y": 530,
                        "zoom": {
                            "x": 0.2,
                            "y": 0.2,
                            "d": 0.2
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 6,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "25EDDEDB2A3A1940F50B29D1FC97C859B1B3",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 215,
                        "green": 217,
                        "blue": 181,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "ACF94300035D6548982A0A4630CDA5B8FE55"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "FC90A240467E92403D7BF7045FDE2C5D094C"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 901,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "56B14C7323267441FC2BBF2071654014AA81",
                    "predefinedPositionId": 0,
                    "blendMode": 2,
                    "zOrder": 0,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 400,
                        "y": 398,
                        "angle": 90,
                        "zoom": 1,
                        "horizontalFlip": false,
                        "data": {
                            "x": 225,
                            "y": 199,
                            "zoom": 1.4,
                            "angle": 90,
                            "horizontalFlip": false,
                            "width": 353,
                            "height": 199
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "025FA4C277359240217B7DF0680C43E282CC",
                "expanded": false
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 901,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "AB26FBBC6B9B674591490C197B28E8E26C67"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "A3409642293CE4407468B923F60BAA282D67"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "duration": 15,
                    "waitForCompletion": 0,
                    "opacity": 220,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "39FE2B0C1BD6654CB22B3A71CF8DB68E6687"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 901,
                    "duration": 15,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "29CA716A668A02462A28EF48BC071B8BA04C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "BC6890CB51FFD14B4768ADC7E487EA647FDC"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "duration": 15,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "C323909A3D9553410C78F932C6CA4F3CF8F8"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 901,
                    "duration": 15,
                    "waitForCompletion": 1,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "DC9C737472D8984E8A29A0A028076A28B273"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B946989045ED7746378977C1279738DAC47C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 901,
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "52AA6DFB956AC74CB93B0275C118ADDED937"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 99,
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B9C898977A1E964090899686AC25267FA22F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0A855FC8119FA24EC64BB915E6B3C2D3D694",
                        "defaultText": "파라트라스"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EB9623EE40DA144F6A08434885D97128ACC5",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Faratras"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D3A4F95917191546968BC081DC99F467BCFA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 96
                },
                "indent": 0,
                "uid": "ECBA97DD4B3C82496E8BCB9229B412BC6088"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "31681E52979708414388E095A19622CD3444"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BB1C4CC59B62E04FD38A3744E96733BD402D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "218E13A77E4C5641D68B9A545F727D4378D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A4791773089E540FF4BF716A9C76EAD2C7D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FED19F498FF5C645BA1B9831A84FEF839702",
                        "defaultText": "드디어 그녀의 기척을 느낀 것 같아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5C9C02671840D6498A394E53954982537484",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A17E8987B71474F537A27D105A9B4E4BBAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DDCFD0056283B2475D5B00A73D60BDAA4463"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76AA05195BDD0248A9091DC583F8024EBD50",
                        "defaultText": "이상해. 한 사람을 감지하는 데\n이렇게 애먹는 건 나답지 않은데."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51BCD8409551F4476529BB55440DDD9C141E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C998141D7D4EB64D2B8908C725C625E2B8A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0339058E4877684F5E4AEF881D7DD72FDB02"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "118912965FB99849770A1AB3857114F12B87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            100,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F3D38F0198AB54EAE0ADA40BB06CC3D583D"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 215,
                        "green": 217,
                        "blue": 181,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2726A8FE3C79C34EDF4A4B9096E9EDE68574"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "80224BB456F20447A66B00655B66DBB14DA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "F6C65B6110C7224ABB7AD2D32D95982A27A8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A3B4A5BC1C34834DC2481154989EFA2726E2"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 60,
                    "waitForCompletion": 0,
                    "opacity": 220,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5784E2945FE64848B559CD162EAD726797BA"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 900,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "56B14C7323267441FC2BBF2071654014AA81",
                    "predefinedPositionId": 0,
                    "blendMode": 1,
                    "zOrder": 0,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 1345,
                        "y": 105,
                        "angle": 90,
                        "zoom": 4,
                        "horizontalFlip": false,
                        "data": {
                            "x": 670,
                            "y": 50,
                            "zoom": 4.2,
                            "angle": 90,
                            "horizontalFlip": false,
                            "width": 1447.3,
                            "height": 815.9
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C5219B030E137740475BAC26D6646E6B6060",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "A7A204937846D24FB3599358DECA5C6C2B43"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BA6EF0E081A5C44F2288A6546227934969CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D7B49D181B0054A890B2E9219112297F418"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "831777555949D94AE26990791AFF11960226"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "869F502D6756A345A61B2569BA95E0DD59DE",
                        "defaultText": "아, 여기 있었군요.{W:300}\n아직 안 자고 있었어요, 파라트라스?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "124C7BF4109867419D394DE493A1E0903A53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DE15BF44C2AE243615B51F54B07F903759A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "476A8A1187E019498919733804A01FF33BC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "040119EF68706541CB190616C2CCD31DFCEE",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "85A850D543ECC642EC8BABD19484C87A270C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48E550D28785C04091597B52D49D59DA7833"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E6083688FB2A941C15B9E9791FDA79E26ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F002867251B0C8480C39780736773B947763",
                        "defaultText": "그녀의 감정은 언제나...{W:200} 흐릿해.{W:300}\n표면 아래의 악의를 보기가 어려워."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DEEA0A910E1AB7428E88478369DDCF49DCB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50851D6F3BDE69492B2B31B2A597AF64A807"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05143DB8506E634736494D272B83C4EDA76F",
                        "defaultText": "그녀 안의 마왕의 힘이 일으킨 부작용일까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1EABB4658A0E4841231A46F1050F7F619A32",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D2A9E3E0D9C214C34693570DEDF878FC4E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00142AAD502CD549714ABE2058D0B8FD9226"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D2FF264B4A4DE947976AC1B57E0AF4771067",
                        "defaultText": "그렇게 갑작스럽고 위험한 상황에 처했는데도\n감정을 잘 통제했네요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "155465892EB9754C0C598DE84DA99AB33A68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E50101CE795FE44A7C592D558D21F681E39D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4C8973E32B2654A613A79283A2C8645158E",
                        "defaultText": "당신처럼 굳은 결의를 가진 사람은 좀처럼 만나지 못해요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BAEF004F668B324A008B93D843F306B5F970",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20ED65E52F4A454C6C2A27B5D019122023E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            5,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D715193835880842C12A97235833456ACF07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "965E4DDA791A974C3A3975174915D55DC4C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F79E8868160E545E53A8EB0E7B4A543D499",
                        "defaultText": "넌 아무것도 몰라...{W:300} *딸꾹*"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F3F7F8F324B31944CC78D6C874FECA0BA751",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAB352327E05664C5C2BCA96798D661014FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8480AB2C4DF3674DE05A004106C3194F2352"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76E9DD407D2DA64DF23A96F6EC263C912E4A",
                        "defaultText": "파라트라스...?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "429D35EB4A8AF14160085775C069E41580FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "847127C59AC045411C1A64D8244B4642510E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            10,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A71968843A51145F74B3CD433C428F37D22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC8A902403B1044E527AFAB4B2F75BA2A678"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0F64E3FA31154540C61B8FC5EB207B0C00DB",
                        "defaultText": "감정을 통제한다고?{W:300} *딸꾹*{W:300}\n제발... 웃기지 마!{W:300} *딸꾹*"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7BE0A3A0503CF5476C2BB3E16BB1F72DE426",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B58F5C7984EE93495288DEE55AD2A6E23BD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93C517872E4F4140A68A097157EC2EE342E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62386F211BE1C84CB24B54C161C99FF60B34",
                        "defaultText": "내가 그렇게 하기로 정한 게 아니야.{W:300}\n난 나 자신을 통제하도록 저주받았어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B975CC128CFEF14F4528EBB604D0B12D784D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "48773A0869AE034D1828C264D64E9391AFF3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "604168379CF7984AF66A2257BC2AE629CE1B",
                        "defaultText": "너... 괜찮아?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1BC917405AF63646441ACB42228B3EEAA324",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F83920BA3436944A9058D221E7BE6DD3F948",
                        "defaultText": "잠깐, 설마 취했어?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B9B83953410568404D496F091F1141F4ECA3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "okay",
                            "drunk",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAD83D0074D1A749B65A31148D65D1452019"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "226173BB6E4B1749B4397D09B0733D774222"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "okay"
                },
                "indent": 0,
                "uid": "9B0D879439F24940C53BB2941791329ADDF5"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-aff"
                },
                "indent": 0,
                "uid": "35F19D6106A0B64D78694E7980FC51719A92",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            40
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C98A9C35DE091473358C9F7135028EC522B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2784102E7B52674D4189862507402D0F0BEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B07D40C6627302424C2821425423019E9AD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A3F7E8839D7C6435D793827BFDC9A30C2CC",
                        "defaultText": "난 안 취했어!{W:300} *딸꾹*"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "59FC01B25670724D602981D1B97E5DEBAEB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2DCB8967718C1412359DDE4FD5BD60EFF8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B813BA336F862402F1BD8A1130FA8F5C429"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "8CB31B674739D2464F2AFC40A153B06AF248"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "drunk"
                },
                "indent": 0,
                "uid": "D78F16E488EC314BD23A13D3CD3EA95EB39C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-aff"
                },
                "indent": 0,
                "uid": "40321D9963E9214FEA4B989270511E6287B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            40
                        ]
                    }
                },
                "indent": 0,
                "uid": "776C1CDF5067994B734A94E4158EBF18CCB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C1C61C924EC22460778F3F713C2F2434FB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D383C4EF2461464F3A1AB1A46464FBEFC129"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A47D32E34968024B006AA742C1961B8AB49B",
                        "defaultText": "나 안 취했다고...!{W:300} *딸꾹*{W:300} 네가 취했잖아!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F38EFD276169B54EF789EDC7A2FFD3846161",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56293E0E6652D645408933A72B2785A2AD24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2FABE7F8E0AE3485469E416D4C42DF777E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94080F8A545912492A6B3865F29936ECD0A8",
                        "defaultText": "난 그냥...{W:300} 조금 슬플 뿐이야...{W:300} *딸꾹*"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "37B90D385CB7D443453B0543A905371A875B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69B772A18B34C147256AE8070E3A0CE328FA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 1"
                },
                "indent": 0,
                "uid": "D41956337FAC8642160BD02333428F98F663"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DEC9C0768C7B84B6E2A2B73EE90D1249C8D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A54BAED223F384D6229BF47CEC24551DB02",
                        "defaultText": "안 보여?{W:300} 내가...{W:300}\n짊어진 엄청난 악의가 보여야 하잖아!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6294394A8F88194F90583B11DD3B674E3B98",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7872FE888D02D441CD7851478680C7E4B251"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C644E043CA6A142F0895BE554BEA0B8921E",
                        "defaultText": "하...{W:300} 하하하하하하!!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line16b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "21902FB03F93564CEE3AB326390B74B3875F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD05B880123DF848C8395728D702D0DA67A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E949A0E135CE443A0694FA153A7E8ADFFF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "196F698329C27844A90B66C82EE2FFB2EDBB",
                        "defaultText": "사실...{W:300} 안 보여!{W:300} 왜 그런지 모르겠지만,\n그녀는 악의가 이렇게...{W:300} 이상한 첫 사람이야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "554C5DA089F9B042D77A079076046E7821FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EE93AD81CE69140012A9DB5921A5E2FB0E4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-sanity"
                },
                "indent": 0,
                "uid": "CB64A42723E03849A62B9542C65944CA83D2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            1,
                            15,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BAFC41F6BB42249671A478337F6295B3023"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 900,
                    "duration": 36,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5C766D7C5E3914480C88BFE6FB637213EE0A"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "389A7C08221E5243B469AAB3F49725C20A13"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7E4C8EDE8E8E714DD76ACDE5478FE86E2823"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            99,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D5F9F648CD9154AD56BE2143B6F13E10414"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E39BD4ED811F624C381822777A077EECFF11",
                        "defaultText": "이러니 불안해져.{W:300} 그녀는 거기 있지만, 없는 것 같아.\n난...{W:300} 그녀를 {SP:2}{C:1}볼 수 없어{C:0}!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCD175A61B1BF74C106A45282B6EB841A1B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "117D54A14A7DE749000B32527FC41D748DB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "346EDD11161DC64E0B89C0D6C32BC49CA377"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "853ECB65741405405A7B98D2968391D8B891",
                        "defaultText": "파라트라스, 들어봐요.{W:300}\n무슨 말을 하는지 모르겠어요, 미안해요...{W:300} 혹시--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line19a.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "00FAAC98934B5540A17BEA7143E601382547",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB326F296D3FA749BF1BD320C2D1DC016102"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            100,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5C4C3C917A5D44F3F59ED524F8483792684"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 215,
                        "green": 217,
                        "blue": 181,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2F9CADF1684BB0478F78A1F5B51B11D00D48"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "C2A1A18E0DC5B34293082F38F9D7AAB85C9D"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 60,
                    "waitForCompletion": 0,
                    "opacity": 220,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BAFB1C258F20E040F44A47E15D8041B99EEC"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 900,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "56B14C7323267441FC2BBF2071654014AA81",
                    "predefinedPositionId": 0,
                    "blendMode": 2,
                    "zOrder": 0,
                    "duration": 60,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 1345,
                        "y": 105,
                        "angle": 90,
                        "zoom": 4,
                        "horizontalFlip": false,
                        "data": {
                            "x": 670,
                            "y": 50,
                            "zoom": 4.2,
                            "angle": 90,
                            "horizontalFlip": false,
                            "width": 1447.3,
                            "height": 815.9
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "48C4CE38459EB54D3F2978E0A2377305D2B8",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "F079DCAF9DF2234C117964C10A39C0CCEA4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF34EC086D63F243172A7CA7F4EA41CCC8F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FECB285D58C85848F98B89768B38BD63F41F",
                        "defaultText": "지금{W:300} *딸꾹*{W:300} 장난해...?{W:300}\n난 마왕의 그릇이야.{W:300} 내가 존재하는 것 자체가... 죄라고."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E70655277693E34C4C7AC1E2675D6E445726",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE8538336796B54C4C6960443A31192E9DD9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "946448B5334DA242D959B0E5C2B815AD454A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D31F182363DD845C44984D3850A3DD538A4",
                        "defaultText": "고통스러워 보이는데 감정이 보이지 않아!\n무슨 말을 해야 하지??"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A86E09250798145FC389E89124FAAC278A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C99686ED17DB0745AF9A29F5C46DF3D704A4"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8C6AC7BB537F5047F97BFB78E89FA2303B11",
                        "defaultText": "네 곁을 지켜 주는 사람이 많이 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AC2EA38F5B28874B4A78A2383BDD00864592",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EE434BD1206C914A8B6837F70B9663CE391B",
                        "defaultText": "그릇인 널 사랑하고 존경하는 사람이 많아!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D63C46D03D9C684FBE888915034B0692E58F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whatever",
                            "whatever",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "4759D3E25717D5456F9977D22D7E0CCEB205"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DC18419683E8C44668190355F43A1217D837"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whatever"
                },
                "indent": 0,
                "uid": "DA3CAD427F819245C08B12E4AA2991278755"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE4A8E9599ED364FA648FD084E384FEE6574"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FBB141051B45614C29598DD88EC0173DBD62",
                        "defaultText": "우리 동료들은...{W:300} 날 호위할 뿐이야.\n내 백성?{W:300} *딸꾹*{W:300} 날 위협으로 여겨."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "564F2EBD1683B547EC78ABF8CED49CFD37F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1A178BB55039540297B04A292AB04D91300"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0027EBAF216CF640C22867B2258E749AED76",
                        "defaultText": "난 한 번도...{W:300} *딸꾹*{W:300} 친구가 많았던 적 없어.{W:300}\n태어난 날부터...{W:300} 늘 혼자였어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6074073D3A636348B34BA665E8F34BDFAAE5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71CF147F7E71E54DF31B27B4437324F110D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B28F5E0364AA149F70BE731A1E8E4AEDB6D",
                        "defaultText": "아버지도...{W:300} *딸꾹*{W:300} 어머니도 없어.{W:300}\n유일한 오라버니는 낯선 사람이고.{W:300}\n내 유일한 가족은...{W:300} *딸꾹*{W:300} 얼음처럼 차가운 여왕이었어..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B1541390306E0743038860609AD01D6EA8DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62F59DCB63DAE142197AA8E789B52DE67512"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1794A640A1BA840398A93A4C1883671C8CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A63DCE95131B46427D9B056980F050199525",
                        "defaultText": "하지만 전부 거짓말이었어.{W:300} 날 이용하고{W:300} *딸꾹*{W:300}\n쓰레기처럼 버렸어.{W:300}\n백성들도...!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4FECD6E9572FB146B96919E15E58E3E2C390",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "04DCFAD734DC17429248E5A4C6B2E0093E0D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B080AB4F87553242C6392094137C5B9C2885",
                        "defaultText": "호이카데 사람들은 아직도 널 존경해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "609A4EBE6CA0B6461669171367A0988483FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whatever bis",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2F633C7290AA341314950D892F27D1B54FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D9BDB9141C9A714D3C48876393059BF66C56"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whatever bis"
                },
                "indent": 0,
                "uid": "5F2996908BFBF64EA52AA466B1929FA3C7BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            10,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA43B0229EDD964314993D57F2262AD36DAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A00423C696D47046231964851267EFFD9C19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D60AF33077A4446AA9B68057DB0A3D47958"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5825D214D3581423889FEF396B6FD1478F0",
                        "defaultText": "아니... 그들은 날 존경한 게 아니라 두려워했어.{W:300}\n그 두려움이 거짓 존경심을 넘어섰을 때,{W:300}\n*딸꾹*{W:300} 내게 등을 돌렸지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EA6835C4819C0446A518D346EA27D6ECF3E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5A89E8E82EFB849C25A4E620D723C8C0034"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            1,
                            20,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "",
                            1,
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2EF6DE24DFDC34050986F727EC7B7913415"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E119F28D3BB31149D759B0B2BF783024067D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "59C9D78C2E12F449295978A84BC8628D490F",
                        "defaultText": "그녀의 감정을 막을 수 없어...! 넘쳐흐르고 있어...\n너무 아파... 왜지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1325B6BA60C8E349357865B3B0C1E386757C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC4F13635E42B246423AA2902973952CB5DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            5,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DDA83B786C6F614B25891E64C183D2E7F978"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC517384413B174C618B8E4688BA646719E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39A4813C03B9F4497F4810C44203198AA070",
                        "defaultText": "봐? 난 나보다 더 거대한 힘을 담는...{W:300} 빈 껍데기일 뿐이야...{W:300}\n알바노 스승님이...{W:300} 말했던 것처럼...{W:500}\n내가{W:300} *딸꾹*{W:300} 그분을 죽여야 하기 전에. 훌쩍..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C8CAB29C23CAE94362685AA8B0DCA737F36D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D20EF791B229343528840241D8434AAF20C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9C4AE3FA48C52846582B463766949AC9E682",
                        "defaultText": "그만해 줘, 파라트라스..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "796ED70432DC184478392E13239837D61A3F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CEEB3B2051860240A08BE3E2A35A2AC46BE6",
                        "defaultText": "다 잘될 거야..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C01D28E4887134F2E280FA2F5BE247D3FFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whatever 2",
                            "whatever 2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB068D7E7A3D7647918876E19765A3A38CE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4EA8168231BA434B843A3FD6F6F1968E9D13"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whatever 2"
                },
                "indent": 0,
                "uid": "FFC779264654024FCB6ABA58FDAFEF5BC7EA"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-aff"
                },
                "indent": 0,
                "uid": "5AE609CF53135644396AAEB637959E0BF2A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            4,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            20
                        ]
                    }
                },
                "indent": 0,
                "uid": "228C1AE8269D3245956A37E35A5D32116C23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E419033A287107441B697C54566B872B3412"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2377F67F7462574206391CD30C0E1F570F99"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD178EE8278A2440D158E67337FEE3976EDE",
                        "defaultText": "흐흑...{W:300} *딸꾹*{W:300} 하아..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B1CAC7FE95A2B34F45586D58B9187B4726E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC9C47318F93164B70284903F57D22C05303"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B23949F57090349FE6B3968D8E51D1CD4D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE8D95D76E0BC8406B697844F624E4FCB746",
                        "defaultText": "왜 그녀의 감정이 이렇게... 익숙하지?{W:300}\n내 능력이 없어도... 그녀에게 공감하는 건가?{W:300}"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "804BA0162EA3A34810489DC8381F12F3207F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E791A7866D41545BE7BAB97E73D8DE4A8C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5040236E3A6B5041C24A3336DA37084C5CFD",
                        "defaultText": "아파...!{W:300} 너무 아파, 제발 가지 마--"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "63B7CDC31149E64F3E385997C49567F9FA73",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA0621CA89AE28402C29A6C1A392F3CC2BED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "168F11016BD28045670B4EB7DA765B8D6E5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57D96BA19E20D041DE0AECD3B1806BB65669"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8BD1A9E12460274F872BA7728FBBFDB564C2",
                        "defaultText": "물러서!{W:300} 가까이 오지 마!{W:300} *딸꾹*{W:300}\n난 네 친절을 받을 자격 없어. 물러서..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EF23DA151943584B5E5B64B6D9B0F02DEB16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C0890C55346F94E2428B7C73572FBF252CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "331524C23335884E5428DE8763982F4741D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1989424E963FC44143799920D461CE0AAE45",
                        "defaultText": "자, 잠깐...!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line19b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8279570E0A41D34F632AD264C53BF78D31A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74935D80524D344F068A52E0C9F547247DFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "622A285F5E85284BAB5A189899D76224857B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            9,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "730E25621186F84C5448A5255412D1354806"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "047127C46B13D54D8D9BE3B70AEDBFAF5F84"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C86046DA9393F8471F7AE9C29E57CD3E8261"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "004140536419434B06386A255116004E6510"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3F6D21E1208444AED19B4213CFE5F72BD3C",
                        "defaultText": "물러서!{W:300} *딸꾹*\n이젠 아무도 필요 없어..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-08_line39.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DBD82C189691414AD609BF93C5636828BE81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B1C9D6C95E550490C78FBB4EF1F6090EDE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "960FD5BA41EAA14C7379D8A89185CE25BDF7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "30B892286C04724FED78FAC57220C17B2A14"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "86519867130DC549D52AC1B63A044AAA4217"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 900,
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "71B9C2E859255341A86B65A06D24DC6ADDCB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 96
                },
                "indent": 0,
                "uid": "E156DADC45C2854CE06A57E7001862FE364D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "she exits"
                },
                "indent": 0,
                "uid": "2CB2A1C95E93564E173BDB485AA5E0E7553F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C2FC85BA3F3AB1401A28184422E0595FFD56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB6C28483829C34AF8884665957557EB012C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5596C8E4FBFD5446D5BE42696A03FB8D154"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37A815971FAA414BCD5AC1B883AC051DC5E3",
                        "defaultText": "파라트라스!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9A291C4392D7B245F979591112706D2E6FBF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7015A813622A96478E2A5E04B841F5BEB331"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3289CAA51526A54D869B14C56C9CA09D9E26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3F2E6021646C34CCF38E731045EA3FE4B80",
                        "defaultText": "큰일이야! 이제 그녀가 느껴지지 않아! 무슨 일이야!?\n어디로 간 거지? 어떻게 해야 해??"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "81D6A1EF2C21844608689623E4C35A22F788",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AF155A690D0A534DC259A7E3B9A62362B475"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36B2A258309787498E5B64569A9AB7586AEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D61207E27DDF34A254AA8A23395B57AF6C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "452853B59DCBB5403F4835072EAB6679C427",
                        "defaultText": "한밤중에 어디 가는 거예요!?{W:400} 파라트라스으으!!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-08_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0DEC0E8E8ACE6646D46B047637A2B43E0C2C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2FBF83D0114D934EDC3A32D620FDC5A09A43"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "081B81C38968D24940880E8697BF5B3845D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82FE749D2DB6264A062B7C423BFF539DE84B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "D4EF22F51FFC62414568B806D8D5BB6F0D4D"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "EFF8B2955E55C14B384B2E68BAF4830C248D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "6776BE877380704F097A7C953C3DD65D30DF"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "6E1A57D05D0E404BE6797E44DD6238D8DB9E",
                        "name": "SAVE BETWEEN CHAPTERS"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DCF7E78A1032E34D976B74B9BBA64704E012",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}