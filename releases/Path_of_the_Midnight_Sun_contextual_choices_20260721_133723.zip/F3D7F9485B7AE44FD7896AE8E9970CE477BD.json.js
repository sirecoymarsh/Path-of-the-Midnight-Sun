GS.dataCache['F3D7F9485B7AE44FD7896AE8E9970CE477BD'] = {
    "uid": "F3D7F9485B7AE44FD7896AE8E9970CE477BD",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-02 P1 Rya (after Cristoph joins)",
        "type": "vn.scene",
        "parentId": "D51C041D7AF1A2430C3914532F7C6F84BAA7",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 0,
        "localizableStrings": {
            "4F9FA643333F854886195512CFEC134E5737": {
                "t": "Well? Weren't you going to visit the city?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "2C91B2CB3984E64DF67B84D50A3041645C56"
                }
            },
            "9F658B7F2909844BE58B0A73189D757A1205": {
                "t": "Umh... yes, indeed. Sorry for disturbing you.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "D5F7D424451C4445CA7B3FB81C7BEBD9A3A9"
                }
            },
            "F57C74907CFF0946A789E6F22AA5D6CB224F": {
                "t": "She always keeps her distance... I wonder if I'll be able to socialize more easily with her later.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "437A12821B27784A4998818391F433B98E09"
                }
            },
            "6D3671FB6C85B44DF06869631DB8FBA310C5": {
                "t": "Are you done visiting Viborera? You can wait here until the meeting time if you want.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "F83F81EF8A8E7247C22A17018301BDD52F60"
                }
            },
            "6D38396D307CE4465F38D676E2C5F898E9E7": {
                "t": "Yes, let's wait here.",
                "d": {
                    "eid": "732FE8282A45574C9E3B16793A3EDB402630"
                }
            },
            "02FAA80B8C87124E8F3946C471D49EBBDB0F": {
                "t": "{C:2}No, I need to do a few things first.{C:0}",
                "d": {
                    "eid": "28B3ED8216DF534EF69A88468066DC576D5D"
                }
            },
            "940F353235819347241A9B6207644955C873": {
                "t": "Are you sure? Don't change your mind later.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "E408909B1F48C04938388EA3BAC2C58BA21E"
                }
            },
            "A3BE962E538EE84E40295390A2C9772D153D": {
                "t": "Yes, don't worry. I'm ready.",
                "d": {
                    "eid": "EC213C52563B374FA409D4834587D63753C8"
                }
            },
            "402AA936913C844FB2480CB11EFE9D2DBD7C": {
                "t": "{C:2}Actually, I forgot something...{C:0}",
                "d": {
                    "eid": "11EC08351A913743E17B53D3826C8C8FCED4"
                }
            },
            "5D0EB65B17F78447BB888087F736E4D5C68F": {
                "t": "Very well, so be it.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "C7F2066616A49147736B5CF68F34674FD66A"
                }
            },
            "99353A8D1D6FA2411D189F74C6D273BB755E": {
                "t": "Tch, don't waste my time like this.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "2A734B163619A542644B64132790592790AB"
                }
            },
            "F2B45C6D2306C743475873367B892E5FB259": {
                "t": "Whatever. Just come back in time for the meeting.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7992D592570E014D4B3A7C1527C67B5264B9"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            800,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF51E3374E705840C38AE1313AE385E8B5E0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E6D276733C09D241AE7A3F41302FF0B87807"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BDAA4B06A2E294F2E39E3C7EEEA65459BEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB9D3D9D7468B44A8E4997D08BED0BB73D04"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista Scene Luoghi già visitati",
                        "index": 512,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "numero posti visitati",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5CEE9D9F44211648DC29DE538EEB23B09FF2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "numero posti visitati",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2250D1723558614EB61A1A113815B2E7E764"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F9FA643333F854886195512CFEC134E5737",
                        "defaultText": "그래서요? 도시를 둘러보러 가려던 것 아니었나요?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "2C91B2CB3984E64DF67B84D50A3041645C56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E657793D208DD44F37283D345F19158BBC5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A29E005A53A02742513BDDA28A90DFF9CF2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9F658B7F2909844BE58B0A73189D757A1205",
                        "defaultText": "음... 네, 맞습니다. 방해해서 죄송합니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D5F7D424451C4445CA7B3FB81C7BEBD9A3A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A3876CDA53E85246CD2915A5652AA1F7866C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2A1F504C4D4671463149DB736C59DA93E90D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 1,
                "uid": "31F0BE206126C643EB0989A671E067FED636"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "01CA234713CDA645456BAA049C626DD6586C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "81305ABA658F864F9B3BBA110D992209A2A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F57C74907CFF0946A789E6F22AA5D6CB224F",
                        "defaultText": "언제나 거리를 두는군... 나중에는 리아와 좀 더 편하게 어울릴 수 있을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "437A12821B27784A4998818391F433B98E09",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event 2",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "6EB63B705A0028479A7A40F692EBFA494E4A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If already visited another place"
                },
                "indent": 0,
                "uid": "7510E439598DF64F8E3884E03D99371FF581",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9596C1B79587924E060A65015520263354CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D3671FB6C85B44DF06869631DB8FBA310C5",
                        "defaultText": "비보레라 구경은 끝났나요? 원한다면 회담 시간까지 여기서 기다려도 됩니다."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "F83F81EF8A8E7247C22A17018301BDD52F60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC5990C64435A540DD990E710186A67C9F00"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6D38396D307CE4465F38D676E2C5F898E9E7",
                        "defaultText": "네, 여기서 기다리겠습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "732FE8282A45574C9E3B16793A3EDB402630",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "02FAA80B8C87124E8F3946C471D49EBBDB0F",
                        "defaultText": "{C:2}아니요, 먼저 할 일이 좀 있습니다.{C:0}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28B3ED8216DF534EF69A88468066DC576D5D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "wait",
                            "do stuff",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "598C88973D73B144880985A4E91382B764CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "84536CB655C2C640F48B09E47ECAFC840057"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "wait"
                },
                "indent": 0,
                "uid": "D228F3B48DFEE04E247B1D928EA835C5971B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A65D81141E2964A4E6939865A6DB23D9D64"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "940F353235819347241A9B6207644955C873",
                        "defaultText": "정말입니까? 나중에 마음을 바꾸지는 마세요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E408909B1F48C04938388EA3BAC2C58BA21E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE7D76F089EBD349BE58F1C076E809E5F6B2"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A3BE962E538EE84E40295390A2C9772D153D",
                        "defaultText": "네. 걱정 마세요, 준비됐습니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC213C52563B374FA409D4834587D63753C8",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "402AA936913C844FB2480CB11EFE9D2DBD7C",
                        "defaultText": "{C:2}실은, 깜빡한 일이 있습니다...{C:0}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "11EC08351A913743E17B53D3826C8C8FCED4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "confirm",
                            "unconfirm",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA5925983D8B5149940A5A270F0DAAA707BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DFE5B1B211D57147D228955329A4F8E63E47"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "confirm"
                },
                "indent": 0,
                "uid": "6901FE663EE81545E24A570742899216AF4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D01B1F50724D247BD8AAF2731528047C8D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BF8793C1326B844E0891277D01EE7430854"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D0EB65B17F78447BB888087F736E4D5C68F",
                        "defaultText": "좋습니다. 그렇게 하죠."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C7F2066616A49147736B5CF68F34674FD66A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4E7EBCA41A9E4403399E0D64B3B7A6DC5CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D2A86262E8A664CB21986A279B8CD2A4E6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23B946CD8B8F01460A393AE72C56AB1595FF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7B719E49890866416F38A719DF6790C5EA42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94C9122F16EA194A471861A929F46695EE00"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "A6B55BD6799D624D3E092FC70FFC31124CA6"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "051F7A243CB59242DC480C54B6996FA8A38E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "5B4AF0172FAFF641BB2B52084CC4B73725A5"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "98314FC36160164CFE1928213ED4295D405D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1D5E67F3544E0848BE88A763A89E77D3829C",
                    "parameters": {
                        "values": [
                            4,
                            2,
                            25,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD8E29AC1E73474C5D6B6957CA4A942779DD"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "A7B2D0F0217965406F1833C1813034CC1EA8",
                        "name": "C4-03 Ending - Meeting with Phoebe"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FDEAE2B7851D114B280975B64041A1FFA3CA",
                "expanded": false
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "unconfirm"
                },
                "indent": 0,
                "uid": "935B2AF25A6DF54BD17857A789A117EE97C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99C701B5250DC245314B7461A797E857AC95"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E548F353A60914C0189B8B349DE665C6DA8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99353A8D1D6FA2411D189F74C6D273BB755E",
                        "defaultText": "쳇, 이런 식으로 내 시간을 낭비하지 마세요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A734B163619A542644B64132790592790AB",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "C7E2D8574249134A3D2B34E0E32E8BA3E3CA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "do stuff"
                },
                "indent": 0,
                "uid": "D5C3F52313F6C14ADB3BF63350D6716F902D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D94C209409B6414A8A9855F75729FBFE6E1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5AAEF3E05BC0844F15A90530CFE393E66EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2B45C6D2306C743475873367B892E5FB259",
                        "defaultText": "됐어요. 회담 시간에 맞춰 돌아오기나 하세요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7992D592570E014D4B3A7C1527C67B5264B9",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event 2"
                },
                "indent": 0,
                "uid": "0E27D9772FAC654A0B58B459F906911E0327"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2BEEE8AC400F924C443AAA003FB19D20F2B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "38F34B6F75871248BC6AE9518B9478680211"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6192523F5D0737423C6AFB853750B1847120"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "DB6892243B87A241B5180778207141CB8D1C"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "numero posti visitati",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}