Path of the Midnight Sun — 맥락 기반 인물 대사 선택지 재번역 패치

적용 대상
- 기존 한국어 패치와 2026-07-21 런타임 이름/장소 수정 패치가 적용된 설치본
- 인물의 실제 발화형 선택지 669개를 원문과 장면 맥락으로 전수 재번역했습니다.
- 그중 기존 문장이 이미 자연스러워 동일하게 확정된 30개를 제외한 639개가 파일에서 교체됩니다.
- 상점·게임 오버·반복 시스템 메뉴·행동 지시형 선택지는 건드리지 않습니다.

현재 사용자 설치본에는 이미 적용되어 있습니다.

수동 재적용
1. 게임을 완전히 종료합니다.
2. PowerShell에서 다음 명령을 실행합니다.

   powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\install_choice_retranslation.ps1" `
     -PackageDir "." `
     -GameDataDir "P:\SteamLibrary\steamapps\common\Path of the Midnight Sun\resources\app\data" `
     -BackupRoot ".\backups"

3. Steam이 아니라 다른 경로에 설치했다면 GameDataDir만 바꿉니다.

복원
- 설치 때 출력된 backup_dir을 사용합니다.

   powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\restore_choice_retranslation.ps1" `
     -BackupDir "설치 때 출력된 backup_dir" `
     -GameDataDir "P:\SteamLibrary\steamapps\common\Path of the Midnight Sun\resources\app\data"

안전 장치
- 설치 전에 148개 대상 파일의 SHA-256을 전부 확인합니다.
- 하나라도 예상 설치본과 다르면 아무 파일도 쓰지 않고 중단합니다.
- 적용 전 파일은 자동 백업합니다.
- 설치 도중 오류가 나면 이미 바꾼 파일을 자동 롤백합니다.
- 설치 후 SHA-256을 다시 검증합니다.

검수 결과
- 번역 전수 검토: 669개
- 독립 교차 감수 교정: 101개
- 실제 교체: 639개 / 148개 파일
- 제어 코드 오류: 0
- 40자 초과 선택지: 0
- 줄바꿈·인코딩 손상: 0
- 미해결 QA 항목: 0

세부 자료는 documentation 폴더에 있습니다.
