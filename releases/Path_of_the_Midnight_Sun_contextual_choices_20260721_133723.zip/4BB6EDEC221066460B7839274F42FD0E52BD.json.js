GS.dataCache['4BB6EDEC221066460B7839274F42FD0E52BD'] = {
    "uid": "4BB6EDEC221066460B7839274F42FD0E52BD",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C3-04 Night at Magnolia Palace (END)",
        "type": "vn.scene",
        "parentId": "07B52ED66061E04FEA897F640D20451EF056",
        "chapterUid": "420B33D281484446613AEC618F65228E94D9",
        "order": 4,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Magnolia Palace bg"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1D5E67F3544E0848BE88A763A89E77D3829C",
                    "parameters": {
                        "values": [
                            5,
                            2,
                            50,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A987796C3080874B826888D4415D99B6B3A0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "96D305D05A9A1949E75926C17A22253F1FEA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "689D95C85C36584C77892D48BCB6FA8EFBBC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "B17B9539821EB546D06B5E84E01DACA71435"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "A10739F5005AB846A928DD75D6FAEBD24126"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAE907FD5E7E97476118E8C96DFB89D2C6DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FBE97F211A99D64C389BB1C15BEF1A80D6BB",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "64727B7292F0174A25696628DEA17F8B06BC"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 145,
                        "y": 145
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "70FC7B56335E3540655A74E5D5E2DD71B696",
                "expanded": false
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": -290,
                        "y": 150
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "34D4D4A520AFD848FD49C3460E48FFA1434A",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "615623C0412F874BC97AA881F95B73A0D5C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1623F925A617143D658CFC2F04D64C20BEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "F3823FD62416494D4B19AC16A32B0551CD5B",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "567F1E3489D91446CF4A0ED6AF508D6BB339",
                            "0FCC16EC8F14214F211BD711C5EF156BDE65",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BAEFE7194243B640E12B293668D11FC3BA7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F5B49A1001A885446F49B423D831E979B2AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DED9A67019CF7843393BACA348E7DD2B48DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4241B2DC967235493F5A9066318AA09F3E1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0927D27346C1B7428F281C0779FCBF9CB12C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56CD6C5E8CC0064AA62A96C5E91A6A11D1B9",
                        "defaultText": "우리가 자리를 비운 동안 궁전을 지켜 줘서 고맙다. 모두 물러가도 좋다."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "49B5918F5E9C9442CD5B8E6108805096F685",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "94EC5D6555C2764FCB881876D82A4481DE8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D1A6DE558FEB24E3F2815E6479BCF979842"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "C9324ED32F0EE34FB359DD48D8EFB03887A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            9,
                            1200,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5560B3592181347047B8F44C44F1B5C675E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "6790841E30DB2548447B8C22F8A0E78A91E7"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F7D44594507534467B8B629784021D9B18D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "44C09E7C385C284E503B5632BC1D4A3C2BEF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "32E5A18710D17547392A7978798515E3249B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "35EE735601E8624E8689C8C4E69E32FB1281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CFAA80307529C54CE87A9EA034E3B8DF3DD6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F32407FA8BF47342A8380B667891E29F2D5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A04CEA060AE6B746FC1823E254981C11ADCD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26FFE617266EE54EDC5A4C4766AEB9806870",
                        "defaultText": "크리스토프."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "23EDF374005C634239889857D16898ABA2F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C89FEB485331E842E08A844572CA792526A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B244B7BA3D6C5145D0195731BEBF72E86D34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B45E6203FDF7048EF1A60F83279A9807F34"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2E23113192F464BE0796F2865C5214DC652",
                        "defaultText": "네, 아가씨?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "634D245B5346E548087976945EB5D4F8E436",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C5A50663A80154540583BD07C4CD1E0EC7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "946C745441E50147A95B6197DDDC76E07D37"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4628774C77AB78438F9AAA8708F0411E0D80",
                        "defaultText": "오는 동안 왜 그릇을 마흔일곱 번이나 모욕한 거야?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D6C386E806AAF0496A58A6C3A27D512FA56B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAD573549202014D1E7987D83D9EABFC04EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A625285765946497D3AD6F67DF1BBB3F394"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC06985E3087064D2E583527C5105927D27D",
                        "defaultText": "미안해, 리아. 하지만 난 저 여자를 믿을 수 없어.\n통제하지도 못할 힘을 타고난 사람을\n존중할 순 없다고."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BBC212AC01EA544E062B209655B4FEC3D3B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "070ABE681149124B544B883980C858775627"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F69FB260889D824B3B9BBE92619B6E064625",
                        "defaultText": "저 여자의 이야기도 들었잖아? 호이카데 사람들이 옳았던 거라면--"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2234E0924277A540C47B7F565FC79C2530D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8A299831C53564C8E386432A9299F8F1E87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "788389EA1428C443889BDE01197E34074C50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E743F6C1292F03418B4805E43F8C675441D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5A0CC98A281423493948F584D477A75893DB",
                        "defaultText": "말조심하고 가끔은 머리 좀 써!\n정말 악마에게 조종당했다면, 놀리는 건 위험할 수도 있어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8916D17C3DD0674D722862168454B650C8FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18868FD47533C847F73AF0144102E313EF18"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2F643567A2E454F9548B8751338C893AD8D",
                        "defaultText": "조종당한 게 아니라면... 무고한 여성을 모욕한 셈이고."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "237DECB5262A274537882902F78212453797",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5CD5FE093779442B84AC448178A0CF33D51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3FDD98F700801404E2912A7FFD0FF81EF80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BDE807B4510194EDA7B88A4E3DE2B7DB769"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8353EB268105B747644B603733A2E3542A12",
                        "defaultText": "... 네 말이 맞아. 미안해."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6743006D8F99734E9778B740412BF24DE16E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB63EB783A44844DB78AD0F4259ADAC3C4C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB9387E73682E64307196DF43C60E282E38A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CC5E681110BF44CE76B0FB9667EDCBEBAF9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C92DDC4E861E4745157B7204EB6304824F4A",
                        "defaultText": "저 여자가 수많은 일을 겪었다는 것도 생각해야 해.\n태어난 직후 부모님이 원인 모를 일로 돌아가셨지."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F36C361C19F08849F56B7037D2FD5170CADD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B53753C4F6DF547CA9A94585343682E2455"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7E194617F023649F92A18263A439DE2147D",
                        "defaultText": "그리고 지금 호이카데의 여왕인 사람,\n전 군 사령관 무니의 손에서 자랐어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D6641DE6520024DBB78B2A8BB00F5B37F50",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7624B6552715445764B44666A9B03D73DA9"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cristoph Overworld model.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "03_Half_Eyes_Closed.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A22854C48E574146AD5990C264DCCAD79A87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B6A59506A6FD044637B5659411BE5CF9426"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "740B65568DD7D4470E4BA033901EB72CC971",
                        "defaultText": "그 모든 일을 겪으면서 마왕의 무게까지 짊어졌고..."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8756B19D44A7434F117B2372B7952E5A5A3B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A64F80782C4E9643446AA6A3B24E9F7E101E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C88A20570BC0C6473E28643433C4A7A2953B",
                        "defaultText": "나중에 사과해야겠군."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2D90769811B6948148AA7830354E8D265A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2447E01D5313B447CE286871B590258B5753"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6E6B5D941291145778815C48C9E515067FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C3BE2C37724A740C87B85B3890481B90877",
                        "defaultText": "그건 네 선택이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2F5C46A2516B14495A4B13D56E66D52C9B8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1D198A20F19164E18192C356BC6219309AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "784A922E91B6B64F6D6A0275569342AA8CDF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4FDB46A4EE980485598DBD25CB6BE153A3D",
                        "defaultText": "호랑이도 제 말 하면 온다더니. 누가 왔는지 봐."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "27B3C55E7144A742DE5979091614369120B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8863528C81B05146406A0F621EFFE9DDDACA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42CA4C313DAFC14CD34A9ED3EF6B8BB29F82"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "2C6AD6A876B9244A0D1B69898147C5766C9E"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "1758B7A70943984FE57A3725692941AF4EA6"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 48,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "496A237F6C9621486E59E678DBE403582D77"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "1C49045D7918E14B584A7F35610CC24C2452"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5D6DDBFB5A5B0140D72A0A5509DC8AD7AECE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B0D7FC56CF8514F807BE267F7A762B94C79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E0258477316284ACA696C0676B0DBA27619"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE04E2D96D4FF24F4D1ADED2366208F0642B",
                        "defaultText": "방금 무슨 이야기를 하고 있었던 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AF4037A16C92E744E40ABCB301F6D8FE8FED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD124A6B7BAAC6480C19F6E2C95149D162A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EDC3F6813F5C3402E5A67A9300C0304AEDA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FC367D38E99724DCC5AF351081CC564D0A9",
                        "defaultText": "리아 공주의 궁전에는 처음 와 봅니다.\n아주 독특한 양식이군요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6480A76A3B46F0440A5A7F3308DBDD805845",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9D89B259626B84FD29A42B0D9F7AEA3383A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            800,
                            0,
                            801,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7DA72A26C3A8241666993F7AC623241C797"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -25,
                        "green": -25,
                        "blue": -25,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BEE80CC77A7B3142091B9013DD574F370097"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "8A961CD08D6880419579B2B73CF606ED14E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F2119961816004F6D7A0552170588A840D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68F5997A5F1BF140836923161B604EDE08F3",
                        "defaultText": "칭찬 고맙습니다.\n아무튼..."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "58E65E6B5BEF284F005AD596659E13D975D5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B5C8CF74414F642362A4059FC47E1FDA502"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6668CEFF4ECF48413A8AA93085A41477D3F0",
                        "defaultText": "오는 길에 보고한 내용을 보면, 가능한 한 빨리\n여제 폐하와 이야기해야 한다는 데 의심의 여지가 없습니다."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "19B3EB034EA6A745A14A6E62E1B4F23AFA37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A4447C44595F4416B28AC67EEF337F58826"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCDC392A833EA540854BB5F8ED5A58D243F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "956C86394916A14F9D689047037C21D9434C",
                        "defaultText": "좋아요. 회담은 내일로 예정되어 있죠?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "930B9D788623594DBE687D07F6697D9103F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "224C6610500326451D3ABE71EFB71885C729"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5592FC3675F51941021A95859D79140FB800"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B9005093B4E3645406B25B5B4DF944443D6",
                        "defaultText": "네, 오후입니다. 그동안 모두 이곳에서 쉬면 됩니다."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0B3E3E763E5F4442A0A3D8436D2F4CC3F0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E05A1A2925D09244C268F6B249AE0A6445EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00392D2C1B22D548014BFC1435D58078C60D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0E7059E0673A242F33B5958B881BE105131"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2971D323F505745AC9B00C0BB818CBB5009"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "59D5B14D945396402F0A6819238D536DD1A2",
                        "defaultText": "난 좋아. 이렇게 아름다운 곳에서 마지막으로 잔 게 언제인지 기억도 안 나!\n... 말 그대로."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "49715D0E3F3E5345043A10B2F101C08D291C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35BA31277A64504B205B4F68C1FF8B9E8798"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B82E8E57055424D7D1878C151901641389D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9441FB756EC5C6439B69B034D93B6EBFFB59",
                        "defaultText": "또 그 빈정거림이야? 귀에서 피가 나겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB606D842740B5406D88739920132018D5B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D62724FC9375C14558194C1350C8CC6450D7"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "Suzaku's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FC61DD0A1BF581490208D5350E0F2D9E90F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "667DB3E776FA4844C61A89218601CAD79358"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FC803829A02A846D648FE4799815D0D33FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DA31ECA281DB945CE78A44287404080D751"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B06440F15BA913470619BB763B267B769F61",
                        "defaultText": "그 못된 혀를 잘라 버리게 하지 마, {LT:1}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C88BA1E198E943480D7961C9135D7FEFB50C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E72A62511BA791460969DDF5319864AE6682"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDD0A1927838124AA94A21679F8E17AE5CD7",
                        "defaultText": "기억을 잃었다는 게 아직도 믿기지 않아.\n예전에는... 이것보다 훨씬 품위 있었는데."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E095995937CB414E1388A4E9AE7D894159AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02CD8BF33071C84305994BD5914FC9D4932C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            700,
                            0,
                            799,
                            -40,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51DE24C8544D8447187B4618C754BD7DDE5A"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -25,
                        "green": -25,
                        "blue": -25,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "24B2C83D41DD484FED8AEDE30877B1F551BA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "187E24159BCCB247BC6802385F6C266AB2A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "746BC8DB2484E341EF2A84D010BA151D90BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A476EE8227DAD14F4A2A0741D0F7EC40F52C",
                        "defaultText": "정말이야, 리아? 내가 보기엔 예전의 오르니에르 그대로인데."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D39787017C00034F0D5B766696EEC13D7941",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E084F610388C24158192AB72C8167680AF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43F337C49A161240E389FA33AEC8723C6E19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85AD95B62FD6C647673BA5F3928CA5FC29F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8E125B467AF214BC188D6D1A4E1395A7205"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1275E334C995042D779B2A32ED2F0989676",
                        "defaultText": "네 기억력도 원래부터 나빴잖아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4695E32E84F9D8418A8A6695EE8BE0F2EE95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72AF2F795C37154AC108DDD74660E0C826EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "1505058E23AA814EFE29D21490E2B21A5AD3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB5F74E1762E5140003A05230C0E6CFCF232"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BEB04B0F370716452828C3574B6374FC6A7C",
                        "defaultText": "그저 직감이지만, 왠지 리아 말이 맞는 것 같군."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF5867DF16A6A64D6F68C5E4A724FF419AB8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EA2170D82AA04499918D9589C26A59142E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86FADD6B445158458C8BC0A598C595167B74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C4321CC9ACCB048AC3A2AD6D2BAF628F14B",
                        "defaultText": "크리스토프. 방으로 안내해 줘. 나머지는 내가 맡을게."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A608B24429881348400989D64DD335A1ED38",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B6FD39165EC6142837BDB66957750E4BE1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21904AED7A12C5445F69BF56615F9CFCE46F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44E348AC3885E845227ACE06C0A2C69EF1E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C54176252DC8A448E65A81E8B3531CBC1360"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "84609E7582D2D546A418FD02C396C60D2BD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5801BD684A012642FE4BE7F5EDD66931516A",
                        "defaultText": "알았어! 나한테 맡겨."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47DEE4C99AA7B1489459C9D4C3985B55F3B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4230BEA7F69334C5A7BC5A75DF0391E65BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "D530467F4F4A6348205A99A69F5590974AEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "182ECC697F12774C783B7633CE67067C31F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810"
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE30F25E21F81446267BF1A796471D0CB66F"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "942DDF2E962F644FF26BEB27F0644E47EE15"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "EB5AF93C39C6174FF42B3B21F34F2269ACED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9E2AE66A5E90394AE67B31C1E0B10DE51A56",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DFB9AD38619594C7269AB445135C1FCBBE6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8661F48444C1F74EF33B9925B72B4DE59F7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "233246C81CE8024159380FC43951F9513FF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D607F1AF3DD9204B978AD43265DD14DCAA7C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "66D3265B509BF2467F5AB89022283307E43B",
                        "defaultText": "상당히... 특이한 동료를 두셨군요. 그래도 좋은 사람 같네요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8A3A7B4E1532D245747AED76AFA002F14FAB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "868AC39B70BB1644048A34463D1809B90A8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C7FAB755D9D324F9939C7F35F0CD3A95DF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "944273BC5AF6F9407E4BEAD7B001F5C7C888"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "284023C77530884B556A66F62AC8D2D16257",
                        "defaultText": "좋은 사람입니다.\n이제 방으로 모시겠습니다, 그릇."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8FE24D64552D414B8C6BF966CFD7250A2C5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14DFC3822076E6415B7BB1D1B5BD9DB37815"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41314A684C95784AFD18E052BBB37CCE84F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F31AA6A188D9744D56AE5739010AAE02EE4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B74CFEFC2DB49945056B2F52DD3C304C9E1E",
                        "defaultText": "잠시 시간을 내주실 수 있습니까?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3959C581C27084D617A7C61C6AE8F1CA5AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD98F8B12B1278406B1AE8069B15C6845626"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D673ACCB4BE150482C29A0732DB21663BCD4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C05DBDD3229C34CB01A29C37BA4E3EF9105",
                        "defaultText": "말해라, 기사."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2BD813642E809448A79B313063DB4DEB3158",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B16FB2432657484AAE5BBB478BF6D53B4F30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA53BBFF0F14354396780DB218393A6BD4FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F870A86A1E134448804837A8BD1B8B9AE25C",
                        "defaultText": "방으로 가기 전에 파라트라스 님과 단둘이 이야기하고 싶습니다."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "50359E826FF9F0478A09CAB8F43859221091",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED8D68584428634A9748E522DB81DAB77AE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C4D40EE6BE4264B758B1B170EC5F849954F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B24C7F3E58E8E04EB0784301AEB521FF4774"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8226F47A216EB84CEC79CF80A188C43F45BF",
                        "defaultText": "하필 지금?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "45BF248004A0C847935BC79649D762A449F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1DC6C703B57D14D61182472F1D2E7C7CB5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2333CD7E7C834141F50900B550A0D0E3BAC1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5FF74C439484C243527A1060FC3DF3CF55FB",
                        "defaultText": "온갖 일이 벌어진 탓에 아직 헬리오스와 단둘이 이야기할 기회가 없었어요..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BDBDA5344E4E42403B0BD773D7A3BB6E8DC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AFD06260CA0434DE359F5F13FEA89FB1CF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC692FCD131BD24AB34A35D286D2008A5D22"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C40347803E423441841A3E2449C1C6772852",
                        "defaultText": "부탁해요, 리아. 몇 분만 기다려 주시겠어요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A1D5DB1B76C4504008592AC3BECF3E8DFD21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BA059AB791DE649506BB2018F22A74351A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E3EBB0312C95743307AC8D3FFF5D27E7C73"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF73F1F92D4D7543026A0C22769BC8DECE04",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A07B3737908F64CF849BA52DEAE2B807EDA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F553177553B1948BA8BB4B206B9D9E83CE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "150F5DA566531649194B1CE48F4C2EC7E41A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "743BC50B8A5FA146B64A6E62823D76713943"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FB5DE744192314EFE4AC09617F1D70B0322",
                        "defaultText": "복도에서 기다릴게요. 수상한 짓은 생각도 하지 마세요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0643F16B2668C14BD829A073C512C1F11DC7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEE3A8244BB62040897B05892EB06DF4146B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D759B9E28F9D540798A74132CF0F8F8BE00",
                        "defaultText": "마그놀리아는 전술가와 정보원의 나라입니다.\n이 건물 자체도 늘 감시받고 있어요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C4568DD11EC6774A3B4A38D8E50D2549465A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6280EC1461DD5488F09F05771C07B1B16F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0BAB4EB94E3B341636B437696728A815A37"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7CD23157947B714E693AD7592D40EB24386C",
                        "defaultText": "걱정하지 마세요. 당분간은 도망칠 생각이 없으니까요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "139BC0E728EED245FA8810C84CB77194A8EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9067A8B076F22143EE39C3856ECC3BC61902"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66311B342C4E12468C28CCF7EBC0C658F7CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77FA08962862384D05994CF2D3B69E0494DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C3E871B046BFB9461279C184F48C712EAAA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87D3B7EB23E3F44E266A9AF53B302CDEC40E",
                        "defaultText": "그럼 좋습니다."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "440347BA617EF14089692B767A5B374124B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0421FD7447A97540F418FE23C3785681A2EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "835191BD7540634827181764F0A315EA2189"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B67D08165E58B941B3885F51FAE3EE962CBF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "2638086015D22440147B5E66A0F153BC68EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "51DFBCF99DDA434E9E490F635F0F723FB728"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4DDADB217A5FC542461ABEA5AF7267ACC407"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "533B1AD546BF09410F085688C216063DD59E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A191B045E3253419D9B14B70C5DE93DC7CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C08768E3E1BC54C381A0175CD3A59EA40E7",
                        "defaultText": "그래서, 무슨 이야기를 하고 싶었죠?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "629653AF3F5CF141E79A56A838A56BF6E48E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA6ACEBD1D2EC443244B67509D512DA25B42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "171BF7F884F0F94C4F38B2445B903B8E3D60"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F6365B0B1DE7D04A1C5AEAD1BFF616AB03EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            900,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58E96D991898324BBD4849C3F4849189F101"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -25,
                        "green": -25,
                        "blue": -25,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C37F03AA01E0D94A8D886CD81A64FF401F57"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "5D5E5B13499CD54A3C68DEC2AB61DAB7DEF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D8A0172688CE44A5889C078C5B1C9CB3676"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABC0E8AC89190140FD09D5C273DD03CE3BE0",
                        "defaultText": "질문이 많으시겠지요?{W:300} 무엇이든 물어보십시오."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "61E52FA7584A76445B885074C98ABB8A65CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8E1ACA06F0631480B7BEE396BCA8DB03100"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15F495F94B11384C2A6BD0F30BF1200F835A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D81A67EE34F239461A0887435F1256AFF863",
                        "defaultText": "맞아요.{W:300} 하지만 어디서부터 시작해야 하죠?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3B11C27487F90459089A4D23738E9A501B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E90FB1D13FE147483A18B1F53E157C28639C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "755F99F4947A7549658960789C5AC9948F92",
                        "defaultText": "넌 누구지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B7C7F18B3EA4D44C9E084C55A92CD10BF1A3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "BF43E3DE28BFD444B5492B26FB4139150AED",
                        "defaultText": "알바노의 계획은 뭐였지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3BBC2F104D8625432D28902925BA78FCC2DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "identity",
                            "alvano plan",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D24437B76120A14EE40B3C31794CE031ED56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "79453D1B282F824B569B30736818FBD107C2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "identity"
                },
                "indent": 0,
                "uid": "5218C8C0770523466C895C76A91384F776EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48593C755E27E644BB9A57B3D1F59C6218E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B107371A141E02481969609340C85FF5DC7E",
                        "defaultText": "저는 그저 무니 여왕님이 존재를 비밀에 부친 사람일 뿐입니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5490AC2D4F0F8048525A5441E04DC4677EFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "969B5D6B520D214CBB49A0846F41DBE5821B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5E7225A21432541247ACC982791725CBE63"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5770F2C38DD454470778A76222E18AB38C23",
                        "defaultText": "왜 어머니가--{W:300} 무니 여왕님이 그런 일을 한 거죠?{W:300}\n내가 모르는 뭘 알고 있는 거예요!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "50F67786639E36438D5A65E59758B993BC09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67D089E31A4CF748454B26C8C01540589BEC"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "final reveal",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "597771372EB83741FC681DD81F20B1F807D0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "alvano plan"
                },
                "indent": 0,
                "uid": "BF8457B022D4064DCF9901C57B35754E469B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E242A51D401A8741A17AA62240102789B2BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA4FA81B9534224AFE08F606C6C22DE2CE2A",
                        "defaultText": "오늘 일어난 모든 일에서 알바노의 역할은 그리 크지 않았습니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line54.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "77C550700898674839592687A8007C7C3A07",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC14752F14696743D749E0879AF7A68AC3A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8812CEDD116BA24F2E690817E5ED840E6F7F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64059D078E58B146044838E75222D5EBF8CC",
                        "defaultText": "무슨 뜻이죠?{W:300} 알바노가 진짜 배후가 아니었다면, 대체 누가--"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line55.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FD34B8C84DDC724E877ACA233239537C0797",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31BAB64C1296E043B3387D3986E8B53C6F93"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "final reveal"
                },
                "indent": 0,
                "uid": "F17400C71A9E6942474A94645376AE578F85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E87149CA471411457188F662CC611E231F23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F27932F281A1E641518A97B5A24CDA0812B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E70539214A5668434E1AC3F44019D1F96CB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E90F8F18634A7401E996A97FF4457395CF1",
                        "defaultText": "진실을 알고 싶다는 확신이 있습니까?{W:300} 당신에게 고통스러운 진실이라 해도요?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "31450D24980A354B3B5B3C17A4C6E1973B0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87FEF0968F95E149302829E858FA41E2F2AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2224FFBD3650E340AE889716AA3284989244"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8263A53A76A1A14BDB2879D12F8ED6C2FD5B",
                        "defaultText": "지금 느끼는 것보다 더 고통스럽다고요? 그럴 리 없어요."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "393F426C694E144B7B392F90C0DCC4C43205",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEF3A91B1A42E647EB291BC4A59570AB0FE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8E4F7188B6C2849E74B92D301CA101FB25C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E236C4080DB044E1F3BE881B700821B1FDE",
                        "defaultText": "부탁이에요.{W:300} 더는 비밀로 하지 마세요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line58.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1348EB744535A04A5B1B0A669217DAFDEAA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C96D43E4083204FA64AAAA51C7DB7B06181"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24FC53FC23AE044E02795AE491AE6E288BD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F6C6E964B46E1429E8AE84904CBBE83CE0C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36694BAC10AEC6463E888CE62CB6A2331359",
                        "defaultText": "알겠습니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line59.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7C7A98FC67DBE141485AF5348763E8951BDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC53DCB73724214994683F8642FB50ADAD8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF0F2D796A3BA747A57912D2FFBAF268B994"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12B2F1E62AFA414C142A5F4529A0464C5297",
                        "defaultText": "무니 여왕님이 {SP:1}{C:1}당신을 배신했습니다{C:0}.{W:300}\n병사들의 정신을 지배하려 한 것도 여왕의 생각이었습니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CA1D9CC43E35154A5B4AE9520648326BB98A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5C425054319744ED47A4406875B0DDD3BF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A55DE60D74FC194A2F5B2492FF1A102D0297"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46D864AF4E27E1408A59E443924ACAD064A5",
                        "defaultText": "뭐-뭐라고요!?{W:300} 무니가 그럴 리 없어요!{W:300} 그분은..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line61.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "45FAAECB25483742E88B05A34A7B2B676806",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E15C8CF11F2BB542B43A51B54D13F7DAB3C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A165FAC1257F0147A96A0EB78ED84AECFC54",
                        "defaultText": "우리 사이에 차이가 있어도...{W:300} 제게 어머니 같은 분이에요..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line62.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DC57FBB8553F6542AA58598527703B9FE647",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC5935562E29B14DF5691BF44EE5FCF46A48"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E26592508890C2452A48BEB704B9CB98F2F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0479ED614DAD6844E08962E83F14C6E34751"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "108C954869ADE142E95A62331E52F13B5743",
                        "defaultText": "무니가 알바노에게 그 병사들을 세뇌하라고 명령했을 때\n저도 그 자리에 있었습니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B00D3C451E8475438589F6373E4F481B886E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A18CA3222588254C791BEAE847FB31AA4056"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEC837D526BE11452E7BC5D3A66584E77E89",
                        "defaultText": "알바노의 힘이 부족하다는 말은 분명 거짓말이었습니다.{W:300}\n목적은 오직 당신을 함정에 빠뜨리는 것이었죠."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line64.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F93DBC03547F554840395D71C0A9BB0DEA34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB5D92645258B14AE20962C94BD49A31FCC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5EF863A8CD15548605901D80C3D796BC71B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9CCBE45569B50642014B1DF81BEC46AD704E",
                        "defaultText": "왜...{W:300} 당신이 왜 그 자리에 있었죠!?{W:300} 정체가 뭐예요!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "39C211F87B7FE044B378CC49F06DCA19783B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9AFA8E92A9C0445F3596B74ADC2AD23F1F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63BD6BF41089454DF92ADBA5FAD7405640FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "89C8AAFF2877F34D6A3AEC83C682E3E17319",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line27_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4B17AA283879874D2A7BA903B01FAAC7D2E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6B1E02A8793D5445B1A29C74A630643FA66"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D6F4EDC85F7A3474929F4969DBAC37D3B0A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "A2A02BFE8D3D7749C538464442C83D38F11C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B190B3D23F4CE34AA34B91F170ED30543756",
                        "defaultText": "제 존재 자체가 죄악이기에, 저는 언제나 그림자 속에 숨어 지냈습니다..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "10A2BFE974317148376A5E8666CC74F15D41",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC46A8C2437FF2421F8BD9A83084C79FAD85"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF8B89E455707140CC693A5892818DD6B30B",
                        "defaultText": "파라트라스, 저는 무니와 당신의 아버지 알프리드 사이에서 태어난\n{SP:1}{C:1}숨겨진 아들{C:0}입니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5D34EBD01B76B441F10BEDD6A39E219A5F7F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2AD14093138C7471E49C338A0E673F78A0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "594A3CCA22345647BF3859B8B49773944811"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F5E987E16DEB9740B23972369EB8132FFD83",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line29_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5867C0348387154B9E8875E38489D6610FFC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BFAB14AA3738C34C6F58F1F436021257E1E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C62940918312A34234197D12D76E8DC7529C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F83760A65AB28748703A37A14DA7D71622BC",
                        "defaultText": "그가 내 {SP:2}{C:1}이복동생{C:0}이라고!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F979270E5E0CC54EE22B7787A697063AF776",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "325F9027020043411C39A0B640B646879709"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCA9888C3DA205416F28515888A46007BDE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82ED1F7B7A2A3241AD79F96566D9EF276283",
                        "defaultText": "아-아니야... 거짓말이야..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line68.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BC00B4D155F33147303ABAA1DCF4A8BD2D10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77C879C666266247383B2041F0CB588490F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FCEEAC8384182405D6917B8338F74C9217A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97CAB1DF8744154AF9691C67781AFD60FDA7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B812E9A363CE84547381568CBBDFA879F07",
                        "defaultText": "제 왕가의 붉은 눈도 거짓말을 합니까?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line69.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "198BE2D110412643B149DD3584AE52761736",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEDB830733D8854906587ED8305DF24DCF5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E27F6574439E514E669A0CF5C84623217B6E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A33C065C7F9425422F2A1B98BDB3760684A6",
                        "defaultText": "호이카데 왕족만이 붉은 눈을 지니고 있어요...{W:300} 이 사람은..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "62263C08675A284013391526DAD5D85C3C32",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "159F5469368F234FA17AFFE7914CA03665F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36034E01151A644AE0383B200AFDEA20C7A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F91FA7E044BC548B07BF7B7DECC5FB51551"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D67B57E578F25046836A848795320927E035"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "655BADFF76178747834BF8D976C35973C9EC",
                        "defaultText": "갑작스러운 이야기라는 건 압니다.{W:300} 제 말을 생각해 볼 시간을 드리겠습니다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line71.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5A4E5094615E384A5E6ABF964C3F07900862",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB4CF2B260719842D428E76526FA9C70DAEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B111195823F7149F92BE09352802B28D65F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "0A6E6C679C07C847F9593988F05A2F8952F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6FD94BE23AC8644BB3ACF514F157E784520"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 74.4
                },
                "indent": 0,
                "uid": "196D47AF5BF6674AA6287C04553179E811C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            7
                        ]
                    }
                },
                "indent": 0,
                "uid": "1547DE601008B046CB2B6AD66363616A7E63"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A6E0B6671B52A441CA296CB2C6F7097337A4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "C72140CA3A9D224EBC39E29560A3A29B8812"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "869AC6302F98844B6A8AA6741FAFC90872A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF1F86CB1C6941493D2A7887E6BAF56FFE7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F78450DE21EB72489A5B197616A549BD02AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D696DF22745F2341171A8A682E01B55A0C4C",
                        "defaultText": "자-잠깐!{W:300} 헬리오스!!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line72.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9D24D2576F38704E4D2B769710C185DF854E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CA66F50543CE4465F68CCE2AC2418ADCD57"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 20,
                        "x": 2
                    },
                    "speed": 200,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2D5BE06F6A0518426B3B9C454156D055CCDF"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "HEARTBEAT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 1,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6B3986F6616C83431E0ACBE240FE2E20A4F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "545F5F7A5B2CA64E165AE5F7EE3727C6A412"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4ACAA8C24122D449227920C3831022B9E673"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "374346F04BDBF849D5188396916801D0EF8C",
                        "defaultText": "으윽, 이건 좋지 않아... 진정해야 해..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "23ED08C78745D140F03A26A53110294C2FC6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "267CED217369C640D91805415DD92124C312"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5AF4066867C614B2A392B4507C72DF6F8F8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F290FEB996CBE74871090227E2320C45283F",
                        "defaultText": "아무리 고통스러운 진실과 마주해야 해도... 나는 그릇이야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "22488AFF4563E04276999183861DB909F94E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BDBDB6665C6384147889B31FB5F5B06F269"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 20,
                        "x": 2
                    },
                    "speed": 200,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9CEEEE6183BAB144B649BF638163B13A8E57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6844203788953147123903E420D3E0164C6F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73F3F5C79F12D2498A2A96436ACE808C4D01",
                        "defaultText": "흔들려선 안 돼. 이런 감정에 굴복할 순 없어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D23D9E8F8320C14CF01A6898494D07AC7C5D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A417815C05234647B87B3E95D31ABF5C74C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9C6122593EF864EA06AF3D220422CCBD8F9",
                        "defaultText": "진정해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E000650156C1D54FAA3AC5E163EB83E867B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4FE995288F37445E239B23074251E2907B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D02D048D76F2C443A15BCA86CB52C1C29393"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "0292F3FE7C89094DAB496BA5207E9D37371B"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "HEARTBEAT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "02004F8965713942D02AF333EFCE5F8E7031"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DE39E2161026A5498978B972A07A032881F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39FD49E74EF0A44BD49A9A82A5675BBC349E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A27229AB219393457338ED763F3F1136E944"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "78CDDE048F180747C90AB6B58578C0873D51",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line77.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E9C42CC42A121840E958EB74B6EADCF02D6D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E9D1B8FA8E3A1349463AC48458EA31703AB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9FD0C033F1FF244336A02C85E4332861F29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "959DDC0122DC114435389424A34C4294C103"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FAB3D0B5110FE44C6F4AF737270DAF8F9AB5",
                        "defaultText": "헬리오스..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line78.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D5F844ED6800D347401AE00645FAB2984BE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FD88B62C3FE386445C8A02E3E681F2889BAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "36F7FFEA859998452E28E638DA434000D24D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E26118115C36F14CBC88D4B5F284F4BFFAC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "768430852A37014A7369356383E87F882137"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "454F0F722EC3E845287877B758F923D97240"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "EC08341917C29748D659A4F7112A55F98644"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "174C983259B796421B1A60D3B0EC5ED63A80"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "3D58F704004B6647108A9516335856F74717"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "C8E78EF921245844718A60D1FFA341949E52"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "EF1E3B27623CD145E869AFB00D03B36D8BF5"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "6E1A57D05D0E404BE6797E44DD6238D8DB9E",
                        "name": "SAVE BETWEEN CHAPTERS"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7BAAEB0432D6B348562B84A466D5D59852F4",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "Suzaku's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "56CD6C5E8CC0064AA62A96C5E91A6A11D1B9": {
                "t": "Thank you all for guarding the palace while we were away. You're dismissed.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "49B5918F5E9C9442CD5B8E6108805096F685"
                }
            },
            "26FFE617266EE54EDC5A4C4766AEB9806870": {
                "t": "Cristoph.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "23EDF374005C634239889857D16898ABA2F8"
                }
            },
            "F2E23113192F464BE0796F2865C5214DC652": {
                "t": "Yes, Milady?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "634D245B5346E548087976945EB5D4F8E436"
                }
            },
            "4628774C77AB78438F9AAA8708F0411E0D80": {
                "t": "Why did you insult the Vassal forty-seven times while coming here?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "D6C386E806AAF0496A58A6C3A27D512FA56B"
                }
            },
            "AC06985E3087064D2E583527C5105927D27D": {
                "t": "I'm sorry, Rya, but I can't trust her. I can't respect someone gifted with a power she can't even control.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "BBC212AC01EA544E062B209655B4FEC3D3B1"
                }
            },
            "F69FB260889D824B3B9BBE92619B6E064625": {
                "t": "And you heard her story, didn't you? What if those Hoikadians were right--",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "2234E0924277A540C47B7F565FC79C2530D4"
                }
            },
            "5A0CC98A281423493948F584D477A75893DB": {
                "t": "Watch your tongue and be smart for a change! If she really was controlled by the Demon, teasing her could be dangerous.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "8916D17C3DD0674D722862168454B650C8FA"
                }
            },
            "C2F643567A2E454F9548B8751338C893AD8D": {
                "t": "And if she wasn't... you would have insulted an innocent woman.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "237DECB5262A274537882902F78212453797"
                }
            },
            "8353EB268105B747644B603733A2E3542A12": {
                "t": "... You're right. I'm sorry.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "6743006D8F99734E9778B740412BF24DE16E"
                }
            },
            "C92DDC4E861E4745157B7204EB6304824F4A": {
                "t": "You also have to consider that she has been through a lot. Her parents, right after she was born, died under unknown circumstances.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "F36C361C19F08849F56B7037D2FD5170CADD"
                }
            },
            "E7E194617F023649F92A18263A439DE2147D": {
                "t": "She was raised by the woman we know as Hoikade's current queen. The former general of the army, Munie.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "8D6641DE6520024DBB78B2A8BB00F5B37F50"
                }
            },
            "740B65568DD7D4470E4BA033901EB72CC971": {
                "t": "And she also bore the weight of the Demon King while going through all of this...",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "8756B19D44A7434F117B2372B7952E5A5A3B"
                }
            },
            "C88A20570BC0C6473E28643433C4A7A2953B": {
                "t": "I suppose I have to apologize to her later.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "B2D90769811B6948148AA7830354E8D265A5"
                }
            },
            "6C3BE2C37724A740C87B85B3890481B90877": {
                "t": "That's up to you.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "2F5C46A2516B14495A4B13D56E66D52C9B8F"
                }
            },
            "B4FDB46A4EE980485598DBD25CB6BE153A3D": {
                "t": "Well, speak of the devil. Look who we have here.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "27B3C55E7144A742DE5979091614369120B2"
                }
            },
            "7FC367D38E99724DCC5AF351081CC564D0A9": {
                "t": "I've never been to your palace, Princess Rya.\nI must say, it has a very particular style.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6480A76A3B46F0440A5A7F3308DBDD805845"
                }
            },
            "68F5997A5F1BF140836923161B604EDE08F3": {
                "t": "Your compliments are most appreciated.\nAnyway...",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "58E65E6B5BEF284F005AD596659E13D975D5"
                }
            },
            "6668CEFF4ECF48413A8AA93085A41477D3F0": {
                "t": "After what you reported to us on the way here, there is no doubt that you need to talk to the empress as soon as possible.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "19B3EB034EA6A745A14A6E62E1B4F23AFA37"
                }
            },
            "956C86394916A14F9D689047037C21D9434C": {
                "t": "That's fine. Our meeting's scheduled for tomorrow, right?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "930B9D788623594DBE687D07F6697D9103F3"
                }
            },
            "2B9005093B4E3645406B25B5B4DF944443D6": {
                "t": "Yes, in the afternoon. You can all rest here in the meantime.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "E0B3E3E763E5F4442A0A3D8436D2F4CC3F0D"
                }
            },
            "59D5B14D945396402F0A6819238D536DD1A2": {
                "t": "Sounds fine by me. I can't remember the last time I slept in such a beautiful place!\n... Literally.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "49715D0E3F3E5345043A10B2F101C08D291C"
                }
            },
            "9441FB756EC5C6439B69B034D93B6EBFFB59": {
                "t": "Not that sarcasm again, my ears are bleeding...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AB606D842740B5406D88739920132018D5B8"
                }
            },
            "B06440F15BA913470619BB763B267B769F61": {
                "t": "Don't make me cut out that nasty tongue of yours, {LT:1}.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "C88BA1E198E943480D7961C9135D7FEFB50C"
                }
            },
            "BDD0A1927838124AA94A21679F8E17AE5CD7": {
                "t": "I still can't believe you lost your memory. You used to be... much more refined than that.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "E095995937CB414E1388A4E9AE7D894159AD"
                }
            },
            "A476EE8227DAD14F4A2A0741D0F7EC40F52C": {
                "t": "You sure, Rya? He seems like good ol' Ornières to me.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "D39787017C00034F0D5B766696EEC13D7941"
                }
            },
            "C1275E334C995042D779B2A32ED2F0989676": {
                "t": "Your memory has always been weak, too.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "4695E32E84F9D8418A8A6695EE8BE0F2EE95"
                }
            },
            "BEB04B0F370716452828C3574B6374FC6A7C": {
                "t": "It's just a gut feeling, but something tells me she's right.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "EF5867DF16A6A64D6F68C5E4A724FF419AB8"
                }
            },
            "7C4321CC9ACCB048AC3A2AD6D2BAF628F14B": {
                "t": "Cristoph. Show him his room. I'll take care of the rest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A608B24429881348400989D64DD335A1ED38"
                }
            },
            "5801BD684A012642FE4BE7F5EDD66931516A": {
                "t": "Roger! Leave that to me.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "47DEE4C99AA7B1489459C9D4C3985B55F3B5"
                }
            },
            "66D3265B509BF2467F5AB89022283307E43B": {
                "t": "Quite the... atypical companion you have there. But he seems like a good person.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8A3A7B4E1532D245747AED76AFA002F14FAB"
                }
            },
            "284023C77530884B556A66F62AC8D2D16257": {
                "t": "He is.\nNow, let me escort you to your room, Vassal.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "8FE24D64552D414B8C6BF966CFD7250A2C5E"
                }
            },
            "B74CFEFC2DB49945056B2F52DD3C304C9E1E": {
                "t": "May I have a moment?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "B3959C581C27084D617A7C61C6AE8F1CA5AA"
                }
            },
            "3C05DBDD3229C34CB01A29C37BA4E3EF9105": {
                "t": "Speak, knight.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "2BD813642E809448A79B313063DB4DEB3158"
                }
            },
            "F870A86A1E134448804837A8BD1B8B9AE25C": {
                "t": "I would like to talk to Lady Faratras privately before going to our rooms.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "50359E826FF9F0478A09CAB8F43859221091"
                }
            },
            "8226F47A216EB84CEC79CF80A188C43F45BF": {
                "t": "Now, of all times?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "45BF248004A0C847935BC79649D762A449F8"
                }
            },
            "5FF74C439484C243527A1060FC3DF3CF55FB": {
                "t": "With all that happened, I still haven't had the chance to talk to Hellios privately...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BDBDA5344E4E42403B0BD773D7A3BB6E8DC9"
                }
            },
            "C40347803E423441841A3E2449C1C6772852": {
                "t": "Please, Rya. Would you be so patient as to grant us a few minutes?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A1D5DB1B76C4504008592AC3BECF3E8DFD21"
                }
            },
            "EF73F1F92D4D7543026A0C22769BC8DECE04": {
                "t": "... ... ...",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "7A07B3737908F64CF849BA52DEAE2B807EDA"
                }
            },
            "3FB5DE744192314EFE4AC09617F1D70B0322": {
                "t": "I'll be waiting for you in the corridor. Don't even think about doing anything funny.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "0643F16B2668C14BD829A073C512C1F11DC7"
                }
            },
            "1D759B9E28F9D540798A74132CF0F8F8BE00": {
                "t": "Magnolia is a land of tacticians and informants. This very building is constantly under surveillance.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "C4568DD11EC6774A3B4A38D8E50D2549465A"
                }
            },
            "7CD23157947B714E693AD7592D40EB24386C": {
                "t": "No worries. I'm done running away for the time being.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "139BC0E728EED245FA8810C84CB77194A8EF"
                }
            },
            "87D3B7EB23E3F44E266A9AF53B302CDEC40E": {
                "t": "Very well then.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "440347BA617EF14089692B767A5B374124B3"
                }
            },
            "5C08768E3E1BC54C381A0175CD3A59EA40E7": {
                "t": "So, what did you want to talk about?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "629653AF3F5CF141E79A56A838A56BF6E48E"
                }
            },
            "ABC0E8AC89190140FD09D5C273DD03CE3BE0": {
                "t": "I suppose you have many questions, don't you?{W:300} Ask away.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "61E52FA7584A76445B885074C98ABB8A65CE"
                }
            },
            "D81A67EE34F239461A0887435F1256AFF863": {
                "t": "That's true.{W:300} But where do I start?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E3B11C27487F90459089A4D23738E9A501B5"
                }
            },
            "755F99F4947A7549658960789C5AC9948F92": {
                "t": "Who are you?",
                "d": {
                    "eid": "B7C7F18B3EA4D44C9E084C55A92CD10BF1A3"
                }
            },
            "BF43E3DE28BFD444B5492B26FB4139150AED": {
                "t": "What was Alvano's plan?",
                "d": {
                    "eid": "3BBC2F104D8625432D28902925BA78FCC2DD"
                }
            },
            "8263A53A76A1A14BDB2879D12F8ED6C2FD5B": {
                "t": "Even more painful than what I'm feeling now? I doubt it.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "393F426C694E144B7B392F90C0DCC4C43205"
                }
            },
            "A33C065C7F9425422F2A1B98BDB3760684A6": {
                "t": "Only members of the royal family of Hoikade possess red eyes...{W:300} He's...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "62263C08675A284013391526DAD5D85C3C32"
                }
            },
            "374346F04BDBF849D5188396916801D0EF8C": {
                "t": "Nnngh, this is bad... I need to calm down...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "23ED08C78745D140F03A26A53110294C2FC6"
                }
            },
            "F290FEB996CBE74871090227E2320C45283F": {
                "t": "No matter what sort of painful truth I have to face... I'm the Vassal.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "22488AFF4563E04276999183861DB909F94E"
                }
            },
            "73F3F5C79F12D2498A2A96436ACE808C4D01": {
                "t": "I can't falter. I can't be overcome by such emotions.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D23D9E8F8320C14CF01A6898494D07AC7C5D"
                }
            },
            "D9C6122593EF864EA06AF3D220422CCBD8F9": {
                "t": "Calm. Down.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E000650156C1D54FAA3AC5E163EB83E867B1"
                }
            },
            "DE04E2D96D4FF24F4D1ADED2366208F0642B": {
                "t": "What were they talking about just now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AF4037A16C92E744E40ABCB301F6D8FE8FED"
                }
            },
            "B107371A141E02481969609340C85FF5DC7E": {
                "t": "I'm merely someone whose existence was kept a secret by Queen Munie.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5490AC2D4F0F8048525A5441E04DC4677EFD"
                }
            },
            "5770F2C38DD454470778A76222E18AB38C23": {
                "t": "Why would mother--{W:300} Queen Munie do something like that?{W:300} What do you know about her that I don't!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "50F67786639E36438D5A65E59758B993BC09"
                }
            },
            "EA4FA81B9534224AFE08F606C6C22DE2CE2A": {
                "t": "Alvano didn't play that big of a role in everything that happened today.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "77C550700898674839592687A8007C7C3A07"
                }
            },
            "64059D078E58B146044838E75222D5EBF8CC": {
                "t": "What do you mean?{W:300} If Alvano wasn't the true person responsible, then who--",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FD34B8C84DDC724E877ACA233239537C0797"
                }
            },
            "5E90F8F18634A7401E996A97FF4457395CF1": {
                "t": "Are you sure you want to know the truth?{W:300} Even if it may be painful to you?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "31450D24980A354B3B5B3C17A4C6E1973B0D"
                }
            },
            "5E236C4080DB044E1F3BE881B700821B1FDE": {
                "t": "Please.{W:300} No more secrets.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1348EB744535A04A5B1B0A669217DAFDEAA1"
                }
            },
            "36694BAC10AEC6463E888CE62CB6A2331359": {
                "t": "Very well.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "7C7A98FC67DBE141485AF5348763E8951BDF"
                }
            },
            "12B2F1E62AFA414C142A5F4529A0464C5297": {
                "t": "Queen Munie {SP:1}{C:1}betrayed you{C:0}.{W:300} The idea of controlling the soldiers' minds was hers.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "CA1D9CC43E35154A5B4AE9520648326BB98A"
                }
            },
            "46D864AF4E27E1408A59E443924ACAD064A5": {
                "t": "W-What did you say!?{W:300} Munie wouldn't do anything like that!{W:300} She...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "45FAAECB25483742E88B05A34A7B2B676806"
                }
            },
            "A165FAC1257F0147A96A0EB78ED84AECFC54": {
                "t": "She's like a mother to me...{W:300} despite our differences...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DC57FBB8553F6542AA58598527703B9FE647"
                }
            },
            "108C954869ADE142E95A62331E52F13B5743": {
                "t": "I was there when she asked Alvano to brainwash those soldiers.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "B00D3C451E8475438589F6373E4F481B886E"
                }
            },
            "EEC837D526BE11452E7BC5D3A66584E77E89": {
                "t": "She obviously lied when she said that Alvano wasn't strong enough.{W:300} Her only purpose was to set you up.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "F93DBC03547F554840395D71C0A9BB0DEA34"
                }
            },
            "9CCBE45569B50642014B1DF81BEC46AD704E": {
                "t": "Why...{W:300} Why were you there!?{W:300} Who are you!? ",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "39C211F87B7FE044B378CC49F06DCA19783B"
                }
            },
            "89C8AAFF2877F34D6A3AEC83C682E3E17319": {
                "t": "... ... ...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "4B17AA283879874D2A7BA903B01FAAC7D2E0"
                }
            },
            "B190B3D23F4CE34AA34B91F170ED30543756": {
                "t": "I've always been hidden in the shadows, since my own existence is sinful...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "10A2BFE974317148376A5E8666CC74F15D41"
                }
            },
            "BF8B89E455707140CC693A5892818DD6B30B": {
                "t": "Faratras, I'm the {SP:1}{C:1}secret son{C:0} of Munie and your father Alfhrìd.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5D34EBD01B76B441F10BEDD6A39E219A5F7F"
                }
            },
            "F5E987E16DEB9740B23972369EB8132FFD83": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5867C0348387154B9E8875E38489D6610FFC"
                }
            },
            "F83760A65AB28748703A37A14DA7D71622BC": {
                "t": "He's my {SP:2}{C:1}half-brother{C:0}!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F979270E5E0CC54EE22B7787A697063AF776"
                }
            },
            "82ED1F7B7A2A3241AD79F96566D9EF276283": {
                "t": "N-No... You're lying...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BC00B4D155F33147303ABAA1DCF4A8BD2D10"
                }
            },
            "6B812E9A363CE84547381568CBBDFA879F07": {
                "t": "Do my royal red eyes lie as well?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "198BE2D110412643B149DD3584AE52761736"
                }
            },
            "655BADFF76178747834BF8D976C35973C9EC": {
                "t": "I know that this is sudden.{W:300} I'll let you think about what I've said.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5A4E5094615E384A5E6ABF964C3F07900862"
                }
            },
            "D696DF22745F2341171A8A682E01B55A0C4C": {
                "t": "W-Wait!{W:300} Hellios!!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9D24D2576F38704E4D2B769710C185DF854E"
                }
            },
            "78CDDE048F180747C90AB6B58578C0873D51": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E9C42CC42A121840E958EB74B6EADCF02D6D"
                }
            },
            "FAB3D0B5110FE44C6F4AF737270DAF8F9AB5": {
                "t": "Hellios...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D5F844ED6800D347401AE00645FAB2984BE3"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}