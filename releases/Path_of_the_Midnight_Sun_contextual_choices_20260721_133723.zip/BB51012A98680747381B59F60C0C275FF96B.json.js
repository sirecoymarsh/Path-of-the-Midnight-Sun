GS.dataCache['BB51012A98680747381B59F60C0C275FF96B'] = {
    "uid": "BB51012A98680747381B59F60C0C275FF96B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-02 Talk - Cattleya & Menmus",
        "type": "vn.scene",
        "parentId": "E0FB0CB122CBB64CDB2914660A8217741C93",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 5,
        "localizableStrings": {
            "CAAC19A508B7174D6A799953EEF008B09D7F": {
                "t": "Huh... Okay, this is awkward.",
                "d": {
                    "cid": 0,
                    "eid": "ABF938395E3F054258287988B40B24C75349"
                }
            },
            "4FFB5CBE71F332431E687D262081DF270C73": {
                "t": "Is anything the matter, Sir Ornières?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "9F3267C718A4454EAF7A30878B956EB7C6F1"
                }
            },
            "6950905D27B198478D48EDF8A686B5E5810D": {
                "t": "Oh, nothing. Except for talking to someone against whom you fought a battle to the death a few hours ago...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "347CA2C37DCA53485A3A79C43EBBED7AEAE7"
                }
            },
            "722AA16609590241F649B19582DC43370491": {
                "t": "I'm surprised you already know my name.",
                "d": {
                    "cid": 0,
                    "eid": "27D791CD251DF245B0485D7435A7A3947E43"
                }
            },
            "4142EDD64FC938472C6ADD5575005FB210A0": {
                "t": "Names... are nothing more than empty husks, containing the feelings you carry for someone.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "3E56FD3B6A05F34D845BA49479A393E2BAEE"
                }
            },
            "1523DCBA218A4245253B2B199EB050E21EA9": {
                "t": "Can you stop being philosophical for a second, Menmus? My mood is bad enough as is.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "A2929BBD20B5244E7D8A90F97CC5BF02D6E1"
                }
            },
            "E37787BB95E2A2445C5BF296E19CBE42379F": {
                "t": "I was getting to the point... You need to be more patient, Cattleya.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "8870AF499E8EF7434E6B7F36D2ACF23F4667"
                }
            },
            "0701345297490447C12A84E83EDBDC6452AC": {
                "t": "Captain Menmus, color me interested.",
                "d": {
                    "eid": "A14A5E2A8D1C264C614AD076317B38988D05"
                }
            },
            "7D79A645576A224ECA899F803AF4BC100DC7": {
                "t": "I think Captain Cattleya is right...",
                "d": {
                    "eid": "CB874A242C6E78481A5922005C3897FC454D"
                }
            },
            "EC2EF4450839A2447128A74405E03508260C": {
                "t": "You can't be serious... That's why I prefer to stay in the rear. I don't have to deal with his nonsense.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "C36BBDBC15A770437769FD22B02B02C620B0"
                }
            },
            "56F79FEB40BFB845569B40E4D23FA79A6B15": {
                "t": "Her tongue is as sharp as her blade, but don't you worry, she appreciates our company.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "C4E2F7025039654642580EE9B03CB7E27618"
                }
            },
            "4C67258768846941A87AC3F1B048C7168C13": {
                "t": "Sir, my disappointment is immeasurable, but I still respect you.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "8B034CB61CCEA744D62B2847ECD38118CEBB"
                }
            },
            "2318235810F40747B548BD74056D88757397": {
                "t": "Any sane person would agree with me.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "C1CC36179E8247464E49F1226F895B643DFD"
                }
            },
            "3F2FE109576BC549A6793869A828670422AE": {
                "t": "Regardless, what I was trying to say is... Ahem.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "C615BC15353B274A9848E8B06ECA11F0B837"
                }
            },
            "7B81BFD647D8324C5B785B01BFA5AE22901C": {
                "t": "... ... ...???",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "34BA44D32A3F614AAB6AA2B6B89FF33112F0"
                }
            },
            "F9069824960A5442B02882329D266745973A": {
                "t": "Menmus likes to talk in this... puzzling manner. He's probably referring to your Manacrest.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "5A7A60342BE72749C93BFFB5057825F4EC78"
                }
            },
            "AE966B8213A5E841B17A7EE61CB7836DD644": {
                "t": "Ah, this. Are you interested in it?",
                "d": {
                    "cid": 0,
                    "eid": "93BB1A873F21B4495B78DCF7F87C1A9C7E09"
                }
            },
            "C7E3605394D0674C184A44976F7C587B23B4": {
                "t": "A tool that allows us to use magic whenever we want... Imagine the applications! We could save so many lives!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "E48F84068AAA77423A6B637930EFF2F02C2A"
                }
            },
            "8A37D0A549A291465D48C9E07CD4D3F1F908": {
                "t": "That's what everyone keeps telling me, and I appreciate your enthusiasm. But I can't learn any healing spells, unfortunately.",
                "d": {
                    "cid": 0,
                    "eid": "AE1BFD818CA5A54E435910101594DA1A1BA4"
                }
            },
            "78869EC870895347D52926622C9AAB294A1D": {
                "t": "That's why you have the best captain of Hoikade here for you. It's time to unlock your true potential!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "DB1F4A2B6E23544E7F583984471788919BD9"
                }
            },
            "1912D26295C3574592980548F8D2E9EA9C72": {
                "t": "He's talking about me, obviously.\nDo you want to spar?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "33FED9B93BAAD1434E7B8D86B614F1FD26C6"
                }
            },
            "F6ADAD566C1B7244681BDEB5FBEF48F48922": {
                "t": "(Train with Menmus.)",
                "d": {
                    "eid": "CBE91F896A4D574E0C99CE615FEF3541E645"
                }
            },
            "8297895E7408D54DD5697EF0B060F4DE41CE": {
                "t": "(Spar with Cattleya.)",
                "d": {
                    "eid": "C29FB49C340312420F39A9E47C216FBC75CA"
                }
            },
            "52A4D2E93F157746A3497D08D8ED3227E4A9": {
                "t": "Wise choice, Sir Ornières. Wise choice.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "DF2621F135E2124BCB48F392897FE8D376C0"
                }
            },
            "F1AFD38B11AAD5445F1B92738F12FFB88B38": {
                "t": "I beg to differ.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "8AF8C7DD3004D24F005A2383BDD3104F3057"
                }
            },
            "4FFD58202A2C684C364A32B643098F466D9A": {
                "t": "Let's get started.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "74367487382A0740597B0060203911390156"
                }
            },
            "AE0188E12432514531498A239A5AA9694A56": {
                "t": "Puff... Pant... Well, that was more strenuous than expected.",
                "d": {
                    "cid": 0,
                    "eid": "466FF9AD52A59744D05A35A40873ED95DBA3"
                }
            },
            "3CB01692289628451C3A49D259781F72B24C": {
                "t": "I'm glad you recognize the strength of a Hoikadian captain!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "FCA856FD0444E04F287B27F4C3DF96089071"
                }
            },
            "E2A123959903D741736B77F6DBDAA5457F18": {
                "t": "So, are you done?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "14797DCE7E3E32486F6BC6A7DD28C756C051"
                }
            },
            "48E074EA86E1B9483A0A30D9EC1DFEDD11E3": {
                "t": "Of course you'd choose me.\nMy bladework is unparalleled.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "9727571B52194246A91840314B0BC546E8C0"
                }
            },
            "67386A946E233348CA8B79C76DA90AFFDA68": {
                "t": "I'm a bit disappointed, but more than that, I'm afraid I might get torn to pieces if I stay here. Until later!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "79D5E1F914D1D443B698D133AF7CCCB05160"
                }
            },
            "FAF94338375413443E6B9193B3129FD9E2DC": {
                "t": "Wait, Menmus! What did you mean?\nAnd weren't we going to train in magic--",
                "d": {
                    "cid": 0,
                    "eid": "7A9BCA1381F93145794B3DB5FFDF8036AEA7"
                }
            },
            "AACAC3D024EEB7414308ACC7B379FC5C14B6": {
                "t": "The moment I unsheathe my blade, it'll be too late.\nEn garde!",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "ECCF11C8860FB34CFE5B18E99DFDE9AC1092"
                }
            },
            "FC6669A747DD174F1D29AF89C0703DDE4AD3": {
                "t": "I'm... I'm starting to believe that fighting the Demon King would be easier.",
                "d": {
                    "cid": 0,
                    "eid": "F6D8DA2B5B269641315BB7B887C21E8CD682"
                }
            },
            "CE2B47325D17D34D3B9A9CE65F21BA919149": {
                "t": "Hmph! You survived. That's all that matters.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "2233E8FF72728144CD1BAF264030EEA886E7"
                }
            },
            "AF8E20B97AAFB6409B5AF8D61B3C99A4BB75": {
                "t": "I see you've finished. And you're still alive...",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "4B415E66344B114DCC3AC4B729171E344254"
                }
            },
            "912B6AAB54CBA54F1D7AF4862B9D9F5AE7ED": {
                "t": "Yes, but... wasn't this training supposed to teach me how to use healing spells?",
                "d": {
                    "cid": 0,
                    "eid": "E3A213998A144543872BE7F8928F4CAE6E22"
                }
            },
            "D9463A3463CAB14E585B1C4141BD6C82BAB2": {
                "t": "... ... ...",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "66D299AF5788F74B438BCA923EB79AA51A40"
                }
            },
            "D642D5267428F543921821B44DB6A901C47A": {
                "t": "... ... ...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "2B35632069B624464149DF11FB2D839E94AE"
                }
            },
            "5E0D5BD932FA114A5438D1A1D13E64AD1A39": {
                "t": "Ahem! You've gotten stronger, and you still dare to complain?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "33A8D05A1CA0A34462992FC4E19BAB3F0051"
                }
            },
            "2351B15A852C9842B789F8516C4B0AA67B9A": {
                "t": "R-Right! I'm sure you'll learn how to use that Manacrest properly. But it's useless if you die first, right?",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "B7D282FE760205426C496C34F9E54BACB859"
                }
            },
            "377FEF57736C4944052A1178935D209EE448": {
                "t": "Well, I can't argue that. That's right, I need to get stronger... and you helped me. Thank you, Captains.",
                "d": {
                    "cid": 0,
                    "eid": "CE21FE5A23DFD046229B6FD37FBC70E35A62"
                }
            },
            "009259C742B19148B928B897FFB7E2FBC1F1": {
                "t": "We've sworn to protect Lady Faratras. This simply increases her chances of survival.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "89566CF2619FD145C4497D6758E293BB7D55"
                }
            },
            "69B0F76688EA1743E7486D7561B7248DF977": {
                "t": "You seem to care a whole lot about her.",
                "d": {
                    "cid": 0,
                    "eid": "8E7FF14387045848AD0B6D020D04019783BC"
                }
            },
            "AAB624DA26D63443655816090851455A29C9": {
                "t": "Everyone in Hoikade loves Lady Faratras. She's our beacon of hope.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "D49937646432844B8E1A8E2179C3CAF3824D"
                }
            },
            "6ED9395C7DE02149AA7AB7E5D70C8D4381AC": {
                "t": "I've always seen everything from Faratras' point of view, but this conflict must be nerve-wrecking for every Hoikadian...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "772442BF781D614DD47853906EBCE2BDFAED"
                }
            },
            "D59BE3904FE87046D828D8025091AE60FA25": {
                "t": "... And there she goes, without a word.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DA0F9C6819C3304F7228A167C46394BD532D"
                }
            },
            "05E8093770F576405C1A15463BD07F60B2B4": {
                "t": "Please excuse her. This conflict is still hard to digest. Moreover, she lost her lover just the other day.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "818608502194054C5C6B0CD39B01749CCA26"
                }
            },
            "5C7C4F6861E6C6462D5A1CA23B353B666362": {
                "t": "I'm very sorry to hear that. And I'm glad I can count on the two of you.",
                "d": {
                    "cid": 0,
                    "eid": "F868DDF37B7B97459F29D15136BDDEA4DBC6"
                }
            },
            "05EF1F2658D05242886A5A99227C01DD0474": {
                "t": "You also have an empty husk with you, filled with our hopes and dreams.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "2751928F3E03534316893E8492EAB5B76DFC"
                }
            },
            "0DBE27CD21AED7488E59E1F5DCCC54DC4468": {
                "t": "Well... I'll see myself off for the time being.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "A601560A7A6B84406B3997015618BEF5EF8B"
                }
            },
            "F6FBA3682D09E141A7595C183705D9B4C7CE": {
                "t": "Or, well... She used to be.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "ED3789964DBDB4482D384726823B31729F2B"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "8C642B99036E044F386A4470DFB8724CB7B9"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "model": {
                        "name": "Cattleya.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 78,
                        "y": 58,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "FF4F8A645FE4C34376596D719D8D8F2D4D45",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "model": {
                        "name": "Menmus.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 634,
                        "y": 56,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 24,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "034C62FB7D81B74C5588CEE1E2A0BB8CA026",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.8,
                    "idleIntensity": 0.9,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "EED46DF393991246FD0A611209504E32EC87"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.9,
                    "idleIntensity": 0.7,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "4BA496196C54414B436A0683FC57FD9CA295"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -22,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8E092DD34C434846834882627D20BA6949FF"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -22,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3471ABA95010E441898804838B9E1CF74FC6"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "EADE29624A35584AF40AB4C3751DE7F37126"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "48FFA6F60B1F49499F68D1B570BC3366DC8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF47A3A128DFB24EA83AC57562558A50C1E9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "42E7EB882B007848C35A04F5C38E982920A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76A52BAD1837144BE06AB74885858EA766E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E1C408356658449752A7948BBA5C183810D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAAC19A508B7174D6A799953EEF008B09D7F",
                        "defaultText": "어... 그래, 이거 어색하네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "ABF938395E3F054258287988B40B24C75349"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A07EE40E5343C2436F1A9336818A7B3ABED8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BC69E80778CD54BB368BCC74485F8ECE4DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FFB5CBE71F332431E687D262081DF270C73",
                        "defaultText": "무슨 문제라도 있습니까, 오르니에르 경?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F3267C718A4454EAF7A30878B956EB7C6F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "233F939B2B00E447E76A13D434E1FAAB71C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "891D99838B8EB044804AC3F1D244299E9417"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6950905D27B198478D48EDF8A686B5E5810D",
                        "defaultText": "아, 아무것도 아니야. 불과 몇 시간 전에 목숨 걸고 싸운 사람과\n대화한다는 점만 빼면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "347CA2C37DCA53485A3A79C43EBBED7AEAE7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BD11C843B4C304D3159F5667EBCFCA6D80A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0BE9B656A6E9842236B50715D57D97B0E21"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "722AA16609590241F649B19582DC43370491",
                        "defaultText": "벌써 내 이름을 알고 있다니 놀랍군요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "27D791CD251DF245B0485D7435A7A3947E43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DA665A474304640AB6ABD68EA6B6560FF84"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "561A9D904EBD45448A5948B845003DD0CB39"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF92DE3F7292254C1F4828E857D7AA675E72"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4142EDD64FC938472C6ADD5575005FB210A0",
                        "defaultText": "이름이란... 누군가에게 품은 감정을 담는 빈 껍데기에 불과합니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3E56FD3B6A05F34D845BA49479A393E2BAEE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AEB83DF5C41D6437F2A117368C450022F93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "727EBFF57571C7437729577934B6E5638E3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBD9C4E15D71994D564B73B62CB189467C83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1523DCBA218A4245253B2B199EB050E21EA9",
                        "defaultText": "잠깐만 철학적인 소리를 멈출 수 없어, 멘무스?\n안 그래도 기분이 엉망이야."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2929BBD20B5244E7D8A90F97CC5BF02D6E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97A90A065684084CB48B565661A49426C1B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC38623852D35245681BC5A3DC76BFEB5F2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "321392B33274934B0C18E5F8E86CCA116F54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E37787BB95E2A2445C5BF296E19CBE42379F",
                        "defaultText": "이제 본론으로 들어가려던 참이야... 좀 더 참을성을 길러, 카틀레야."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8870AF499E8EF7434E6B7F36D2ACF23F4667",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4BCC616822A40417D29D7F79413EE92001F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0701345297490447C12A84E83EDBDC6452AC",
                        "defaultText": "멘무스 대장, 흥미롭군요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A14A5E2A8D1C264C614AD076317B38988D05",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7D79A645576A224ECA899F803AF4BC100DC7",
                        "defaultText": "카틀레야 대장 말이 맞는 것 같은데요..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CB874A242C6E78481A5922005C3897FC454D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "menmus",
                            "cattleya",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2504EF3C31926447EC69270600AA42CBAA59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4883908337D07743C78A7125EC14F42DC645"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "menmus"
                },
                "indent": 0,
                "uid": "6357AB805B3E3245EE3A8FA14CE0FA5BCBF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "63FAE9C4202CE3404078CFD4D49110D8096B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6EDC25D3232C442CC2BDC13C2176695E975"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC2EF4450839A2447128A74405E03508260C",
                        "defaultText": "진심이야...? 이래서 난 후방에 있는 게 좋아.\n저 헛소리를 상대하지 않아도 되니까."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C36BBDBC15A770437769FD22B02B02C620B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C4D36E58E8DC54572894707AFEA6FDF9DAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "09FC336D8B44A145327AEE465E92ADC1F389"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECBEC8D3747EE945F918E109CD1EBDBEF083"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56F79FEB40BFB845569B40E4D23FA79A6B15",
                        "defaultText": "칼날만큼 혀도 날카롭지만 걱정하지 마십시오.\n우리와 함께 있는 걸 좋아하니까요."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C4E2F7025039654642580EE9B03CB7E27618",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23DA339912F48142404B668540E4F94F44A8"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "ECCC045A0DA9064855593B413061E8BE389F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cattleya"
                },
                "indent": 0,
                "uid": "369243EB8E25754628184F551F9D5DBF7F0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD5463569B9501410C5964073126E042348E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9678EA516A4F2640457AC97811ACCEC2C8FA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C67258768846941A87AC3F1B048C7168C13",
                        "defaultText": "경, 실망이 이루 말할 수 없지만 그래도 존중은 합니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8B034CB61CCEA744D62B2847ECD38118CEBB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BED4A08B59968248BD88BAB5CDA98F76CE2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D387E0CE14E554490C5B337856B603DCB0AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D648E662FDE944BF5485508624803F4E657"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2318235810F40747B548BD74056D88757397",
                        "defaultText": "제정신인 사람이라면 누구든 내 말에 동의할 거야."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C1CC36179E8247464E49F1226F895B643DFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6333872D3C05884F501992B666EF311CD2A1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 1"
                },
                "indent": 0,
                "uid": "250FAB683C06E246DF49B5B386ECAF506EB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BFAACC4821146470A1BAF135726101C161F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B043E9C731B11642C57B69F9FA17C675D66D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F2FE109576BC549A6793869A828670422AE",
                        "defaultText": "아무튼 내가 하려던 말은... 흠흠."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C615BC15353B274A9848E8B06ECA11F0B837",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0AF9DD54FB8444F698A2B32D385387BDE7C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05EF1F2658D05242886A5A99227C01DD0474",
                        "defaultText": "당신도 우리의 희망과 꿈이 담긴 빈 껍데기를 지니고 있습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2751928F3E03534316893E8492EAB5B76DFC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66D80F2D2BF8C849327890A09D3C486066E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0E42949611318453D3BC6592114C453A6F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B81BFD647D8324C5B785B01BFA5AE22901C",
                        "defaultText": "... ... ...???"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "34BA44D32A3F614AAB6AA2B6B89FF33112F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58371473777F6342C57A8AD7CB05D881735B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D3C57980D1A4240B90B7E08DDBE4E65AFE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88AAA9FB1F8DE74BD86A67534F2E97826563"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9069824960A5442B02882329D266745973A",
                        "defaultText": "멘무스는 이런... 수수께끼 같은 방식으로 말하길 좋아해.\n아마 네 마나크레스트 얘기일 거야."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5A7A60342BE72749C93BFFB5057825F4EC78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "401A4C104621C9408F2A84E8712F12AB0978"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69A179EA7158564CE49965D1AE6D4F401EA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE966B8213A5E841B17A7EE61CB7836DD644",
                        "defaultText": "아, 이거. 관심 있어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "93BB1A873F21B4495B78DCF7F87C1A9C7E09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8F1A7A88673554A2C890390D37F47F6A432"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "061C76AD292AC24A06695C4311C972AF7485"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9037E0E1EEEB1445C198317755C2240EB90"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C7E3605394D0674C184A44976F7C587B23B4",
                        "defaultText": "언제든 마법을 쓸 수 있게 해 주는 도구라니...\n활용 가능성을 상상해 보십시오! 수많은 생명을 구할 수 있습니다!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E48F84068AAA77423A6B637930EFF2F02C2A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC1F33C73DC2F649AB5B8C9612E2C8833561"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DD9400E7538F24EEF5AB3798F4614E116BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A37D0A549A291465D48C9E07CD4D3F1F908",
                        "defaultText": "모두가 그렇게 말해 주니 열정은 고마워.\n하지만 안타깝게도 치유 주문은 하나도 배우지 못해."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE1BFD818CA5A54E435910101594DA1A1BA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "052F870216796341A95A691358C3D81C0CAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C0BF6022A07E449D57BDC674C0B1B7C294C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "78869EC870895347D52926622C9AAB294A1D",
                        "defaultText": "그래서 호이카데 최고의 대장이 여기 있는 겁니다.\n당신의 진정한 잠재력을 깨울 때입니다!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB1F4A2B6E23544E7F583984471788919BD9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF611C325166C2443F29A806FA9A8AF91522"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1722DDB07C8E654A488A0461DB4EACB518DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1912D26295C3574592980548F8D2E9EA9C72",
                        "defaultText": "당연히 나를 말하는 거야.\n대련할래?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "33FED9B93BAAD1434E7B8D86B614F1FD26C6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C759D6B587F800420F294734E686DB536584"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F6ADAD566C1B7244681BDEB5FBEF48F48922",
                        "defaultText": "(멘무스로 훈련합니다.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CBE91F896A4D574E0C99CE615FEF3541E645",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8297895E7408D54DD5697EF0B060F4DE41CE",
                        "defaultText": "(카틀레야로 스파링합니다.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C29FB49C340312420F39A9E47C216FBC75CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "menmus2",
                            "cattleya2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB356F72821AC0484C8BF395C3DB36B494AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "557728632C3BC14A46296736C59B7088D9F2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "menmus2"
                },
                "indent": 0,
                "uid": "421FB02E6D905349518A436245F239092CFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3E3D77F11F41441647B16E369BDA1A4728A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "52A4D2E93F157746A3497D08D8ED3227E4A9",
                        "defaultText": "현명한 선택입니다, 오르니에르 경. 아주 현명합니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF2621F135E2124BCB48F392897FE8D376C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBB73EAA8BCB6946EC29E478A15032D384E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA8B471C685E58423E781FE041843F468D2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F681C2EF7BB7B94A652B694858F33B0DD4F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F1AFD38B11AAD5445F1B92738F12FFB88B38",
                        "defaultText": "그건 아니라고 보는데."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8AF8C7DD3004D24F005A2383BDD3104F3057",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "079051B76FC4D54EA7680A67988AD31F10DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0DBE27CD21AED7488E59E1F5DCCC54DC4468",
                        "defaultText": "그럼... 나는 잠시 자리를 비키겠습니다."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A601560A7A6B84406B3997015618BEF5EF8B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "49221A5E9A4E9848A45A6C80E751C928CC08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "018A2F7A75270647B11A0A9247E36D381720"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "49A69AAB8F1787461559EDF2DE236027C49F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "5D7B36E92A496348FB5A4DD9CC40027136C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41542E791CF9C64B722A6A33DC2F3EC6D9C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "894BA62A061B81411569F2767D77FA2FE567"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FFD58202A2C684C364A32B643098F466D9A",
                        "defaultText": "시작하자."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74367487382A0740597B0060203911390156",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "80E11619859A554C3A8B3722A369099B6EAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0579D0081A0A44A9A3812590715E694D7F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "BD9C22B982D81843641B84A45F317CEF6F8F"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D79E404B78452949792ABA777793CC075900"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            6000,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4909E0C906389541772831212191A56EBFEC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "F3FC01B438FBF84A9E69D732A8BAAA8C776E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E4B34F46870A4443685AAC6127AF464EAA2A",
                    "parameters": {
                        "values": [
                            200,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E071B3A95FABA544B828F0813158AC848410"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "28ED8E619237E4454F8B4F20CD718068A3E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9E2AE66A5E90394AE67B31C1E0B10DE51A56",
                    "parameters": {
                        "values": [
                            40
                        ]
                    }
                },
                "indent": 0,
                "uid": "73B7E7A0503CF643C668FB27E9908C32417F"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Time_Out.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "915AABA273891545BE2ACAC470A14418B176"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "55A6640D3598F344A92912E58FDF17957EAD",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "8767F0903409D04D7C199F792962F06746DA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "BEF2AAD93D2D004C656B10B8C47171394459"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B6F624543FBE2543402A7275E2A0DDB2AFB2",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F5329DE9D0FA140600AE7270DB3304BD92F"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6000,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "89C02E9D1ABE2640E03A6A2242D8D66F66E4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "C7FD149709D945428E09C6030ECF7874402D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            4,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C40AC5231BCBF6483C49A093CF24942A5A36"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "68FB001F1DAB834EF2696CD39E3F0351A9C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            5,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "05056DC72568C5439B698AC51D3DC15DFDC2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "2F71BAD808786748C87BF5C345121FD86253"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A5B8B0734564845860B0184D6551F4EC5BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECAC465122554649AB6B770922785A2C8403"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE0188E12432514531498A239A5AA9694A56",
                        "defaultText": "후우... 헉... 생각보다 힘들었네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "466FF9AD52A59744D05A35A40873ED95DBA3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "724E31EF14EBA64E616B28094D30130D025D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2258FD7273484844112A9B523E092D288ED0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3CB01692289628451C3A49D259781F72B24C",
                        "defaultText": "호이카데 대장의 실력을 알아주니 기쁘군!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCA856FD0444E04F287B27F4C3DF96089071",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB6E2A4907E5C545CB2A1481AC71F8D41E26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE5546EA1461274D8E48FA378D19AC50285B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "5FC84076141BA84C3C79358859AF500E6198"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "model": {
                        "name": "Cattleya.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 78,
                        "y": 58,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "348A71E7520E014AC46B15B5C2B6A0564C1C",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -22,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E59F2FF9F69D6480C695A47A5D3799CFFF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBC858D38C541045426A29B54D7F91FAB102"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "5AF6624033C5D64FB58A15D665441DB2C07E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D60BEE91183C345469809C3DC63BBDABB78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E12CC9EB53059644F0891C69C0FC29DD1A81"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E2A123959903D741736B77F6DBDAA5457F18",
                        "defaultText": "그래서, 끝났어?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14797DCE7E3E32486F6BC6A7DD28C756C051",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "537655AB7857184AF658A005C31039E8F8C3"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "351196A636B7F54BA9380796736E57BACDD1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cattleya2"
                },
                "indent": 0,
                "uid": "A0AE4A366C27444B84790DF33CCAB93298E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "649EA43B7867854E3468CA682B4FAC48D367"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6216118821EA93435F38DBB3AB47C5804F83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48E074EA86E1B9483A0A30D9EC1DFEDD11E3",
                        "defaultText": "당연히 나를 고르겠지.\n내 검술은 타의 추종을 불허하니까."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9727571B52194246A91840314B0BC546E8C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65F9B0CF2726A44B5E69AEB8E1795AC1146E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7C946607EB128453319E4181A3D7F3C1F4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FD68F236A0E4643065A4D778E7B6769DCB9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67386A946E233348CA8B79C76DA90AFFDA68",
                        "defaultText": "조금 실망스럽지만, 여기 있다가는 갈가리 찢길 것 같아 더 걱정되는군요.\n그럼 나중에 봅시다!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79D5E1F914D1D443B698D133AF7CCCB05160",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C36C78447958964E5119E7D796995C050FB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99441D1624F04441E52BDE9970D32642F7F8"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BAFB9FA45ABD724AD51A6C5041DEE995FA18"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "DCF8DCCA5179D348013995089BC763688717"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF9D8B7C36936246505BE8170DFA0725962B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "171114CF859DE64CA37A6738AA083D71E0CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FAF94338375413443E6B9193B3129FD9E2DC",
                        "defaultText": "잠깐, 멘무스! 그게 무슨 뜻이야?\n그리고 마법 훈련을 하려던 거 아니었--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A9BCA1381F93145794B3DB5FFDF8036AEA7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C784D1786E57E348FF1B8557409A6DC5E0BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "40C93C7B748BA547F58920514200004B1A8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45C125B7835076492E4B9423B3FC080DA752"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AACAC3D024EEB7414308ACC7B379FC5C14B6",
                        "defaultText": "내가 검을 뽑는 순간에는 이미 늦을 거야.\n앙 가르드!"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ECCF11C8860FB34CFE5B18E99DFDE9AC1092",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA7B32BF50C8414789790EB4EEEBEE1CA7ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58D9C7387CD8474B21891C41199DA2DE9B2A"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cattleya.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "menacing.mtn",
                        "position": {
                            "x": 40,
                            "y": 54,
                            "zoom": {
                                "x": 0.9,
                                "y": 0.9,
                                "d": 0.9
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1A8AEC155E54846B75A25A34883AD62B460"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "E06672026DADD4412C6958D5FCFDF5109956"
            },
            {
                "id": "vn.ZoomCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 24,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 260,
                        "y": 260
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "4B7D2CA562C6C545D61B01145A29232390DD"
            },
            {
                "id": "vn.MoveCharacterPath",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "path": {
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        },
                        "data": [
                            {
                                "pt1": {
                                    "x": 1104,
                                    "y": 254
                                },
                                "cpt": {
                                    "x": 1890,
                                    "y": 484
                                },
                                "pt2": {
                                    "x": 1180,
                                    "y": 304
                                }
                            }
                        ]
                    },
                    "loopType": 0,
                    "duration": 24,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D9A5EA730FB90424A48D5F44B6D8620EFE9"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D73094AA5A28A243C38AE9A156666F7685EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            6000,
                            350,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59DC733F5D592344E08A4A97F74BC4B18551"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "09CBE32D611BC84D6A491FC8AAA27EF889F6"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "EACAB0EA098F1142091AFC54470A87F7D4BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E4B34F46870A4443685AAC6127AF464EAA2A",
                    "parameters": {
                        "values": [
                            200,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08A398F0450B694C054A6F17A77EC874A620"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "0FF6AC4F2EC3844AA21962F4B1E8B3936920"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9E2AE66A5E90394AE67B31C1E0B10DE51A56",
                    "parameters": {
                        "values": [
                            40
                        ]
                    }
                },
                "indent": 0,
                "uid": "E521579A28B9164E993991536632BF64A434"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Time_Out.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "968124B9118FA148E12BB731FC8206954D28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "55A6640D3598F344A92912E58FDF17957EAD",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "99F9126D0DF736485349ED88DFB35215DBC2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "BAC0F9791511D24E981BA9E857E085175D07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B6F624543FBE2543402A7275E2A0DDB2AFB2",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF09EAEC6C071444729984122EB75E40F594"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "model": {
                        "name": "Cattleya.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 78,
                        "y": 58,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "D3141A297839E241B14974802BD7D2575578",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "model": {
                        "name": "Menmus.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 634,
                        "y": 56,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "0C8C4B337C1A264233592266BE1B5C34DDB5",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.8,
                    "idleIntensity": 0.9,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "B6F5D5700A2B7244B26BCED101E31DC9BDE1"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.9,
                    "idleIntensity": 0.7,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "752D81ED410572489B787941536F63253C87"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -22,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A9B518F83E05E1419A0909E3A8CB8239DBEE"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -40,
                        "green": -40,
                        "blue": -22,
                        "grey": 40
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2DD59C363CC3E74C40389D42E6AA57080ED0"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9C89399781FE2140A0193BC95FC1992751DB"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "AD95F199588BB54F211BBD018DB17BAB1C5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DDA5AE531BFE5416E3983C18334D5884235"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "53EE7F4499C043439B1A3E52B470DCBEB542"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6000,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "DCF1F0D04BE00843AA49F3A06A66EC905854"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "92235B6C19F9604BD18B5E533E28D3798B49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            7,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BB8F25171F893469E788EB8FBE982569709"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "DF7563F055D72741687AD8950E4E998FA8B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            6,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CF7E14C145A90467D58C1A08AB8131E2323"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "CEFB85CA94274248353BD2996E6B845D8A77"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++ speed\n+ 3% crit"
                },
                "indent": 0,
                "uid": "22A0E68053134647AB992E125AEFFE58C2C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64B54D1B8D9DE447A66BBBE115CBF763DC28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "216DDB59997EE64E0A2AEDC40E0D47F2211F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC6669A747DD174F1D29AF89C0703DDE4AD3",
                        "defaultText": "마왕과 싸우는 편이 더 쉬울 것 같다는... 생각이 들기 시작했어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6D8DA2B5B269641315BB7B887C21E8CD682",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7B03823804C10449189455425A9608C23E9"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "E546DE183818E245BF58E6098EE0E73DD729"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B917F064983B164D7E8BACD4FD17C340C2FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CE2B47325D17D34D3B9A9CE65F21BA919149",
                        "defaultText": "흥! 살아남았잖아. 그거면 됐어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2233E8FF72728144CD1BAF264030EEA886E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "321412EC1B918542D04B02C3F34D240CD512"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "1D10CBC533B15843F40BF5D4D51116CDEA98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D4D22ED463EB2459C5A920683A14E1A6C20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF8E20B97AAFB6409B5AF8D61B3C99A4BB75",
                        "defaultText": "끝난 모양이군요. 아직 살아 있기도 하고..."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B415E66344B114DCC3AC4B729171E344254",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23B59BBB6130364F562ACBE41AB3B2CE69BA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "9ADF10F12B4DA540505B20A665A43AAC8777"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "694618F94CE265405C7A3BC1458E908892C4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "912B6AAB54CBA54F1D7AF4862B9D9F5AE7ED",
                        "defaultText": "그렇긴 한데... 치유 주문을 쓰는 법을 배우는 훈련 아니었어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3A213998A144543872BE7F8928F4CAE6E22",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "746A91FC3F01F2486C486AE20AD318AFC1DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "D92E62C72C6BC3404A781D33DFFF0EC4CEB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4FAA4CF506B0241581936007BF1869B44DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9463A3463CAB14E585B1C4141BD6C82BAB2",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66D299AF5788F74B438BCA923EB79AA51A40",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67F169596DFE6744F67A6B391FCE66F0088E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F2C9CE1AD36346E59968E88C32AA2AFB9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "905F2A313EF68949C14B2394A49DD4DA0D45"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D642D5267428F543921821B44DB6A901C47A",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2B35632069B624464149DF11FB2D839E94AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A91854433C8B364A327AEF268E37192D16D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DDF6FE5026F914E58789CD98D512EF39684"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E0D5BD932FA114A5438D1A1D13E64AD1A39",
                        "defaultText": "흠흠! 더 강해졌는데도 불평할 셈이야?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "33A8D05A1CA0A34462992FC4E19BAB3F0051",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E74CFE7F7DF4D84BD0393348D6BE7E714FAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC2179F94A5AB740BB390C380DDB0542431B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13D143DA65D1234A5B9820C02745AC31F090"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2351B15A852C9842B789F8516C4B0AA67B9A",
                        "defaultText": "그-그래! 언젠가는 마나크레스트를 제대로 쓰게 될 거야.\n하지만 그 전에 죽으면 소용없잖아?"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B7D282FE760205426C496C34F9E54BACB859",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57D13BB0898D874D011BE5C2C3CCDE2F9BBC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A96C59DC1B3AB347BC698776E7F2541E8450"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "377FEF57736C4944052A1178935D209EE448",
                        "defaultText": "그건 반박할 수 없네. 맞아, 더 강해져야 해...\n두 사람이 도와줬어. 고마워, 대장들."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CE21FE5A23DFD046229B6FD37FBC70E35A62",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00702A6A6F3F0440D2084A285D9E17DBD2FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "6491BB2182C4174B83388F2605FFD5302210"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA3681A33A31C644836B95A3765072A74C7A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "009259C742B19148B928B897FFB7E2FBC1F1",
                        "defaultText": "우리는 파라트라스 님을 지키기로 맹세했습니다.\n이건 그분이 살아남을 가능성을 높일 뿐입니다."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "89566CF2619FD145C4497D6758E293BB7D55",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "163F4B1323367147AE68A7E705DA99C1C51C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9C1CFC279CB2345E89A0266B6942CD0DAC6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "69B0F76688EA1743E7486D7561B7248DF977",
                        "defaultText": "그분을 무척 아끼는 것 같네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8E7FF14387045848AD0B6D020D04019783BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A792978419C68840131AD102D12024D908C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2922F3E864F4A24F65783EE32F1BD398B80D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAB624DA26D63443655816090851455A29C9",
                        "defaultText": "호이카데의 모든 이가 파라트라스 님을 사랑합니다.\n그분은 우리의 희망을 비추는 등불입니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D49937646432844B8E1A8E2179C3CAF3824D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5794DD4078B5614F216898D642C0ECD64C2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1339BD7671BF443E4480841D72938AFDCDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "40462FD33E5DF947EA6A0C75C248C09DA7B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6FBA3682D09E141A7595C183705D9B4C7CE",
                        "defaultText": "아니, 뭐... 예전에는 그랬지."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ED3789964DBDB4482D384726823B31729F2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23614033900EF94E228BDA67372D4ADD7B5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B55EF47160CEB34AEB3B52C6BFDFB90EAD5B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6ED9395C7DE02149AA7AB7E5D70C8D4381AC",
                        "defaultText": "늘 파라트라스의 입장에서만 바라봤지만,\n이 분쟁은 모든 호이카데인에게 견디기 힘들겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "772442BF781D614DD47853906EBCE2BDFAED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6971D97250D974218892B8397AD02D40E90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "096BB8193DBE8442B428CA13EB5FFE6E4D2A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "5F31D6826CED8747EB5B7CE2BC4502044D5D"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F8BC3FBA3AC6244ECF08D93487EBAC4ACDAF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "9BB04296228077491A196E38E0AE0ED14815"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4F8203D2678A74B6D6955F0591FE33316B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D017BDB6575E4470128F3C169FAAE4FF30C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D59BE3904FE87046D828D8025091AE60FA25",
                        "defaultText": "... 아무 말도 없이 가 버렸네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA0F9C6819C3304F7228A167C46394BD532D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D9878CB7383E542691BD1922BF6B4F7A0A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D81FCAD597A724EB81A4F92B83DCD380A1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D998F18466B83459758AC74E999B479EDE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05E8093770F576405C1A15463BD07F60B2B4",
                        "defaultText": "이해해 주십시오. 아직 이 분쟁을 받아들이기 힘들 겁니다.\n게다가 며칠 전에는 연인까지 잃었으니까요."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "818608502194054C5C6B0CD39B01749CCA26",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1D8D11F6EF70549CA0AEC13F961BB9F1F79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13D7C2BF185DC6441C4A54226BE44520636E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C7C4F6861E6C6462D5A1CA23B353B666362",
                        "defaultText": "정말 안타까운 일이네. 그래도 두 사람을 의지할 수 있어 다행이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F868DDF37B7B97459F29D15136BDDEA4DBC6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF34022D2EC158498F5A1CE88252BC9C5BE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50CBA07A08A67146A32949B97F02B9F9E583"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "2E581ABA3BDCD54B1D79E3C7643645BB63B8"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "239494090A62B148BD6BF1424754457456BA"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}