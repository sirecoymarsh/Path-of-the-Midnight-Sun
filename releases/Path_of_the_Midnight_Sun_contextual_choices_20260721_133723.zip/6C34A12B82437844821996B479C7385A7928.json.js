GS.dataCache['6C34A12B82437844821996B479C7385A7928'] = {
    "uid": "6C34A12B82437844821996B479C7385A7928",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C10.5-5 Meet Soraya",
        "type": "vn.scene",
        "parentId": "ABB998293DB98847048AD652DAF46B657127",
        "chapterUid": "600AA11C0D65A64A4A8AD6A687CDC5D59826",
        "order": 4,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA25DE724121664ABC1BDF776910A341E37D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4666CB234C4D004C8F489891094801AC95C7"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "FEEB28CE186A3342E70A634062AF25688319",
                        "name": "1 - Luckos"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "AFDCB29354AE9442C9890042AA32F1DF1203"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "9674B27A6828B242B899EAA33F8D47182116"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "23FA9AE204012940AD8934A2BE667BF7C176"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "D9C8AF5C86031342183B0D97559CD74F766F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "B5DFC541684D024F155B48143ACE87647998"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DBA1E2CC25C69248240A025471C781151D65",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBB088FD71C30344F1384AB32DCEE22785CE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "fix party stats"
                },
                "indent": 0,
                "uid": "D2C7B072193CC141F349D076554F9D31FB72",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Disable Inventory?",
                        "index": 224,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "13A5BDC369CFE7468C58FDE2332860916014"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EE4C00D377D16040425B4157B34B119ECF01"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 25,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A5D47A6F34411141BF4B7A15330B37862DAF"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 20,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CB99415626F40743122AC9F1A992A2C95351"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 20,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C54407C0110A334889092F32C1C074F27A73"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "A0D6D6EC5D92F7486498F4D91D4F82DE596A"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2CA5BDBB29670646A15B210717630640BFC1"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 30,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EB5E464C327938416D1BBFA4A47C818A0D51"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 20,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "848D126F0F1FD44CF97BB787538B80B5E4B2"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 20,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8060FA477DC31449B44A0B6471C333F4696E"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "F9436D9B1CDD4843FE4BA078A3D8847A7A64"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1E9061FC3FDA46420068DD54F41A0FC0101D"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 13,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F7B938946016264B7A6BF574BD7112EBE082"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 20,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "649EF74570F3D748684988946B810E98F2EE"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 20,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "ABC66D7F1DF0764B40884F562FDD6FECFEAA"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "CA051F903F1B9840EA0BD482E0641B831303"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FF4C50505893D643104B47B078FA753CA5D0"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 18,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CEC7D109195E514A115A7D7645AB7D02E784"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 20,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28AAE3C54EFF3649D649E921FD3C711A73D2"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 20,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "32A70CF18C61124233386013D701FAE919CF"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "param": {
                        "name": "Mente",
                        "type": 0,
                        "value": 90
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "299A0C8A7CF62843AC9A31F6A4F7B2618782"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "model": {
                        "name": "Phoebe.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 810,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -191,
                        "y": 37,
                        "zoom": {
                            "x": 1.95,
                            "y": 1.95,
                            "d": 1.95
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "F95950083E6493432D18C963B16336E519D5",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "45918E0E12BBF148635A9360998958409EFE",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2A76CAD01A3E845081B4E4408DF2D3DDC41"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "end of fix"
                },
                "indent": 0,
                "uid": "DB5350776601E5454F9978219753A91155C8",
                "expanded": true
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 0.8,
                    "lipSyncSensitivity": 0.9,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 1,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "FE2D5F8B8A20C348CE68FDA67222749AF5D6",
                "expanded": false
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "F9192ABF7E64D3459D9ABFD56EB7DF5D2EC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            0,
                            0,
                            801,
                            50,
                            10,
                            7,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AE0EB3A3D4CB44B068B9408B960E5508A14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "136B9DFB5A5E474C6C283B847FB67B0D8167"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            30,
                            -7,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E18B0D9D5221E64FB90BB99484D96D3F42D6"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "model": {
                        "name": "Soraya.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 545,
                        "y": 80,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 1,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "FA5B6D4B9FA8E8479D79EAB6C81981F79544",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.8,
                    "idleIntensity": 0.7,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1,
                        "eyeBlink.enabled": 1,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "860C74195E75C34A934AE1F9C91D4B2EF0AB",
                "expanded": false
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "347BACFA65D05742329970415AA3D0922FF9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 0
                },
                "indent": 0,
                "uid": "73CB3268765006453D39BB83EC58A16C5E35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0774CA4F922C744A366B793007826C9B2402"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "C8131BF062DAD34DC28A06A49122C988DE84"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D9258A5951A384BDD28CA372BDEF82755FF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "4274133C589932441649246205430B9DF6D0"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "80E51D6C73F6C2443B588EF9BBF34DCEF6EE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B4B1FF101570E14916284F794AE475176748"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E0F64C02398A7492198DAC65FE7D615CA2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "709CA14C2B99A344067B1E514492D2B638FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2D7EB8A450B944CCD88BD164FB5572AE714",
                        "defaultText": "다들 어디 있지?{W:300} 이 방이 비어 있을 줄은 몰랐는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D90F4CB01EF3004D0779E3F1AF4AAC673119",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53005833868FF849BF4A3E860BFD7C9382FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B9DB9007B4BC74F075AE225DD102D8B6181",
                        "defaultText": "뭐, 완전히 빈 건 아니지만."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1744700A8663A540C53A8579B33B0348FEFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "337AD61A6BD011464C49C2A23518154F79DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D55FFB2671E0A24E5B9BE8414722820C8E38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "40F95A893C002740314A98E603758B960D7A"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DDADDB106D332247CB281F23A4FBD0104E58"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "00075B6B630707454B4BC35271BE0E092F72"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 45,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BE3FDF543648234A2D2A14108EE9261A43D7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D06BD0F54604104D8478519224D3DEF06438"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "904D232966B125464C5B3A1746DCA2D2CDC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "536CFA3334B11844E259B5923B3CFE2C5FA1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E00D060F90282849DE5A33A5A1C0866CB45D",
                        "defaultText": "마그놀리아 사람들을 찾는 거라면 손님을 모시러 갔어.{W:300}\n곧 올 거야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D6E8AFDC5167764A5C79F773B42F30DC3D6B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E666C5BA2FAB074D062AF9A1A28B0B38EB88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F2736F068EAE24075495054056F4FBE173D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AAA18B18BC08647F4392CF8108C94284832"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "220B2CE4692E1147EB6AF5A51978225DF102",
                        "defaultText": "안녕, 니니."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "74B11E7B90EF1640DA0BAD0296BCDAC01F0B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24154A4A95DD9848BA3B0434D308E63604C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CADD703515BC514AAC7B20C8D7C04ED4504B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E89362EF2F363949578BE24713A7D6BF4E1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D8DC7143C015248A298B904EFB3AFE5DBC6",
                        "defaultText": "... ... ...{W:300} 지난 며칠이 그렇게 정신없지만 않았어도\n네 빨간 눈을 보고 엄청 놀랐을 거야, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "375B6BDB177FF140AE2A40149CE7DF22F626",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92AA844C51D1D34DDF2ABDC854860E4E295E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B2E74C08B47654EB07B89E0834C8C267BBA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "207A8F8F63C5714F6279396025E4A02F2B56",
                        "defaultText": "이해해.{W:300} 너무 많은 일이 있었으니까."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DE0D2C7448F0C64894081934EB40AEF0E583",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF7D14002CA51443E03B1E76EF18CB25401D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DBA84ABB43B791403859F3E66EEC4E8FB873",
                        "defaultText": "그래도...{W:300} 다시 보게 되어 기뻐. 말 그대로 모든 의미에서."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D63D4EC52132974393594589DF3C111CD6A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A8B9E077E12E9438C693701FFE2D6985705"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F664219B3FE41646437B93A16AE427711A34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C537A2421D114246D2495DF5D35A93FDD241"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AFA7D6A98DBA244D8D399ED9F3C8B6EC051E",
                        "defaultText": "나도 같은 마음이야.{W:300}\n그래서, 어떻게 된 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D3D05BF04296714E5718F0E807E0837A75F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5EC6AC75EDB754DEB9AC3B494FABCC2774F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "034944BF65A5A04A453BE4C4778505ACAEC2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FBB52275E876343CD49B4C281C75ACEC227"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31B76E0E366D64480C6B1565C53A374E0E2D",
                        "defaultText": "우웃 우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2123464B47CA074D8D392843708FFE716CFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "795E397247C50141F1798F30D46F889E2DDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "594DA39167548549166929D4AF0E0DCF779E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C3C60B117E4384FD118E731E0A78E2C1331",
                        "defaultText": "이 얘기는 다른 사람들이 올 때까지 기다리는 게 좋겠어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10.5-5_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "225DD8DC54F48244F31985C6E62351C842F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBC9491E577D3348344B339164F3F4DA91BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1D94E066455A345F8092B78E777EBBB847A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C7214519BEC5345C48B5AE716AF8222B62A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EAC707334B71748805B67D69A482F6CF4DF",
                        "defaultText": "니니, 네... 기억은 어때?{W:300} 그때 정말 걱정했어."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "729E35B74FDD244C0B79BDC431F14BBA1DDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "849323391D8FC143F90B4FB4F47A24F64291"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C2A216A048DC340597A70562580C92840BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F73D8356F95A74E249A7AE3196220922956",
                        "defaultText": "난 거의 의식이 없어서 당시 일을 잘 기억 못 하지만,\n저 친구도 홀린 상태였던 거 아니야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3CF4F7A185EA424BEE48CDA5B769700499BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB9AC9A67240A744863AFC01F557FB709DAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1725B4A8006F3646ED0B12773EFD64C86C22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10330C5704A9464950895438D7AD66C5DB4E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82C3C48D4BBC034A6F7B4217A1589E9FEAF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8B35EB880BF4447732A8A6878FFC231496D",
                        "defaultText": "...나도 아는 게 별로 없어.{W:300} 늘 그렇듯이.{W:300}\n하지만 한동안 아무 증상도 없어서 손을 풀어 줬어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7B56083968E725423F798AD4C0AA4CC34433",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BB4F99F8B38844C3118F1C64EC994AF6832"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B859C745A578741FC594134CF0245BC60DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DE4113D22E3674864789D48851D6644F14A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68F6A4DB6896524FD28B683493921C5594CE",
                        "defaultText": "그건...{W:300} 정말 다행이네, 테헤헤..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E160F19D609473404B5B48152B4C8BC573C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B87926DF3B70A34F8D4BEAA40A4D6E2E61F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "0374A90D42C368463F2BC527FE4C827B84B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C8A609E78070514C903B7873F8EDE13B2852",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34D9A5CB980AC4401618D835AB5BB5EECD17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "55B4213A19AF9248DD18AED1E12264966CCD",
                        "defaultText": "돌아오셨군요, 폐하!{W:300}\n어서 오십시오, 성하!"
                    },
                    "position": 0,
                    "characterId": "C8A609E78070514C903B7873F8EDE13B2852",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "C10.5-5_line14_merged.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "66AC58BE89B6344CB81B7C94859D7A50F118",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D753416E1C02E949FB8BEF95A10AF1B38D09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "974E33F37289A54C068B22A58ACCAE12389D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9670AE8539560644AE1A3780533A7D3B9B2A",
                        "defaultText": "리아와 다른 사람들이 돌아왔나 봐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3FC764CB1C5F08438A48F264E2460E3CD1CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "015A7FF8589F124342995BD518708E03C2F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9399BE3A6268744E1D6903129AAFA7771C61",
                        "defaultText": "잠깐... 방금 \"성하\"라고 했어?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "879BDC174A76D340523B8C056F59D401B6E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17C8839928FA01400E1A38039286EC734E7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "C67563C26C6808435E5BEA9129234EF37BDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19906DA055D0C54BB08B05047C28CA571F7D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1DAE00D41FF834581097458ED47E564E5B4",
                        "defaultText": "우우우우웃!?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EF9E0DB054DEC84F7D1B4372797753DCC123",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9D4802E545FA64E316BAF82BD42464DBBD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "009988275538374D965A8248EDE56AB7FDC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6189A77365B0274BDD0A3F2796BFF4A42C18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C4088B045CCD74FA428F2B29CF3D08501BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C22C0C7E63B9B648E24A4686ABEE1FB1AD83",
                        "defaultText": "이봐, 착한 아이답게 굴어!{W:300} 아주 중요한 회의란다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "49CC61F3546AF0415A399EB01C45BC4AF941",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "569D0ADB129F744A555B96210592F2D9B93E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08BD2D4239DF7349522B5BA6706A45F45C1A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E575811B5BD3B941E86ABD06148696A81B25"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "3FBADEB36804024A1108CB417AC4F1CB7E2D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "5D88578F87F4D8477E6BF0F80A4EA5AD3FE2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen"
                },
                "indent": 0,
                "uid": "460E7749634037458F69D414B50896C5944C",
                "expanded": true
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "D09586BE680056459E5A5DF53792BB5793D1"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "DF3A70701B93084E173A23D56DB68328A0E0"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "F6C5DF849A1DE34A44689A940324B75EF73B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45C4395882A7554AA45A52D3CC4E3BBA65F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F1911E910EEB64736491639DF5709426665"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C09F333373930847C78948327A1EB0877A01",
                        "defaultText": "다들 안녕.{W:300} 기다리게 해서 미안해."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6B26A8A53EF7B14A034B078538FE3C64D0E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80F9D31A174CE2427379A53639C4875605F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09BC2AA9132E8645278B04D328162F26F426"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D139E7BE07EE634678380E959D0631F60366"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77A62E4A17CD8844760A7954C6AF407C92F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "880347802755694BC039D269FA0E2D7B4F58"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "784A965E3E93664C196B97E6D63B9547BEE8",
                        "defaultText": "잠깐, 잠깐, 잠깐!{W:300} 시오리, 네 눈!{W:300}\n실수로 고춧가루라도 뿌린 거야?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C10.5-5_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7283DE1F274D27492F6A3D76DEC17FABCB51",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F2446AE7036524DD84A8FB3FBE2876AA379"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "182CE03C7D34A549731B9605D77304CE4802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4361F5FC7AD16140EE899CE1F23E5533997A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8927F5D2922F345472975A46D514ABCDA33",
                        "defaultText": "닥쳐, 크리스토프.{W:300}\n어떻게 한순간에 꽤 재치 있다가 엄청 멍청해질 수 있어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C10.5-5_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7894E8F668C9C5483A581645E0AC38671D0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C65E1EF826BBC34EB46B037761D49DBCEA2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1DBCBE45695A742096AFC31CB3A48AB0A97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "617E549D459920457678D1F1D46DABB46D4E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9EA069FA29A6C44049792F05B7DA8126EFD3",
                        "defaultText": "테헤헤!{W:300} 괜찮아, 재밌었어.{W:300} 웃음이 필요했거든..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6C9820A6158DC048B2192D62DA3D41D3E42F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E62DF8090B9E784EFB0BC4F50A4CBA6E8AEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00B0655A1BC6644FC22BA7E89AE5FDE7BAD9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97797A6B6989234B107A1AA1FA4B4AD1CEFE",
                        "defaultText": "그럼 더 진행하기 전에,\n파일럼의 대모이신 소라야 성하를 소개할게!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A8DC0FE7877A2749E879DD44CB212AC7B55C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC31A3581A96F540668853B2FF9C79AAE3C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57001097893067481E0809A5F68988CD0D53"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DE1A1590105B8248FC3A36B85EDDD10121C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "B6EE7AD6786298480C19F570CF041228A8FB"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C3D2BF7571E9754E332B56C2A27C1E3B0FC0"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "1DE4E5C13915B7463388678350919901576E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "74B4842B5811A1432058F266DE6CA971CB98"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "92F74A3D806C6843A639CD68B4F5D348CB3A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "A7A42E8945AA984052383D943C5A86A8FF4B"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "duration": 42,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3521F92D36A0234BA2387D6743ACF146A076"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "66463FD70BAFC4437579E637940D853DD5BA"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\nSoraya appears next to Phoebe"
                },
                "indent": 0,
                "uid": "C39C4AA13C906240166B88D7419480BD20BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C024D4181D8D94D6149C2A3A96EDFC1B1E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10C20C697B84B2484D1BF8E6951B524BF0FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F464CBF1B76F34BAC6A64A8CD8221A78146",
                        "defaultText": "초대해 주셔서 감사합니다, 피비 여제.{W:300}\n언제나처럼 따뜻하게 맞아 주는 궁전이군요."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Soraya",
                        "name": "C10.5-5_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "253F2E3C3A0B74409D0B0DE4E0E8B23EC7F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B06DAAB52266743FA8B0FE8BC092B562FE6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92EF65F68534E2439138C4976DC1FC455AAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79280A1434B9444B427B83012C6ADF97EAC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D1EA4B85A87474D5D6B8CD16F7963774395",
                        "defaultText": "성하...{W:300} 오랜만입니다.{W:300}\n명하신 대로 마왕의 그릇을 따라왔습니다.{W:300}\n다만--"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "444AD8D06B26D64DB659D4F0AFA84DF8A638",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7384E4742C1C147D14A1664D2C6AE9EAC40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9842A367E814648D99B65B1CD740BD5E428"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24C59DC122CEC6456A3A9D366B1F882F5EB1",
                        "defaultText": "그사이 많은 것이 변한 모양이구나.{W:300}\n가여운 아이야...{W:300} 많이 힘들었겠지."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Soraya",
                        "name": "C10.5-5_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E30CD94E3AE8C8471F0B6F61DD6A8A8795B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E59813E6D44D84E747BCB74A9B481366E80"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Soraya.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DE9D23617130B54C084B359497D0A2B5A209"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50F04C5331DB774DC439DE8144F94C09E09B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D9E98647E281349BA4A0DA25FEED2D1D9BD",
                        "defaultText": "그리고 당신이 호이카데의 파라트라스 님이군요.{W:300}\n만나서 반갑습니다."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Soraya",
                        "name": "C10.5-5_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1D8A6D9D37F6F2443F9B6FD3D53901C4CC06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "87451A4C0E8F124ABF7B53375C092CD0A6A0"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "477D63263A19F44A152BCD9064947DACC0C3",
                        "defaultText": "저야말로 영광입니다, 성하."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1678405F8D575349AB0B6B3899DDEACE3CBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only choice",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "C217B5FF43E321443359CDB6A34907AB3790"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7B61492F6E02664FEB7A78D461C1970318A6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only choice"
                },
                "indent": 0,
                "uid": "CEDC748525ABF849263B3B219945D510DFB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43B1E3FC72CB38468D9A69E15E62ED913B19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E72D35C83150448E74BC7376C655BB1302F",
                        "defaultText": "모두가 말한 대로 굳센 눈빛을 지닌\n참으로 아름다운 아가씨군요."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Soraya",
                        "name": "C10.5-5_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9CD771A620AC244F3B2A7A04B38E5159081D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD5D392C6117B34C6E295DD73F88C2B1A107"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51FB895D7C37534E4A59A1D97EBA2FCC7BE7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E6D23B881CF7A341F32967F533F88501AC42",
                        "defaultText": "뭔가... 온화한 기운이 느껴져. 마음이 편안해져."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA44C4552EDB0541EC1B7061E6670D8D5CC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8070A4CB871261418959ADD8A3EF51BA124E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Soraya.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3CA8E9942180D641DD182732E3C8840BC1D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "322EF3F672881046849BA8283B4F1C90EAC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A22007A31A07145111908A38A03C9E985F6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B8AC1494CB6164DE37A4EC77FB8F037BFA3",
                        "defaultText": "즐거운 만남을 방해해서 미안하지만,\n알다시피 마왕 문제는 아주 급해."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "94FF3E8B02785643726BC9E98A8783A9D634",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "702A6168332AE7400A9A7131A2F103FB2B7A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "789FE99A4DD0D34158482C958623689ADC4F",
                        "defaultText": "회의에서 다음 의제들을 논의하고자 합니다.{W:300}\n첫째는 물론 헬리오스 건입니다."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5058C6C2197EE342598A12307D2B3014796A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "025B0A638764324349483A466A2B33A8547B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80A4A00F796A76478A791ED1EF4DF0B61CBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D03190C456F9F4441F4A3E11E00A72B23C2C",
                        "defaultText": "물론이지.{W:300} 우리가 여기 모인 가장 큰 이유니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10.5-5_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D66E25569BCAA54D769BBE150BDD42C5D10A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B19F73C99CF7D641C67B8C24CC7349209691"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A32EA182B188146D1890539C8013D87434E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4425D980D54E340B2994EE01D403D13D66C",
                        "defaultText": "둘째, 오르니에르 경과 마나크레스트에 관해 이야기하겠습니다."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C1AA58FA524E334D3D5BAD39F63AAEDB4FD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F94496373CBC4643B27B988590F946235BE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "03AD6A7D8A12E047D12BEDB9ED132F1DE755"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FD98E214A99C948AD599CF68300A2082DFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFD1CAB93A5672453E7970C98BAC06902C91"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FAD9EC410A45624D6A49D4619FD888C78AB1",
                        "defaultText": "나 말인가?{W:300} 뭐, 예상했던 일이지만..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10.5-5_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C2370DE97D8F6749EF2AA7919F523D00CB42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "220CBAD44BDF9647F77919F5BFAB7999E9E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4151A1B278A4614CD81B51370490851BEA8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "77D7BB4C74EA084BF738BC55E17EA34694D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D8EB4386C3DA5432B0A267385A29225DF40",
                        "defaultText": "그리고 마지막으로...{W:300}\n원래 계획에는 없었지만 시오리, 네 눈도 그냥 넘길 순 없어."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Phoebe",
                        "name": "C10.5-5_line35.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9A94F95768C085479B887FE016CF038CB255",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4985D0DE5F1CB6489E8B0CA93938B690CBFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "171800444C8CA0409B78F48113B80AACF026"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "429BEB3F81BF5145944808D0626BC776579C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95D8D6D01C77E346A52A3A80156466E73D72",
                        "defaultText": "난 괜찮아."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10.5-5_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5F4893F56A00D94F953B6C7699DB8E2FAD89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CD328B9173CA24A574B4B6238F43130BEBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B5AFC6012261049AD19E101E5C2AE33F0B8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "57301F406E82A34D736872D302F0375E4298"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05E27B5D501E754BC54915C1E1B0D0E1B99D"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "69FF21AE636D164741688852E34ECE01F8F1",
                        "name": "C10.5-5b The meeting (to 11A/B)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C10D6BD95EA2D84EAF29C413A7A731395E11"
            }
        ],
        "livePreviewDisabled": true,
        "localizableStrings": {
            "C2D7EB8A450B944CCD88BD164FB5572AE714": {
                "t": "Where is everyone?{W:300} I didn't expect to find this room empty...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D90F4CB01EF3004D0779E3F1AF4AAC673119"
                }
            },
            "6F464CBF1B76F34BAC6A64A8CD8221A78146": {
                "t": "Thank you for inviting me, Empress Phoebe.{W:300} I must say the palace is welcoming, as always.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "253F2E3C3A0B74409D0B0DE4E0E8B23EC7F0"
                }
            },
            "477D63263A19F44A152BCD9064947DACC0C3": {
                "t": "Likewise, Your Holiness.",
                "d": {
                    "eid": "1678405F8D575349AB0B6B3899DDEACE3CBC"
                }
            },
            "E6D23B881CF7A341F32967F533F88501AC42": {
                "t": "She has a kind of... gentle aura. She really puts me at ease.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DA44C4552EDB0541EC1B7061E6670D8D5CC4"
                }
            },
            "FAD9EC410A45624D6A49D4619FD888C78AB1": {
                "t": "Me, huh?{W:300} Well, that had to be expected...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "C2370DE97D8F6749EF2AA7919F523D00CB42"
                }
            },
            "3B9DB9007B4BC74F075AE225DD102D8B6181": {
                "t": "Well, almost empty.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1744700A8663A540C53A8579B33B0348FEFF"
                }
            },
            "E00D060F90282849DE5A33A5A1C0866CB45D": {
                "t": "If you're searching for the Magnolians, they've gone to pick up a guest.{W:300} They'll be here soon.",
                "d": {
                    "cid": 0,
                    "eid": "D6E8AFDC5167764A5C79F773B42F30DC3D6B"
                }
            },
            "220B2CE4692E1147EB6AF5A51978225DF102": {
                "t": "Hello, Nini.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "74B11E7B90EF1640DA0BAD0296BCDAC01F0B"
                }
            },
            "4D8DC7143C015248A298B904EFB3AFE5DBC6": {
                "t": "... ... ...{W:300} If the past days hadn't been so crazy, I would be extremely surprised at your red eyes, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "375B6BDB177FF140AE2A40149CE7DF22F626"
                }
            },
            "207A8F8F63C5714F6279396025E4A02F2B56": {
                "t": "I can't blame you.{W:300} So much has happened.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "DE0D2C7448F0C64894081934EB40AEF0E583"
                }
            },
            "DBA84ABB43B791403859F3E66EEC4E8FB873": {
                "t": "But...{W:300} I'm happy to see you again. In every sense of the word.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D63D4EC52132974393594589DF3C111CD6A7"
                }
            },
            "AFA7D6A98DBA244D8D399ED9F3C8B6EC051E": {
                "t": "I share the sentiment.{W:300}\nSo, how did it happen?",
                "d": {
                    "cid": 0,
                    "eid": "D3D05BF04296714E5718F0E807E0837A75F6"
                }
            },
            "31B76E0E366D64480C6B1565C53A374E0E2D": {
                "t": "Woot woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "2123464B47CA074D8D392843708FFE716CFD"
                }
            },
            "4C3C60B117E4384FD118E731E0A78E2C1331": {
                "t": "We should probably wait for the others before discussing this.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "225DD8DC54F48244F31985C6E62351C842F8"
                }
            },
            "8EAC707334B71748805B67D69A482F6CF4DF": {
                "t": "Nini, what about your... memories?{W:300} You really scared us back then.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "729E35B74FDD244C0B79BDC431F14BBA1DDF"
                }
            },
            "4F73D8356F95A74E249A7AE3196220922956": {
                "t": "I can't recall the events very well since I was mostly unconscious, but wasn't he possessed as well?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3CF4F7A185EA424BEE48CDA5B769700499BF"
                }
            },
            "C8B35EB880BF4447732A8A6878FFC231496D": {
                "t": "... I don't know much either.{W:300} As usual.{W:300} But I haven't shown any symptoms for a while now, so they untied my hands.",
                "d": {
                    "cid": 0,
                    "eid": "7B56083968E725423F798AD4C0AA4CC34433"
                }
            },
            "68F6A4DB6896524FD28B683493921C5594CE": {
                "t": "That's...{W:300} incredibly relieving, teh heh...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "E160F19D609473404B5B48152B4C8BC573C2"
                }
            },
            "55B4213A19AF9248DD18AED1E12264966CCD": {
                "t": "Welcome back, Your Highness!{W:300}\nGreetings, Your Holiness!",
                "d": {
                    "cid": "C8A609E78070514C903B7873F8EDE13B2852",
                    "eid": "66AC58BE89B6344CB81B7C94859D7A50F118"
                }
            },
            "9670AE8539560644AE1A3780533A7D3B9B2A": {
                "t": "Seems like Rya and the others are back.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3FC764CB1C5F08438A48F264E2460E3CD1CB"
                }
            },
            "9399BE3A6268744E1D6903129AAFA7771C61": {
                "t": "Wait... Did they just say \"Your Holiness\"?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "879BDC174A76D340523B8C056F59D401B6E1"
                }
            },
            "C1DAE00D41FF834581097458ED47E564E5B4": {
                "t": "Wooooot!?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "EF9E0DB054DEC84F7D1B4372797753DCC123"
                }
            },
            "C22C0C7E63B9B648E24A4686ABEE1FB1AD83": {
                "t": "Hey, be a good boy, you!{W:300} This is a very important meeting.",
                "d": {
                    "cid": 0,
                    "eid": "49CC61F3546AF0415A399EB01C45BC4AF941"
                }
            },
            "C09F333373930847C78948327A1EB0877A01": {
                "t": "Yo, everyone.{W:300} Sorry for keeping y'all waiting.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "6B26A8A53EF7B14A034B078538FE3C64D0E3"
                }
            },
            "784A965E3E93664C196B97E6D63B9547BEE8": {
                "t": "Whoa, whoa, whoa!{W:300} Shiori, your eyes!{W:300} Did you accidentally sprinkle some chilli powder on them?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "7283DE1F274D27492F6A3D76DEC17FABCB51"
                }
            },
            "A8927F5D2922F345472975A46D514ABCDA33": {
                "t": "Shut up, Cristoph.{W:300} Can't you stop going from quite witty to extremely stupid in the space of a moment?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7894E8F668C9C5483A581645E0AC38671D0A"
                }
            },
            "9EA069FA29A6C44049792F05B7DA8126EFD3": {
                "t": "Teh heh!{W:300} No worries, that was funny.{W:300} I needed a laugh...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "6C9820A6158DC048B2192D62DA3D41D3E42F"
                }
            },
            "97797A6B6989234B107A1AA1FA4B4AD1CEFE": {
                "t": "So, before proceeding any further, allow me to introduce none other than Her Holiness Soraya, Matriarch of Pylum!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "A8DC0FE7877A2749E879DD44CB212AC7B55C"
                }
            },
            "2D1EA4B85A87474D5D6B8CD16F7963774395": {
                "t": "Your Holiness...{W:300} Long time no see.{W:300} I've followed the Vassal of the Demon King, as you requested.{W:300} Although--",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "444AD8D06B26D64DB659D4F0AFA84DF8A638"
                }
            },
            "24C59DC122CEC6456A3A9D366B1F882F5EB1": {
                "t": "Although I see that many things have changed, since then.{W:300} My sweet child...{W:300} it must've been hard for you.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "E30CD94E3AE8C8471F0B6F61DD6A8A8795B0"
                }
            },
            "5D9E98647E281349BA4A0DA25FEED2D1D9BD": {
                "t": "And you must be Lady Faratras Hoikade.{W:300} A pleasure to meet you.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "1D8A6D9D37F6F2443F9B6FD3D53901C4CC06"
                }
            },
            "8E72D35C83150448E74BC7376C655BB1302F": {
                "t": "You're truly a beautiful young woman with a tenacious look, just as everyone seems to describe you.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "9CD771A620AC244F3B2A7A04B38E5159081D"
                }
            },
            "4B8AC1494CB6164DE37A4EC77FB8F037BFA3": {
                "t": "I'm sorry to interrupt this pleasant meeting, but as y'know the matter of the Demon King is very urgent.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "94FF3E8B02785643726BC9E98A8783A9D634"
                }
            },
            "789FE99A4DD0D34158482C958623689ADC4F": {
                "t": "I would like to bring the following topics of discussion to the attention of the assembly.{W:300} Firstly, the case of Hellios, of course.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "5058C6C2197EE342598A12307D2B3014796A"
                }
            },
            "D03190C456F9F4441F4A3E11E00A72B23C2C": {
                "t": "Of course.{W:300} That's the main reason we're all here.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D66E25569BCAA54D769BBE150BDD42C5D10A"
                }
            },
            "F4425D980D54E340B2994EE01D403D13D66C": {
                "t": "Secondly, we shall talk about Sir Ornières and the Manacrest.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "C1AA58FA524E334D3D5BAD39F63AAEDB4FD0"
                }
            },
            "5D8EB4386C3DA5432B0A267385A29225DF40": {
                "t": "And finally...{W:300} Well, this wasn't in the original plans, but we can't ignore your eyes, Shiori.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "9A94F95768C085479B887FE016CF038CB255"
                }
            },
            "95D8D6D01C77E346A52A3A80156466E73D72": {
                "t": "That's fine by me.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "5F4893F56A00D94F953B6C7699DB8E2FAD89"
                }
            }
        },
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}