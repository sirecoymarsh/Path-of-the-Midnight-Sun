GS.dataCache['600AA48C79661741C739DBE5044DA0C58930'] = {
    "uid": "600AA48C79661741C739DBE5044DA0C58930",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C2-02c P1 Chamberlain (Advance to next)",
        "type": "vn.scene",
        "parentId": "4128727E2334D249A98803B18CC6BDB0D6FD",
        "chapterUid": "821526CB730C524E8E8AE3E37167B67D0B30",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 78,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 240,
                        "y": 240
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B3A8A1BC3C62B2465E1A7DD26AA031BECBB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            3,
                            1300,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A51F73252FEAB54BAD9B4DA0B5F291088617"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "43019B4557C2874DF8882E3275D98C1081AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32AC29831C1EE34A3D3A1D35E4C7809FD348"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BC484A27721BD74D1B79C35516B262911F18"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "558609A017CA764FA21B4AD245B88993C5DE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-ChamberlainHoikade_line4_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DDABF4572058A343357AF472ACD599469CAC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "81D9333C854B0642C1488D05ACD9F14CC060"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6A7EE3E64F49934F3B08C202310D3747D02F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1BCD53B8AE0254005596346585B2FF114E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E4B34F46870A4443685AAC6127AF464EAA2A",
                    "parameters": {
                        "values": [
                            200,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "185C97971A731145D53976931E68C9BC46F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CF4A86740A21745898AB1D414F5AEA0B107"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D5C8274F0DC037432F28DF045CD683C2756E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6929FDD96A73F54B4E097934EA23A17700C2",
                        "defaultText": "늦으셨습니다!"
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "6388E38584C47444E0096C9110A9E2E89B41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F40992F747ACD246605A2EA8F0ECD1D4D403"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A6FF6AA154B7D54BF51B4DF8356A2CB52300",
                        "defaultText": "어서 알현실로 들어가십시오!"
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "67E571011BF0614D322B5AE28B78983C190D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "503F27637A63E54E436AC005532977A4ADA7"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "question",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "E485FEBD5AA07945966923458242572FB786"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75BD1AFC550AB84DB5481975BD3B2093FB17",
                        "defaultText": "일찍 오셨군요."
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "A5843ACB4343F64C701A3FA19E775F6482B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32CA3E8B69E9E64CC67A75D7CC05FC45E537"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54AD6A2235AB9846A68B29448ED8EB3356FB",
                        "defaultText": "원하신다면 지금 들여보내 드릴 수도 있습니다."
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "5096D97184200745128809A9069F02C55410"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7184846832B6E84109688334A7819E0338AA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "question"
                },
                "indent": 0,
                "uid": "66D7511544DC7248E42B2E319B6ED756F6FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5C3C1BB182DC348F40BA619993728D790DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "444B895E72B8B246910931D72748B20A6B0C",
                        "defaultText": "들어가면 회담이 끝날 때까지 다시 나올 수 없어.\n어떻게 하지...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "7BE9D89F043B234907584292E986E5C8312F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0B40890472DC34615481D7257C12BB88819"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "797AB21A1263F9433F2BBAD7DB7E89313076",
                        "defaultText": "좋아, 가자."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B18B4F193B3C2740D279C2427161701744C7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "74F176A23B32824F6F587305702E96808787",
                        "defaultText": "{C:2}아직 할 일이 있어.{C:0}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "37BF6CA95749744A954A43E29095205FE968",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "let's go",
                            "not yet",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DA43E627A9174443D9BD851CEBD043BFFFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5501D8612990E54A506B270410565821153A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "let's go"
                },
                "indent": 0,
                "uid": "2C6022302F3775430F8A4632CAB5BD90E0C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6A7EE3E64F49934F3B08C202310D3747D02F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62D8731410642244FE9B0F16AC2F523ECF06"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29B7FBD2280A2241BD6840B418CAB1690A20",
                        "defaultText": "저를 따라와 여왕님께서 정식으로 입장을 허락하실 때까지\n문밖에서 기다리십시오."
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6744AD32240E614BD97885E3A0B1A2E370A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7390981B7416414A1D7B2924CCEE5646FFB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3850618E8B9541451768ABE658563BD0041C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF3B5B56670BA749AF8A8A295C18ACAAAA56",
                        "defaultText": "절차는 알고 있어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "39E7E44697F4D641794842A7EEF407B88C79",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B6F624543FBE2543402A7275E2A0DDB2AFB2",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "359F25EF42154249684A5106CE84020D889A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC545D0F8E318843F24B0278D70DF674F29A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6F2A794139C37483F283E22904704054891"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6152D866698C1541A92ABC34A540A7DDFB41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED3199B480C9614CF58821F9941C8D395A1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            5,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F19E7E971E060740D758B131132BACDAABC6"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Coming from Shop scene?",
                        "index": 237,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "95C3EF55396008430758BB587B173DC851F3"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7F26538D659D894BC33B8C9367381B182EE5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "CD0789D816EA13491109EAD12723905D18BC"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "B29A7BD04D5EE841345A5564C3DFB37DB0E0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "09CE10C44658D944DD184F9458CE91C56E08"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "DCC8BB6C7F8B98425C9B3885A7C878DAED1A",
                        "name": "C2-03 Meeting with Munie"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E1CF34368AB5A34DD95BBA9023ABB2E52314",
                "expanded": false
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not yet"
                },
                "indent": 0,
                "uid": "C43552410109C64D068952847A79ABAA0C52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "6A7EE3E64F49934F3B08C202310D3747D02F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "045E75C82DEB644C08694D705D2CEE6BAE1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "762339803DCD5945306A4719D67E272131C3",
                        "defaultText": "칫!"
                    },
                    "position": 0,
                    "characterId": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "218BFF95774833458159ADE72FDFAEEE4887",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B6F624543FBE2543402A7275E2A0DDB2AFB2",
                    "parameters": {
                        "values": [
                            200
                        ]
                    }
                },
                "indent": 0,
                "uid": "B69AEDC692C8A345321AF3D551125A6B648F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A88E5388366B0840B97B66777A27EFEC650A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10DF52442687F04FCD788CF4CD673BC72132"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 78,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "A8D6090931A395400E0BECE831E94408F2FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            3,
                            1300,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F51D08FB3DEA1242907966775D80CFF2B877"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "EF30364C5E112343C688C120F5201CDD4986"
            }
        ],
        "booleanVariables": [
            {
                "name": "r",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "6929FDD96A73F54B4E097934EA23A17700C2": {
                "t": "You're late!",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "6388E38584C47444E0096C9110A9E2E89B41"
                }
            },
            "A6FF6AA154B7D54BF51B4DF8356A2CB52300": {
                "t": "Enter the throne room, quickly!",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "67E571011BF0614D322B5AE28B78983C190D"
                }
            },
            "75BD1AFC550AB84DB5481975BD3B2093FB17": {
                "t": "You're early.",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "A5843ACB4343F64C701A3FA19E775F6482B4"
                }
            },
            "54AD6A2235AB9846A68B29448ED8EB3356FB": {
                "t": "I can let you in anyway, if you wish.",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "5096D97184200745128809A9069F02C55410"
                }
            },
            "444B895E72B8B246910931D72748B20A6B0C": {
                "t": "Once I enter, I won't be able to leave again until the end of the meeting. What should I do...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7BE9D89F043B234907584292E986E5C8312F"
                }
            },
            "797AB21A1263F9433F2BBAD7DB7E89313076": {
                "t": "All right, let's go.",
                "d": {
                    "eid": "B18B4F193B3C2740D279C2427161701744C7"
                }
            },
            "74F176A23B32824F6F587305702E96808787": {
                "t": "{C:2}I still have something to do.{C:0}",
                "d": {
                    "eid": "37BF6CA95749744A954A43E29095205FE968"
                }
            },
            "29B7FBD2280A2241BD6840B418CAB1690A20": {
                "t": "Follow me and wait outside the door until the queen formally accepts you.",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "6744AD32240E614BD97885E3A0B1A2E370A8"
                }
            },
            "CF3B5B56670BA749AF8A8A295C18ACAAAA56": {
                "t": "I know the procedure.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "39E7E44697F4D641794842A7EEF407B88C79"
                }
            },
            "762339803DCD5945306A4719D67E272131C3": {
                "t": "Tch!",
                "d": {
                    "cid": "6A7EE3E64F49934F3B08C202310D3747D02F",
                    "eid": "218BFF95774833458159ADE72FDFAEEE4887"
                }
            },
            "558609A017CA764FA21B4AD245B88993C5DE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "DDABF4572058A343357AF472ACD599469CAC"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}