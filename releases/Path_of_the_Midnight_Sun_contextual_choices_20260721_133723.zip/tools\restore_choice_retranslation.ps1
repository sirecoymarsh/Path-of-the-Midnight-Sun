param(
    [Parameter(Mandatory = $true)][string]$BackupDir,
    [Parameter(Mandatory = $true)][string]$GameDataDir
)

$ErrorActionPreference = 'Stop'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}
function Install-Atomic([string]$Source, [string]$Target, [string]$ExpectedHash) {
    $parent = [System.IO.Path]::GetDirectoryName($Target)
    $temp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_tmp_' + [Guid]::NewGuid().ToString('N'))
    $replaceBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_replace_backup_' + [Guid]::NewGuid().ToString('N'))
    try {
        [System.IO.File]::Copy($Source, $temp, $true)
        if ((Get-Sha256 $temp) -ne $ExpectedHash) { throw "Temporary restore hash mismatch: $Target" }
        [System.IO.File]::Replace($temp, $Target, $replaceBackup, $true)
    }
    finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        if (Test-Path -LiteralPath $replaceBackup) { Remove-Item -LiteralPath $replaceBackup -Force }
    }
}

$backupResolved = (Resolve-Path -LiteralPath $BackupDir).Path
$gameResolved = (Resolve-Path -LiteralPath $GameDataDir).Path
$expectedSuffix = [System.IO.Path]::Combine('Path of the Midnight Sun', 'resources', 'app', 'data')
if (-not $gameResolved.EndsWith($expectedSuffix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Unexpected game data directory: $gameResolved"
}
$manifestPath = Join-Path $backupResolved 'patch_manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$files = @($manifest.files)
if ($files.Count -ne [int]$manifest.total_files -or $files.Count -le 0) { throw 'Backup manifest file count mismatch.' }

# Full restore preflight before any write. Refuse to overwrite later edits.
foreach ($entry in $files) {
    $name = [string]$entry.filename
    if ([System.IO.Path]::GetFileName($name) -ne $name) { throw "Unsafe manifest filename: $name" }
    $backup = Join-Path $backupResolved $name
    $target = Join-Path $gameResolved $name
    if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw "Backup file missing: $name" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Game file missing: $name" }
    if ((Get-Sha256 $backup) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Backup hash mismatch: $name" }
    if ((Get-Sha256 $target) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Live game changed since install: $name" }
}

foreach ($entry in $files) {
    $name = [string]$entry.filename
    Install-Atomic -Source (Join-Path $backupResolved $name) -Target (Join-Path $gameResolved $name) -ExpectedHash ([string]$entry.current_sha256).ToUpperInvariant()
}
foreach ($entry in $files) {
    $name = [string]$entry.filename
    if ((Get-Sha256 (Join-Path $gameResolved $name)) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Post-restore verification failed: $name" }
}

[ordered]@{
    status = 'restored'
    restored_at = (Get-Date).ToString('o')
    game_data_dir = $gameResolved
    backup_dir = $backupResolved
    files = $files.Count
    choices = [int]$manifest.total_choices
} | ConvertTo-Json -Depth 5
