GS.dataCache['B9FFDB478C0D784FAE3B0198F82B88EFC03F'] = {
    "uid": "B9FFDB478C0D784FAE3B0198F82B88EFC03F",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "Talk - Soldier (F)",
        "type": "vn.scene",
        "parentId": "5E8B74AD332A684AED98CD3315B39204340C",
        "chapterUid": "8F0F11BF32BEA44F8D6871B6601039C7CB03",
        "order": 1,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C68F35C54F718643ED2A9AC1C9F858A19872"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8243A1EC6013024D95195CB16E84280B9664"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Already seen",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9B448D537167F84B8F387315C2B53809F607"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "34998FE507535248316A9BA6F3B993C0B711"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "2601E4ED3A82964F417911333F23576C7A8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8599AD591BA93343351992F3F4A0F47A01EF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "DD1A178851E9414A2A4B37C48BFB015F4751"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Rattle.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3AFB69AA45AF7147FE79AA1206D406028FD4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 1,
                "uid": "C13D7C3D42948844C338BDC4A4A720A427F3"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Rattle.ogg",
                        "volume": "75",
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 1,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 0,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A00623FC6BE05342076836C15AB46EAA71D5",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 1,
                "uid": "0247A8810E3C514DAB69B7A6ECDAEDB5AB24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "085AF4ED0C27574BA4286888392A7F0239B1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2696E1D946D0A449EF49CBE03F18F6F8B68C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EDF2857B3A95A0410B7867E5DF30699DCE59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "95DA208B56B75346C05AC95855C424C5E871",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1"
                        ]
                    }
                },
                "indent": 1,
                "uid": "3C8CAE3768011244CE5854C5EED49A48914A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2A3EE7F64464742FC29DB47157121A8B981",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "113991681B1AB84BF78BF5783EF5FB1AEAA5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "70A02424715348481788B1D614FDCBBC5E6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "53F876B462BAA5469F8957B977C1509B9EF6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E9503C30D8A104546792F44C9CC5B518227",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "8CED49AC369B6844942B7233E0A3130E463E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "1C39900E4861D141201911C8D066954ED80C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DD16789338EF654EED4A64C2BE6DDA9641ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F711F07060CE8459C287D831E4288D94162",
                        "defaultText": "조, 조, 좋은 아침입니다, 그릇님."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "03E12944127F534081291504E3F6A530F0D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4BB5D9152DCF1140FC19E0199A2BD12D8817"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "89D675D97C7275421739FD432FA1912C63FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F5334C60455C3341D279EA97F01D4D43F869",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "5B96E79B5B1B354EA559C992E9B0712E1F2D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6F57F14A4D3A7548233B348841502A1F66E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E0B54B0C0BF9F043FB180886C90E1CD8B926"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDA97E5B651E9543B529561562C2CC5C6038",
                        "defaultText": "계속 그 소리를 낸 사람이 너였군."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9249E83C6579C54EC28B6CA1A4EE06D521AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C1FF77C529269945173909084FE2F0727143"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "482A3C712D78B545D259E0E41B90A4F22B4D",
                        "defaultText": "왜 그렇게 떨고 있지, 사브리나?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "53EFB45A2B692748EA3A3678735D9AF88BA7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7FC8C9DB5FC4B24FC84BEAE8D9CF7C7C8045"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Sabrina",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0EB976A18F006146949BE3214ED462A264AD",
                        "defaultText": "Sabrina"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D416B8899CCC84467F7AA8D1D51B947BCCCC",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Soldier 2"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Sabrina",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4669D5775258E54D407A31A17A57A99A726C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "29DA337D662BE547006B8CC82041465177E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "016443532C0B4543E91B0FA19382E6B64518",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line6_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "A251A1EC8E6396434779D09183255C98294C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F3E250EB0F6C92424C5845719065E2CA5058"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7607915425B94142A07A9D4031592A253534"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01051B407B8FD743F569CC23D885E985FC9A",
                        "defaultText": "꺅! 잠깐, 제 이름을 어떻게 아십니까?"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "AC3DDF177879D3427A484B88E85E13BE95E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0D6DB2DF31219146103B3033AC78DB8E8713"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "579A898F60A6B44C6C2B1EB4285303CE45E5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5730EAAE274042479878BD546E2E8D066CE9",
                        "defaultText": "알다시피 그릇은 군에 상당한 영향력이 있어.\n모든 병사의 정보를 열람하는 건 당연하지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "EE40AE652643C44FAC286BC62F8ECDE41589",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8E3F542766F3A24ACD8B96A86BE682547BFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "617CB1558DEB914AB89823139840B712432D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03268AFD8B6A3149E4382077FF81884BBCDC",
                        "defaultText": "게다가..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DC2756D91B8C6743F188DD06B441E48C0DBD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3B06DC9366F4244A1F788A613423DE156B16"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0DC90AFD7F9C2948DD68910094414145C842",
                        "defaultText": "난 진심으로 모든 백성을 아끼니까."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "EAFC601F72BDB041B8183CF3F1BAFAB63B7E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2107C39786A1604B1E3AB9B83A319BF062A5",
                        "defaultText": "병사들의 능력을 알아 두는 게 전술에 유리해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "AC8C15C1368AD644048BEA4640E73293669D",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "71B3E884536C3648CE7969725A98BE8AAB23",
                        "defaultText": "그래야 널 더 쉽게 조종할 수 있으니까."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "05697087877CC346920AD5B83069A5717D85",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "care",
                            "tactics",
                            "manipulate",
                            ""
                        ]
                    }
                },
                "indent": 1,
                "uid": "61841B639880B641287A31D406C4C3972AB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "EE24FE8D5F4B51434548E7F7617F9572E4F2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "care"
                },
                "indent": 1,
                "uid": "503E611C4CFA394B3D5956670530A1E21D44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0ABF5BCD84DDD84C0B7A0017A96EA7F41A1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AAD8BE16136CF84ECB1AFD749EDCD41096A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A56E0D371F3A784E874ACDF853C96FF91B17",
                        "defaultText": "저를... 신경 써 주십니까?"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3D9860D858A02245C47BCA49262C3F5289C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "66E0480F6A5EB44FD14BBFE8D6E307DD5E8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "39B0BBC38730D847A54B52A731FA672B71A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7209460D67D55847D92A47D253DC48726EA7",
                        "defaultText": "목숨을 걸고 이 나라를 섬기는 이는 나와 한몸이나 다름없어.\n내 가족이라 해도 좋지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "33FFFE4C449548487D2A8521B0BF1CD06A3D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FE2551E7780E56455938D4498319D7E6CCBE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C75BCBA277F164C405AC8E5FE0D3E3112F0",
                        "defaultText": "그러니 그만 떨어 줄래? 정말 해칠 생각은 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "331D782D778EA24D7579CE86DC124327A400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "93CB3F7306A18448F06A9B867DE528B87FCE"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of soldier choice",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "8BF3B5A303B352438D283CC4A69A33D8D4AF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "tactics"
                },
                "indent": 1,
                "uid": "700FDCBF8AD2124578794C21E9909F50D9C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E53AA32310F783463829AE3837215FF915D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABCD67033CE1284AD27B1E2855359CB18F30",
                        "defaultText": "제... 실력 말입니까?"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "73246BB889E0B442BF1A5051533A9E4BC0FE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3B20A7E4489E6843757B68C88343A9FB0526"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2477B8488568144B983B9A16AB2D419EDCCD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F40864E40D918143DC488BD1EBDF701902C6",
                        "defaultText": "가난하게 살면서도 늘 공부하고 노력했더군."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "2BEFD25529CCE3467F8BB2325B29EC2DACA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "68E0F23301A9254E806826921EAA655F6C63"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2285348F3CAB46485C19B553B5F5F887C358",
                        "defaultText": "그 헌신을 깊이 존중하며 네가 조국을 위해\n무엇을 할지 기대하고 있어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DAF1CF5E0617E940954BDD2302B56F7CA16C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "48F3E30449E5D04A6F3AB4C8D65BFA3AADBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6DCE3CAF8AD77647672A41C101CC30B93CCA",
                        "defaultText": "그러니 그만 떨어 줄래?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C92EF9E964EB994A6A6928F49AD204AAD15D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F542DF982CCCD344027AB7B462A74FA9D9C8"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of soldier choice",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "EB6C1286300E6541FA6841D23BB8E9B59EB4"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "manipulate"
                },
                "indent": 1,
                "uid": "DE567CB43870F04F1B8A04222671581F6FA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "61AA8D1A4A3B424BDF685182AE2572A8B47B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BBA9820A5993E741DA884A63FDD0507BD3AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "670874E98946F248AB589699F906DB485BEC",
                        "defaultText": "제대로 들은 건가? 여, 역시 내 생각이 맞았던 건가?"
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "159FEA6504CBC3473759CC71D17D7C397B87",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C13A817A0C83984DB65B74B57D57B7AD1F7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "027620682BFE28480D396CD65DEE5833704F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "38085E4663AF014EF30B93C83889405583DA",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line32_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "0CF9936547F713417D6978C3EE532902ED3A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A77866A7564A144DE949450303441524F9A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0FC4B8752545F344793B1333AE3BC5FE92DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46EDE27A287B7440F339DA146D1422D6AD32",
                        "defaultText": "마왕의 그릇을 두려워하는 저런 사람은 이미 많이 봤어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "98EAED98883C4747806B17113B1FF4CE441B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DA7BD3B314F8D24B9729B3F7CACE17600A2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "49D6E72041DFF04C998931B0FCEB13F9FFC7",
                        "defaultText": "내가 악하다고 단정하고 그 망상을 부정하는 말은 듣지 않지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "072A04DB6A1FD14F3D19DAE2CEACD2DC57D5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3AF8AC381D60454FD04833A960DBDC5E7DEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "536DA4C36AC5B54EA638BDE2EE3601A1A710",
                        "defaultText": "하아. 싫지만 저쪽에서 선택의 여지를 주지 않는군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "040FFB6B838C684FDB3BE6B553314E37EC27",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5B98BF9959641544546BDB278700C919F8D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3F93E5B817A36542FF0A95A389D402D73753"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B8B50A71D4B1748918A6E109F71EB967D48",
                        "defaultText": "큰 대가를 치르기 싫다면 그만 떨어, 사브리나."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E43969C378514243DE2901C70F70364EB76D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A88239392207C44C0A186FB24872499D23CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "352F934B6A3B0746A70B72438DBD1CA0D007",
                        "defaultText": "상관 앞에서 울라고 급료를 받는 게 아니야.{W:200}\n호이카데 병사라는 역할을 존중해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1B48E5721F4654414428EAB042C7A2BFB9B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "11E869266D7BB343CD4958C5F555D740A0F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2AFFBAAB3AEEF5409D2A68B2469F19B846FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "65FEE26811537944695A24183835EBB320D3",
                        "defaultText": "저... 저는—\n으앙."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8F96EABC1969D1462D7BEEF00E51036C1624",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5AB2EA21388BA5465B3837383A5CC90CA761"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of soldier choice"
                },
                "indent": 1,
                "uid": "8A699BED1C7DC54017793752337916B25377"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "76F16DCA5150B54C7C4B150275CEDCEFAE5C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "32E091452D09E04C017ADDF2B4F2B7BCE7A8",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line5_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "4015CD246BEA5445F67BFF38174D0E95253C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "75545C7E6274D64EB4587822498960AEFC0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7F7721F397DA2145D67A6A28D101A6646FD4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF4809D61D93044F6538E5A346F10E9E7D8A",
                        "defaultText": "...노력하겠습니다."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1690AC24572824470E28FD84E71CEE310C16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2579859F857F47467E7AF04123C7A43DCBFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            1,
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "E17AEDE02B1E3346ED785C92802B16BA0236"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 1,
                "uid": "111224048620234FE7589D70D568F382A5DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A869AED4466FF44DAE7B8A857B3850240A66"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 1,
                "uid": "25FE9B4F638CE2435D68E0F12FD668C560F1"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Rattle.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "37688E2F26042444027B7A1558F00D824FE8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "0F4A9B377D9B154282893E47C59C963B60D5"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Rattle.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F5D04233428D7949724A6A821252F27765D9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 1,
                "uid": "65F5BBB85B3D414E5F7A3856E2555981FDA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D60872D40383B74FBF4856E24F2D92D0992F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EECBD748310E1947442912873567C0F51A00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CB153C3B407570489B1A4FF3BD583F7AAA5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "09445B8C3AA5D84772594845484B9987C0AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10B8BB0A3DADF14263395FE753B072975EF8",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4BF4124E3FFCF047465A31E3CD72313ACF10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "442601413EAD4340449B5704679A67CEB806"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F3223B3E7963F340677807B8F3A66CF5D3D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "89BE809D5D52024A8188F003B878CD004599",
                        "defaultText": "가족을 위해 돈이 필요하지? 그래서 입대한 거고."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "6D469E163CF405400E7BA961F7FC481BC749",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C97456A34EF7144A5E3BDD065DD8A984B8ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6CB778D64DF8314FF08B70A6FA1D69E77B59"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "905ECAB91A5698475F683210A647061C731B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line5_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "6A843CDF70B761472B7BB840D4A996929FC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "07727E62440DD44591391A95D91BF6E6BAF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CD150C326C30954DAE4B7D18115E3B917B14"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA827BDA7DAD7446484A53837DA355DDA468",
                        "defaultText": "...그렇습니다, 아가씨."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8231F4C82E09564E0A7BE80465FE142DDE6C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2EFA064D4D168640A038C9B1462F5AFFAC3E"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "9729B608348A02432F796433025638DE0387"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1AFD71BA9AFF244E1E5AC755AC9A3CE2E260"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7A4090A38E5A024BDD1BC7406AB8CCE0B301",
                        "defaultText": "어머니가 많이 아프신데 약값이 비쌉니다."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6C9480C774A2254F2C2A8674E6FB21F7A163",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BDD8DC20894A04C1C4B84B4D79D09385287"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9EDD84223554274386798172EC08E54243FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8437E1419B0344F509AA1E12A71ED2DCAD7",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "53D7990F8F3946466359FFA3DB631C1F048E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "62EB4C86689D784839498FE79DB33F3DBA15"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E136DAD52E562466E8B0EC2022AA38C214D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9540C566441FB7462D194A488FD76BA5723E",
                        "defaultText": "그럼 어머니를 실망시키지 마. 두려움에 떠는 것보다\n더 나은 모습을 기대하실 테니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A46EFAE284AC74D543BBF54B6A6BE720BB2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D97B981D322C564EF89A641423D463C1F211"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "66EEB40A605AC747277BE428F8328D103353"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "524E7CD5769F5649CA5BCB25E541058AD189",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "expressions": [],
                    "animations": [],
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-SoldierHoikadeF_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9D8785C23D30314934680A969B161BCC412F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F58261864A46E940F71845002013F6A5261F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C822C69F804B554A6B3867100FEDDC8468F1",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20049EFE882E224C8F2B9CC266122CE5C207"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62443C128476B241AA1BC0E2E5BA877223DB",
                        "defaultText": "그... 그런 것 같습니다. 감사합니다, 아가씨.\n말씀을... 되새기겠습니다."
                    },
                    "position": 0,
                    "characterId": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "808B85B96021024297391ED150F307DA8D56",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1CECB7D322408406388D0B3290BF3DAEF2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABAE2DAE4922924DD07835418B6107ED0706"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Already seen",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "02D19D4673CAB34EAA1BC2425D23A0D0BA66"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Already seen",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "AA5DD4BB08E3044F9A2B55C4045A8B7332B5"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B67A5C3B9C08644351492C149BC857F5363A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 2",
                        "index": 161,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F3FBCB855A284648D11A7C04C51691439C0C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 3",
                        "index": 162,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "3C1E399A8E060144D3296AE858E5D8D8EB61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F79C83823F66B24F925BBDD49B53FD378EC3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 3,
                "uid": "F204C7B15A3B4546597A73E1B595ABE57315"
            }
        ],
        "booleanVariables": [
            {
                "name": "Already seen",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "localizableStrings": {
            "C2A3EE7F64464742FC29DB47157121A8B981": {
                "t": "... ... ...",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "113991681B1AB84BF78BF5783EF5FB1AEAA5"
                }
            },
            "1F711F07060CE8459C287D831E4288D94162": {
                "t": "G-G-Good morning, Vassal.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "03E12944127F534081291504E3F6A530F0D3"
                }
            },
            "BDA97E5B651E9543B529561562C2CC5C6038": {
                "t": "So it was you who was making that noise all along.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9249E83C6579C54EC28B6CA1A4EE06D521AF"
                }
            },
            "482A3C712D78B545D259E0E41B90A4F22B4D": {
                "t": "Why are you shaking like that, Sabrina?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "53EFB45A2B692748EA3A3678735D9AF88BA7"
                }
            },
            "0EB976A18F006146949BE3214ED462A264AD": {
                "t": "Sabrina",
                "d": {
                    "eid": "D416B8899CCC84467F7AA8D1D51B947BCCCC"
                }
            },
            "01051B407B8FD743F569CC23D885E985FC9A": {
                "t": "Eeek! Wait, how do you know my name?",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "AC3DDF177879D3427A484B88E85E13BE95E0"
                }
            },
            "5730EAAE274042479878BD546E2E8D066CE9": {
                "t": "As you may know, the Vassal has a certain influence within the military. It's normal for me to have access to every soldier's information.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EE40AE652643C44FAC286BC62F8ECDE41589"
                }
            },
            "03268AFD8B6A3149E4382077FF81884BBCDC": {
                "t": "Moreover...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DC2756D91B8C6743F188DD06B441E48C0DBD"
                }
            },
            "0DC90AFD7F9C2948DD68910094414145C842": {
                "t": "I genuinely care for all of my people.",
                "d": {
                    "eid": "EAFC601F72BDB041B8183CF3F1BAFAB63B7E"
                }
            },
            "2107C39786A1604B1E3AB9B83A319BF062A5": {
                "t": "It's more tactical to know everyone's skills.",
                "d": {
                    "eid": "AC8C15C1368AD644048BEA4640E73293669D"
                }
            },
            "71B3E884536C3648CE7969725A98BE8AAB23": {
                "t": "I can manipulate you better this way.",
                "d": {
                    "eid": "05697087877CC346920AD5B83069A5717D85"
                }
            },
            "A56E0D371F3A784E874ACDF853C96FF91B17": {
                "t": "You... care about me?",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "3D9860D858A02245C47BCA49262C3F5289C8"
                }
            },
            "7209460D67D55847D92A47D253DC48726EA7": {
                "t": "Whoever serves this nation with their life on the line is akin to me. They could well as be considered my family.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "33FFFE4C449548487D2A8521B0BF1CD06A3D"
                }
            },
            "8C75BCBA277F164C405AC8E5FE0D3E3112F0": {
                "t": "So, would you please stop shaking? I mean no harm, really.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "331D782D778EA24D7579CE86DC124327A400"
                }
            },
            "ABCD67033CE1284AD27B1E2855359CB18F30": {
                "t": "My... skills?",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "73246BB889E0B442BF1A5051533A9E4BC0FE"
                }
            },
            "F40864E40D918143DC488BD1EBDF701902C6": {
                "t": "I see you've always studied and worked hard despite living poverty.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "2BEFD25529CCE3467F8BB2325B29EC2DACA6"
                }
            },
            "2285348F3CAB46485C19B553B5F5F887C358": {
                "t": "I deeply respect that commitment and I'm looking forward to see what you'll do for our country.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DAF1CF5E0617E940954BDD2302B56F7CA16C"
                }
            },
            "6DCE3CAF8AD77647672A41C101CC30B93CCA": {
                "t": "So, would you please stop shaking?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C92EF9E964EB994A6A6928F49AD204AAD15D"
                }
            },
            "670874E98946F248AB589699F906DB485BEC": {
                "t": "Did I hear that right? W-W-Was I right about you after all?",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "159FEA6504CBC3473759CC71D17D7C397B87"
                }
            },
            "46EDE27A287B7440F339DA146D1422D6AD32": {
                "t": "I've already seen plenty of people like her, intimidated by the Vassal of the Demon King.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "98EAED98883C4747806B17113B1FF4CE441B"
                }
            },
            "49D6E72041DFF04C998931B0FCEB13F9FFC7": {
                "t": "They've already made up their mind about me being evil and won't listen to anything that doesn't confirm their delusion.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "072A04DB6A1FD14F3D19DAE2CEACD2DC57D5"
                }
            },
            "536DA4C36AC5B54EA638BDE2EE3601A1A710": {
                "t": "Sigh. I hate this, but she leaves me no choice.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "040FFB6B838C684FDB3BE6B553314E37EC27"
                }
            },
            "3B8B50A71D4B1748918A6E109F71EB967D48": {
                "t": "You'd better stop shaking if you don't want to face some serious consequences, Sabrina.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E43969C378514243DE2901C70F70364EB76D"
                }
            },
            "352F934B6A3B0746A70B72438DBD1CA0D007": {
                "t": "You're not paid to cry in front of your superior.{W:200} Have some respect for your role as a soldier of Hoikade.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1B48E5721F4654414428EAB042C7A2BFB9B3"
                }
            },
            "65FEE26811537944695A24183835EBB320D3": {
                "t": "I... I--\nWhelp.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "8F96EABC1969D1462D7BEEF00E51036C1624"
                }
            },
            "DF4809D61D93044F6538E5A346F10E9E7D8A": {
                "t": "... I'll try.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "1690AC24572824470E28FD84E71CEE310C16"
                }
            },
            "10B8BB0A3DADF14263395FE753B072975EF8": {
                "t": "... ... ...",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "4BF4124E3FFCF047465A31E3CD72313ACF10"
                }
            },
            "89BE809D5D52024A8188F003B878CD004599": {
                "t": "You need money for your family, right? That's why you enlisted.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6D469E163CF405400E7BA961F7FC481BC749"
                }
            },
            "DA827BDA7DAD7446484A53837DA355DDA468": {
                "t": "... Yes, Milady.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "8231F4C82E09564E0A7BE80465FE142DDE6C"
                }
            },
            "7A4090A38E5A024BDD1BC7406AB8CCE0B301": {
                "t": "My mother is very ill, and medicines are expensive.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "6C9480C774A2254F2C2A8674E6FB21F7A163"
                }
            },
            "9540C566441FB7462D194A488FD76BA5723E": {
                "t": "Then don't disappoint her. I know she'd be expecting more from you than trembling in fear.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3A46EFAE284AC74D543BBF54B6A6BE720BB2"
                }
            },
            "62443C128476B241AA1BC0E2E5BA877223DB": {
                "t": "I... guess so. Thank you Milady, I will... reflect on your words.",
                "d": {
                    "cid": "C822C69F804B554A6B3867100FEDDC8468F1",
                    "eid": "808B85B96021024297391ED150F307DA8D56"
                }
            },
            "6E9503C30D8A104546792F44C9CC5B518227": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "8CED49AC369B6844942B7233E0A3130E463E"
                }
            },
            "F5334C60455C3341D279EA97F01D4D43F869": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5B96E79B5B1B354EA559C992E9B0712E1F2D"
                }
            },
            "016443532C0B4543E91B0FA19382E6B64518": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A251A1EC8E6396434779D09183255C98294C"
                }
            },
            "38085E4663AF014EF30B93C83889405583DA": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "0CF9936547F713417D6978C3EE532902ED3A"
                }
            },
            "32E091452D09E04C017ADDF2B4F2B7BCE7A8": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4015CD246BEA5445F67BFF38174D0E95253C"
                }
            },
            "905ECAB91A5698475F683210A647061C731B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "6A843CDF70B761472B7BB840D4A996929FC9"
                }
            },
            "B8437E1419B0344F509AA1E12A71ED2DCAD7": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "53D7990F8F3946466359FFA3DB631C1F048E"
                }
            },
            "524E7CD5769F5649CA5BCB25E541058AD189": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9D8785C23D30314934680A969B161BCC412F"
                }
            }
        },
        "stringVariables": [
            {
                "name": "Sabrina",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "Cruelty",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}