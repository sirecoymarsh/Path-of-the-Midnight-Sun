GS.dataCache['A7B2D0F0217965406F1833C1813034CC1EA8'] = {
    "uid": "A7B2D0F0217965406F1833C1813034CC1EA8",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C4-03 Ending - Meeting with Phoebe",
        "type": "vn.scene",
        "parentId": "8D381E7C10471941382A2AC92CD7DB63FF30",
        "chapterUid": "6FC0AF36453CA744B128EAF83314DDE5F897",
        "order": 8,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAE57642329373438C5B7A288164FAB2791E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "567F1E3489D91446CF4A0ED6AF508D6BB339",
                            "2B96228807C91543086AF8734CBB0AD4A6B9",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FCE74B4791AB65459B2A7028C6A731825A22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FBE97F211A99D64C389BB1C15BEF1A80D6BB",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4641C1E8953A445B228FC122C20E18B8A6E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "5AAE2A2E3BC9C743617AFD13563E0A2821E1"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION INTERACTION?",
                        "index": 176,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6EDEE8CD026281486F2AB656C177A562D14A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "987D6E7B303E914FD37A85E84290DD809094"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "9BEDC07C637531494B7A96F7C9875C52D5EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2023FE8E33956542A038AF302F8BDC74437C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "232A376754BE854A6B489A367721B207FD8F"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F58750ED1F592240C14A16D51C64A295D1D6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "F533A04E7893D946951965E7695E77AE4BD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A036F9D98AB8E6476D396A7305442A861E41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16EBAEC259CA434EEC18313683A26B068FED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A6F3BC99A6E554B0E094C639CBC33F01505"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70063F9A8DC899428A791917BAFBCEDDE18E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F06B2E6E9FE60445CE9B7F323C466C83DE3F",
                        "defaultText": "회담 시간에 딱 맞췄군!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "150B80247133A249E99AAD645AFACCFEE7AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB549A0E77FB794D5949C371A2780C8E3A26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "0E8B77714E18674091382BF1F3FD1D87C7DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A73B4FB452957443AE1B29D3F2A3A2356DDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            800,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA73C1B270EED243866BAB168E4E52B2EA23"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 49.199999999999996
                },
                "indent": 0,
                "uid": "EEF90EA77971164CA4595B65E549D9800481"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0819AF404B2EC64B4729F02840582B7180A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "15224E583986C649652961F8D83C325E97D6",
                    "parameters": {
                        "values": [
                            2,
                            40,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BDBAB0B1B6BC4414F499A824B73CF1BC661"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8E278C2E83D8304CA33B4384A4BCA33736C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E13928D45325B84B4C89A672FC0B4CFF5B2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9E424C0C2C4AE34B422B6DE33E55EB80E462",
                        "defaultText": "지금 농담해?\n늦었잖아!"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "719602573479934F4F6849555CDDD15EF2EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DDCBC1122BFEB74E258970A13F4D0D29AF94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            1,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "73E044C3606551412F686F5481225C82C980"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "33331A7A3A98C549D66A14C1344A39C2ED92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "8C5E234E52ECE644573BDBC7576E7BC19456"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6CFBBF23478798483D2ADA02D26F8DBAAF0E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "30032AFF75A323434A8B5ED2746F131E1C2C",
                        "defaultText": "저는... 부정할 수 없군요.\n제 책임도 있습니다... 죄송합니다."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3497A2A8687BC844FE8A5B67BF04B564A5AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EEA7F2624E1CA14AB83B231784350CFB4A14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5A1DCBB4172828416E99E798CC4B5C2B8F4C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DB969DA1C08B54F843827D7CFFFC74DF598",
                        "defaultText": "우리도 조금 무책임했어요..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4A48C95E55BF13466E9A0666321D60E42F7E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C6E3C96D4662344D453A0AB8DF982A92A3C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "17159F9E71C86742391B76F8A536D55A4A08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B55438AD1C3B164C89880E7112842FCDA89A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5A33E5601DE8041759B3EF714FA6240A1BE",
                        "defaultText": "쳇, 됐어. 여제 폐하도 늦는 모양이니 운이 좋았네."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "ADA1FAA944EDE440CD792CE5508D61CDCDEF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3B7DD6CC4F8EE64B0319110444E9AF020A3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B413892705ED6442E35B0F303563F5FBB78C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "259B723C4BA84544220832621186823C2926",
                        "defaultText": "그래서, 어떻게 됐어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D9CF17A00264B64329687CB397E7F915EFBD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4534F04589C654E551A43D051FE579A3A72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "444A59AC46808647B019DA49DA32C7CD0061"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE03979C4EA5F644E7895017DC91B6884D2D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "E3-Cristoph_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0C7F41C3BB6044D515960370DA6BF452E28",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AA6ADB84874C25447728F4045DF427FDC310"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66DFDCC47D02D44BE66AA7D6559CD44F9DA5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67ACB1EF811498420A3BAC3177681203ACC0",
                        "defaultText": "아주 잘됐다고 할 수 있지! 믿지 못하겠지만, 리아.\n계속 도발했는데도 넘어오지 않더라고."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "161641522E8B6344A54B7A37FC07F63C24D9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "041B6F5B6D161746DA49E0D2036F8C25186F"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C67BFF55A8CE04D137AECD37FD94ED1E960"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D217679632C68486F9BE8736814BA496B88"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "69C345EE7F4B52431F2A1AA0AE7A4814FC36",
                        "defaultText": "{LT:1}, 내가 기억하는 성기사와 조오금 더 비슷해졌을지도 모르겠네!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C51A5719DA7D64BFA3B5A13F89DD71C99FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7722E0DF5590024D2A88F1B257D3006E32AB"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "DA3FC9BA5C90014EBC2A6FC2EF57CD2707F8",
                        "defaultText": "괜찮아! 아무것도 눈치 못 챘어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "49C411AF73434246584A99A26CB7047CB263"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "53A764DF6B00B6445248FDC115C6453B6B5B",
                        "defaultText": "마그놀리아는 어차피 쓰레기야, \"친구\"!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "295E2FD48E851247732A3252CC2E21E6B7C9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6B0CE9D92CE13845E36834D200E5EC68EC72",
                        "defaultText": "뒤통수 조심해. 반드시 복수할 테니까."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "0E0C7B266C72C44E741896B2D7CAE80BB30E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "formal",
                            "joke",
                            "angry",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "735950C8774B82445A4A0B27E3A53ABFC4DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CEF0957B5AEBB044910B0197699E61035DA3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "formal"
                },
                "indent": 0,
                "uid": "9D4DDB0C187898404B3B68F262FC13538D1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0,
                            3,
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E1DDEFA5132564A003B8724C3B077281458"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20ED06E86FA7194FA81B35F87495C32D89CB",
                        "defaultText": "괜찮아! 그래도 그렇게 격식 차릴 필요는 없어. 우린 친구였잖아."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3AE5B7D9298A6844578B07E745A4D5949BA1",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of cristoph choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "C710D7BB8F1849406778EE428696AD90B48C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "joke"
                },
                "indent": 0,
                "uid": "56893D19262F01435F1BE372692CEB444844"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0,
                            5,
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87A8EE637B2EC440603ADF247F15DD35CD9B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BA1714E72457145421980D6EAC86AC1F240",
                        "defaultText": "하하, 농담인 거 알아!\n이제 네 빈정거림도 꿰뚫어 볼 수 있거든."
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2972F3156F1047488C4A7548E689DAF59301",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of cristoph choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1C4F412A33FFE2440B29C37964723B97D2C7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "angry"
                },
                "indent": 0,
                "uid": "23A4733274DB6244825A408952F3A7C44694"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            1,
                            0,
                            4,
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D41220DE86155747EA59CDE185F9632F8780"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "59953C3E34328542F649C2B14E26D123DE38"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1C396A42FFB084FEB4978D363F4D5C6BF80",
                        "defaultText": "아, 정말! 뭐가 문제야?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DC27748333ACE5446D4BB6B8442DB4B4D15E",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of cristoph choice"
                },
                "indent": 0,
                "uid": "629539131561944AEC68A6C82B15663E97F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DE4AFCE4363D9490449FC31A09EAD808805"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AB6F7A716510747C689E2A3B76E4BE056D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FE89B9182F84644FC18F5199D91DAB12783"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56041DEF5450E449D648E9A7FA4E7A765738",
                        "defaultText": "아무튼 함께 가요, 파라트라스 님. 크리스토프도요.\n여제 폐하를 중간에서 맞이하죠."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "946A51EA6370304B31088895263ABCE05363",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA88D24D7057084EE259D8365064BCD53D5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4142BBDF46657140A88982C2B5AC7248542A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "77ADE7F8632E224F656ABEC34BC874AC2F97"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "394A2BDC89431544CD3A9295FCE54DD9628E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "691551041148A349A72884E3E2C7C99F8884",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "160B13E64BFC73483E2829F761191DD9E2A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACB7026926C6534A094B0FE5F5729CAAE1BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96389BC28AB1A24547797FB486EAABDD75F6",
                        "defaultText": "저와 오르니에르 경은 어떻게 하죠?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DFFC11173D756947053AD3812A615958AEF6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C01BB9616771D44E97097ED3A685EEA0F967"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BE731D4537B9344B31B752874156D66DBAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E337CCA75AFBF246E45A3726530F10D59FA1",
                        "defaultText": "잠시 여기서 기다리세요. 곧 돌아올 테니까요."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "98F0AE5B2F63694A6718AEE2C6935E943558",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68BD36A083F3354BBE99DDF3582E0A1C208C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A33996D70C4D74A416981559EE6331DB706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1A9CCA53A25E94C56694056E47DD6F73838"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BEAC7ED5CE0044F835AA040DF1B87B421DB",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "098150431291D14275181F508EB51B35E8B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A56C869670B4054CDA4A4913DAB4F9BB1500"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4572CB38439FB845FA090BA2DBCB30F8A2C7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "16F3A9F975BCF54593697E715B7E0F48B9DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC1D9EB2520D824E138B28421B36444905BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5406044C27D4B847BE8AFD25325DEAB697E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AA6C695F266AB6445E0B4F94F2FD8CC48C56",
                        "defaultText": "우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "07BCB74214A348423E69F7976BCCE111517A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DFCF44E5A36F841717B886117A7DE2C4FA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D9BB9E9125814490F2BBF94477B3B0F85E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87DC30F58425D3476F888943BF2C202AF9CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "090AA54D4364684FFB8A229412FC6C20E6C8",
                        "defaultText": "루코스도 같이 갈래? 착한 아이에게 줄 맛있는 간식이 있어!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "18728DA4434A024E5D49C8932307D914674D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB13CE81473E2443F06BB244000E1645732D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "C795D5164BB5B74F08891D01A7F77F0075AD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "67533FEE5927D540898AF1521AB3846371EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DB0D3718E60444D1E8BF442E50F6BF9FD3A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "484A8E7373E3264C1728DE28A74CB592C796",
                        "defaultText": "우우우우우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F987066410A2E54A4A1AF29698AEF1F1A465",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "059CB2CC706710415319BEF7F3AB02C0A153"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F0F96366DAFF3416B596252156364321402"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "49BFA0E3946F95422A393B61F52F5DC19439",
                        "defaultText": "정말 쉽게 매수되는군..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A3AD31B6471F348B67B13F43791359E9BFC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFE6F5F76A92D442D82936024D2D51947FFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B09D8D191594A845043B5D09ECD49628BF2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "594BE881985A71440C58F707C750C781A5BC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "CE49D95073472547E0697AB6BB039C9AA7B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA43C6F87C38004C432B1F14764EF46ED071"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3854BF702F1F94470A1811E35E37C8277DCE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "572BBFCE049EC24F020B7A040C1B85ED2A58",
                        "defaultText": "그럼 나중에 봐요."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "676257449BFCA1478F2BD3B2EB343FADE884",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D86F0BAB9C5A14401C7B1E2598F3E5008C4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00367B950CD7184FB38AAAC498605D2ADFBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "91DEE339854C614D7F886AD773E53B025C87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4698CBBB253BB24CFA3BD572A1532BFD33ED",
                        "defaultText": "안녕히 가세요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FB5CC8AA7D57B848483950A634446E968854",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "79889D3F1DF4B645510B53E008F097F56CA9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "45D006B38C7EF541E14B7933BBE90D19208E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F67D870998A2943524918823C35B246883C"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "68E1AD922036094A224B9896B463D7E3EC25"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "823B077F6A05A84B0938D3B27EB38E07B761"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "11BED36A3FBC464F90293F1274539DBAB48D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DD78E8B893B9445A82AD405CBAF61E0AD34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37CF29CC0C1FE047EB1AD2298098871C2170"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4DCABAC4979B9459C8B2F74F1935BA0FFA7",
                        "defaultText": "... ... ... 그러니까, 헬리오스와 둘만 남았군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "590848147E4F864EAC9AD5E8301DC6394945",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DE379CDD5ECC97413B1A6497545590DEB826"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42CE7F635B132642E4490CC8EB8A9DCD54D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D70F3A480647374B4E6BED76AFF97DC7FD09",
                        "defaultText": "이런."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFE7EEF6291C694F1A69F57223F86461380E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6787A2CA7180F54F104B5CE30853F910CAAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "918263054C9FA444FD7B58F986229F491110"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "61013E5F1BE4274EB789FE72C30C6534F883"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B31731AF1E29294BA118AF9196C8E6DF021B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "16C7E427301522454D296B1387EED05F3809",
                        "name": "C4-03b Viborera Palace pt.2 (Exploration)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "21C32BA79D65284BE29B7D681B849AFCD84D"
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "mall path id",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "F06B2E6E9FE60445CE9B7F323C466C83DE3F": {
                "t": "Just in time for the meeting!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "150B80247133A249E99AAD645AFACCFEE7AD"
                }
            },
            "259B723C4BA84544220832621186823C2926": {
                "t": "So, how did it go?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "D9CF17A00264B64329687CB397E7F915EFBD"
                }
            },
            "67ACB1EF811498420A3BAC3177681203ACC0": {
                "t": "Very well, I'd say! You won't believe it Rya, I kept taunting them but they didn't fall for it.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "161641522E8B6344A54B7A37FC07F63C24D9"
                }
            },
            "69C345EE7F4B52431F2A1AA0AE7A4814FC36": {
                "t": "{LT:1}, you might be a liiiittle bit more like the Holy Knight I remember!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "3C51A5719DA7D64BFA3B5A13F89DD71C99FC"
                }
            },
            "DA3FC9BA5C90014EBC2A6FC2EF57CD2707F8": {
                "t": "No worries! I didn't notice anything.",
                "d": {
                    "eid": "49C411AF73434246584A99A26CB7047CB263"
                }
            },
            "53A764DF6B00B6445248FDC115C6453B6B5B": {
                "t": "Magnolia is trash anyway, \"buddy\"!",
                "d": {
                    "eid": "295E2FD48E851247732A3252CC2E21E6B7C9"
                }
            },
            "6B0CE9D92CE13845E36834D200E5EC68EC72": {
                "t": "Watch your back; I'll get my revenge.",
                "d": {
                    "eid": "0E0C7B266C72C44E741896B2D7CAE80BB30E"
                }
            },
            "20ED06E86FA7194FA81B35F87495C32D89CB": {
                "t": "It's all good! No need to be so formal, though. We used to be friends.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "3AE5B7D9298A6844578B07E745A4D5949BA1"
                }
            },
            "1BA1714E72457145421980D6EAC86AC1F240": {
                "t": "Haha, I know you're just kidding!\nI can see through that sarcasm of yours, now.",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "2972F3156F1047488C4A7548E689DAF59301"
                }
            },
            "B1C396A42FFB084FEB4978D363F4D5C6BF80": {
                "t": "Aw, c'mon! What's wrong with you?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "DC27748333ACE5446D4BB6B8442DB4B4D15E"
                }
            },
            "56041DEF5450E449D648E9A7FA4E7A765738": {
                "t": "Anyway, come with me, Lady Faratras. And you too, Cristoph.\nWe'll meet the empress halfway.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "946A51EA6370304B31088895263ABCE05363"
                }
            },
            "96389BC28AB1A24547797FB486EAABDD75F6": {
                "t": "What about me and Sir Ornières?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "DFFC11173D756947053AD3812A615958AEF6"
                }
            },
            "E337CCA75AFBF246E45A3726530F10D59FA1": {
                "t": "You can wait here for a little while. We'll come back soon enough.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "98F0AE5B2F63694A6718AEE2C6935E943558"
                }
            },
            "AA6C695F266AB6445E0B4F94F2FD8CC48C56": {
                "t": "Woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "07BCB74214A348423E69F7976BCCE111517A"
                }
            },
            "090AA54D4364684FFB8A229412FC6C20E6C8": {
                "t": "Wanna come too, Luckos? I have some good snacks for good boys!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "18728DA4434A024E5D49C8932307D914674D"
                }
            },
            "484A8E7373E3264C1728DE28A74CB592C796": {
                "t": "WOOOOOOOT!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F987066410A2E54A4A1AF29698AEF1F1A465"
                }
            },
            "49BFA0E3946F95422A393B61F52F5DC19439": {
                "t": "It's so easy to bribe him...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6A3AD31B6471F348B67B13F43791359E9BFC"
                }
            },
            "572BBFCE049EC24F020B7A040C1B85ED2A58": {
                "t": "Until later, then.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "676257449BFCA1478F2BD3B2EB343FADE884"
                }
            },
            "4698CBBB253BB24CFA3BD572A1532BFD33ED": {
                "t": "Goodbye.",
                "d": {
                    "cid": 0,
                    "eid": "FB5CC8AA7D57B848483950A634446E968854"
                }
            },
            "E4DCABAC4979B9459C8B2F74F1935BA0FFA7": {
                "t": "... ... ... So, umh, I'm left with Hellios.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "590848147E4F864EAC9AD5E8301DC6394945"
                }
            },
            "9E424C0C2C4AE34B422B6DE33E55EB80E462": {
                "t": "Are you kidding me?\nYou're late!",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "719602573479934F4F6849555CDDD15EF2EE"
                }
            },
            "30032AFF75A323434A8B5ED2746F131E1C2C": {
                "t": "I... can't deny it.\nI feel responsible... sorry.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "3497A2A8687BC844FE8A5B67BF04B564A5AC"
                }
            },
            "3DB969DA1C08B54F843827D7CFFFC74DF598": {
                "t": "That was a little irresponsible on our part, yeah...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4A48C95E55BF13466E9A0666321D60E42F7E"
                }
            },
            "D5A33E5601DE8041759B3EF714FA6240A1BE": {
                "t": "Tch, whatever. You're lucky that the empress seems to be late too.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "ADA1FAA944EDE440CD792CE5508D61CDCDEF"
                }
            },
            "EE03979C4EA5F644E7895017DC91B6884D2D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F0C7F41C3BB6044D515960370DA6BF452E28"
                }
            },
            "394A2BDC89431544CD3A9295FCE54DD9628E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "691551041148A349A72884E3E2C7C99F8884"
                }
            },
            "3BEAC7ED5CE0044F835AA040DF1B87B421DB": {
                "t": "... ... ...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "098150431291D14275181F508EB51B35E8B7"
                }
            },
            "D70F3A480647374B4E6BED76AFF97DC7FD09": {
                "t": "Whelp.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EFE7EEF6291C694F1A69F57223F86461380E"
                }
            }
        },
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}