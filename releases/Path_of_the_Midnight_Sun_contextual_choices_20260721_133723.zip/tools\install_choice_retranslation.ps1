param(
    [Parameter(Mandatory = $true)][string]$PackageDir,
    [Parameter(Mandatory = $true)][string]$GameDataDir,
    [Parameter(Mandatory = $true)][string]$BackupRoot
)

$ErrorActionPreference = 'Stop'

function Get-Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
}

function Install-Atomic([string]$Source, [string]$Target, [string]$ExpectedHash) {
    $parent = [System.IO.Path]::GetDirectoryName($Target)
    $temp = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_tmp_' + [Guid]::NewGuid().ToString('N'))
    $replaceBackup = Join-Path $parent (([System.IO.Path]::GetFileName($Target)) + '.codex_replace_backup_' + [Guid]::NewGuid().ToString('N'))
    try {
        [System.IO.File]::Copy($Source, $temp, $true)
        if ((Get-Sha256 $temp) -ne $ExpectedHash) { throw "Temporary file hash mismatch: $Target" }
        [System.IO.File]::Replace($temp, $Target, $replaceBackup, $true)
    }
    finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force }
        if (Test-Path -LiteralPath $replaceBackup) { Remove-Item -LiteralPath $replaceBackup -Force }
    }
}

$packageResolved = (Resolve-Path -LiteralPath $PackageDir).Path
$gameResolved = (Resolve-Path -LiteralPath $GameDataDir).Path
$backupRootResolved = (Resolve-Path -LiteralPath $BackupRoot).Path
$expectedSuffix = [System.IO.Path]::Combine('Path of the Midnight Sun', 'resources', 'app', 'data')
if (-not $gameResolved.EndsWith($expectedSuffix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Unexpected game data directory: $gameResolved"
}

$manifestPath = Join-Path $packageResolved 'install_manifest.json'
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$files = @($manifest.files)
if ($files.Count -ne [int]$manifest.total_files -or $files.Count -le 0) { throw 'Package manifest file count mismatch.' }
if (@($files.filename | Sort-Object -Unique).Count -ne $files.Count) { throw 'Package manifest contains duplicate filenames.' }
if (($files | Measure-Object -Property choices -Sum).Sum -ne [int]$manifest.total_choices) { throw 'Package manifest choice count mismatch.' }

# Full preflight before any write.
foreach ($entry in $files) {
    $name = [string]$entry.filename
    if ([System.IO.Path]::GetFileName($name) -ne $name) { throw "Unsafe manifest filename: $name" }
    $source = Join-Path $packageResolved $name
    $target = Join-Path $gameResolved $name
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Package file missing: $name" }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw "Game file missing: $name" }
    if ((Get-Sha256 $source) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Package hash mismatch: $name" }
    if ((Get-Sha256 $target) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Live game hash changed: $name" }
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backupDir = Join-Path $backupRootResolved ("choice_retranslation_" + $stamp)
if (Test-Path -LiteralPath $backupDir) { throw "Backup directory already exists: $backupDir" }
New-Item -ItemType Directory -Path $backupDir | Out-Null
Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $backupDir 'patch_manifest.json')

foreach ($entry in $files) {
    $name = [string]$entry.filename
    $target = Join-Path $gameResolved $name
    $backup = Join-Path $backupDir $name
    [System.IO.File]::Copy($target, $backup, $false)
    if ((Get-Sha256 $backup) -ne ([string]$entry.current_sha256).ToUpperInvariant()) { throw "Backup verification failed: $name" }
}

$installed = New-Object System.Collections.Generic.List[string]
try {
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        Install-Atomic -Source (Join-Path $packageResolved $name) -Target (Join-Path $gameResolved $name) -ExpectedHash ([string]$entry.fixed_sha256).ToUpperInvariant()
        $installed.Add($name)
    }
    foreach ($entry in $files) {
        $name = [string]$entry.filename
        if ((Get-Sha256 (Join-Path $gameResolved $name)) -ne ([string]$entry.fixed_sha256).ToUpperInvariant()) { throw "Post-install verification failed: $name" }
    }
}
catch {
    $installError = $_.Exception.Message
    foreach ($name in $installed) {
        $entry = $files | Where-Object { $_.filename -eq $name } | Select-Object -First 1
        Install-Atomic -Source (Join-Path $backupDir $name) -Target (Join-Path $gameResolved $name) -ExpectedHash ([string]$entry.current_sha256).ToUpperInvariant()
    }
    throw "Installation rolled back: $installError"
}

$result = [ordered]@{
    status = 'installed'
    installed_at = (Get-Date).ToString('o')
    game_data_dir = $gameResolved
    package_dir = $packageResolved
    backup_dir = $backupDir
    files = $files.Count
    choices = [int]$manifest.total_choices
}
$result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $backupDir 'install_result.json') -Encoding UTF8
$result | ConvertTo-Json -Depth 5
