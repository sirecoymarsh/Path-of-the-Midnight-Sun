GS.dataCache['7CE3ED9B87416640DF9920F1DB28AE26E7A1'] = {
    "uid": "7CE3ED9B87416640DF9920F1DB28AE26E7A1",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-06b P1 Kalevala",
        "type": "vn.scene",
        "parentId": "BF6673F382B9F5436689DE4173653D6105A1",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 0,
        "localizableStrings": {
            "975E9752469F054C543BE2A64E87974EEFEA": {
                "t": "Umh... hello?",
                "d": {
                    "cid": 0,
                    "eid": "120D3E28805E2348FE4B8BB5302138C0344D"
                }
            },
            "FE5BEE4F37E6374B1D1BAAD0A789AF262026": {
                "t": "Quite peculiar it is indeed, oh valiant knight,\nthat once more you appear within my sight.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "DC7E80448854084CFF08BD8887BAFDC2A937"
                }
            },
            "375A92DB2A8FE54BC6780D42CB2C27EBF178": {
                "t": "How unexpected, to meet a brave warrior,\nlurking around in this gloomy corridor.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "0FF62DE55C7488432319177371FD3B9BE430"
                }
            },
            "2E20BFCB3CFD1240C328EAA170FB650A0906": {
                "t": "Kalevala is my name. Pray, what is yours?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "E93A0C043D19C34DBC6903D64443DFA9B31C"
                }
            },
            "07847DFB3861D1433658C935F4F5C511CADA": {
                "t": "I'm Sir {LT:1} Ornières, captain of the Holy Swords of Pylum. Nice to meet you.",
                "d": {
                    "cid": 0,
                    "eid": "93B0C2E906B365437A7B2044512FDAD949E4"
                }
            },
            "EFEBD8965623274043684632E9098B35E203": {
                "t": "Poetry aside, what are you doing here? It's not exactly the place where I'd be expecting to see a bard.",
                "d": {
                    "cid": 0,
                    "eid": "4C25F3C024F3494A081AF061E8B8DA797BCD"
                }
            },
            "8E32C70A0ECA50404B090DD3E2C7C7A3FF62": {
                "t": "To make the unexpected expected,\nsuch is the task by me conducted.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "4CFB4CBC6CDCF340698B3462583011570641"
                }
            },
            "50A3709514AB8143475A3D8539E34B0806B1": {
                "t": "In other words, I've been following your group for a while now. I'm interested in the Vassal.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "FAD4BEDC1762D4465719183413422E32605A"
                }
            },
            "B875C9D84AF7A3455C7A4D6500D0BE825417": {
                "t": "Stalking isn't nice, you know.",
                "d": {
                    "eid": "F84100B464299644C469C468043F4B4B43D3"
                }
            },
            "A0DFBA3F8B8C334736688FD93AD4FE6E3AD3": {
                "t": "You're \"interested\" in Lady Faratras?",
                "d": {
                    "eid": "55386DFA8D62264B959A66370287421BD04F"
                }
            },
            "BFE3819E7FAE57486F2A4587F7423A9F77B4": {
                "t": "Oh, worry not. It's not my style to lurk in the shadows, nor to cause you any discomfort.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "C4C5A53097D0C04D9D28763488E6FE455047"
                }
            },
            "29B0EC1C8F6244427739F9451BCD4B8F0037": {
                "t": "Oh, no need to be on your guard. I bear her no ill intention, you have my word.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "E5A62ED24E505242968BEE3832A12B5CD305"
                }
            },
            "7B359EC7499D87405B3A4ED5892A66650221": {
                "t": "I just want to help you find the truth about the Demon King, that's all.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "D53824285223F24CAE4A9A55C9327A5AF4BF"
                }
            },
            "F4E68B494A62584E3F1BB2E7FF937E9C6818": {
                "t": "Kalevala... Do you know of anything that you should tell us?",
                "d": {
                    "cid": 0,
                    "eid": "515BAEC61103F94F410ADD980395FF8D4954"
                }
            },
            "AAF722734274774DB54B65B79915FFDE86DE": {
                "t": "What the truth is, I simply cannot tell.\nThat would be a story I just couldn't sell.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "B33E46A71192354E336BBE64F7C237BDC126"
                }
            },
            "2BC86AE94C5BD842FA2AB72392AB44647C4F": {
                "t": "Help me find some clues, if you may,\nand nothing else I'll need to say.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "AE320F4C37213144243A4A636CEDE435A8FB"
                }
            },
            "8CF8FA4B37E9174AAC0B730787C406C8CB18": {
                "t": "Woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "703F73417962824DBD3B4C64B7D112BF608C"
                }
            },
            "8F3FFBB154F98140167915D64387203E3E5A": {
                "t": "You're a strange one, but my dog likes you. So, I won't insist you explain yourself further.",
                "d": {
                    "cid": 0,
                    "eid": "726F4BE877B51943965976C56D05194D19E4"
                }
            },
            "F46599475E265849E49AE9E17852A7DC2942": {
                "t": "Your words are utmost peculiar. With that sort of reasoning I'm not familiar.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "3441981142FEC14081697FC4C746EAA3C4BB"
                }
            },
            "C482DF6358BB4649CB190E13F6B4F59121F2": {
                "t": "... Anyway, if I understand correctly, you want me to search for clues in this fort.",
                "d": {
                    "cid": 0,
                    "eid": "D361E32B218DF544F46BE894B524CB644897"
                }
            },
            "AEB6BA5761B6954D6F8AA483BD61B28A7F4F": {
                "t": "Correct, dear knight. And be careful, as this might be your only chance to grasp the full truth of this story.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "B0F70F080EBF1345E978B3F23CAC036CD6C8"
                }
            },
            "078566C61E004341A01BD9E14B3861072328": {
                "t": "\"Three clues are scattered in this booth,\ncare to search for them for the sake of truth?\"\n- Kalevala",
                "d": {
                    "eid": "66698AAF8A8BD7464D28DB060FA432E76D70"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 7",
                        "index": 166,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B04D6817238D594A857AA269603B16B084CC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if quest is completed"
                },
                "indent": 1,
                "uid": "FE826BC978D128496B0ABAB214FC24F7049E",
                "expanded": true
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "E1E7283E79363746C878E2164E1505E6404B",
                        "name": "C6-06b P1 Alt - quest completed"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5625E2E961BBA7459579998755644ACF3EAB"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of quest complete",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "29B9D1FD8A1BF848993B1D37A1F131946A7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7ABDCF497CBAF54A176B6D3198C52BDF0247"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DD0F1ED23290E845F8290AE01A1D94EEED4D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "6770EB6A1E29A5497049126865E307FBBFE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5E216D82AF43345483B68F4DE0B84664501"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "975E9752469F054C543BE2A64E87974EEFEA",
                        "defaultText": "음... 안녕하세요?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "120D3E28805E2348FE4B8BB5302138C0344D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B838CCA4DABF24EA9098648BE4FBB7242BB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Note for Ashley: as usual, feel free to change the poetic sentences of Kalevala. I'm not that good with English poetry."
                },
                "indent": 0,
                "uid": "D9B2678B271EE548720A8D2528D0A90E5585",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "Kalevala's affection",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "784D42495951864E7159FDF87D9275D9CE3F"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "Nini's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BE854BB78E99824C8908A231F970966E3BA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A466F2400B2264AF74B3D48DD8AFE69A682"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C60A490390AB4048E0094069E8E90F1FCD8E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Kalevala's affection",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F0B12311585027424759DC45A4FF74F508FB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if > 0, you already talked to him in Viborera. Otherwise, you ignored him before."
                },
                "indent": 1,
                "uid": "41AC7B477373F34DB42939F49E2041435D8F",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE5BEE4F37E6374B1D1BAAD0A789AF262026",
                        "defaultText": "참으로 기묘하구려, 용맹한 기사여,\n그대가 다시 내 눈앞에 나타나다니."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DC7E80448854084CFF08BD8887BAFDC2A937",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9733FB6F1F055943232AD4A24D7AA0241309"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "21D25F0843BB114C798BB3B734B1D2716010"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "375A92DB2A8FE54BC6780D42CB2C27EBF178",
                        "defaultText": "용감한 전사를 여기서 마주칠 줄이야,\n이 음침한 복도를 서성이다니 놀랍구려."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0FF62DE55C7488432319177371FD3B9BE430",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A48CE2417E543340DE0821554D5E65635332"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E20BFCB3CFD1240C328EAA170FB650A0906",
                        "defaultText": "내 이름은 칼레발라. 그대의 이름은 무엇이오?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E93A0C043D19C34DBC6903D64443DFA9B31C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9838BE2025D092463069C743627E469AC96D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B19669F530C0E94A353AEFA264970DCC95A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07847DFB3861D1433658C935F4F5C511CADA",
                        "defaultText": "저는 파일럼 성검단 단장, {LT:1} 오르니에르 경입니다.\n반갑습니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "93B0C2E906B365437A7B2044512FDAD949E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B75C0A92F756546E00895C5564DCC1018CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EFEBD8965623274043684632E9098B35E203",
                        "defaultText": "시 얘기는 제쳐 두고, 여기서 뭐 하십니까?\n음유시인이 있을 만한 곳은 아닌데요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4C25F3C024F3494A081AF061E8B8DA797BCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24C07C60346CD5461718B89717D2F64681BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AF50AAE3512924C9D887C448810723CF8B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E32C70A0ECA50404B090DD3E2C7C7A3FF62",
                        "defaultText": "예상을 예상으로 바꾸는 것,\n그것이 내가 행하는 일이오."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4CFB4CBC6CDCF340698B3462583011570641",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EC733B75B0E744F913A6D12F395E0AD6FF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA21ED6C47F434444B1AF301AA10E4642329"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2A0D4256BC7764434782535C7B03E72CF9B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50A3709514AB8143475A3D8539E34B0806B1",
                        "defaultText": "즉, 한동안 그대 일행을 따라왔소.\n그릇에게 관심이 있거든."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FAD4BEDC1762D4465719183413422E32605A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "77DDB193759DA84B445937E584FE897CA5FE"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B875C9D84AF7A3455C7A4D6500D0BE825417",
                        "defaultText": "남을 몰래 뒤쫓는 건 좋은 일이 아닙니다."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F84100B464299644C469C468043F4B4B43D3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A0DFBA3F8B8C334736688FD93AD4FE6E3AD3",
                        "defaultText": "파라트라스 님에게 \"관심\"이 있다고요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "55386DFA8D62264B959A66370287421BD04F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "stalking",
                            "faratras",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D567A7D866A6814DBD5B8852498EEF834ED9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5FFD2852281F6546693B71B31EAAAA2BC250"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "stalking"
                },
                "indent": 0,
                "uid": "6F0A87882CA7A34043988C646E1866672721"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA48F3A95A7503462D7AE0E849B3A2F6EBCF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BFE3819E7FAE57486F2A4587F7423A9F77B4",
                        "defaultText": "걱정 마시오. 어둠 속에 숨거나\n그대들을 불편하게 하는 건 내 방식이 아니오."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C4C5A53097D0C04D9D28763488E6FE455047",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9B3898C18F2EF8478A894F75DA914B870FA6"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "faratras"
                },
                "indent": 0,
                "uid": "40F03130167B0745BF484803BAB34CD63EE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6065E0F616A40417D5A24A76123139FB2D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29B0EC1C8F6244427739F9451BCD4B8F0037",
                        "defaultText": "경계할 필요 없소. 그분을 해칠 뜻은 없다고 맹세하오."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E5A62ED24E505242968BEE3832A12B5CD305",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "B9492C9847D1C744732AE57217A21B9742E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B772FCB105C0043AB5A6758D7D307E9BEFB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B359EC7499D87405B3A4ED5892A66650221",
                        "defaultText": "마왕에 관한 진실을 찾는 걸 돕고 싶을 뿐이오."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D53824285223F24CAE4A9A55C9327A5AF4BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF1AA59C82C4D24A11693A97AC642E8C3462"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4589FC246357D546512907A7411D6BD20579"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4E68B494A62584E3F1BB2E7FF937E9C6818",
                        "defaultText": "칼레발라... 우리에게 알려야 할 걸 알고 있습니까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "515BAEC61103F94F410ADD980395FF8D4954",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23099E735F966147A288296944F0933E5B1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23B17C5A4C096540741A241480BF6F65997C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54216250273D0242111915C992692ED395EF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAF722734274774DB54B65B79915FFDE86DE",
                        "defaultText": "진실이 무엇인지는 도저히 말할 수 없소.\n그건 팔 수 없는 이야기일 테니까."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B33E46A71192354E336BBE64F7C237BDC126",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C664C1042B7E54D088AE946EF4FD593F7AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2BC86AE94C5BD842FA2AB72392AB44647C4F",
                        "defaultText": "단서를 찾는 일을 도와주시오,\n그러면 더 말할 필요도 없으리라."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE320F4C37213144243A4A636CEDE435A8FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1B05C0F82CA824DF289D0F50D13D9BD7C0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F40B5D96EEE8846D06BB7974DB41F83F5EB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "A043BD852C7AE24EA66B7D37CEB8C18AFE7E"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Quest text",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "078566C61E004341A01BD9E14B3861072328",
                        "defaultText": "\"이 부스에는 세 가지 단서가 흩어져 있습니다. 진실을 위해 그것들을\n찾아보실래요?\"- 칼레발라"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "66698AAF8A8BD7464D28DB060FA432E76D70",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EA3235C38988B64A6019D6B33077DC66B0C0",
                    "parameters": {
                        "values": [
                            1,
                            "The bard's riddle",
                            {
                                "name": "Quest text",
                                "index": 1,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            6000,
                            3850,
                            "462E2AE2781EB74A602B4633098D0AF27133"
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE592D021BB97849B7581AB31E15C43F8840"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0C219E9C37417042B158B2D8826E7BA5D6FF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6A2E15E175BDE34EBC5913715D9583660F68"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7AB23B582F8DF949E66A81574A2AF5C9E836"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4F0A9343A27E2464B6B15E55B275C940D42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7928E2194AE891401A6879836940E980FC2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8FDF957232DC045D388C0C5FB82529ADA78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8CF8FA4B37E9174AAC0B730787C406C8CB18",
                        "defaultText": "우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "703F73417962824DBD3B4C64B7D112BF608C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22F922A4783A4046214B9FC87FB9BED3F047"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9206BAD95BC3F4458B298181711E1090B29D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F3FFBB154F98140167915D64387203E3E5A",
                        "defaultText": "당신은 이상하지만 내 개가 좋아하네요.\n그러니 더 설명하라고 강요하지 않겠습니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "726F4BE877B51943965976C56D05194D19E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88DE59607B3E51433198067318F1081C61C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BB57E1712A9B34916294B753FCB207446CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8284B624343F544A73197787C71CC63D698C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F46599475E265849E49AE9E17852A7DC2942",
                        "defaultText": "그대의 말은 참으로 기묘하구려.\n그런 논리는 내게도 생소하오."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3441981142FEC14081697FC4C746EAA3C4BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19B6328E6D23D249AF69B2F5EEAC163BAC88"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "BEC887D6344F594342495791A078AA76F5EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB636D1963BEF0469A8A18C75C93FE81FCF6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C482DF6358BB4649CB190E13F6B4F59121F2",
                        "defaultText": "...아무튼, 제대로 이해했다면\n이 요새에서 단서를 찾으라는 거군요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D361E32B218DF544F46BE894B524CB644897",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2A854DD9D5DD24216482D51934A28F35AC8"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AACE2CB55185F44CDC2985964985F0963321"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0493FA5B42F0B349EC1A4B183B05190629E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E4EBB76830BA6494729023808F93C4DA420"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F22E2DFF7AD2A746623BECC891E23C87161E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AEB6BA5761B6954D6F8AA483BD61B28A7F4F",
                        "defaultText": "그렇소, 친애하는 기사여. 조심하시오.\n이 이야기의 온전한 진실을 붙잡을\n유일한 기회일지도 모르니."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B0F70F080EBF1345E978B3F23CAC036CD6C8",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of dialogue"
                },
                "indent": 0,
                "uid": "6778054F89F9044F18587B623DCD40C3FF93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F95AEA4371D5D2426A49E567D026B17B2D94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE765CE74D47A1441D484BE26E9844B61DA7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "34067D962A20A34AC01A6576CFA5930FBDAC"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "09800D8875167742534B6097210086FB6990"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1FFDDBB957F9224BAF18F6D2600C56226B3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Stronghold Dungeon"
                        ]
                    }
                },
                "indent": 1,
                "uid": "39984DB9675D47400C5BDC41848B00CB9E07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "BB91BB3653B361417E8AA662361D761B97D8"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of quest complete"
                },
                "indent": 0,
                "uid": "F23049C7232964404C79DA22AE8595AC0983"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "Kalevala's affection",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "Nini's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Quest text",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}