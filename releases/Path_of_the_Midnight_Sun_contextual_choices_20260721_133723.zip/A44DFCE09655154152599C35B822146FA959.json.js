GS.dataCache['A44DFCE09655154152599C35B822146FA959'] = {
    "uid": "A44DFCE09655154152599C35B822146FA959",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C1-03c Landing scene - sit at the table",
        "type": "vn.scene",
        "parentId": "F7F581B17D00D5435868B5C374116B4EBEE3",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 5,
        "livePreviewDisabled": true,
        "localizableStrings": {
            "1DC2EFAF6219A44DB5798AE517380B54388B": {
                "t": "Woot!{W:200} Wooot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "4833177554EC984B395AF439785B2D79FFB3"
                }
            },
            "9A2C94356BCD964F937964460AA36D204D47": {
                "t": "Be a good boy, you!{W:200} I don't think it's a good idea to show off--",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "6F837DCE38CD934D3818B073F33191660583"
                }
            },
            "A281E6318422564B547A97C5A531C2285B3B": {
                "t": "Precisely. {W:100}Now we have everyone's eyes on us...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "44420FA94948164FE09A3A302526550AA6F8"
                }
            },
            "EBB016575DACB043923A7F764D2DE5E9DD86": {
                "t": "AH...{W:150} AH...{W:150} hic!{W:200} Isn't that... a raaaare specimen of luckos?",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "41C92FEF7C0B6844028952E36CC573F8A103"
                }
            },
            "18E0C325162772449F5A69524427300217AE": {
                "t": "Hey... {W:150}It's true! It's a luckos!{W:100}\nLook at those accessories!",
                "d": {
                    "cid": "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                    "eid": "79211F550C00164D8B595E35487CF37D77EC"
                }
            },
            "C47C828F21C8214FC64A3933E702FCC817BF": {
                "t": "Nini...{W:200} I can sense the malice growing around us.{W:100} We need to do something, and soon.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9A5BACD40B035741AC291334AE5EBEA1AA93"
                }
            },
            "F50AC1046DA0074B907B3974995304804EBE": {
                "t": "Time for some sarcasm!",
                "d": {
                    "eid": "437A297F2EC8A546B77A9242DF0C8DC3D10E"
                }
            },
            "B26F990C2982D2468688FA253A615D021DEA": {
                "t": "Violence is always the answer.",
                "d": {
                    "eid": "F29A14041C7BF844E708D1C639F06F19C551"
                }
            },
            "ADE7819849E62346F43B95557E7D66A29853": {
                "t": "Let me handle this with diplomacy.",
                "d": {
                    "eid": "4B312CC081CDF14C0B78AA6869B1A24F1133"
                }
            },
            "1DA0D20020D3D64AB459A298466A88BD8CF4": {
                "t": "Gentlemen,{W:200} we're all very tired and eager to party.",
                "d": {
                    "cid": 0,
                    "eid": "F7E14548536D4247A388301728D82188D609"
                }
            },
            "060C8FA565A53342572B8C058331A399C7C6": {
                "t": "Why should we spoil this beautiful evening by dyeing our tables of red?",
                "d": {
                    "cid": 0,
                    "eid": "4EB7FD208280374A665AE1E3D8FCAB11D7BB"
                }
            },
            "83BD92F45D689543756937769AADAB3D2B1E": {
                "t": "You scum... {W:200}Hic! {W:100}I'm gonna break yer face... {W:150}HAHA!",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "BFDFF467363A3949B53BCD81072BDDD4E304"
                }
            },
            "F26EC325172DB043BD8B188050B921038E70": {
                "t": "Please, don't be like that. {W:200}I think we can get along, just calm down for a second...",
                "d": {
                    "cid": 0,
                    "eid": "5B3D3C4E1717B24AC3987F48F7B25B8DE8E4"
                }
            },
            "3F889B7966186545DD4B8AC90F7DFF843F19": {
                "t": "...and your next drink is offered by me.",
                "d": {
                    "cid": 0,
                    "eid": "2A9B75F258C7634AFF4A9D428CD5CBFA974D"
                }
            },
            "AC21EC847BB9734299082145D1CE4BF05A6A": {
                "t": "W-{W:150}Wooot!?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "24841A688F43C644373937B38F5D5A904F14"
                }
            },
            "20658880687B6849952A4808F7AFCBE5C50D": {
                "t": "Pssst... {W:150}I know we don't have much Gold, but I'm trying to save you here! {W:200}Give me a break!",
                "d": {
                    "cid": 0,
                    "eid": "315D475B5E9C9240F949BC5754AA9B5BD27D"
                }
            },
            "CAA7289442AB834AA98BA7269B50195008A5": {
                "t": "... ... ...",
                "d": {
                    "cid": "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                    "eid": "DB820A7612567441137991847AD25C8E2573"
                }
            },
            "E8C8B3EE8939E242E0593397F34CE0E2A9FA": {
                "t": "Pah...!{W:200} Ya can live for now...{W:100} But watch yer back, HA! HA!{W:150} Hic.",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "EA80A4AC532D114D884AF5201394880D3AF1"
                }
            },
            "540F4C912A7B0647A2993BE0AEEF56579769": {
                "t": "... Did it really work? {W:150}Phew.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "13C95E497F99684DB6794429FDB31AAA51E3"
                }
            },
            "2CE1986C61AE3743106B60A78D20DCEFC819": {
                "t": "We've been lucky Nini... {W:150}but I can't say I approve of your way of handling things.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0BC0D7B82DFD944EDE1A81083A51C4CF9315"
                }
            },
            "0C45657424C8D14DA87A0A480A29A251FCF2": {
                "t": "We've been lucky Nini...{W:150} and you handled the situation skillfully!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "243236C862DF6443962BC5816CAF9E36B1EA"
                }
            },
            "CF9ACB0521F95545510B2FA6238744C1897D": {
                "t": "You sure? {W:100}Well, we got away with it, at least for now.{W:200} That's all that matters.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "F499F2503EF3C649655B4876E1BE659BBE4E"
                }
            },
            "E7326CF77B852147428BC7A2AE87DC08EED3": {
                "t": "That stuff must be so good that you're hallucinating things now, huh?",
                "d": {
                    "cid": 0,
                    "eid": "05B603851434624ABF89F2F08E038BD8D00F"
                }
            },
            "3BC22F4821FA544E0208B539D9D6055BF453": {
                "t": "Whaaaaddya say?",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "82AC83115254A14F1F79AAD67F1C2EC5C0A0"
                }
            },
            "3D1EE45F11D3054B0B88B4281295DDAE703B": {
                "t": "Umh...{W:150} Nini?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A48D11283CCBA04EBA399D515FE9CF12D0C0"
                }
            },
            "4A8214E44AF4464D6748BD72210656984785": {
                "t": "C'mon, I'll let you pet my baby shepherd here too, if you want.",
                "d": {
                    "cid": 0,
                    "eid": "24FF21737570824CE01B9D2680EDE15479B7"
                }
            },
            "9B18E1697A3C984EBB896BE02B5681F894E0": {
                "t": "I wish it was a luckos!{W:100} I would be dipping my toe in gold at this point!",
                "d": {
                    "cid": 0,
                    "eid": "7188ED642CB6334DFA69FE24134628040248"
                }
            },
            "0E24307144EDC649EC29E59350ACC21B57A1": {
                "t": "Could it be... {W:200}am I seeing things...? {W:150}Hic.",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "43272A737DE1B342C07B3C30C0DDF8B46E7F"
                }
            },
            "5CEEE8C12226974EA2795BE1FAA6BFE4C920": {
                "t": "Pssst...{W:150} C'mon little one, help me out!",
                "d": {
                    "cid": 0,
                    "eid": "EF5E9703727691422F98F3A3EC65B983FC1D"
                }
            },
            "F8D82B5139A757474A78CE74B91DC68A4BAF": {
                "t": "... ... ...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F8FF9EB58D3890485F0B938406B045F13430"
                }
            },
            "F2F6DF365DD0324D5218E7A1BA20A3A689F8": {
                "t": "WOO...{W:150}F! {W:200}WOO...{W:150}F!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "78A8621C8BC9314B058B230289C874717980"
                }
            },
            "F7F476194989D248A28861C6A2E78F1F258B": {
                "t": "That must have taken a huge effort!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "438AF2984E071647546A28371F6DEA97152D"
                }
            },
            "7F68C56E76F94443C97A33844498BC9A462E": {
                "t": "My life's a lie...{W:200} HAHA...{W:100} HA.{W:200}\nHow tragic...{W:150} and funny.",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "6AE7926D9D80664FBB69D1F880DF597B9574"
                }
            },
            "71A175269214454ED72BDDD9BF8FF89394BC": {
                "t": "And what can a fat drunkard even do, huh?",
                "d": {
                    "cid": 0,
                    "eid": "4C4401706229854DC98BFB067EB249854DCD"
                }
            },
            "34F59FFA4660854627290AF30B06009FA060": {
                "t": "W-What!?",
                "d": {
                    "cid": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "eid": "78C95C1164B3114C4C6947E10EA731C4B2B0"
                }
            },
            "E885F98E6F6AF9496449B7E4A24640717AC4": {
                "t": "N-Nini...?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0BBBC3C93A91A34FC69B8D4350542C3931A8"
                }
            },
            "85A6C53369D72347942872E52EA02F789F32": {
                "t": "Do you think you can beat a trained soldier in your state?",
                "d": {
                    "cid": 0,
                    "eid": "A487DD360E7CA74A8389C223BAFC411C6D4E"
                }
            },
            "FC2CCEDB01202849CD19CE13A398BE735CAD": {
                "t": "Bring it on. {W:200}But you might soil yourself with a different red than the wine you guzzle.",
                "d": {
                    "cid": 0,
                    "eid": "0C6457893DB80049B389BA31DCB77352523E"
                }
            },
            "B727EA5F9696B543B7287FC8EABFDFFFB516": {
                "t": "Woot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "250C6E827ED3C14B90484642E8081482C189"
                }
            },
            "29AD0BF763D8C64479185A75252C5068B47D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9FF73E48085D684B3F79DD89D519EC8BEFD0"
                }
            },
            "6961797828C365414409F03795F34FE84B90": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D2038A8680351341208904790E4E42A8814F"
                }
            },
            "4A5FC25F3B012448571BC893AEB637052D7A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BB3BBD313640414250599B04214DA8284D49"
                }
            },
            "D2A5E9ED6D18014D6268A82065AA3033B950": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2CD6491109BED8433099E73239AE280D5B0A"
                }
            },
            "D749B37F2B3EA147013BB33628E30B1AB8E7": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B6C22C30788883485988F739798E4A98C2F2"
                }
            },
            "4E600A2D3E56A54B0B3AB9940DB33FF56F27": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EB4E41BE80F83748EC78D525A7141DBA03F6"
                }
            },
            "BF55769753EF1849957B98A2435E3FF96B54": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1889AA6C8D243745D23B7A12E665C7B1F554"
                }
            },
            "19B0BABA165A5647BB7A8B313AD5E601C49D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9911BED59D0371433B6A52511D7C64AD18F5"
                }
            },
            "B86A273C869B8145AC4ABDB583053428FEB3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4A40ECDF36BDF74D019A0782ABEE60F4CEDF"
                }
            },
            "7C0F186506F19048A1380486A1C4831B87A4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BE5B51C36A0B074A257B7434993D8EFEB15F"
                }
            },
            "8E4815031CCD35469E1AADC142A88AC26573": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2CB67B505919094D3749D23206C94127345E"
                }
            },
            "06DF5D6B51E9D3458979B4835AEF77836DDD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "0F9656945513024B8919BE5866907635EEA2"
                }
            },
            "D6A515DD9F8FF84CD8681732AC856046926D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "FCE77FAF3683D345075959D6486241CE7A45"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D927C350174351454A795C74B37ECCCF134D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9E2AE66A5E90394AE67B31C1E0B10DE51A56",
                    "parameters": {
                        "values": [
                            15
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1415601959CB340A23879444DEA5E1A6D31"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8F2170957BBF774F721BEF8149FFEBE62918"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Skip scena Luckos",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "4BD13A3266A3924A99283310080405F506EA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "ECCAE7F3300B534C406AEF43E4C156D5D5E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B0AC8DD53CE67549F03A2348402BB9519C11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FFD0107198D954950583A4584AC05841B5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33E2F54D0BED534BF568D6C33CAB5046AC60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4AB461EC7EB74742497B64C21EDEE8DE2AE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29AD0BF763D8C64479185A75252C5068B47D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9FF73E48085D684B3F79DD89D519EC8BEFD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D3DB4F173E8124B637962E7F39958CBBF56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FDFBD093F8F164A3A4B8B047B9485D09417"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DC2EFAF6219A44DB5798AE517380B54388B",
                        "defaultText": "우웃!{W:200} 우우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4833177554EC984B395AF439785B2D79FFB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BDEEC398766144C786BAE35C77C7A286CC2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "07442F0243A2494750694336D8F85D4ACA86"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6961797828C365414409F03795F34FE84B90",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D2038A8680351341208904790E4E42A8814F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DF4BB8D24399C9402D5AF272504885EED627"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBF96566715B7341502B57A09731CDB35BD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A2C94356BCD964F937964460AA36D204D47",
                        "defaultText": "얌전히 있어!{W:200} 눈에 띄는 건 좋은 생각이 아닌 것 같--"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F837DCE38CD934D3818B073F33191660583",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "508B994602E9174FAD68433368058CCD647B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "9483CE2A8D94C64E314A9613A0E971CB06F2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "6DB0E12B078B524946386D977D02D1C1ECD0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E39003467418D548EA0867762BE7DE979DC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A281E6318422564B547A97C5A531C2285B3B",
                        "defaultText": "그러게. {W:100}이제 모두가 우리를 쳐다보잖아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "44420FA94948164FE09A3A302526550AA6F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ADC4E0062DA1848809B73E69B02A0CC1E33"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "604093E45F174740FD1918361B30B844D94E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14E421E4286241457989E9074E474C1A49B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C41A70DE432CE14C2D7852B59E464DF8DB5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E5E7B3F65B560744E589AAD6FF9E0C45A9FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A5FC25F3B012448571BC893AEB637052D7A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BB3BBD313640414250599B04214DA8284D49",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "88EF02A779890546D81807F8D3BF697CDB53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C065845E0BEE1343BB5AAD45D1A79879F231"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EBB016575DACB043923A7F764D2DE5E9DD86",
                        "defaultText": "아...{W:150} 아...{W:150} 딸꾹!{W:200} 저건... 아주 희귀한 루코스 아닌가?"
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "41C92FEF7C0B6844028952E36CC573F8A103",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA8C4C4E786A984AD85B2243E6E1B60DC4EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48AABC2D89C44747FE6A44D43D3A578FB88B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18E0C325162772449F5A69524427300217AE",
                        "defaultText": "이봐... {W:150}정말이야! 루코스잖아!{W:100}\n저 장식들을 봐!"
                    },
                    "position": 0,
                    "characterId": "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79211F550C00164D8B595E35487CF37D77EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAA82FEC6752B54DC5387802AD0FE8B38C30"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "1535848A5469E345AF6A3E4278536220E8D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            750,
                            0,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58F5772902C3B24AB92B20C8100517E303C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            1,
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C3F8CCF070102464D284D03AD79AFEAAB08"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "1B9F92F13638324ADB8AD6A89E58F361EA6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85A2BA7A652E684EAA5B8D679F6C1BDE8A91"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C47C828F21C8214FC64A3933E702FCC817BF",
                        "defaultText": "니니...{W:200} 주위에서 악의가 커지는 게 느껴져.{W:100} 어서 손을 써야 해."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A5BACD40B035741AC291334AE5EBEA1AA93",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E453310172B821456E284806CC6AD26139EA"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F50AC1046DA0074B907B3974995304804EBE",
                        "defaultText": "비꼬아 줄 시간이군!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "437A297F2EC8A546B77A9242DF0C8DC3D10E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B26F990C2982D2468688FA253A615D021DEA",
                        "defaultText": "역시 폭력이 답이지."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F29A14041C7BF844E708D1C639F06F19C551",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "ADE7819849E62346F43B95557E7D66A29853",
                        "defaultText": "내가 외교로 해결해 볼게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4B312CC081CDF14C0B78AA6869B1A24F1133",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "sarcasmo",
                            "violenza",
                            "diplomazia",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "746A7CEE03BA4840B6792B25397166E7A729"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "823009FB3838484EA478FEB57D13C44C14B9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sarcasmo"
                },
                "indent": 0,
                "uid": "889D3C7C2CA6D646ED5A76D391BF9DE12183"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94598EC08F8657474949E0229FB8B6A17D47"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7326CF77B852147428BC7A2AE87DC08EED3",
                        "defaultText": "그 술이 얼마나 좋으면 이제 헛것까지 보이는 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "05B603851434624ABF89F2F08E038BD8D00F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78D7FD671AD8C24C8A48B734E1870F85BC81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "52884D8D6BFBB4495838AFB48C5077A6D533"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D2A5E9ED6D18014D6268A82065AA3033B950",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2CD6491109BED8433099E73239AE280D5B0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6221613269822544A24B7F25ECEB4A43F5EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF657E0C5BC89442B8583A737E0C5310CF8E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BC22F4821FA544E0208B539D9D6055BF453",
                        "defaultText": "어떠어어냐고?"
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "82AC83115254A14F1F79AAD67F1C2EC5C0A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D9E491218ED984C6459FFE52D01508A817A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7504FA215732C242C5489BC61CA34C002A88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D96860F670937447E65BE046F27078EADFC8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D1EE45F11D3054B0B88B4281295DDAE703B",
                        "defaultText": "음...{W:150} 니니?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A48D11283CCBA04EBA399D515FE9CF12D0C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "560847595D1D774D396AB4A282104C563B72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E79B26B17081314EB55B98699CBFD3C2C3A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A8214E44AF4464D6748BD72210656984785",
                        "defaultText": "이봐, 원한다면 내 귀여운 양치기개도 쓰다듬게 해 줄게."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "24FF21737570824CE01B9D2680EDE15479B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09BE769A3EE2024D718A6DB2780639440571"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B18E1697A3C984EBB896BE02B5681F894E0",
                        "defaultText": "루코스였으면 좋겠어!{W:100} 그랬다면 지금쯤 골드에 발을 담그고 있을 텐데!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7188ED642CB6334DFA69FE24134628040248",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C42E7FE43B208240EA7B70E6BB1F027D18B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2F7A0B6B207C06439A59CD111F5F320C2DDC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D749B37F2B3EA147013BB33628E30B1AB8E7",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line7_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B6C22C30788883485988F739798E4A98C2F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CFF89CB188D6B447407AF133A846574ABC2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B98F1B2F1DBE004A61689D1506C9E1ADE05A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E24307144EDC649EC29E59350ACC21B57A1",
                        "defaultText": "설마... {W:200}내가 헛것을 보나...? {W:150}딸꾹."
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43272A737DE1B342C07B3C30C0DDF8B46E7F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7985338421024642255889A414BED257A132"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C389957D3E0EC0443B0A7F6017F2AF4BDEFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5CEEE8C12226974EA2795BE1FAA6BFE4C920",
                        "defaultText": "쉿...{W:150} 어서, 꼬마야. 나 좀 도와줘!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF5E9703727691422F98F3A3EC65B983FC1D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AADAC932CA2E44ECD1AA0550A1E4E9D5863"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D190CDEF63A5124FAA48ECB5087212702CD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F8D82B5139A757474A78CE74B91DC68A4BAF",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F8FF9EB58D3890485F0B938406B045F13430",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2973607366FA734F09899D13470D924BA332"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D53001887C4D774C9C1A67616067F40E3B81"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E600A2D3E56A54B0B3AB9940DB33FF56F27",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_GROWL_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB4E41BE80F83748EC78D525A7141DBA03F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AE1227CF3815A74B3D0980F8371EED4383D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5809855A6EF7694A0B3BB7C7A82C252ED835"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "009C5736848FC14C5868121508E2DFF78F58"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2F6DF365DD0324D5218E7A1BA20A3A689F8",
                        "defaultText": "우우...{W:150}프! {W:200}우우...{W:150}프!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "78A8621C8BC9314B058B230289C874717980",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2E444DB2E9A84409849A571132442FBD0B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01A2974D4FA3C44B4878BFD4BC809C1A24E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7F476194989D248A28861C6A2E78F1F258B",
                        "defaultText": "정말 엄청나게 애썼구나!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "438AF2984E071647546A28371F6DEA97152D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7E69FD50FD8F743949B8BA6DB6C308E92F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8FC31BC8CB5E9420B5A06838E196E3DEA45"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8179F2F11F992141D94936D2D4E11F2E8737"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF55769753EF1849957B98A2435E3FF96B54",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line6_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1889AA6C8D243745D23B7A12E665C7B1F554",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6DF02151996A1244FE2B0C25C0B73C063757"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "202053B34805074C6D6907A5B43B18DA2388"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F68C56E76F94443C97A33844498BC9A462E",
                        "defaultText": "내 인생은 거짓이었어...{W:200} 하하...{W:100} 하.{W:200}\n얼마나 비극적이고...{W:150} 웃긴지."
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6AE7926D9D80664FBB69D1F880DF597B9574",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A1289597F54E24DD22AEDB3EB91FD7C3741"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07E06ED724A928453769104459C53AC4B7EF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "fine scenetta",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "529098FE5D033446364BE4F49CF31E7E92AE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "violenza"
                },
                "indent": 0,
                "uid": "58163C7664E6D147370B447857D6B51453F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFBF67893B16D3439C8A9914D0C645BDA388"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "71A175269214454ED72BDDD9BF8FF89394BC",
                        "defaultText": "그래서 뚱뚱한 주정뱅이가 뭘 할 수 있는데?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4C4401706229854DC98BFB067EB249854DCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD0253E6307EB148B74BF3082551C5F045F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D44E45E37FD7624068291D5559031ED4E264"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "19B0BABA165A5647BB7A8B313AD5E601C49D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line7_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9911BED59D0371433B6A52511D7C64AD18F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3BB1747C72E8F648761BC3F9ADB47F3283FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "303F33B02BFCF64CD74B02D288DE90D3FCC0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "34F59FFA4660854627290AF30B06009FA060",
                        "defaultText": "뭐, 뭐라고!?"
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "78C95C1164B3114C4C6947E10EA731C4B2B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "175B43039827F1414F08A917A1E5C52BEFBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82FCCF2269AED7489268EF962ED34B30655E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E4C755C37994C346505BB977962ECC74D718"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B86A273C869B8145AC4ABDB583053428FEB3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C0.1-01_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A40ECDF36BDF74D019A0782ABEE60F4CEDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "105AB8963FB7344AE7680978F9913BB6166B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CE1A1FA3C3474476F185797D1F533B7AADB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E885F98E6F6AF9496449B7E4A24640717AC4",
                        "defaultText": "니, 니니...?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BBBC3C93A91A34FC69B8D4350542C3931A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE130E0A3870704CD879F9F85A795463B3E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "841600F277E8E54DAA3B6D23EA1C79EEEB38"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85A6C53369D72347942872E52EA02F789F32",
                        "defaultText": "그 꼴로 훈련받은 병사를 이길 수 있을 것 같아?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A487DD360E7CA74A8389C223BAFC411C6D4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8960410672C414C9D3BC093FB4E7CEB386B"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "11720B981215C4448D0922F44CAEF4039623"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC2CCEDB01202849CD19CE13A398BE735CAD",
                        "defaultText": "덤벼. {W:200}하지만 네가 들이켜는 포도주와는 다른 붉은색으로 바지를 적실지도 몰라."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0C6457893DB80049B389BA31DCB77352523E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A07F14DA57CEF54A5E78F57611B8429554BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7FAED1F48B0C7467569B9277AE70BB8FC78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "23E7DDF355A70141817961789EF9669EFF4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C0F186506F19048A1380486A1C4831B87A4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_SAD_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BE5B51C36A0B074A257B7434993D8EFEB15F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6B543AC44B60A344F81ACCB822AAC83B64B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40482093414A764427387DB841D72FE49B06"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B727EA5F9696B543B7287FC8EABFDFFFB516",
                        "defaultText": "우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "250C6E827ED3C14B90484642E8081482C189",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "088B3CAF1D2BC647B84822F56890303C61BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            8,
                            2,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B782AC111E7F149F00B1BD76223A30D42FF"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "violence?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C9BD20641391C14A6A795105EF351135F940"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "fine scenetta",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1C643B1D77A02544C61A2E4215FBCD10C4DC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "diplomazia"
                },
                "indent": 0,
                "uid": "5960AF0484AD3745556AEC8746DF113BA317"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE0DA315086D614FDA8A09A9204D94D87A02"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DA0D20020D3D64AB459A298466A88BD8CF4",
                        "defaultText": "여러분,{W:200} 우리 모두 지쳤고 즐겁게 놀고 싶을 겁니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7E14548536D4247A388301728D82188D609",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CFDEC251B380147D43A3ED5B83F02100168"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "060C8FA565A53342572B8C058331A399C7C6",
                        "defaultText": "이 아름다운 저녁에 식탁을 붉게 물들여서 망칠 필요가 있겠습니까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4EB7FD208280374A665AE1E3D8FCAB11D7BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BA5D490557C864CBF2BB9F2F0492374EF05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1BF2DC9A32B7D549518AF094777C61DBB19D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E4815031CCD35469E1AADC142A88AC26573",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2CB67B505919094D3749D23206C94127345E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2B1E3C766ABEE6447A18B5A4486979AE672F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8304873332F9714AF13A46F52DEC0960FE02"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83BD92F45D689543756937769AADAB3D2B1E",
                        "defaultText": "이 쓰레기가... {W:200}딸꾹! {W:100}네 얼굴을 박살 내 주마... {W:150}하하!"
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BFDFF467363A3949B53BCD81072BDDD4E304",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4C46498884577410D69EBE4E0C2D18C1BCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83FE0E71612EF84C2A08A465F5E31A4D7F66"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F26EC325172DB043BD8B188050B921038E70",
                        "defaultText": "제발 그러지 마십시오. {W:200}잠깐 진정하시면 서로 잘 지낼 수 있을 겁니다..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B3D3C4E1717B24AC3987F48F7B25B8DE8E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "706901A64607D045E2189395A0264E4FEB50"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F889B7966186545DD4B8AC90F7DFF843F19",
                        "defaultText": "...그리고 다음 술은 제가 대접하겠습니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A9B75F258C7634AFF4A9D428CD5CBFA974D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F586DDF62E5A45413A1B75410E6651D85753"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "0415D78B1DFAC344BF7A6C3410DF8F9C5C56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A3EE19632218094ED16895A2979641AA0A67"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "06DF5D6B51E9D3458979B4835AEF77836DDD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F9656945513024B8919BE5866907635EEA2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8164D6A6372A22491E7BD6E0E8A61A253335"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD3851E926CAA34B9E7BFA074AD5E4E450CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC21EC847BB9734299082145D1CE4BF05A6A",
                        "defaultText": "우-{W:150}우웃!?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "24841A688F43C644373937B38F5D5A904F14",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54B4568B67B841496A39BF1143CBC44A1240"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DF76F0A6DBF33489A4880281D5902A467CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20658880687B6849952A4808F7AFCBE5C50D",
                        "defaultText": "쉿... {W:150}골드가 넉넉하진 않지만 널 구하려는 거야! {W:200}좀 봐줘!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "315D475B5E9C9240F949BC5754AA9B5BD27D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5883881D6C38334AB19A09D9FB63970E22DF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fine scenetta"
                },
                "indent": 0,
                "uid": "0B3C90D463A3224476594BA57F54EF1D10DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9173C4AB7243554DA05B28B5FDAFE79ADE78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAA7289442AB834AA98BA7269B50195008A5",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "2BA2EEA35BD78240FC7B62333CAD721D6C9E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB820A7612567441137991847AD25C8E2573",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB47446D567A84441A09C9029890AC80B646"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DDCBE3494B66564B7A79781394738F395645"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0057957167C43844C13A9294933DCF57DF10"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "2E9AD9611740F04D10296705D36616E991DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B7AF33D2BBAE849151B3007678C7A5719B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B60162FC2FDDF249473AD92479CD2A7DFD1F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D6A515DD9F8FF84CD8681732AC856046926D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-DrunkardPylum_line6_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCE77FAF3683D345075959D6486241CE7A45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ADB7F0E016D64643CE1870C0B54D3FD18F1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "325DD9BF9F29B844CA683A979670D7FD219A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8C8B3EE8939E242E0593397F34CE0E2A9FA",
                        "defaultText": "쳇...!{W:200} 지금은 살려 주지...{W:100} 하지만 뒤통수를 조심해, 하! 하!{W:150} 딸꾹."
                    },
                    "position": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA80A4AC532D114D884AF5201394880D3AF1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "55DD25619A05184FF78BAB817A3C4AA88088"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FD39FC09C5735475E9AF0D88EA699C3659B"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "model": {
                        "name": "TarmenDrunkMan.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 710,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 220,
                        "y": 469,
                        "zoom": {
                            "x": 0.32,
                            "y": 0.32,
                            "d": 0.32
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "08D6AF325C6B094DB9796C88A9A74014954D",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "F785A0503DFEE146592B311858FF60A3BBFA",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "004BD99B8E66364CA22AC5A4525B284EBC9A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "637D3A5B3EF2384F0258CA54D0FEFCEA067D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF5E44341897C24EC058C5C769A6C6A5D1C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CD7AB7C2980804B47390209460EC5CC3264"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "540F4C912A7B0647A2993BE0AEEF56579769",
                        "defaultText": "...정말 통했어? {W:150}휴우."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13C95E497F99684DB6794429FDB31AAA51E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AE9BF3B2463974F6739D24233DC4295E799"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Violenza?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F6690A1564A8444E858B27E378136F888D5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            6,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CEDA7D5A86BB0446A81842F8CC0D8732A71B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            10,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7057CA0752A33248314B6C44708FB5240EAB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3A1E3FE55268C64DA11B2513507010F33937"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2CE1986C61AE3743106B60A78D20DCEFC819",
                        "defaultText": "운이 좋았어, 니니... {W:150}하지만 네가 일을 처리한 방식은 마음에 들지 않아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0BC0D7B82DFD944EDE1A81083A51C4CF9315",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "8EF861503DC6F943D93933098B30CFCEF6CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1308D59B12B9D94822091DB1CE1F86BAC4BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "27142EE34E6F944ACF5B4A9660CB1E55FD69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9D54578D67997440E10848B5EDB86B9265CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C45657424C8D14DA87A0A480A29A251FCF2",
                        "defaultText": "운이 좋았어, 니니...{W:150} 그리고 상황을 능숙하게 처리했어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "243236C862DF6443962BC5816CAF9E36B1EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B235756A3995564DC729D3025F8F6F614815"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "388ABF8714C7C34E1878FBD12B8B4C55E9A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7EC76FDC56DA864E175B6D4417D0C37FAA26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF9ACB0521F95545510B2FA6238744C1897D",
                        "defaultText": "그래? {W:100}뭐, 적어도 지금은 무사히 넘겼잖아.{W:200} 그게 중요하지."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F499F2503EF3C649655B4876E1BE659BBE4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67244BFB037638448939C4279278EF11BEE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE71912914A9564BC95A33C319CF358923A9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Skip scena Luckos"
                },
                "indent": 0,
                "uid": "B61943815B75D74E4D5965808B19206D9235"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "AAC188623EEEE5452D7A923805D0C70810FE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "8612794E1749C3473C6A0982297B320FE5A9"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2EFF267B41FA84405E4A70A330F772345E6D",
                        "name": "C1-03d Arlene, order food"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3AA9B7824FAE84494518F7D4ADDB4AF275C4"
            }
        ],
        "numberVariables": [
            {
                "name": "sarc",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "violence?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}