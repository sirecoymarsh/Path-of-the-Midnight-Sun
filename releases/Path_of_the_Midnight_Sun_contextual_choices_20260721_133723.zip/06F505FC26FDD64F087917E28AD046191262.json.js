GS.dataCache['06F505FC26FDD64F087917E28AD046191262'] = {
    "uid": "06F505FC26FDD64F087917E28AD046191262",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5-05 Post fight - Cattleya endings",
        "type": "vn.scene",
        "parentId": "555C26067448B148177A8258764AD85D121F",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 7,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Only two endings this time.\n1) You fought Menmus and recruited him\n2) You didn't"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "20E1AA6749DAC5489B097FE9C30DD6EC8FE9",
                            "023CFADC6BABC748CA4BD8A6D50084A69CFC",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7DE85988820C064458093A43FE5D61D210D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "92B90F261345D6470B0991805908EDD2D40C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "734CA55286282540185A18690D1AE94FC1F6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "8496741C2994B34457395BF287C4985A73B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4604174B1AE6F14E418854148F185C6F9520"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5ED7E79A6E71D84CD35B2150A35A0490038E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8CF52854F107349F239B4A3101E5F81673D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8DC0A1E3E235345DD58EA20CADA2C4112AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8134FBCE1BD8B345F4197F0242360FE946C7",
                        "defaultText": "완패했어.{W:300} 수많은 병사를 잃었군..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "638995A46C3F414F1E48DFC6C96FBF5463F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D25453C61603448AC3A8484CFF330DB48C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B8DC95C10DA344670489493EC2BA187968B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "86D044E1294B354D5A49CAA2D495BC814011"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C346D36B6D03A842A818226667A2D71E3561",
                        "defaultText": "지금 기분이 어떠십니까, 공주님?{W:300}\n지키겠다고 맹세한 병사들을...{W:300} 직접 죽인 뒤의 기분이요."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B1A1AC884A4C074DD69AD161A048FC5E23E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "554B4E62928A344E80383F924775088F1B7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "781BEF7698B8444C681B43373D09796D41DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A1AA30207A5D694E312BCC46C895421C157E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "176BFBBC3597984739589686137C8AAB8389"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "6EDB19831CB03747572B111517D0AAC0D9C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "9B60A3CF3630E44D8158477328729312F194",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7DABF8C16CA9D342F968FDE7F5EE47A07A0F"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "model": {
                        "name": "Cattleya.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 420,
                        "y": 72,
                        "zoom": {
                            "x": 1.4,
                            "y": 1.4,
                            "d": 1.4
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "17D1EAA5580DE34E4C4BA748362CE15A942E",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2633C3862A504642920948187380B22A1B9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "E12881A85BF812408D2BD34781845245DD3C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 0,
                "uid": "9F5B5F786A73364F4F3BF664119C3C2751DF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E19F8B955A770440A1694FB4B497E5D18067"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "36D476137CD8F648C96BEDC326F65E6D0D80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C2A78DF5600F01432F4927E098D31A4BA071"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73E5F3EB81FCF84955598C004D9097915673"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "493C3FFD1E2CA84347295D1237726E7C8E24"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D7CF7A9081C684E5B48BA52CCB2352D94D5",
                        "defaultText": "안녕, 카틀레야 대장."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "694675278520154D374B4E015DEE93FACC4C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D68741F4881E90477A29B097BACC5014CF4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9C4B17E201DC2412B4A9C190DA1425014AB",
                        "defaultText": "예상대로 혼자서 나를 기다리고 있었네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "26D5EBC01C2042429C28CC46815AED3C13B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30EAE88D6C703344F44AA6849CDC5ED571BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E568A8AA6D7922444718E253050328B94E23"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7251598379768447C64B40E83D7FD8FB3055",
                        "defaultText": "우리는 어릴 때부터 서로 알았잖아...{W:300}\n서로의 생각을 예상하는 게 당연하지."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AA20EDB3218D594F8019E4066A5CA15B380C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CA8F8051B02A3492C4987E74648F5514FB8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3AC87D518FC6646E579FBE8097F09A5CA16"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FBEBCC250025944275A3D91BA343BDED50E",
                        "defaultText": "그럼 내가 무슨 말을 하려는지도 이미 알겠네?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "03222A2F0C8C5444EA796437636E7313CC3D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EB807B7859BB8446A38E1B70897504D1A91"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "79D591DA4D84664ABE28BA999E61DF9280EE",
                        "defaultText": "나와 함께해 줘, 카틀레야. 네 힘이 필요해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0921409188F8174E6C8A7AB44B8FE475ED4F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E6EF9E3310EA764E9F3BFBD785906F98AAB6",
                        "defaultText": "날 믿어 줘."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2BDCD55170EE274E573A06C30451BCCED158",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "848B43E86E27D74CC38931C0FA0EF0F52759"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B9F8DEE44293064DAC58D8755212A4CA6935"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "789F215D5D216343C45BD96099DC72DA5361"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cattleya.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "severe.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "38C86F0358F59842082A95879D3FBE4984A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06071C874CC3F8459979A5B866DD35674057"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "262F441F2E8846479A69A40842A8AE827965",
                        "defaultText": "...{W:300} 알바노는 죽었어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EB0BF50D9C03C04C069A5F66C259C01764BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E56CF375E5E904C390AFC73FFE828E9193B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D0AD9DDD11707149B04A0BC5497D79CE09F1",
                        "defaultText": "나는 그를 사랑했어.{W:300} 넌 그를 존경했고.{W:300}\n모두가 그를 우러러봤지."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CB280D6B5CBD704738580551759380996D6B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "287C1B6B2FBA37458C6A039487AFE4431713"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3119492044018545A58ACD6573D321CFDCE6",
                        "defaultText": "그런데 네가...{W:300} 그를 죽였어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line10b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "832A14CE3844C54EDD3972933AB8A68FB7B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8AF792E362845642DC887993BA9941ACD1DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6C5D1B54B75274F083B6563E909E33D3812"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DC3CB2276AB26499C387CB7F01D486A42A5",
                        "defaultText": "내 진심을 보여 줄 수만 있다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line33_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "75C88C6020474841D03B2B31D9690A789CBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF2D0F922E19C843E57B6B635CDB0361597C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D04748DA06771445E88BB039972EFC1DD549",
                        "defaultText": "하지만 한순간이라도 망설이면 모든 게 끝나.{W:300}\n나도, 모두도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "897750A45E0CC04465182095784A3C0B51C5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C7AFE0144EED848E99B5DB41C62B436271F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88F386B6728A0041F76816E56264ECF2A705"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "336C4202379D884CB8187EA554F925B64553",
                        "defaultText": "알바노 스승님은 아직 모르는 이유로 나를 배신했어.{W:300}\n나는 자신을 지킬 수밖에 없었고."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3EB69D00805FF44D5C0A6944B80FE5F25E21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C913A5228C17941716ACDC3772874F53D70"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EF410B13B21274EDE0A5C76B29D8B0F0586",
                        "defaultText": "이 무의미한 전투로 많은 사람이 목숨을 잃었어.{W:300}\n하지만 마왕이--"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "91062D0E980BF74F86293C41FEC1332716DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01C306BB7A0FD74C4B6BED5012919A53339C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F2603EA6AEF414D673BA178B75FDE9B41C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD315EDF03477340F83BF18982DC9740A7CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "597191634571474D282979356DC0BCF73636",
                        "defaultText": "그만해.{W:300} 네 말을 믿을 수 없어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6DDF627A6CD100435C8AA187885371FEAD37",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C903E01A44235148A3687DB70E08B7AA8B3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "99128A2151ABA04F977B3DE43F8F543914B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8FDB785A0415E8481638773877AFB3931D60",
                        "defaultText": "네 목숨으로 죄의 대가를 치르게 해 주겠어!"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8294BE8B6368A44F3E2B2B07818CE5057940",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B0C34FC70A267416118CCC5FFD953641ED4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B6B2BF3484C6142792B30298C7E8BC10047"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "560E28AC38D2F8480D0A06411612591AE0F4"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Cattleya.model.live2d",
                            "folderPath": "Live2D/Z4 - Adjutants",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "menacing.mtn",
                        "position": {
                            "x": 40,
                            "y": 54,
                            "zoom": {
                                "x": 0.9,
                                "y": 0.9,
                                "d": 0.9
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28891CA92C42C44CB619A6F4F1FE3E370869"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "7323669D7936414FCA6BD731FFEE64D126D2"
            },
            {
                "id": "vn.ZoomCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 24,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 260,
                        "y": 260
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "F9081045919D544E688867C122DFCA41F853"
            },
            {
                "id": "vn.MoveCharacterPath",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "path": {
                        "previewBackground": {
                            "name": "$live_preview_snapshot"
                        },
                        "data": [
                            {
                                "pt1": {
                                    "x": 1104,
                                    "y": 254
                                },
                                "cpt": {
                                    "x": 1396,
                                    "y": 398
                                },
                                "pt2": {
                                    "x": 938,
                                    "y": 292
                                }
                            }
                        ]
                    },
                    "loopType": 0,
                    "duration": 24,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "395C4D46299F7044A43A9978D9864EC9694C"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1DE2B55F6617A44DF90BB755E2D1BF6FC475"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            350,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0351ED3075AF88462A297DE2528AF18B6665"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "DD687DF875B4F542E0483087B2C724599C39"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B36407534067D648176A79244957FBAB233D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B42569E741E4654B5A6A6B6304CE9D68A5DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81A6618F6354464014081F903023100F758A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA20F02E3CC4D54EBE7BA2F623397A271452"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AE55F1B273E43045552A26E7BFD6703A92BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FCD8B2B6095D164DF929E696E06F610F57A7",
                        "defaultText": "멈춰, 카틀레야!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ABBD99256E73C444D3684574CB8E3ABAC284",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6950D8A5E78F54F4F991C4564D894A4609D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "816A6C2882994542D2690274AE3791BEC685"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "model": {
                        "name": "Cattleya.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 420,
                        "y": 72,
                        "zoom": {
                            "x": 1.4,
                            "y": 1.4,
                            "d": 1.4
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "5A05CD3D4EFED64C5569C4F0C0BF63D8D3B9",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2B3554AE34B5E84DD59BAE99431A3604ECEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5EFFD474504F64D1359D991B5BB605251FA"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3789A4866B58E94CE62BCBC31EDCF3470EFB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "D77391AC51E0C64B4779DBA48EBFAC9C24AC"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "81176D4B8F4648434A4A1D1897EAC8CF7F7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4DD38C072C348742313962427D1DA8E2B678"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BCEF52D37B71846F23A0E03FC750D20C283"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D30579A333D2D445F33883940D4A6E1B6F10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BF328405761064FC81B3727C7F1AB183B6C",
                        "defaultText": "멘무스 대장..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "87C683A17295074995381801AF54A4962793",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C80ECA44935D134B1638A8B692AEAB54D928"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "636239158259A9416A3AB018406DE9D61058"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "670104845EB74841170ACA70468EBBAA1757"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9A11629260B654C9A5BA672826E8E5C2EB3",
                        "defaultText": "뭐 하는 거야, 멘무스?{W:300}\n이자는 더 이상 우리가 알던 그릇이 아니야!"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9C34B7FA2DFD3440A17BFAE85C64D7AED6AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5A210C2352AB848FB18E79041C040DAB1A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA134D9E358C5643D5586CB106DC585406FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53A82A1B2205E74C7C9A22A3577613E1E883",
                        "defaultText": "우리 전우들과 알바노를 죽인 마왕이라고!"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CC88D3171C02524E339897A4FE000EC356B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47E3DBA51C21B74B7F7B2C99AD343FA97BA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F2C8E313639B744A1229E786954C59704EEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E93E298E7C9D62401C788EF318153EC6AB1A",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC"
                        ]
                    }
                },
                "indent": 0,
                "uid": "D63C315C4E2EF84A32395DB529AC96A66EE0"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E9DB62955849B841C718C9820BF9E191293F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if you recruited Menmus"
                },
                "indent": 1,
                "uid": "89F8796948B67341E74A5955FC0E04FAD725",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C6C20EE49FF08248422B62A3690B8DEA0D76"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "6233194C6FECD442053A49F9A6E0668C7722"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "997DDA687941D1497F8B22561C43C3C992E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EAD8631D2F2908410E1AC602FD45785C1A77",
                        "defaultText": "제발, 카틀레야!{W:300} 저분의 눈을 봐!{W:300}\n정말 마왕이 보여?{W:300} 내 눈에는 보이지 않아!"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1C7A2AF311F0234AD558ABC2A343B8DE3ACA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C68E97236D970740BE5AAE086FC6051ECC08"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "28176BBC16F57746CF7A2BE4ED024FC3936A",
                        "defaultText": "감당해야 할 상황에 깊이 괴로워하는,{W:300}\n언제나와 같은 파라트라스 님만 보일 뿐이야."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "37C1F5D89016E447EC380D9647D4236C2829",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DEE0A2730F5506448B4A57E70427A7DEA7EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "87A4662B6648D2454F98B1F1575A59603179"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B726388D28B62548F528C6415B80C0BC342F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A26A0B7893F194C77598D881CECBF0431C4",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "21A1C4C874DCF247C689DC9912C058DD3CAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1DF77EB97131F84BAB3878365D75045D0C4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6ECCCA6C4CDF8646211ACA05FBDC08691545"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99F47A2762D6D743C24BCA2778BBE152AF09",
                        "defaultText": "나와 싸우고 싶다면 그래도 돼, 카틀레야.{W:300}\n널 막을 권리는 내게 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "DDDCFD8F8AA1F34E6A68F646E7C211D7D120",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F21D824B25F06740024AEAE36A3D9296A580"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9156B8F244E9742C92BC901371845078473",
                        "defaultText": "다만 이 모든 게...{W:300}\n거대한 오해일 뿐이라는 말은 하게 해 줘."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "9105696E6B17754E7918C53165D130250F30",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D029D0A95575E847D04A7580D936F841E779"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AAE491143E01A740C86BAD366A7205F053A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2E24EA82285D64BCB2B8557B0BF20F722E4",
                        "defaultText": "...{W:300} 좋아.{W:300}\n내 눈에도 마왕은 보이지 않아, 멘무스."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "3A8A32C85464474C829B44F55CF0B40F25A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D919F1A1238E334EA5382943CE8F44458D24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "70282F7408C0E14C21193E17F9DD9E0D58BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95EC5C8616C5E342C37B6E24AA3E1566D2F7",
                        "defaultText": "그 말은...?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "CA335E1716CBD74EB94A2817BF1FC90EDCC2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "43EA355E39E412454D5B27A2504C28BFD89B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F3BDBB95879B7645398A38068CF1F6E66B1D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1826E30959FD440A978CB876EBFCB48AC73",
                        "defaultText": "알바노...{W:300} 내가 사랑한 알바노는 죽었어.{W:300}\n그 사실은 바꿀 수 없어.{W:300} 삼두정은 이제 사라졌지."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "E05F89EB0DE3184C4D8B40C14ABC31893969",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0511E60A94C4D3430D2807823DBED7C55DC1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA72AC102A81C449825A454138E0CBF54687",
                        "defaultText": "하지만 그 저주받은 날, 우리와 상의도 없이 행동한 건 분명 이상해."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "EEF72CAF52C019492A3AFD98DD5263423649",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "53FD19E371E4F6441D89CB909CD26FADC956"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "434625897297E241AA6914F6AE8BCF3D2CC6",
                        "defaultText": "그에게 무슨 일이 있었는지 아직도 모르겠어.{W:300}\n내 모든 고통의 원인이 너라고 믿으려 했지."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "F7A707E8540B1142FD08C067987310022E86",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9459B86618332140496B1BA4F03E49523750"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7121FA844DA5914A4C5A8BE151F82044D095"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "064C49BD7FB4E24FBB9A6375D36DA477F003",
                        "defaultText": "카틀레야... 나도 이 모든 일을 탓할 사람이 있으면 좋겠어.\n하지만 어머니 말고는, 나는..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "6F12B4B65EFCA542993972788E52D1514990",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4A5136D68CB6C74E5D68CB49F9FE975C175D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F38E86541092E94FC85BFDB3E8537ADA074A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "22EA2DEF3F90E64C9C295379E07A36E94A3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79DE5BF15267D343142B5CC52B9F7833A437",
                        "defaultText": "알바노와 파라트라스 님이 모두 이 분쟁의 피해자일 뿐이라면?"
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "56C7D8D89167654D7A0ABF11967773E8DA34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8CB4525E0D0A944A608B5206465EB4BBF4D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D924EBD24F94C84AA089AE00DFA4D5F24B93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1EDDEFE65C958244891A6C31C6F3BB74C2D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D26FE743532F814C544988B106BB3207EC76",
                        "defaultText": "그렇다면 이 모든 일의 배후는...{W:300} 무니 여왕님..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "B59101CA5E30C84DB32A9B92C6EDD5C752B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BFB5BE025DB63148639B9E93023D8AADDC91"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "21BF96EE22DD35429F887A28E3D0197CD14A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F922D8C526B4149F21B419787A4B09E3D0E",
                        "defaultText": "믿기 어렵지만 그렇게 보여.{W:300}\n어떻게 할 거야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "12E9947588C81249CB7A9B07DCEA73008318",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CB277C146E39044AB169AF40A5D321AD30B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6ABCC1436EE5D848DC3B20133D983F907CD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ED1A730D56F40340E44989A8568581C7C6A1",
                        "defaultText": "제 결정은 이미 아시잖습니까, 파라트라스 님.{W:300}\n당신을 혼자 둘 수 없습니다."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line35.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "2B03A90B50C77143452A9150A3DA6C2459A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1A4C85796E5CC545BE7938E06B278F2C40B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6E49D27E1360764825184B53F029B3F07E5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53A57FC72DFAE44F6869562705A5267CFBDE",
                        "defaultText": "너는 어때, 카틀레야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "0DE608D270955842070A2280B084F6BD0D78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "14DC8D52780A7444652B201547E7DDEF014E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "F77F12F40B8892494D59DFA44DC335AB5A59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "E312A1832404964F0F4866C1454C65D9A3B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FA617BA019F014495B3904D2B845F0CDA7F7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8407591F119F7845B0882446B7AEBCCB2BC0",
                        "defaultText": "... ... ...{W:300} 널 용서할 수는 없어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "B343EA6F1D848744E85830E16CA6F7F196B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F6B9D4E9333E7542DB1814E5FBAC4473A22B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E056A3196E02A646DE69D012DF59F2E4DBF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "27F2CD8320D0914591298C966AFE99DC4423",
                        "defaultText": "그건...{W:300} 이해해.{W:300} 걱정하지 마."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "570D9B2E30E6C94D2D58C7568885F3035051",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D05D535841E47346716BA2D47E3A38F33431"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B2AF0EC62247914C365A29A5DEE31BEBC52C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1284B6AC6E42A146D68BC5088D048C34C594",
                        "defaultText": "... 하지만 동시에 이 일의 끝을 보고 싶어.{W:300}\n진실을 찾고 싶어."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line39.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "A865F7F57F43534D748B9370CC5D85BF8AEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9CBAB263749411423B3A6516014529A7F474"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8425C5C57E25854504898C232CAD42AD9E08",
                        "defaultText": "네가 우리를 속이는 게 아니라면...{W:300}\n이 모든 일을 벌인 자가 대가를 치르게 될 거야."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line40a.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "40DCC31B454AA54EDC2BFAD36F189985ED08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "52D6C0975C099541002A9D1922D197292565"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BF1AC4BF73F6344E6F68F7D231733F6F948C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "024B368B47F1554CF09B43E5C00EF18D1D06"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 1,
                "uid": "81D19846512B0842173845B24079394F68BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            6
                        ]
                    }
                },
                "indent": 1,
                "uid": "0573C64F2F7D0541145AC6262AC1B8ECB1D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "849BB7BE7741964F02996A6487B70B100FB0",
                        "defaultText": "지금은 나도 돕게 해 줘."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line40b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "51A8A3730A081242C869B5C378D6E7DB92ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C68F833F1244584F9D3A5575D16D78827B87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "48ED6A3C62ABA54F9D78E861195477711DF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E07833C6B56A44F913AF053307ADB4BB206",
                        "defaultText": "카틀레야!{W:300} 고마워...{W:300}\n신들이여, 감사합니다..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line34_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "7D74DCAC7E96324FBA8BC4778BE8C08985B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "680056521CAA4342C28B6128BBBEC9022219"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "00ABBB613AE638422729F17787B5FB439D89"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44CCC1B849E364454C1B1192E36CAE0F07F7",
                        "defaultText": "내가 얼마나 기쁜지 넌 상상도 못 할 거야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "BD5623226967824F43881A95EF818CF58804",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D97912FB46D7864C6E3844D5276AE879B308"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "38C0E28C7388434DF9180F89534A37549032"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2497D85756DC914DC8393BC7E8F6D3D0D657"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8808153439A7341865A8355C221395A0DBB",
                        "defaultText": "삼두정은 사라졌어도...{W:300} 우리의 유대는 영원해."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "EB440BB06EB8F44E4B1AB8A4E98E7A649EF8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "38FFB14F6074964AA878D813EF804DE74332"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6E6CAF4C892E41406658D08730711666CC22"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "F69FA1FF5911E4409E796DD7791335271313"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D86A0B755C3931407F0ABD74F73B1E1241A9",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "18FDF81812ED964D90495EE7E04C83742802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "{C:1}Cattleya{C:0} joins as an {C:2}Adjutant{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6822DA8F44E7A54BC819EAC1FE08902AB588"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "86DE3174809B40476B2AC9C5E9B47707FEF5"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "7249CF6635A24347948A343604E97F52CD8E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if you didn't recruit Menmus"
                },
                "indent": 1,
                "uid": "FA973C6D29387245276B8FD39AFC3F23802F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0C6D3630897EB540969AFC985B03725D0BB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7406C74719C47147FD8B9799BF46E4412249",
                        "defaultText": "왜 나를 막은 거야?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "22D5FA843DE6394CA69A41C1D330FA53BE6B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "83FFC37135AB8446C75AA2B7D2ABDEDC9057"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1BC21E991E707943998A4007A9143329BF1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B2FC4EE939BFA443662931D6F2A3A4F33D6E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "033099333049B14672290DC19D091FC63674",
                        "defaultText": "우리는 이미 패배했어, 카틀레야.{W:300} 게다가..."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "58EC0E874BFD584BAC680B780DCBD322D30E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F16656271B4D7643EF7BCC8129AE92B09854"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "118EF2AC5CEB6440DF2BD97361552827CFFA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A824E6F452BEA54E8448309498F16D9782C3",
                        "defaultText": "저분이 정말 마왕이라면 지금 우리에게 승산은 없어.{W:300}\n아니라면 그릇에게 죄를 짓게 되겠지."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1D5999A37D71164E404B8418C15FD6A7BCF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7A0A919B620A284242489258B869B342EF0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EEE1E5F887F2F84F373A8ED088905E0C244C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98D25F7A3B79A84A622BB39142C584DDD065",
                        "defaultText": "의심의 여지를 남겨 줘서 고마워, 멘무스 대장."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "57BCF8C53417B14E7528D758BE5612683A2A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6713F04A399A244D650BD6F802205F180D09"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E28778D405303408A7A5A88267579B92E43",
                        "defaultText": "이제 너희 둘에게 의지할 수 없다니 아쉽네.{W:300}\n하지만...{W:300} 어쩌면 이게 최선일지도 몰라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "D80B2FE5148FC942B35904D399FEBBBCFB10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3EECDEBD4E5F5949524BCD44150CA6216510"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E538BEB29CDB494C171889E41B93F2735383"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E779138F0E9BD147533A6BC523AFF2236905",
                        "defaultText": "무슨 뜻입니까?"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "63D9D9908A8D6745B26B51F452D84F45EDCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7FE2031C9E709545668AA2333A1C847A38FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "906D32FD78996946BE59DF111DD201E42C12"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5DCACDD85157C849B07965F948A319C7139F",
                        "defaultText": "너희가 말려들지 않았으면 해.{W:300}\n나처럼 쫓기는 도망자가 되지 않기를..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line50.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "F7AF104091BEA441FD18D4B6E67BE809AA72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E9A8BB8B1AAB4147BE4BB9D78FD08B35FBA9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "28C709E60CF4E44298694F78B394DDCC9B62",
                        "defaultText": "여왕의 명령 아래 행복하게 살아.{W:300}\n그게 모든 호이카데 병사에게 가장 큰 영예니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line51.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "7049232C69F5364443288362650BF173CDB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7AF3DEC3961DB14F368A03B603E3341D6315"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DC90175A2AE415466568BEE8253DD30BFAF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C3341A48DA9B343D048E4E098CE802891C3",
                        "defaultText": "그래...{W:300} 이 길에 나를 따라올 필요는 없어.{W:300}\n기다리는 건 고통뿐일 테니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B317852A8EE9F0425D5BC8F38880CE710438",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9B2E2C6E67714643A1183B222F59D743B05B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ABFE906F265BA945BB5BCEE196053EABE5AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A76A1D2D4392B145A5486A951A6BAE7B4E19",
                        "defaultText": "... ... ...{W:300}\n가자, 카틀레야."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "07FF54418BC2754626484E044D25162E5308",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0196BB1A60FF26490248E378F36058D50A87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            2
                        ]
                    }
                },
                "indent": 1,
                "uid": "B4C4C1996153014DD73A2867738A91181E6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E11EFB774CE92645818939143F368A74A1FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB9CACC38553864E131B4655776ADA4AAC14",
                        "defaultText": "이대로 가자고?{W:300}\n지금 여기서 복수할 기회가 있는데--"
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line54.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "CA07D5A21177B64E8F7B56C6E1575DD79E76",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ECFA28C65749B74AB96B3C62110833B7F0E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97485D471944224FC57A49788ACF301D4CAC",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1C889AAA105CF240084AD67510B6DC73559D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E47DCEE35F278455C8ACFF3CB648423B5FA",
                        "defaultText": "이미 말했잖아.{W:300} 감정이 흔들려 마나까지 영향을 받은\n지금의 너로는 절대 이길 수 없어."
                    },
                    "position": 0,
                    "characterId": "97485D471944224FC57A49788ACF301D4CAC",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Menmus",
                        "name": "C05-05_line55.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "44AFDA473CD21342812BBB959C7B86941DB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "822A9AD41CE2F44BD27AE2C41177279F29C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1C8DF4AB13B9E34F096A1137056E82DEB726"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0562C7084AE357483E8A4409CA648FA64E1D",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "E3-Cattleya_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "6683B1FC63995746EA4AF8D032E15BC3E9A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "58191F0A6C17F0400229F227B2AC54F32C31"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4E7213AC09C7134DFF8890806E150C2CC116",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8B345B9C3CD8744F972935C436A2B4AABEA4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6FA1A657073D84D999AF30583EB260BBDE1",
                        "defaultText": "칫.{W:300} 멘무스 말이 맞아.{W:300}\n언젠가 다시 돌아올 거야...{W:300} 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cattleya",
                        "name": "C05-05_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "FAEFD2170A21C648F6489028D1C572A94A8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2F0EBEC18E25584B876846F2C227F3A2C13B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4589AC5B51F5874D3659A77193CA1C4B8B02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "1441FEE27E83934CE718A2567B8073DB2BDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A35EBEF83671943910BFE49B5415F0DD97F",
                        "defaultText": "잘 가, 친구들아.{W:300}\n다시 만날 때까지..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C05-05_line57.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "F56A8C2F275E344E8C0AE938823430CC9BA0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "778CF81B150E964CD24928F62C9B00BDF248"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8A9D46092E10D4455D0A0B9197428FE4EC1D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8A9762D00F2F214C5A3BEE8093535BD6179C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "135D718F773CB64021198845C8E7049DABB6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "6F68E4CD8ED2834134586696A0EBC895B6B0"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "4859E1D7035EB2466F8822253D9BEEDF4C1E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "A28B776156DEB845467A95761FE7ED08881F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "transition while keeping music"
                },
                "indent": 0,
                "uid": "025328642AD596465E0AA450C9553F19CA5B",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "E34DA651692D5848BC193D807CBF88DC4F3F",
                        "name": "C5-06 To the mountains (END)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "95884AB33D14E14D755903D4B7EBFC3C98F7",
                "expanded": false
            }
        ],
        "localizableStrings": {
            "8134FBCE1BD8B345F4197F0242360FE946C7": {
                "t": "It was a total defeat.{W:300} We've lost a considerable amount of men...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "638995A46C3F414F1E48DFC6C96FBF5463F1"
                }
            },
            "7D7CF7A9081C684E5B48BA52CCB2352D94D5": {
                "t": "Greetings, Captain Cattleya.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "694675278520154D374B4E015DEE93FACC4C"
                }
            },
            "79D591DA4D84664ABE28BA999E61DF9280EE": {
                "t": "Join me, Cattleya. I need your strength.",
                "d": {
                    "eid": "0921409188F8174E6C8A7AB44B8FE475ED4F"
                }
            },
            "E6EF9E3310EA764E9F3BFBD785906F98AAB6": {
                "t": "Please believe in me.",
                "d": {
                    "eid": "2BDCD55170EE274E573A06C30451BCCED158"
                }
            },
            "D04748DA06771445E88BB039972EFC1DD549": {
                "t": "But a moment of hesitation, and it's all over for me.{W:300} For everyone.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "897750A45E0CC04465182095784A3C0B51C5"
                }
            },
            "FCD8B2B6095D164DF929E696E06F610F57A7": {
                "t": "STOP, CATTLEYA!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "ABBD99256E73C444D3684574CB8E3ABAC284"
                }
            },
            "064C49BD7FB4E24FBB9A6375D36DA477F003": {
                "t": "Cattleya... I wish I had someone to blame for all of this, too. But aside from my mother, I...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6F12B4B65EFCA542993972788E52D1514990"
                }
            },
            "7C3341A48DA9B343D048E4E098CE802891C3": {
                "t": "Yes...{W:300} They don't need to follow me on this path of mine.{W:300} Only suffering would await them.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B317852A8EE9F0425D5BC8F38880CE710438"
                }
            },
            "C346D36B6D03A842A818226667A2D71E3561": {
                "t": "What are you feeling right now, Princess?{W:300} After having killed your own men...{W:300} those you swore to protect?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "B1A1AC884A4C074DD69AD161A048FC5E23E0"
                }
            },
            "A9C4B17E201DC2412B4A9C190DA1425014AB": {
                "t": "As expected, you were waiting for me, alone.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "26D5EBC01C2042429C28CC46815AED3C13B0"
                }
            },
            "7251598379768447C64B40E83D7FD8FB3055": {
                "t": "We've known each other since we were kids...{W:300} It's obvious we'd be able to anticipate each other's intentions.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "AA20EDB3218D594F8019E4066A5CA15B380C"
                }
            },
            "1FBEBCC250025944275A3D91BA343BDED50E": {
                "t": "So, you already know what I'm about to say, right?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "03222A2F0C8C5444EA796437636E7313CC3D"
                }
            },
            "262F441F2E8846479A69A40842A8AE827965": {
                "t": "...{W:300} Alvano is dead.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "EB0BF50D9C03C04C069A5F66C259C01764BF"
                }
            },
            "D0AD9DDD11707149B04A0BC5497D79CE09F1": {
                "t": "I loved him.{W:300} You respected him.{W:300}\nEveryone looked up to him.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "CB280D6B5CBD704738580551759380996D6B"
                }
            },
            "3119492044018545A58ACD6573D321CFDCE6": {
                "t": "And you...{W:300} killed him.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "832A14CE3844C54EDD3972933AB8A68FB7B6"
                }
            },
            "3DC3CB2276AB26499C387CB7F01D486A42A5": {
                "t": "If only I could show you how I truly feel...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "75C88C6020474841D03B2B31D9690A789CBC"
                }
            },
            "336C4202379D884CB8187EA554F925B64553": {
                "t": "Master Alvano betrayed me for reasons I still don't know.{W:300} I had no choice but to defend myself.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3EB69D00805FF44D5C0A6944B80FE5F25E21"
                }
            },
            "8EF410B13B21274EDE0A5C76B29D8B0F0586": {
                "t": "Lots of people have lost their lives in this nonsensical battle.{W:300} However, many more will be put in danger if the Demon King--",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "91062D0E980BF74F86293C41FEC1332716DE"
                }
            },
            "597191634571474D282979356DC0BCF73636": {
                "t": "Please, no more.{W:300} I can't believe you.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "6DDF627A6CD100435C8AA187885371FEAD37"
                }
            },
            "8FDB785A0415E8481638773877AFB3931D60": {
                "t": "You're going to pay for your crimes with your own life!",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "8294BE8B6368A44F3E2B2B07818CE5057940"
                }
            },
            "3BF328405761064FC81B3727C7F1AB183B6C": {
                "t": "Captain Menmus...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "87C683A17295074995381801AF54A4962793"
                }
            },
            "B9A11629260B654C9A5BA672826E8E5C2EB3": {
                "t": "What are you doing, Menmus?{W:300} This isn't the Vassal we knew anymore!",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "9C34B7FA2DFD3440A17BFAE85C64D7AED6AE"
                }
            },
            "53A82A1B2205E74C7C9A22A3577613E1E883": {
                "t": "She's the Demon King who killed our comrades, killed Alvano!",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "CC88D3171C02524E339897A4FE000EC356B4"
                }
            },
            "EAD8631D2F2908410E1AC602FD45785C1A77": {
                "t": "Please, Cattleya!{W:300} Just look into her eyes!{W:300} Do you really see the Demon King there?{W:300} Truly, I cannot!",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "1C7A2AF311F0234AD558ABC2A343B8DE3ACA"
                }
            },
            "28176BBC16F57746CF7A2BE4ED024FC3936A": {
                "t": "I can only see the same Lady Faratras as always,{W:300} deeply pained by the circumstances thrust upon her.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "37C1F5D89016E447EC380D9647D4236C2829"
                }
            },
            "0A26A0B7893F194C77598D881CECBF0431C4": {
                "t": "... ... ...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "21A1C4C874DCF247C689DC9912C058DD3CAA"
                }
            },
            "99F47A2762D6D743C24BCA2778BBE152AF09": {
                "t": "If you want to fight me, Cattleya, you're free to do so.{W:300} I don't have the right to stop you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DDDCFD8F8AA1F34E6A68F646E7C211D7D120"
                }
            },
            "A9156B8F244E9742C92BC901371845078473": {
                "t": "Just let me tell you...{W:300} that all this is nothing but a huge misunderstanding.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9105696E6B17754E7918C53165D130250F30"
                }
            },
            "C2E24EA82285D64BCB2B8557B0BF20F722E4": {
                "t": "...{W:300} Fine.{W:300} I cannot see the Demon King either, Menmus.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "3A8A32C85464474C829B44F55CF0B40F25A8"
                }
            },
            "95EC5C8616C5E342C37B6E24AA3E1566D2F7": {
                "t": "Do you mean that...?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CA335E1716CBD74EB94A2817BF1FC90EDCC2"
                }
            },
            "B1826E30959FD440A978CB876EBFCB48AC73": {
                "t": "Alvano...{W:300} My beloved Alvano is dead.{W:300} That cannot be changed.{W:300} The Triumvirate is no more.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "E05F89EB0DE3184C4D8B40C14ABC31893969"
                }
            },
            "BA72AC102A81C449825A454138E0CBF54687": {
                "t": "But it's indeed strange that on that cursed day, he acted without consulting us first.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "EEF72CAF52C019492A3AFD98DD5263423649"
                }
            },
            "434625897297E241AA6914F6AE8BCF3D2CC6": {
                "t": "I still don't know what happened to him.{W:300} I tried to convince myself that you were the cause of all my pain.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "F7A707E8540B1142FD08C067987310022E86"
                }
            },
            "79DE5BF15267D343142B5CC52B9F7833A437": {
                "t": "What if Alvano and Lady Faratras both were nothing but victims in this conflict?",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "56C7D8D89167654D7A0ABF11967773E8DA34"
                }
            },
            "D26FE743532F814C544988B106BB3207EC76": {
                "t": "That would mean that the one behind all of this is...{W:300} Queen Munie...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "B59101CA5E30C84DB32A9B92C6EDD5C752B4"
                }
            },
            "1F922D8C526B4149F21B419787A4B09E3D0E": {
                "t": "It's hard to believe, but that's what it seems.{W:300}\nWhat will you do?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "12E9947588C81249CB7A9B07DCEA73008318"
                }
            },
            "ED1A730D56F40340E44989A8568581C7C6A1": {
                "t": "You already know my decision, Lady Faratras.{W:300}\nI can't leave you alone.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "2B03A90B50C77143452A9150A3DA6C2459A9"
                }
            },
            "53A57FC72DFAE44F6869562705A5267CFBDE": {
                "t": "And you, Cattleya?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0DE608D270955842070A2280B084F6BD0D78"
                }
            },
            "8407591F119F7845B0882446B7AEBCCB2BC0": {
                "t": "... ... ...{W:300} I can't forgive you.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "B343EA6F1D848744E85830E16CA6F7F196B5"
                }
            },
            "27F2CD8320D0914591298C966AFE99DC4423": {
                "t": "That's...{W:300} understandable.{W:300} Don't worry.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "570D9B2E30E6C94D2D58C7568885F3035051"
                }
            },
            "1284B6AC6E42A146D68BC5088D048C34C594": {
                "t": "... But at the same time, I want to see this through to the end.{W:300} I want to find the truth.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "A865F7F57F43534D748B9370CC5D85BF8AEB"
                }
            },
            "8425C5C57E25854504898C232CAD42AD9E08": {
                "t": "If you aren't deceiving us, then...{W:300} someone will pay for all that has happened.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "40DCC31B454AA54EDC2BFAD36F189985ED08"
                }
            },
            "849BB7BE7741964F02996A6487B70B100FB0": {
                "t": "Let me help you, for now.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "51A8A3730A081242C869B5C378D6E7DB92ED"
                }
            },
            "4E07833C6B56A44F913AF053307ADB4BB206": {
                "t": "Cattleya!{W:300} Thank you...{W:300}\nOh gods, thank you...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7D74DCAC7E96324FBA8BC4778BE8C08985B2"
                }
            },
            "44CCC1B849E364454C1B1192E36CAE0F07F7": {
                "t": "You have no idea how happy this makes me.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BD5623226967824F43881A95EF818CF58804"
                }
            },
            "B8808153439A7341865A8355C221395A0DBB": {
                "t": "Even if the Triumvirate is no more...{W:300} our bond lasts forever.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "EB440BB06EB8F44E4B1AB8A4E98E7A649EF8"
                }
            },
            "7406C74719C47147FD8B9799BF46E4412249": {
                "t": "Why did you stop me?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "22D5FA843DE6394CA69A41C1D330FA53BE6B"
                }
            },
            "033099333049B14672290DC19D091FC63674": {
                "t": "We've already been defeated, Cattleya.{W:300} Besides...",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "58EC0E874BFD584BAC680B780DCBD322D30E"
                }
            },
            "A824E6F452BEA54E8448309498F16D9782C3": {
                "t": "If she really was the Demon, we would have no chance against her now.{W:300} If she wasn't, we'd commit a crime against the Vassal.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "1D5999A37D71164E404B8418C15FD6A7BCF4"
                }
            },
            "98D25F7A3B79A84A622BB39142C584DDD065": {
                "t": "Thank you for giving me the benefit of doubt, Captain Menmus.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "57BCF8C53417B14E7528D758BE5612683A2A"
                }
            },
            "4E28778D405303408A7A5A88267579B92E43": {
                "t": "It's a shame I can't count on you two anymore.{W:300} But...{W:300} Perhaps this is for the best, too.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D80B2FE5148FC942B35904D399FEBBBCFB10"
                }
            },
            "E779138F0E9BD147533A6BC523AFF2236905": {
                "t": "What do you mean?",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "63D9D9908A8D6745B26B51F452D84F45EDCD"
                }
            },
            "5DCACDD85157C849B07965F948A319C7139F": {
                "t": "I wouldn't want you to get involved.{W:300} To become fugitives on the run, just like me...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F7AF104091BEA441FD18D4B6E67BE809AA72"
                }
            },
            "28C709E60CF4E44298694F78B394DDCC9B62": {
                "t": "Live your lives happily, under the queen's command.{W:300} That's the highest honor for any soldier of Hoikade.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7049232C69F5364443288362650BF173CDB0"
                }
            },
            "A76A1D2D4392B145A5486A951A6BAE7B4E19": {
                "t": "... ... ...{W:300}\nLet's go, Cattleya.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "07FF54418BC2754626484E044D25162E5308"
                }
            },
            "BB9CACC38553864E131B4655776ADA4AAC14": {
                "t": "What, like this?{W:300} I have the chance to get my revenge here and now--",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "CA07D5A21177B64E8F7B56C6E1575DD79E76"
                }
            },
            "2E47DCEE35F278455C8ACFF3CB648423B5FA": {
                "t": "I told you already.{W:300} You would never win, not with your emotions in turmoil and your Mana thus affected.",
                "d": {
                    "cid": "97485D471944224FC57A49788ACF301D4CAC",
                    "eid": "44AFDA473CD21342812BBB959C7B86941DB9"
                }
            },
            "0562C7084AE357483E8A4409CA648FA64E1D": {
                "t": "... ... ...",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "6683B1FC63995746EA4AF8D032E15BC3E9A6"
                }
            },
            "B6FA1A657073D84D999AF30583EB260BBDE1": {
                "t": "Tch.{W:300} As Menmus says.{W:300}\nWe will be back someday...{W:300} Lady Faratras.",
                "d": {
                    "cid": "4E7213AC09C7134DFF8890806E150C2CC116",
                    "eid": "FAEFD2170A21C648F6489028D1C572A94A8A"
                }
            },
            "2A35EBEF83671943910BFE49B5415F0DD97F": {
                "t": "Farewell, my friends.{W:300}\nUntil we meet again...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F56A8C2F275E344E8C0AE938823430CC9BA0"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}