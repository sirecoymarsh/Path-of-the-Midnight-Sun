GS.dataCache['717C76E24B0EB84423096D52AFD8AD093DAC'] = {
    "uid": "717C76E24B0EB84423096D52AFD8AD093DAC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C15-4 Final Pre-battle",
        "type": "vn.scene",
        "parentId": "A32267E55B8D954E8689C9B2F444F64ACDE7",
        "chapterUid": "8723B4CA2C69C345D49BB027C1AEC03404D9",
        "order": 3,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0141EDE2796BE84C5F48C44593FBD1AE61CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A388A6686AF1549528B2D462E2D0A3EAD7A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "BFDEA4F7197E844BA32BC1B0F0CAD16F3081"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7623DD5E5B7DC54940292E3537B7D1F33E1F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7F1871133DF341432B8B0B1856A09DEBCF45"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "72A89E457A8BC84A682957C358DA1F19F006",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37B55F17496C5548AE696A226492A5D4F16E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A196D26D899D7343613A56D6A6FEDA836E72"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "74CAFE535FCD1343765B1C7686FD97B885C0"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "DA0702D23E81874B5F49A3F54B9A70C3DD84",
                        "name": "32 - Phoebe"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "1C21F3158351C04520498AD7A7D937DA1EE2"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "44E8A74C2EECB340126BFDB6F8A15BE2E89E"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "0560F4C234FD524A9F9B4E3496C7E3DB43A9"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "A0C841BB1B1888484B294A38763A164112FA"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "04034DBA5A0B01412A6A7FF7D44382F9D8A8"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "model": {
                        "name": "Soraya.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 801,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 505,
                        "y": 78,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 1,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "08D5DC35587F624D0089B0F61AF870A610C0",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.8,
                    "idleIntensity": 0.7,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1,
                        "eyeBlink.enabled": 1,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "6ABF2C6D3C00384C925B0D64D5C746141A76",
                "expanded": false
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "8F1C2AD43FED204F863B4F69D587001BBF7E",
                        "name": "C15-8 Final Battle Interlude 2 (Defeat and Rebirth)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "148C189F69A3A841EE2A44632323BA6E6790",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "AA131493965B7148FF4A0CB8B3778F813EC1"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "35380447257A2740F6290D84A0B91D0FFEC1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0077C3FC2A9A5443CC595920C85ADA436D7B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "125D775D8543D244041839B03398F076BBE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EEE68CAD57BF15407D483749F8B128D60FD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDE2AA2F1FFD8245534978D758B78E1864A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B964C4EF71185840E12B9020797220570903"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "06B1CE93504C6146D53BE8E3EFC3ACC9A8C2",
                        "defaultText": "드디어 왔구나."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC4574FC6B52F24E308A5A900DDAFCAA1827",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA6055B7773393480C3BE6D1DB644FD7EECF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C10491863A3BC64BEC6806969CA7AB576BBA",
                        "defaultText": "성기사단과 아마란스의 연합군을 물리친 점은 칭찬하마. 정말 대단한 자들이군."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DAE0C91E59189740F65B18B39B139A2FECED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67BE54039451204399894A984C501F8BBE46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DDC5558934BA54C047A97B427C89D455802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7478D5BE1CCDF841B0392458F8C7DBD74D9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3C94A12662AA449808AA5135022506DFD48",
                        "defaultText": "안녕, 소라야! 오랜만이지?"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6FB0C3A1754DB645A23B50F3408BE001B457",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E59F7A842C5D754F6219CF074288A566F2B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C35BB4A470D64643194B4372EB279AAFB3F3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9DB0F3E4306AB44F40784EE35D36D2A32C9A",
                        "defaultText": "저들과 함께 왔군, 피비. 자기 동맹을 죽이는 기분이 어떠냐?"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "078C58871AB57649B75B8E1636C9FF00C194",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07DDA29F2D3B6842515B891700724E22BC04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "027A2ADC890826466A1B5197606CDC3DF6E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "65466F934BCF534DDF085D66F387001BF028",
                        "defaultText": "이제 와서 훈계하지 마! 조약을 어긴 건 너잖아."
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B6E66CB167BCB14CC20920656568D0DC70EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9EE178A0ADD854AE19A0175E0BBFB3DADA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF1B5177232617414C9A09D3D1CB74E36B3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "032B06B81B99B540A90B85B4648D5C54240A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB03A7276E5CA04A4F1B1EF1C72A6418480F",
                        "defaultText": "게다가 그다지 똑똑하지도 않네. 아마란스를 대놓고 드러냈으니\n이제 모두가 네 계획을 알게 될 거야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F3549B45A1BB144095B5D76940C66A920B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BB34F605EF64047267A990605326C53C5A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C9C682E53A200415568A35167FE20B01CBB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4ADE32DB50CD3349DC480074E4DE3C19EC22",
                        "defaultText": "하하..."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C6AF3C340D99F84CFF6A6853B532DBDBEE5D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B342E6D446AA24DB318454298FCFC160F31"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "change expression to psycho face"
                },
                "indent": 0,
                "uid": "19E79B9E6715B14F20094823E13E481C935D",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Soraya.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "insane.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "15DD46C361755442F22BCCA8454F3A155C20"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "233AF20F6FDE2743F26A7671674EB4174866"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E35F624637244453F0889D61C751DB01224",
                        "defaultText": "하하하하하!!!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "49FF1BD578B4E3432F183761B955008EA924",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7BEF06F281E5848DC3AC40763854891D8FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4257CB15277C6742524823B7B6BFA8919698",
                        "defaultText": "어리석은 것들! 이제 그 어떤 것도 상관없다!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F9A7046B382C28430C383EC0A5460B3708C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25003CE5533D914BEB783406B26FEEA9D373"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E27B3DB88ED2D242F19B973535957B9574D9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "601AE69E7196E84BFD4AB79431F668852FBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32C98F3F41E76249861B1787F3C150A8316F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AB8AD667196D142AC8B5730AB1014D630B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B68196263CAE22484D5BF4F300F4E9C68CCD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "387AB75C1953E74BE17B6793D141439A3CB8",
                        "defaultText": "무서운 압력이야! 저게 저자의 마력인가!?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1E48A6225452914F10992891D7819A8CA021",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5C627CC2FEAB341799AA7D456601D27E097"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1012668F1132D3440C6A9FC22B974E369ABC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0671A8153CB5247F5284FA57ED0451556B5",
                        "defaultText": "이야, 얼굴이 참 예쁘네! 처음부터 가면을 벗지 그랬어!"
                    },
                    "position": 0,
                    "characterId": "16A8EBB78B09C146315A36E675A482079533",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "987BA822665D5447E158E1B2D6949EEC60A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7E0ED21444B50467828A2B7D8FC9DA93E4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A84E3476C1A354EDD3AE2B55B6D8B5033F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "E2EA09BA6A175843687A4F1270206540F47A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "810796587A382243FC6934D3130D6F55F046"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC6B823B4353484723697AD81EF3BDCBEF0E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7C099C154293743A0183168B7993A842EEB",
                        "defaultText": "지금쯤 소식이 퍼지고 있어. 다른 나라들도 이 일을 외면하지 않을 거야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E33929DE4092224D369A30A77388F95E7FCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B58C8ECF16CC8942855A72D7FFB98F47C8FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A84E47339AAB248E41955A4209DF41B5B83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA873D66252F57488D8A1446EFD47C93CD02",
                        "defaultText": "상관없어. 60년 넘게 준비해 온 계획이 곧 완성될 테니까."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5119363684A2643A87B7E894D8259E867AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "741F28F69A75F243FC1AC1F1F8DCB909C3FC"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C071EDD52733384C351AB0F167F00263EF3C",
                        "defaultText": "60년도 넘게!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D1F523E26CB11461A8895C329D947CCDBE3",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7C4B38AA1A56414FA2386143F2D268A29087",
                        "defaultText": "대체 몇 살이신 겁니까…?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "590E69A84AB1C04A7B199DF4E644B50E56EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F081DF8F7B13B64EC83B4C4108B4C8597FC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2714C340309BC24DE11A3DE910260A9BEEAF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "B72C0EEE22D48644B878760366E65988E055"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D548ECF28F08814A948B5342683CE51B9D5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "728DC0E69776F446736AEE9818CF858501B3",
                        "defaultText": "겉모습은 사람을 속이지. 내 위치에 있는 사람은\n마음대로 역사를 다시 쓸 수도 있어."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "985DFEB628E5A240F3295AA2FD2F988AF685",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9842E3F47B4BD8461089BB43B3C9B7A1F302"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1C20AB132A575741816838961E8DAA69B62E",
                        "defaultText": "그래... 사이토 파스칼의 연구를 훔친 사람은 나였다! 모두 오늘을 위해서였지!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "652E3683291414496C2A15D7BD98797F8366",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB32C01872A0844EE27B92A68E86B406423E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2AF0D11980AE147CE9A1B2786CF07261002"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A64D31F56930544FC17AC1D3B3B84CC54CDF",
                        "defaultText": "역시 사실이었군."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD1B9E7C70018644F3193234FE9B87C96E5B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A56C45F6CABB64BA73959045692B48D0CEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "16A8EBB78B09C146315A36E675A482079533",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD25256E3115E84841885E62746DB9B42070"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "4FC0BB3D59854746011A10B13A8C2277611C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EEF6B3775D3C24C0518A373F3B72A212D27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "718E9D817BEA894F1E2BB09572624169D6DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EF3034E4E5F8140E63BE4542B771CA2089F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8D593C339041574B1B39FDC3523C35690307",
                        "defaultText": "성하... 이게 성하의 진짜 모습이라니 믿을 수 없어요."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB8E0CF706DD394E2B895556FF8F8480EA21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2A7A37C1C5F124D340BFE644957FD02FA1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DC893675A45E6409F2BC3C4EB860E9E9F1E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A10C18EA55FF2246F9885F55B334B7EE9699",
                        "defaultText": "시오리, 넌 절대 나를 꿰뚫어 보지 못했을 거야."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7755BA3D2C782947C8582A71542A1432EC7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0E7400C1E3F444581984A73F12F08EC72AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "473440FB33922843662AAB564D0510DC69A3",
                        "defaultText": "호이카데 왕족의 피로 오랫동안 실험한 끝에\n네 하찮은 수법에는 전부 면역이 됐거든."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "86EA777739A3F945C4491FD49C6510A0F6DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96624C971AD44349DE5820656908546860FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88AE9D7F05C44343B37BF2F5D45375D8F0DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFC042BE3E2502467D5880C9275832F5E376",
                        "defaultText": "사실이었어... 헬리오스처럼 진짜 악의를 숨길 수 있었던 거야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F906A91353B954CAD4BA5A1515ABAA84006",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "290C75AB7EE1E54D81893A73C8C3BA4EC21F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB0A76A9103DC5483D2AEA019C832916CCAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22C7E0251E2B04491D3930D6FA8FB81DA0CD",
                        "defaultText": "그리고 곧 모든 일이 끝날 테니 마지막 비밀 하나를 말해 주마."
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D979D7B955498541B228983692112CBF2785",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50B29DC75A72C544B24AE076C2E21B587E5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "468B9B34287E5543257A17853CC25772C977",
                        "defaultText": "파릴데 2세 호이카데를 죽인 것은 바로 나다!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "913923C33DE61340FD6B78F4C57657A4E135",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E955E193C491448FE9B3AF10F7EEFD94D77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A5A47AB6C485945C788D922D16ABA09A270"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "485BB3CD2BB87640BB59CF012D381BCE2B8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B72800018F9A8042AB69134207C28483E9AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D3CCFC2233C644CF41A64B15AE51B63349C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E499CB183AB4D640A72AD462B5C990EC2026"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DA95B7468BA22461808A8466F47C3F643D4",
                        "defaultText": "뭐... 뭐라고 했지?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E8184DA48829654FC65B670366AA34B03280",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BAC31C090236145D43AF556ACA3E422EF05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7FDDF4841CB3146091837324880C745846A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D23C1ECF5B423540195BDE82DFCCD89D80A5",
                        "defaultText": "그럴 리가 없어..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2378E211418BE945BE4B02C8F5D32DBCA323",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "995702A44D2021454E095121C3E077E76015"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "9C2DAF061BC9494D14589D0336F98A166C85",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2726F56B85A0E742877AA254845997DC5E95"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BE86B4D60FA634C223858636DB985019DD5",
                        "defaultText": "하하하! 지금 너희 표정을 봐야 하는데!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A9559E31BF5B74D885B23A4F243ED5C6248",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8513C5208D8A144EB439C933235A0B1F296B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F06315F57703044BF888DEB3ACEB215B4A83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "3984AB2D9DE1C64F293ABF84A811305322A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC8C0A9B6BED9640E19997A74A4958F1713D",
                        "defaultText": "놀이 시간은 끝났다, 아이들아.\n너희 생명을 영원히 꺼 주마!"
                    },
                    "position": 0,
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7F53214E4989C1464628C321DA21C41A843B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9F9B79A62BA1004B232B3AD4FA1CE9204D4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EC20D3215888544FAE8AA5E1039A99144178"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7138C8257E0D244C256B08C02C3851820B35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E4DCC363C898042F249FE84E7ABED98A22F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "295AE1BA9CF82541327BE02628B7D0658F6D"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF5987F227998744247AF613B741151FCBEF",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "E9D528597074A6464B4B3B49486B09FE0424",
                "expanded": false
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "FB3A144838429746A93AE8E318964252621E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "29250C9F7040F5496D888DB69816B0822B23"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E89FC408290CC143DB2908F8007BA073E670"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "4B933AED2FB02346256854F3B46A689189FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3D6CB73F55ABD74D909B8077E4534CDEBDE5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CE4C33574220E34F564AF481D076AC9C9376"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "21F0047944A692465E1B7373F8BCE7335511"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5D46DEED1695914A4678089112FA4963B320",
                        "name": "38 - Lady (Final Boss)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "9B5A87631DD5794F5A2A469798EB678E4F82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            0,
                            "E122A670658EE44F9D48FFC616265D6A32F3",
                            94,
                            2,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "70B85FBF23087745B719DC64C1FFC8F837E9",
                            "Graphics/Avey's Battle Backgrounds/Pylum Cathedral 1.jpg",
                            "63A1C1863D6D7244B479B0F76E386258E2D3",
                            4,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4F279B0E2F7855425929C2F53FF9EFEA2AD7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "battle"
                },
                "indent": 0,
                "uid": "144A2BC90377C04BD36BFB45B605F498B3AC",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "70B85FBF23087745B719DC64C1FFC8F837E9",
                        "name": "C15-5 Soraya (FINAL BATTLE PART 1)"
                    },
                    "savePrevious": 1,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2653A0526044234B0F6974A4C136E434734B",
                "expanded": false
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the battle, go here:"
                },
                "indent": 0,
                "uid": "3E14BC8E60C4074A067AD526E39E8E33575F",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "9072144F60A36346C53BCFA72394E5CAAF23"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "3DB8679940D198432F0BD0247688512C5B8F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "1D6D773B8BC0654E1E4A4016BBB732454730"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the battle"
                },
                "indent": 0,
                "uid": "5CF7DA4914DF75479A1BBD8201CE5F84AB7B",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "22405A208760654A0B3AE96578789B47F972",
                        "name": "C15-6 Final Battle Interlude 1 (Lyvonis fusion)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6D0680501894204A129BA4E4D91F075B238E",
                "expanded": false
            }
        ],
        "localizableStrings": {
            "06B1CE93504C6146D53BE8E3EFC3ACC9A8C2": {
                "t": "You're finally here.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "AC4574FC6B52F24E308A5A900DDAFCAA1827"
                }
            },
            "C10491863A3BC64BEC6806969CA7AB576BBA": {
                "t": "I applaud you for defeating the combined forces of the Holy Knights and Amaranth. You truly are something else.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "DAE0C91E59189740F65B18B39B139A2FECED"
                }
            },
            "A3C94A12662AA449808AA5135022506DFD48": {
                "t": "Hey there, Soraya! Long time no see, huh?",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "6FB0C3A1754DB645A23B50F3408BE001B457"
                }
            },
            "9DB0F3E4306AB44F40784EE35D36D2A32C9A": {
                "t": "I see you're with them, Phoebe. How does it feel to kill your own allies?",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "078C58871AB57649B75B8E1636C9FF00C194"
                }
            },
            "65466F934BCF534DDF085D66F387001BF028": {
                "t": "Don't lecture me now! You're the one who violated the treaties.",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "B6E66CB167BCB14CC20920656568D0DC70EC"
                }
            },
            "BB03A7276E5CA04A4F1B1EF1C72A6418480F": {
                "t": "And you aren't very smart. Letting Amaranth out in the open... now everyone will know about your plans.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "6F3549B45A1BB144095B5D76940C66A920B4"
                }
            },
            "4ADE32DB50CD3349DC480074E4DE3C19EC22": {
                "t": "Haha...",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "C6AF3C340D99F84CFF6A6853B532DBDBEE5D"
                }
            },
            "2E35F624637244453F0889D61C751DB01224": {
                "t": "Hahahahaha!!!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "49FF1BD578B4E3432F183761B955008EA924"
                }
            },
            "4257CB15277C6742524823B7B6BFA8919698": {
                "t": "You fools! None of this matters anymore!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "F9A7046B382C28430C383EC0A5460B3708C7"
                }
            },
            "387AB75C1953E74BE17B6793D141439A3CB8": {
                "t": "What frightening pressure! Is that her magic power!?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "1E48A6225452914F10992891D7819A8CA021"
                }
            },
            "E0671A8153CB5247F5284FA57ED0451556B5": {
                "t": "Yo, what a pretty face ya have! Should've taken off yer mask right away!",
                "d": {
                    "cid": "16A8EBB78B09C146315A36E675A482079533",
                    "eid": "987BA822665D5447E158E1B2D6949EEC60A7"
                }
            },
            "F7C099C154293743A0183168B7993A842EEB": {
                "t": "By now the news is spreading. The other nations won't close their eyes in the face of this.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "E33929DE4092224D369A30A77388F95E7FCD"
                }
            },
            "CA873D66252F57488D8A1446EFD47C93CD02": {
                "t": "It doesn't matter. Soon the plan I've been working on for over 60 years will be completed.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "D5119363684A2643A87B7E894D8259E867AA"
                }
            },
            "C071EDD52733384C351AB0F167F00263EF3C": {
                "t": "Over 60 years!?",
                "d": {
                    "eid": "3D1F523E26CB11461A8895C329D947CCDBE3"
                }
            },
            "7C4B38AA1A56414FA2386143F2D268A29087": {
                "t": "How old are you, exactly...?",
                "d": {
                    "eid": "590E69A84AB1C04A7B199DF4E644B50E56EA"
                }
            },
            "728DC0E69776F446736AEE9818CF858501B3": {
                "t": "Looks are deceptive. And someone in my position can rewrite history as they please.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "985DFEB628E5A240F3295AA2FD2F988AF685"
                }
            },
            "1C20AB132A575741816838961E8DAA69B62E": {
                "t": "Yes... It was me who stole Saito Pascal's research! All for this day!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "652E3683291414496C2A15D7BD98797F8366"
                }
            },
            "A64D31F56930544FC17AC1D3B3B84CC54CDF": {
                "t": "So it was true.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "CD1B9E7C70018644F3193234FE9B87C96E5B"
                }
            },
            "8D593C339041574B1B39FDC3523C35690307": {
                "t": "Your Holiness... I can't believe that this is your true self.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "AB8E0CF706DD394E2B895556FF8F8480EA21"
                }
            },
            "A10C18EA55FF2246F9885F55B334B7EE9699": {
                "t": "You could've never seen through me, Shiori.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "7755BA3D2C782947C8582A71542A1432EC7B"
                }
            },
            "473440FB33922843662AAB564D0510DC69A3": {
                "t": "I've been experimenting with the Hoikadian royal blood for so long that I became immune to all your little tricks.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "86EA777739A3F945C4491FD49C6510A0F6DE"
                }
            },
            "FFC042BE3E2502467D5880C9275832F5E376": {
                "t": "So it's true... Just like Hellios, she's able to hide her true malice...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9F906A91353B954CAD4BA5A1515ABAA84006"
                }
            },
            "22C7E0251E2B04491D3930D6FA8FB81DA0CD": {
                "t": "And since it'll all be over soon, let me tell you one last secret.",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "D979D7B955498541B228983692112CBF2785"
                }
            },
            "468B9B34287E5543257A17853CC25772C977": {
                "t": "I was the one who killed Farilde II Hoikade!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "913923C33DE61340FD6B78F4C57657A4E135"
                }
            },
            "3DA95B7468BA22461808A8466F47C3F643D4": {
                "t": "Wha... What did you say?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "E8184DA48829654FC65B670366AA34B03280"
                }
            },
            "D23C1ECF5B423540195BDE82DFCCD89D80A5": {
                "t": "It's not possible...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "2378E211418BE945BE4B02C8F5D32DBCA323"
                }
            },
            "3BE86B4D60FA634C223858636DB985019DD5": {
                "t": "Hahahah! You should see your faces right now!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "9A9559E31BF5B74D885B23A4F243ED5C6248"
                }
            },
            "BC8C0A9B6BED9640E19997A74A4958F1713D": {
                "t": "Playtime is over, my children.\nLet me extinguish your lives forever!",
                "d": {
                    "cid": "9C2DAF061BC9494D14589D0336F98A166C85",
                    "eid": "7F53214E4989C1464628C321DA21C41A843B"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}