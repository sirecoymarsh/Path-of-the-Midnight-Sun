GS.dataCache['A3618176202682418D7995409A85F162CE6E'] = {
    "uid": "A3618176202682418D7995409A85F162CE6E",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C13-1 Opening",
        "type": "vn.scene",
        "parentId": "6C71761C2410664EDB6BA5141884A87C6D4F",
        "chapterUid": "308CB00B9377A744EF192A255CFEC62F6D2E",
        "order": 0,
        "localizableStrings": {
            "8A4965CE37C9724C7908A9B9331A5D140175": {
                "t": "It's time... Hellios has been spotted nearby.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F0CF4AC04E510649AE5B9156E8BB10085255"
                }
            },
            "D9F322B644516942C02A9E56917B5BFF2511": {
                "t": "Faratras didn't hesitate despite everything that happened. As her sister, I can't be a burden to her, especially now!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5BBE116A5454C540709B33D53428562D5521"
                }
            },
            "DEBCFB215720634DAA48F2639C8DEC716E0F": {
                "t": "Hey, Shiori! Why the serious face?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "83C9F1B81B2D9442DD68293687C3C0FE4C08"
                }
            },
            "8F832DAA17F31740E76AE777F332D0A822C4": {
                "t": "C-Cristoph!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "517B32DA6EE9A648453B5F2992147B0C7A93"
                }
            },
            "73E0752128291641F88AF3025F93AF084203": {
                "t": "I'm fine!",
                "d": {
                    "eid": "E532A35939B182443158C0D65FB325E39610"
                }
            },
            "214DE6AF7BC7D44F40996814457CAD3DC36A": {
                "t": "I'm trying to get in the mood.",
                "d": {
                    "eid": "7EDFE8A838D4334D4F5B7067F8CDD9AE939A"
                }
            },
            "7BADF59A628CE241144A64D0B02575AAB848": {
                "t": "I'm really nervous, actually.",
                "d": {
                    "eid": "D2283F374EA653422938FFF7D637214AD91B"
                }
            },
            "C5C3F4974162E54B3F3AAD057C9E93AE7E25": {
                "t": "Haha, you seem nervous though!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "AC18CB5463F4B546953B87352D206A601AD3"
                }
            },
            "AA4EABB14B20F248065AA6F8C5A683871961": {
                "t": "Well, I can't blame you!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "83999A687AF8D2430E4B8B17F5C5F57DAC6D"
                }
            },
            "7811A59E363AA9457D1878E5FC80F3D00C85": {
                "t": "This will be our last battle, and on top of that, we're up against the Demon King.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "47A75D772F928346037BED24E1054BF069AE"
                }
            },
            "1D6D95C95EE63441E769FC541C0CB0098D6E": {
                "t": "Yeah... Sometimes I wonder what I can do in this situation.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2414F6188254C6423D1B9F0869A4E442ECF0"
                }
            },
            "BC7F1EDE8918624CC859EC064DC03A74D2DA": {
                "t": "Ah, I get it. It's that kind of mood, isn't it?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "B36570AB2706834B5158A570B5BC3B0459C8"
                }
            },
            "B1D61B545297A2468D6AB4C495DDE52C52D8": {
                "t": "Well, you're a priestess of Pylum! You should know what Lord Valonja wants!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "254AE09F8BF1D94D0038EEF8FFACC9984C0F"
                }
            },
            "EE16163312AB554EC08BF1E9D7B0E99BCF9F": {
                "t": "Umh, that we confess our sins every week?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0C08666410D7A64671984F1047CDCDBBE97E"
                }
            },
            "EAF12E594D62E941389B6341195E9C3D9F19": {
                "t": "Haha, no, silly! \"Be yourself and I shall be the light within your heart and above your head.\"",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "9AA7C67E6B5C1442FE79C8D827F25E80FD29"
                }
            },
            "15E410C510B76248D86926F6CFBBF5CCE7EC": {
                "t": "Oh... right. That's one of our teachings. But how is that relevant now?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A1C846B997F0D645EC5A47967A596C56BEA4"
                }
            },
            "2FD3BD4E6650B046F149BAF75B173BB7DDE1": {
                "t": "Haha! Don't tell me you haven't noticed?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "851FA50D80F151496C2BF1B8DF613CDB3790"
                }
            },
            "38CC730353878840193A75E342EEF9C4C250": {
                "t": "You're basically the emotional support of our group, Shiori!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "0B2E2D8508127042AB3BEF69FD683246ABB8"
                }
            },
            "ABE49265492C804A1D59F8F45C21892E8ACA": {
                "t": "M-Me?",
                "d": {
                    "eid": "A3DFF955735AF547482A4056C2A37E80BC1C"
                }
            },
            "05C9DBB34E6BE84C647B9EA9AC34B7740CB0": {
                "t": "You're too kind, Cristoph.",
                "d": {
                    "eid": "45960D1C107343498048F2083300A7A955A7"
                }
            },
            "EF0F7A3846A0714E1539204445B484DBD0D8": {
                "t": "Yeah! Is it that strange?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "697E655F37E65644162A3C11E7AC5B922BC5"
                }
            },
            "0279A2B918C4B34F1E8B8457B222556AE953": {
                "t": "Aww, c'mon! I appreciate the compliment, but I'm actually serious here.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "3FCCE520737D77483D5A9DE2A0AA6A3F4BA5"
                }
            },
            "FE45B25506EF7148123804B7401AA3F1F252": {
                "t": "I always thought that role was Rya's, or yours...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "77B177DA08CAD643CC098CF174006F6CAEF9"
                }
            },
            "97AB3C308DDD7448F55AD5C5868C52519EE0": {
                "t": "Nah. Rya is our strategist! She's a rational and logical person.\nWell, most of the time.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "7D9259DB746906452C192D480F58D85CB8F7"
                }
            },
            "2AE5AC6B8CC118407449DE0573B31D445F2A": {
                "t": "And I'm... kinda funny? Haha!\nBut sometimes I'm not good at understanding other people's emotions.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "6525B9C18155D34A88689370CF1F4BB054B4"
                }
            },
            "C7B221F08B10E84E5C0905025E6593028E4E": {
                "t": "Oh... I've never thought about it, but he's got a point.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5B1B80355BB04844275BECD256D046EA82C6"
                }
            },
            "8A944ED55599D34B834B24039949B88F555B": {
                "t": "But you! You've always supported our group with your smiles and empathy!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "74C5B96A33CB504FB84AF3E506A57D3CF4AB"
                }
            },
            "060F7809441CF141E65B3B6639FFFBCEF39D": {
                "t": "So... You just do you, and everyone will be fine! Yourself included!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "FC173BEA32B33346773839499AB01964464F"
                }
            },
            "A259F69B67A638401F68B778F305C0CC4F87": {
                "t": "Do you... really think so? I feel very different from when I started this journey.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "79DC169803EE9141E78BA5654587A5B18CCE"
                }
            },
            "CA6DAE846C35044B3F7A72923B4CD0641414": {
                "t": "And that's totally fine! We've all changed!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "E7163CB080CFA8434358E6510939C024A612"
                }
            },
            "1A83C4030F1A1542D0788F231D07D9B8ECA5": {
                "t": "It's not the first time that I've had this conversation. Nini, Faratras... everyone keeps supporting me.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F104B0834157C545713AD12550B1CCD53E39"
                }
            },
            "0C916D8785AFC243A21BC773C3BFDA70F937": {
                "t": "You all keep telling me that.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C09EB48C630514463E680CE76BF3F7B42E55"
                }
            },
            "F58783BB9C68E74EE13BC432FC03177EA20B": {
                "t": "Believe in yourself.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "49C9F7FE58ECD042833B40F2D08CA11A94BB"
                }
            },
            "33F113F94870194C42482E53AEC300622B7F": {
                "t": "... ... ...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0513BE890A01374D927B3DF7306ECB4B5CB5"
                }
            },
            "DFAA9E4638F3464BFB486F0892983A0596EF": {
                "t": "Stop feeling sorry for yourself, Shiori Leblanc.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "14B09B1A5BFD11407D9850536E00109936FA"
                }
            },
            "B84B65A76BEDD44777288852B3331FF52D0D": {
                "t": "If you can't trust your own judgement, then... Try listening to the voices of those who're there for you.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9A504CD339BE294D42699C61FE91A26AAEBC"
                }
            },
            "96EEA0500F06D2442E291F747A98212515FC": {
                "t": "What I should say right now is...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D17925D77DD960457F7990D7EFD74A21AAFB"
                }
            },
            "699BD38A8A1F144347884D753C3CA7135625": {
                "t": "Teh heh! Thank you, Cristoph.",
                "d": {
                    "eid": "DB174F4255065740142A04872749ADEF244C"
                }
            },
            "F40CAE4F96B6F049D55AB6397A73DE33B193": {
                "t": "Time for this priestess to shine, then!",
                "d": {
                    "eid": "419BDEA537870848762B85202BD7FC70D400"
                }
            },
            "0461A8A356A53846838B95612CAC5485F36D": {
                "t": "There. That's better already!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "6FFB53DD7FE422420B6985924B18B2F71DB7"
                }
            },
            "F67212901BB1A948CE8A85285691A7CFCBB1": {
                "t": "I... by losing my power, I thought I had lost myself.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9CC030E14852B943BC182F01391D9D5BBC4F"
                }
            },
            "47D4A47456BE464DBE79D0D3745A54CD2865": {
                "t": "But maybe, unlike Fa or Nini, I can... still consider myself who I was in the past.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "AE7196535BA83449C15B8EA2ECEF55032B67"
                }
            },
            "E26DBC781909274D351A1321F88C23801167": {
                "t": "I've just been a bit... {SP:1}{C:1}blind{C:0} about my whole situation, teh heh!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "410A5DEC24ABB24AB54B2926DE462875B36F"
                }
            },
            "477C6A78574E5743ED1A71E678A2A68706E8": {
                "t": "That's my girl!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "C63FC15656A9D5440C5B187659168946E5DD"
                }
            },
            "3B93BD0577BB434B4A28B271CA6DBFB3D004": {
                "t": "Thanks, Cristoph. It seems I only needed this last little push.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "18F423BD0C9DE94093489C287A3EDB2319B9"
                }
            },
            "64A60EC20382A245EE6A73A10FD51DF3B177": {
                "t": "Even if I'm different... Even if I can't understand others like I used to.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E1E4747D270A804FF16BF0F6C871777C51BD"
                }
            },
            "80BB5855843140437C7AC4D25F20F83D5FB2": {
                "t": "I will keep supporting them in this last battle!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0E9C45239739584F037ACD0252CCDC23A058"
                }
            },
            "022130059026D94AD92945A2D402397E2215": {
                "t": "Are you ready?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "564312AF1E594241498B5566EEB2FC0443EE"
                }
            },
            "5630B42D73B0454554381EE6062876884DAB": {
                "t": "Good evening, Rya.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CB0C48A12886534A807B88B8F0E3BDEE37C2"
                }
            },
            "706665E0388B26467F296D453D98BA3F7BFC": {
                "t": "How are you?",
                "d": {
                    "eid": "A9F058F3308EC74BB57B5307E09C1D565EDE"
                }
            },
            "EBA8200E27A5F046F64810F5E98BE4C6F720": {
                "t": "You look pale. Do you need anything?",
                "d": {
                    "eid": "86365EC61ADF3646C44B34B8FDC84F62D831"
                }
            },
            "2E505551185257432938BB4909E4E33C575C": {
                "t": "Do you need a massage?",
                "d": {
                    "eid": "B92ED14A8AAC3442AF9AFD24BA3173DCA7AF"
                }
            },
            "4CCDAE3140F7C14E921A0F3590530352DDC0": {
                "t": "I'm... fine.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "31F09D8F5F92C4428B9B7C05E1BAD1D8D1B9"
                }
            },
            "CDA033047CDED648F41917F05378E5C3E976": {
                "t": "No, I'm... just a little hungry, actually.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "76364DFB0B88324A464AA23323274065C6FF"
                }
            },
            "CFEB0192616A65475688A9926F9D5D3AB636": {
                "t": "What!? You should watch what you say, Shiori!",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "FA8702D79C4AF14F3D28C2440E87672D959E"
                }
            },
            "1A67F67C625089492989C1D2AFDA40F19A50": {
                "t": "Is her back that sore? I don't understand her reaction...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5FA8B0277973E443066A1581986A3E186241"
                }
            },
            "7ED1C66A84B4F14CC048DE434630A7A9C53E": {
                "t": "Anyway, what's with you all of a sudden?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "692A089532DD034DF8598D75C150BF549AB7"
                }
            },
            "7ED8DCC842342749C948D17610E2ED8DE336": {
                "t": "It feels like a big weight has been lifted off my shoulders. And it's all thanks to Cristoph!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "57AA5C563AB7644E3B6BDF03935C309DB8B8"
                }
            },
            "7F9E65B5845B714EA438DDB369EAAA4C46F3": {
                "t": "Hey, every now and then I do something good too!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "F3D3672220E7C44671282C63DB4C250EA6EB"
                }
            },
            "5D36B5AF7EB50241920A04B699741DA6BCEC": {
                "t": "Hmph. I won't deny it...",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "6C7E57CE99205945601B2F94FF7FFBC6FDA9"
                }
            },
            "6F02E5A886073445EA583A0551405B2A74A4": {
                "t": "I'm glad you two are in good spirits. We have a brutal battle ahead of us.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5EA2C5F427038445C849975441784D92B992"
                }
            },
            "FFF1F2B9324BF844331A1EF20F0EAE1AAA6F": {
                "t": "What's the situation?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "40B17DEE6E4FF84B8939D044F98B54F55055"
                }
            },
            "7C6615983207334FEC6AFC75C03AB4F376F7": {
                "t": "The forces of Magnolia and Pylum are containing the hordes of monsters surrounding the forest.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "001E86CB1626764AEE2BB219CCC383790395"
                }
            },
            "C362DA9642B2B447DB1800E88C859CA0E25A": {
                "t": "If everyone is gathering here, that means...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "913BEACD8F804149074A4F5559C8A927BA90"
                }
            },
            "31B786C37CA0544BF36A9E17041D38483153": {
                "t": "Yes. Elias Lehmann is close.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7BCCD9CA5CC38546E15B75D8FB1B27FAD531"
                }
            },
            "2AB7F62023FCE44EEB1A65F4A79582C754EC": {
                "t": "This is it! I can finally smash his face in!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "B7AAF1734ACD4044854A7786B4E421CC6073"
                }
            },
            "D4025DA972A3284ACA1A007520F45FA4B856": {
                "t": "Hehe! Where are the others?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "594B73B923AF77421C2BDE630F9E19EE97B1"
                }
            },
            "ED1B9BB62B7392462889DA6749E1B6D85C1C": {
                "t": "Still in their tents, as far as I know.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "E702713F38929449996AD038918DA7FF80FD"
                }
            },
            "4E6E3306252B3042C88883D0C3E2EDE445A5": {
                "t": "They must be preparing mentally for the battle ahead.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6DE7566D28B200437F0816215EF166DCD464"
                }
            },
            "6A4D54FF2C9FC347F68A6EB6CF46727E5DA8": {
                "t": "This is going to be tough for everyone, but especially for them.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E55505D15C8B554E8F79DFB7A40D6EFF5CC4"
                }
            },
            "DEB8374656B2D448928B4F384A674BA6199F": {
                "t": "Maybe I'll go check on them.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "ACD18A7C95A3E64F6F49E347E2A12F043A17"
                }
            },
            "44CCFBE28F87564C9E5992D220D0FA620433": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EB4EBCA699EF174743686E79E4267C43DDDB"
                }
            },
            "CAEFA09C9BE74540E178D153AF9BC045089A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F893B0220C497640939BEFF32D2ECA16C0D8"
                }
            },
            "B2431EB33C7A254DAE68DD259A5BAF532E22": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "14FB286547CFE343917B0DF5442C8C0E77FB"
                }
            },
            "88DEEEB68918624F527A0096E5147098E47E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9320D9123B3E964EE928B812B63EC953B133"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "SHIORI'S POV"
                },
                "indent": 0,
                "expanded": true,
                "uid": "94B2CBB202A2C2464679C7E855E2341B9AFD"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-briefing on the situation\n-Shiori's worried for her comrades\n-Rya tells to talk to her for a discussion"
                },
                "indent": 0,
                "uid": "00C52C1C550FA749F37A5B52B96B57C37143",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "1973746B6946C44E2B7B14F666F8FC09D52D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E137F11191E4B640F4291E052EED27929E0A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "FEEB28CE186A3342E70A634062AF25688319",
                        "name": "1 - Luckos"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "5FD1809E8336E947FE3972388B8B3F62F76A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "C29123EE984170468C795185EB487A899979"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "1601A15F4798844B619A201150AFDDA22DA0"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "BE116DAB3FD36248426BF3040CD62CB9B302"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EA00A14B490C5840685811B73FE338103297"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8C26D0D58AA39048AA1947B944D52815CCEB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "15D73C9D8DF9F1421F3B7BD58539199127AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAD335B912C3E4400B791FB5787A386EDA6D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "BDEDFE9A12F83044AA090733BDF8EC3DBCA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C301967E51CA63475D880DD755E3338E07A7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "D9AF6F765671B24E703A80502DB2DE4D2C2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BFC3132455D2444EC2936029888561B32EB",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBC7F16C1DBA354F20786A05422F74BBE4B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A66601E4C52384B887B9BD4CA2A54E09A88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "869F3BF078BBE249BC191A7541E46F6324EF"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "03E45FAB951D154B788A38A25AE2021FCC1B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "ACF1B85C0ED7A84859594F63E76F8402D474"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C6668DCF638BC3408578FEB1038DF916DE74"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "CCE0195924D69840317A4C7646FA3B9BFE56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "56D9164D29B2B94ADA48C2C49AF1CBCB9DCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0066474C5E214743833A70A439BCCBCC755A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A32B12714EE984FB9698741C6F2EA0F95BE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A4965CE37C9724C7908A9B9331A5D140175",
                        "defaultText": "때가 됐어... 헬리오스가 근처에서 목격됐어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0CF4AC04E510649AE5B9156E8BB10085255",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46DA31B281C8C24792193ED7A9E92DD50CED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9F322B644516942C02A9E56917B5BFF2511",
                        "defaultText": "그 모든 일을 겪고도 파라트라스는 망설이지 않았어.\n언니로서, 특히 지금은 그녀에게 짐이 될 수 없어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5BBE116A5454C540709B33D53428562D5521",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C17EC6018E627945611BFCD636BFE05B322E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            550,
                            0,
                            801,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8337BD233B2924C7059C803B98953001CDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76AD83925883E6413F68B3B33247F953F707"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "306AA3C573ED654AF26A391645BD8009AA8A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 33
                },
                "indent": 0,
                "uid": "5F4CBB478483924E1E7A25F25488E84A94E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AB2BBD2882BF9048669BD1F69BB0EF1CDBA1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44CCFBE28F87564C9E5992D220D0FA620433",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "E3-Cristoph_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB4EBCA699EF174743686E79E4267C43DDDB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "829CCC2C10EE844BC76A4E48DBF92890EC2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90AF2D8D65E0884E551B82D4D17129A7A7B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DEBCFB215720634DAA48F2639C8DEC716E0F",
                        "defaultText": "이봐, 시오리! 왜 그렇게 심각한 표정이야?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "83C9F1B81B2D9442DD68293687C3C0FE4C08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "113DEA822A792847728AB0E0A785624226C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "383EEFEA1862D84AF17B53731F813917D3EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAEFA09C9BE74540E178D153AF9BC045089A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F893B0220C497640939BEFF32D2ECA16C0D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EF5C2A0E378715451B3B09B1D08D8A431A53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "238847F344427847B80BC3721795A0AF59FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F832DAA17F31740E76AE777F332D0A822C4",
                        "defaultText": "크, 크리스토프!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "517B32DA6EE9A648453B5F2992147B0C7A93",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7364989599DED644AB5AF055D5A94393F4A3"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "73E0752128291641F88AF3025F93AF084203",
                        "defaultText": "난 괜찮아!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E532A35939B182443158C0D65FB325E39610",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "214DE6AF7BC7D44F40996814457CAD3DC36A",
                        "defaultText": "각오를 다지고 있었어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7EDFE8A838D4334D4F5B7067F8CDD9AE939A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7BADF59A628CE241144A64D0B02575AAB848",
                        "defaultText": "사실… 너무 긴장돼."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D2283F374EA653422938FFF7D637214AD91B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "fine",
                            "not fine",
                            "not fine",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3472A608CC1974B062A7308C1612B31DCFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "768EA6658D4154446B3A11F9CCF5D7756573"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fine"
                },
                "indent": 0,
                "uid": "6818C3EA1280B746BF19CB74AFC22A2FBEE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2BED171194CC540634810D1C8F2056C8393"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C5C3F4974162E54B3F3AAD057C9E93AE7E25",
                        "defaultText": "하하, 그래도 긴장한 것 같은데!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC18CB5463F4B546953B87352D206A601AD3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92859D772EA94349D35B0799805CFED2EAF0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not fine"
                },
                "indent": 0,
                "uid": "AD34E2738715F74E3A48CCF6CB40497487E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E83840876FA7C140B62B3263F40850FDB416"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C7327C74B30D644410B3F431CBF659D5A4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A24E98F6F1038448E983E89D3402C096558"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AA4EABB14B20F248065AA6F8C5A683871961",
                        "defaultText": "뭐, 그럴 만도 하지!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "83999A687AF8D2430E4B8B17F5C5F57DAC6D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "587B40887BF5014E4A89AD13076FE9FDEFD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7811A59E363AA9457D1878E5FC80F3D00C85",
                        "defaultText": "이번이 우리의 마지막 전투인 데다 상대는 마왕이잖아."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47A75D772F928346037BED24E1054BF069AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F85406073E547426E0AFE57F5B994F89E9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF0DD9AB09A9F9481A485295657321B9A0F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D6D95C95EE63441E769FC541C0CB0098D6E",
                        "defaultText": "응... 가끔은 이런 상황에서 내가 뭘 할 수 있을지 모르겠어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2414F6188254C6423D1B9F0869A4E442ECF0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40B98AB466CA1445B77944C66909EA10AACB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "970B0BD833A7654EE28B44218E003D67F47C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC7F1EDE8918624CC859EC064DC03A74D2DA",
                        "defaultText": "아, 알겠다. 지금 그런 기분인 거지?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B36570AB2706834B5158A570B5BC3B0459C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67E23AD20548194197588E5296A1060B31B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2E85B4F4F2B974F126975877F16B718515F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE32F07A2E06A349891827C097B23E55A5A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1D61B545297A2468D6AB4C495DDE52C52D8",
                        "defaultText": "넌 파일럼의 사제잖아! 발론자 님께서 무엇을 원하시는지 알아야지!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "254AE09F8BF1D94D0038EEF8FFACC9984C0F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CA923233FF78840F31BD0D4760E249AADEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E3C0B57748BC646B05A6DB84D3447DBE427"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE16163312AB554EC08BF1E9D7B0E99BCF9F",
                        "defaultText": "음, 매주 죄를 고백하는 거?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0C08666410D7A64671984F1047CDCDBBE97E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6042886747E9C64B132ACF4346027D9975AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A38B80AF6134514B778B61A03B836F5665C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EAF12E594D62E941389B6341195E9C3D9F19",
                        "defaultText": "하하, 아니야, 바보야! \"너 자신으로 있으라.\n그러면 내가 네 마음속과 머리 위의 빛이 되리라.\""
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AA7C67E6B5C1442FE79C8D827F25E80FD29",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89C4816B4FBA174B5228A401D31C0BE6254B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "531515991DB798447B39AB96C02F0B28FB51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "15E410C510B76248D86926F6CFBBF5CCE7EC",
                        "defaultText": "아... 맞아. 우리 가르침 중 하나지. 그런데 지금 그게 무슨 상관이야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A1C846B997F0D645EC5A47967A596C56BEA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DB8480254B52846BD1A98E31DEB25FF14C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2D6BAAA3319C4446B692EC889E84423AC21"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BD7581403A0D44536181902CE02DB351FD9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "667AE17E1119B04968092B66FE3FB10C3E0F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2FD3BD4E6650B046F149BAF75B173BB7DDE1",
                        "defaultText": "하하! 설마 아직도 몰랐어?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "851FA50D80F151496C2BF1B8DF613CDB3790",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "568D621F3780524FF46ABCC791DE6143539A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "424ABB346DD981445888EF82840B754561E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "38CC730353878840193A75E342EEF9C4C250",
                        "defaultText": "시오리, 넌 사실상 우리 일행의 마음을 지탱해 주는 사람이야!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B2E2D8508127042AB3BEF69FD683246ABB8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FA49E2115570148614868B717E3AB290557"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "ABE49265492C804A1D59F8F45C21892E8ACA",
                        "defaultText": "내, 내가?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A3DFF955735AF547482A4056C2A37E80BC1C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "05C9DBB34E6BE84C647B9EA9AC34B7740CB0",
                        "defaultText": "과찬이야, 크리스토프."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "45960D1C107343498048F2083300A7A955A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "normal",
                            "compliment",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5E4772F5897B348E299CD859461D4B9259A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "023A099F3BB29849293927405685E7B23407"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "normal"
                },
                "indent": 0,
                "uid": "A579F7E41442A14BFE49B9257ACBC241CC53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6D6D1D65DF5E143724AE2A595D37FF2199E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF0F7A3846A0714E1539204445B484DBD0D8",
                        "defaultText": "그래! 그게 그렇게 이상해?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "697E655F37E65644162A3C11E7AC5B922BC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85ABCA0A1C3B824F827B86B39A54783BB56A"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "C5D8BCF68DD7414C385ACBC178D98FB54189"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "compliment"
                },
                "indent": 0,
                "uid": "FC9B611E3941614BAF3825B268B21DF80D52"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "3ED1AAA477D052418A1B521794FCA82A7C23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4A54FB51DA2874B831A18E1B6461D724CCB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0279A2B918C4B34F1E8B8457B222556AE953",
                        "defaultText": "아이, 정말! 칭찬은 고맙지만, 난 지금 진지하다고."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3FCCE520737D77483D5A9DE2A0AA6A3F4BA5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36F7D1B098A8364F4A8B6253012105DB67E9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "411421DD2760574E277B9EB4A93C36513481"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AF1116A95720642253B64C77414D4BA235B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE45B25506EF7148123804B7401AA3F1F252",
                        "defaultText": "난 늘 그 역할은 리아나 네 몫이라고 생각했는데..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "77B177DA08CAD643CC098CF174006F6CAEF9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE1D570C28D4C84ACD0AB291D714CD8B593F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F05C7C9505384438A2909D995AB8A38D264"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97AB3C308DDD7448F55AD5C5868C52519EE0",
                        "defaultText": "아니. 리아는 우리 전략가야! 이성적이고 논리적인 사람이지.\n뭐, 대개는."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7D9259DB746906452C192D480F58D85CB8F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5243DF820A54D445A57A6907B074AC52D187"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E5C92288848F6400F492EC3CA6EBDB11CBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "938F0802127FF149307901B55ADA1F94FFE5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AE5AC6B8CC118407449DE0573B31D445F2A",
                        "defaultText": "그리고 난... 좀 웃긴 사람이고? 하하!\n하지만 가끔은 다른 사람의 감정을 잘 이해하지 못해."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6525B9C18155D34A88689370CF1F4BB054B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62341A3E895EC142516A20159CDEF43662F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B55BD41E708C1048EE69F492521F60CD0441"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C7B221F08B10E84E5C0905025E6593028E4E",
                        "defaultText": "아... 생각해 본 적 없지만, 일리가 있어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B1B80355BB04844275BECD256D046EA82C6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75EE494A0497164121483121732A5D381D25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A4AC70859D42D342944821F510D0DBA19AA9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2431EB33C7A254DAE68DD259A5BAF532E22",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "E3-Cristoph_line13_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14FB286547CFE343917B0DF5442C8C0E77FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8391E0CB9F003546624989100B251B8734CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3782D9C8560201475C88AE6801B15C2ED5C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A944ED55599D34B834B24039949B88F555B",
                        "defaultText": "하지만 넌! 언제나 미소와 공감으로 우리를 지탱해 줬어!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74C5B96A33CB504FB84AF3E506A57D3CF4AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B22F3CEF9D43F44CAF5BFE17F3BFBF9F0BCF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "060F7809441CF141E65B3B6639FFFBCEF39D",
                        "defaultText": "그러니까... 그냥 너답게 있으면 모두 괜찮을 거야! 너 자신도 포함해서!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FC173BEA32B33346773839499AB01964464F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6386D1215E19A34C012B9010739C6E4C2FAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48AFF80D1A08B54B4E3A9CC768773A0B38A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A259F69B67A638401F68B778F305C0CC4F87",
                        "defaultText": "정말... 그렇게 생각해? 여행을 시작했을 때와는 내가 너무 달라진 것 같아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79DC169803EE9141E78BA5654587A5B18CCE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFD724BC2480214A857ADC87950F57553E21"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80EAE222107721431C3A9E650E6AAFA1E3A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "353EA2CC7789114E5C69E714805F7D86313D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B94A65E34DB2014AAA9A6E64463A07FCEB93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA6DAE846C35044B3F7A72923B4CD0641414",
                        "defaultText": "그래도 전혀 문제없어! 우리 모두 변했으니까!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7163CB080CFA8434358E6510939C024A612",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "983639995EBCD64EE889F7A39A7E1735791D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEF0C5BB5603594CAB4978D0109B2908B224"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A83C4030F1A1542D0788F231D07D9B8ECA5",
                        "defaultText": "이런 이야기를 듣는 건 처음이 아니야.\n니니도, 파라트라스도... 모두가 계속 날 응원해 줬어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F104B0834157C545713AD12550B1CCD53E39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89D9F95C6E036147B04BAF75F451CAA8DD84"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C85034865134D24E924A16A86E44ECE48CA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C916D8785AFC243A21BC773C3BFDA70F937",
                        "defaultText": "다들 계속 그렇게 말해 줬지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C09EB48C630514463E680CE76BF3F7B42E55",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4537C2C18CBD741595A2D87CC0483BFA89C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "877C3BAD8C5B934D6C49C70728EFFDB8BEFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A424E5248541324D9A1836D14F7FF0FC329D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F58783BB9C68E74EE13BC432FC03177EA20B",
                        "defaultText": "자신을 믿어."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "49C9F7FE58ECD042833B40F2D08CA11A94BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DE67E9541CF7042AB2A7805DA6DEAF6DBB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B24788381A197546BE189F961E62916BA814"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33F113F94870194C42482E53AEC300622B7F",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0513BE890A01374D927B3DF7306ECB4B5CB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FDFA9414CD8564DCF48ABF9D26B298E35B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DFAA9E4638F3464BFB486F0892983A0596EF",
                        "defaultText": "그만 자기 연민에 빠져, 시오리 르블랑."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14B09B1A5BFD11407D9850536E00109936FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "796F05F04A20294C446848C0559674C54768"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B84B65A76BEDD44777288852B3331FF52D0D",
                        "defaultText": "자기 판단을 믿을 수 없다면...\n곁을 지켜 주는 사람들의 목소리에 귀를 기울여 봐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A504CD339BE294D42699C61FE91A26AAEBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAEDADEF5FF7874F4B69A242C0A90FF671E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "3CE99AB26C32484E68795F431B8AA3CF74FA"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "03FBE679646AB9445388F9B439CD7B65AE23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5679BAE1BDA31440D2BAEA8EABEFDAB7B4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96EEA0500F06D2442E291F747A98212515FC",
                        "defaultText": "지금 내가 해야 할 말은..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D17925D77DD960457F7990D7EFD74A21AAFB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "58023643071C91438E3B9F44C8D1091B62DB"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "699BD38A8A1F144347884D753C3CA7135625",
                        "defaultText": "헤헤! 고마워, 크리스토프."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DB174F4255065740142A04872749ADEF244C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F40CAE4F96B6F049D55AB6397A73DE33B193",
                        "defaultText": "그럼 이 사제가 활약할 차례네!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "419BDEA537870848762B85202BD7FC70D400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "40F6D072499A914D568B0D3193BBAE260FFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A7A708D88C39684CE5388EF127F9824B054E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "7FC8B3D7910FE54B478BA3C6AF0BA6F4CB92"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "music change"
                },
                "indent": 0,
                "uid": "4CDCD8A047AFF149932B8ED8B7F7D1E269ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0,
                            7,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50BBBE8C23E3324634881302C6B87F05F233"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A2AAD472C771343468B70D6A0FA21ED962C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEA282B0600646453E08CEC51988A8D29FE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4CA481B8FA6D642E988B727A6B711621056"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0461A8A356A53846838B95612CAC5485F36D",
                        "defaultText": "그래. 벌써 훨씬 낫네!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6FFB53DD7FE422420B6985924B18B2F71DB7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E0414AC4C82C74D2C6B5A31841A867AEC75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "372A0C2D373682445A793BC5517E5790210F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F67212901BB1A948CE8A85285691A7CFCBB1",
                        "defaultText": "난... 힘을 잃으면서 나 자신도 잃었다고 생각했어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9CC030E14852B943BC182F01391D9D5BBC4F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FD1B6366AA7F346D15B14D5117F949C39E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "47D4A47456BE464DBE79D0D3745A54CD2865",
                        "defaultText": "하지만 파나 니니와는 달리, 나는...\n아직 과거의 나와 같은 사람이라고 생각할 수 있을지도 몰라."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE7196535BA83449C15B8EA2ECEF55032B67",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B2D89D97C96A346202B52889FC3A38FAB32"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E26DBC781909274D351A1321F88C23801167",
                        "defaultText": "그저 내 상황을 두고 조금... {SP:1}{C:1}눈이 멀어{C:0} 있었던 거야, 헤헤!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "410A5DEC24ABB24AB54B2926DE462875B36F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A0ECC8D3C1AE245A6795637BF817527D29D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B0FD5F36831B74C4A482AD09878F9D0284E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "477C6A78574E5743ED1A71E678A2A68706E8",
                        "defaultText": "그래야 내 시오리지!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C63FC15656A9D5440C5B187659168946E5DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94D493C359C60742E21A4B154CF3B4C0F34B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5188E5C0029CD7498C2AEE09725B0D8F1B51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "88DEEEB68918624F527A0096E5147098E47E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9320D9123B3E964EE928B812B63EC953B133",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "45AD635185906043133B6D83C979918EFB22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4AE398328805145AD6901E10626E6CB0D78"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B93BD0577BB434B4A28B271CA6DBFB3D004",
                        "defaultText": "고마워, 크리스토프. 마지막으로 살짝 등을 밀어 줄 사람이 필요했나 봐."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "18F423BD0C9DE94093489C287A3EDB2319B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A922269919BC6547EA9AB0B3F1E6C74E606F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27338EAB9C1B354F2B4A69790F13A56549EA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64A60EC20382A245EE6A73A10FD51DF3B177",
                        "defaultText": "내가 달라졌더라도... 예전처럼 다른 사람을 이해할 수 없더라도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E1E4747D270A804FF16BF0F6C871777C51BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89236A067AA4D2481829BFF828F3AA3DFC3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80BB5855843140437C7AC4D25F20F83D5FB2",
                        "defaultText": "이 마지막 전투에서도 계속 모두를 지탱해 줄 거야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E9C45239739584F037ACD0252CCDC23A058",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A957B1F3B66904C253941B3E4B0C3EB9A74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A017EBD94AE8014F0039F2E3ABB64E6F2A11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AC28E9078B1A748E31A9E79E987D4477E8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F39B10CA657AF241F11865E6EB5893BBD160"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "022130059026D94AD92945A2D402397E2215",
                        "defaultText": "준비됐어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "564312AF1E594241498B5566EEB2FC0443EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA7D81993BD2D94C3C68C935DB433CEB99E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8359BBB14ED22547316964A24AEBD827F936"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "5B3C5B804E23E84BC008C3F79F8661D7E0F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            550,
                            1,
                            0,
                            -100,
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05B74C6B7256D44BFA79BB274A9CAE049C31"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "A75C40E39C73554D823A65617A129C7226DE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Rya appears"
                },
                "indent": 0,
                "uid": "9864C72F70023948EB4BDEC5265AC56EBCD6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B029FF94AE1F343F078759396EA32E81A03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85D4829924D29644DC08D477A0A3DE9D3190"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5630B42D73B0454554381EE6062876884DAB",
                        "defaultText": "좋은 저녁이야, 리아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CB0C48A12886534A807B88B8F0E3BDEE37C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "25DE2CBD6201E64D4A480957D6370C461D7B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "706665E0388B26467F296D453D98BA3F7BFC",
                        "defaultText": "오늘은 어때?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A9F058F3308EC74BB57B5307E09C1D565EDE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EBA8200E27A5F046F64810F5E98BE4C6F720",
                        "defaultText": "얼굴이 창백한데. 필요한 거 있어?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "86365EC61ADF3646C44B34B8FDC84F62D831",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2E505551185257432938BB4909E4E33C575C",
                        "defaultText": "마사지라도 해 줄까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B92ED14A8AAC3442AF9AFD24BA3173DCA7AF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "how are",
                            "pale",
                            "massage",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB9A408156370848C46825685F45177FAFF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9EBDC6EE7DF1C9404E9A15E4D5AC51E9418A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "how are"
                },
                "indent": 0,
                "uid": "AB2A832C6A725745459BA612F1F8C62B8094"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA59673F47161841AA39AF96DC38E3D0DCE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CCDAE3140F7C14E921A0F3590530352DDC0",
                        "defaultText": "난... 괜찮아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31F09D8F5F92C4428B9B7C05E1BAD1D8D1B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1578B0CB38E3664FFC7BFD205148A728ACE7"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "0F5A103C259E8344698BF71489CFBD65F983"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "pale"
                },
                "indent": 0,
                "uid": "2E15C33069DA7942B02B4033750980D2D31C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CA8001628D6D44098993F0110E7A52C222D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDA033047CDED648F41917F05378E5C3E976",
                        "defaultText": "아니, 사실은... 조금 배가 고파."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "76364DFB0B88324A464AA23323274065C6FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "438BE5EF76E3A0425C585BE5B1B13B21C370"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1521A61208F6304F6E3A491360E6E45ADA08"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "massage"
                },
                "indent": 0,
                "uid": "1B63D24D3DEA094E188BF868414B91FC19EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            5,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB3B27BC4655A64CC22AE6C913292CE54D7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06F7590835E8914D9C18C813233259CEFB82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EFB7AEED76CB784BBF78A09840F714E6FF42"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CFEB0192616A65475688A9926F9D5D3AB636",
                        "defaultText": "뭐라고!? 시오리, 말조심해!"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA8702D79C4AF14F3D28C2440E87672D959E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09E99FE5427B4146B62B35B56CCAF0816584"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "597DEC442969224A252BE0B326FE7F4A12E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A67F67C625089492989C1D2AFDA40F19A50",
                        "defaultText": "등이 그렇게 아픈가? 왜 저런 반응인지 모르겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5FA8B0277973E443066A1581986A3E186241",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FA08E8D1DC8B444D44B0D487C216BF74140"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "FDFCFFE65D60714E1E493416E4B1CE44C9A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7BD54291D8D6646898BB5F23F1DB039EB4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2461A1812535F64683895F525688C191EEEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F755E7574461446D23BFF574378F266FFD3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0F1F14387F92541FF786B6122FF0A6AD905"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "716555920986844A026A5C831DC2D5E16C2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7ED1C66A84B4F14CC048DE434630A7A9C53E",
                        "defaultText": "그건 그렇고, 갑자기 왜 그래?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "692A089532DD034DF8598D75C150BF549AB7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C75C56B64845E445508A68B5737524990BB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "717AFC1D8BC7004E604963F769F694EAEDDC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7ED8DCC842342749C948D17610E2ED8DE336",
                        "defaultText": "어깨를 짓누르던 큰 짐을 내려놓은 기분이야. 전부 크리스토프 덕분이지!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "57AA5C563AB7644E3B6BDF03935C309DB8B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "361964B71C64734062189BF295716F1300A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CD463814E48104E124AAA5822066E284123"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F9E65B5845B714EA438DDB369EAAA4C46F3",
                        "defaultText": "이봐, 나도 가끔은 좋은 일을 한다고!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F3D3672220E7C44671282C63DB4C250EA6EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C309235F8E6BC1414B99CCE2681ACE9C1836"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "881935CF2858994AF99B185232EEED703361"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D36B5AF7EB50241920A04B699741DA6BCEC",
                        "defaultText": "흥. 부정하진 않겠어..."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6C7E57CE99205945601B2F94FF7FFBC6FDA9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FD3DD884210E8410C8BAF45CBD965911967"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F02E5A886073445EA583A0551405B2A74A4",
                        "defaultText": "둘 다 기운이 좋아 보여서 다행이군. 우리 앞에는 혹독한 전투가 기다리고 있어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5EA2C5F427038445C849975441784D92B992",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6905A6A1176B4546AA3A15357BBB0A5B4194"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "125FFF5B92E945460E394DD15BFF0B9867F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFF1F2B9324BF844331A1EF20F0EAE1AAA6F",
                        "defaultText": "상황은 어때?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "40B17DEE6E4FF84B8939D044F98B54F55055",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "999953B52DF3214B8E7BD784A6253667FE30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A95004307E50014A294927F2D390F6433542"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C6615983207334FEC6AFC75C03AB4F376F7",
                        "defaultText": "마그놀리아와 파일럼의 군대가 숲을 에워싼 괴물 무리를 저지하고 있어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "001E86CB1626764AEE2BB219CCC383790395",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11C628F19C59124A4618B5F5DC1296E5B79F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C1F336045065645191AC547BE0FFA06566B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C362DA9642B2B447DB1800E88C859CA0E25A",
                        "defaultText": "모두가 이곳에 모이고 있다는 건..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "913BEACD8F804149074A4F5559C8A927BA90",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C3475D9383F7643C80BBAB646AC62248755"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3547BF140E0854CF86B0247EA71013ECA89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71F37B74116D554B2A28CFE87F38233FE283"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2F55F6187894145B759EFF2A119F65C5FD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E73399890F19E74BA58869C8D92FB6E2D5D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31B786C37CA0544BF36A9E17041D38483153",
                        "defaultText": "그래. 엘리아스 레만이 가까이 있어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7BCCD9CA5CC38546E15B75D8FB1B27FAD531",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D5E36060A86A241FB1A4572564FC89042D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A29CD97B9A252043522A3893E2B882382AAB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C2B785FE5028394B496AF8770F40B2D84D50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD31C8FC5BAD7148C35A38E35B2E725D4E54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AB7F62023FCE44EEB1A65F4A79582C754EC",
                        "defaultText": "드디어구나! 이제 그 얼굴을 실컷 두들겨 줄 수 있겠어!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B7AAF1734ACD4044854A7786B4E421CC6073",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA902D7466C7D348646834B79091B9F810A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F87D269D122C824CE60B71D4A0C088DF86E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4025DA972A3284ACA1A007520F45FA4B856",
                        "defaultText": "헤헤! 다른 사람들은?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "594B73B923AF77421C2BDE630F9E19EE97B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DB92AA540B365414B683DA63BAF85FA08A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8C868EB3C02114EBD3BA9A17B0BB845766A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ED1B9BB62B7392462889DA6749E1B6D85C1C",
                        "defaultText": "내가 알기로는 아직 각자 천막에 있어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E702713F38929449996AD038918DA7FF80FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "453AB4822C8CE54A0C6BDDC7FCD06E6215EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACF21C9A45A4D74A1E1AB9356131331B68B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E6E3306252B3042C88883D0C3E2EDE445A5",
                        "defaultText": "앞으로 벌어질 전투를 위해 마음을 가다듬고 있겠지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6DE7566D28B200437F0816215EF166DCD464",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F6647887EBAC844D30A2F01514AE67C39EA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A4D54FF2C9FC347F68A6EB6CF46727E5DA8",
                        "defaultText": "모두에게 힘든 일이겠지만, 특히 그 둘에게는 더 그럴 거야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E55505D15C8B554E8F79DFB7A40D6EFF5CC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C5679ED2F066143671B1575E3529B3A0E78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1A597B000A39644EF7B4F33B6E546129329"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DEB8374656B2D448928B4F384A674BA6199F",
                        "defaultText": "내가 가서 한번 살펴볼게."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACD18A7C95A3E64F6F49E347E2A12F043A17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BA15194E4EC5F647714BF9251B6057C81F3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AC8262B65D28346136B2E697421808D40F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6700F546E071346E76B5FF42929F005F436"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "59C19B7C21BB0645588817C6B944BF5EAF43"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E26609BD0B869847AB09E890FEF9F7069F29"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "9376931C8ADCA04EB85859B8CE06E93CCECA"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9A2EE7158E10104CE18A7747E2A769659AF2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D806CE7E30B6814B86688577095CBC639104"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EBBBD21C835A8549AB794FB7C1212E74CB9E",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C16F9F28734AB94D36980E631B1E51454E80"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2300F6BD2F7CD6418E4BA4F2F3DD3C866065",
                        "name": "C13-1b Encampment (Exploration)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AB192A8323798041D47911A124E68BDE9378"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}