GS.dataCache['8E2BDE5481CF73401488BE038D9D3BEF8EB4'] = {
    "uid": "8E2BDE5481CF73401488BE038D9D3BEF8EB4",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-05 After the battle",
        "type": "vn.scene",
        "parentId": "D114372C8BA57244E87B5C53EF9DFA983139",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 5,
        "livePreviewDisabled": true,
        "localizableStrings": {
            "D3903A24242D614A025A1099D1E8945A2A35": {
                "t": "Nngh... Why didn't you... kill me?",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "C81D8D059FD67149F46BDB7130E9BDA37BD4"
                }
            },
            "B59C91C7844A224C4789A4584A2E8F68BF3E": {
                "t": "Didn't you hear me before? We want to talk.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3FB36F1C8B46044CF219A812CB03F6EF690D"
                }
            },
            "B9355B4F817091422F7860981D83E7B7C65D": {
                "t": "Why is the Cult of Amaranth so interested in me and the Demon King? What's your goal?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8DB214B5215A304CE5188342458FDBE379A3"
                }
            },
            "0B204CEC37EBA34EDE193986C100CD1EB3B9": {
                "t": "I don't know...! Believe me, I was just following orders!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "CA890EAB67DCC349CD7BF4A6D85D8C863446"
                }
            },
            "847ADA2F637F54430E4BEE996BE00AFA7ACD": {
                "t": "Orders from whom?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6CF0C538582C604896193B476549DE9D28A1"
                }
            },
            "19601A7555F365494C08E2F269CF8A945EC4": {
                "t": "I'm afraid I can't answer that...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "4520BFE672642248D92BD3E68975A88E6AE4"
                }
            },
            "05CC634C34955643C6895A29EA62B38B67D3": {
                "t": "How cute. Now, what method of torture shall I use, Vassal?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "206BD1AA37D5E648C96823C610C5572D7BD6"
                }
            },
            "62F5BCA46D054347860A9D43A69466EF3FE3": {
                "t": "Er... Do we really have to resort to that, Princess Rya?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "A6C247B88904014B436837F51C6769D757A2"
                }
            },
            "C2ABCC03272A534C6C3943D47F3BB2C2C473": {
                "t": "Garion! Garion!!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "2C53BB7C399C2445B28AEEA7A0AB721B24BC"
                }
            },
            "40FCDE3942ABF345F69AE293F941E0DF49E1": {
                "t": "Oh, please... Don't hurt Garion!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "0D874ECD8972144C321B4491008D8ED95AA4"
                }
            },
            "AF47C63D51A2C548F369DAE6C863638307BB": {
                "t": "A kid? Hmm...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "04E272BB16F2334B6F684358EA335395E66C"
                }
            },
            "FC4FF73852E89842E8588C4714B2E5A0EF38": {
                "t": "Djambo... don't move. This is... what I deserve... since I am... a member of Amaranth...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "105D36EB0B1234430D984A923A65EF7BE922"
                }
            },
            "8DAA8F9243D5C94A1A888AE340AC9D3D82E7": {
                "t": "If you help me now... you'll share the same fate... stay back...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "92C786466BCF1148D5396289747532E180F6"
                }
            },
            "C3A34D770C95E546018AF7324FD564F59F99": {
                "t": "Don't say that! You're like a father to me! You took care of me and the others!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "220E90D88028E146BC197E098D1A69DCCC12"
                }
            },
            "DC17F19414B4984C4C9AED298978AD357256": {
                "t": "I don't care what these people might think, I'm one of yours! I'll always be!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "DF8CD0F33C10E5458F795B41ECF91D0173F3"
                }
            },
            "D8E0E3BD7951664F508B1487D845B60BF8EC": {
                "t": "Then prepare to meet his same fate.",
                "d": {
                    "eid": "B09FFBAC5EAA0044033ACB936CA0B9988B03"
                }
            },
            "9C23706537091548855A44D4426E61229E9B": {
                "t": "Don't say those words lightly, boy.",
                "d": {
                    "eid": "C6D97F57091AF24DDD0913339F62411E5D23"
                }
            },
            "4D00C9E8509A6841CC780E51D4A0C1B4A9B3": {
                "t": "No, please! He's just an innocent orphan...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "43C347A16CA1E347F63A79D7BE83CA95AC73"
                }
            },
            "588037B17ED8B14A0C7A90A9BDA61B937FE8": {
                "t": "I told you, I don't care! Do whatever you want, I'm not leaving Garion alone!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "FD79CFF131DC114C0E38DB31312636C4B2C4"
                }
            },
            "4CFDE97B50BF434C9279CAA53B891BA96A8D": {
                "t": "Me and the other orphans... Nobody wanted us, but Amaranth offered us protection. A home.",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "E48C453362E4E64CAA79AF867DC64C5A2E08"
                }
            },
            "C1243E9382DDD648339A5BC747F3E22F36B0": {
                "t": "The resurrection of the Demon King? Who cares! That's stuff that the higher ups--",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "C65006AE048CD54B21382AB1ADB149B1E86E"
                }
            },
            "B308236886E07846EC399E08219641FEA58A": {
                "t": "ENOUGH! There might be a punishment worse than death for those who reveal Amaranth's plans, boy.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "445F07D41087F3418D9868798A5CD37C5527"
                }
            },
            "3CE2E81B5BF866416A782EB2D4922F76F534": {
                "t": "Interesting. It seems there are all sorts of people in this cult of the Demon King.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "6DE32B61139EA64AFB49DEB47EACADC9BBDB"
                }
            },
            "543996D21FA5114A5438CD686E1992666510": {
                "t": "I was expecting members with more... polarized opinions, for sure. But this kid...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3BED753B273DE441FB7B1143126432FA6B80"
                }
            },
            "0522A77834C90547CC8B6151AB0C8769EA80": {
                "t": "He reminds me of the emotions I felt when I was little.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B4CF20A26E2EF54F984B38E6A39CBF07EA85"
                }
            },
            "69471E598E51D74DFF6B98F784ED1F65C67A": {
                "t": "Princesses, do you have a moment?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "F448C596748786410078AF05C46A7358BD57"
                }
            },
            "BD39F267283C9646DF88BFE74E5B5A76AF6B": {
                "t": "What's the matter, Cristoph? This is a delicate moment.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "6F3259B381A6B44C0839A895CFC4F14FB274"
                }
            },
            "D305808B59C43743121B19309951135631D5": {
                "t": "Our scouts have found a group of cultists that were escaping with some children. What do we do?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "D9463AEA4032754EB14A74F4D3B65F446C35"
                }
            },
            "2149AD04932F014F11386613A7ED6BB8F8A8": {
                "t": "Shiori, may I ask for your opinion?",
                "d": {
                    "eid": "4B0D69E3702A1740153A9CA9EBA0E0415F96"
                }
            },
            "A967A970241BA448482A0B61F84DB6A148DC": {
                "t": "Hellios, use your powers to kill them.",
                "d": {
                    "eid": "CFE104E346BA024DD158F650642666D5E909"
                }
            },
            "A9FA88FD607DF3454278079830C60E1B5F0C": {
                "t": "I could reach them with Dimensional magic.\nBut, Faratras... are you sure?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "F5C09409710C774F411A1BB84326F88F19DB"
                }
            },
            "904737BA33EF604D255AB1D4537C05F8175B": {
                "t": "Not really, but... I want to see how Garion reacts.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "117FA8EA7A035346025B7B73D055F4DDF451"
                }
            },
            "4E854CE3241292497D7A98C62A6929408DF8": {
                "t": "NO! PLEASE, DON'T!\nYou're a monster...!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "52E6E40B43EBB74CE27B4D9013ABB56F2F2D"
                }
            },
            "87928DC6764B614B8398168853830A74E201": {
                "t": "Am I the monster, now?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "37C318A00D8359464A19A8011DDB8E0836C5"
                }
            },
            "4CCD47E520DA56464E09EB32219E8BA7A79B": {
                "t": "You members of Amaranth plan to resurrect a being that has almost brought humanity to extinction.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CF88DF52397504444B285962FD3D15F36B63"
                }
            },
            "BE5A462B7411754A4C0ACAB45529E9A2ED54": {
                "t": "You kidnap orphans and indoctrinate them into your wicked mentality. You rob and kill to sustain your underground research.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AB95C2AB4DA1D9495F6B7E25AB2EF0CA0C54"
                }
            },
            "961232356A5C56478F98ED45AA2E3C3DAA3C": {
                "t": "You've even gone so far as messing with the Mana Scourge to create mechanical abominations. You're more of a monster than I'll ever be.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4C7C62B4861E0440552B09311C78C4866BFE"
                }
            },
            "172394127DC5F643EE7B6D08E10A87237159": {
                "t": "That's a bold generalization! We're not all like that!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "4979EEA14E1D834BC18A44E24456AF4A557C"
                }
            },
            "E077A98B836EF349097B40B916D133A99551": {
                "t": "How dare you insult Garion like that! Why won't you let him explain!?",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "2D25CD7F9C62F54DC20AE9275889C1B96D35"
                }
            },
            "C0EAE00867058543361AD9624C66330EBBE5": {
                "t": "If I understood how Shiori's power works, she should have 'seen' it...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F0A32A1D7EA03348442B48216854FB689190"
                }
            },
            "92CB216D41634146001B309709FAAD1C1AA4": {
                "t": "I know what you're thinking and... I can't sense any particular malice coming from them.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "404954161237D642A62AB861F1C6CA5361CC"
                }
            },
            "962A501189F54245E88955629FC50FD37854": {
                "t": "What? Don't tell me, it's another ridiculous power.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "5AFFDC8777096648556A4AC72744941EB5FD"
                }
            },
            "AA0D740D50E7E14BAC6BA3E87F1D59E7667D": {
                "t": "Well, yes... Shiori can sense people's malice.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "E2B9A06E0A9F82415C5B00E65D2305123EC9"
                }
            },
            "2BA001C718A59248DF5AD5F49F8446BA5377": {
                "t": "I've already confirmed it. It's true.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7AC0E53D1808D44C663B2E24D29A733823FA"
                }
            },
            "E09A449B6CAE47417049FE1132CD7B787AAA": {
                "t": "There are more 'special' people in this group than in Viborera's circus.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "B8D81DA45AFCA4468E6A67F314991CA97197"
                }
            },
            "7FC28F195029D7486078F401277E3277C984": {
                "t": "Anyway, if these two aren't malicious... then...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E3DF9A55567C64475D9B80D38A0756B172D7"
                }
            },
            "FE68A43C1C5E414E801BBFA3C4D9E776E73D": {
                "t": "Those kids... They're just orphans without a home whom I took under my protective wing.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "DE1E4E710E64F342384BC888A9092FC06B68"
                }
            },
            "12EA3BD5436C9242663B4EB61DA94B96A15B": {
                "t": "It's true, I'm one of them!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "1790149003394149DA38B324C143B22D1E27"
                }
            },
            "C0FA695578C67342D76811066786FFCC3031": {
                "t": "Then speak! Why would your organization want to mess with the Demon King's power!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C0D70A2F9D3641440749E7281AC1304F2C9E"
                }
            },
            "AFC59C481F3CF14C9F39E851188A93F19439": {
                "t": "... I don't know. Even within Amaranth, only the higher ups know the true meaning of our research.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "AF6FC1676B17424F4C3AA1D1E96A3F398E7B"
                }
            },
            "90255E968B00344A649A26C3824388ADD0A4": {
                "t": "That's ridiculous. You're telling me you're part of a group whose goals are unknown to you?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "3127D6CC2E33994D30297A10AC521349DBAF"
                }
            },
            "AB4B2D612FD9D248988B23849D8D3C252259": {
                "t": "Exactly!! Amaranth pays their officers with a good sum! And Garion only uses that money to help orphans like me! He knows nothing!",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "343A143F2ECDA14DDD7B3125DC634E332F8D"
                }
            },
            "82AFCDD6532E10442E3BB5724E011778B4C8": {
                "t": "Unfortunately, not all of my underlings... share my values. But I deal with 'em when need be.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "E7B2E1AA4AE9F64A3C4AF0A4A8C866E632E5"
                }
            },
            "83DDF3306F8EE249F319EDC0B564D4D17500": {
                "t": "So? What are we going to do with them, Faratras?",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "F030CB6201B0F64BAF3B8D3419537FE1E966"
                }
            },
            "E8ED8CD86EE8C64E81983AA0E344E99E6AB6": {
                "t": "I think I have collected enough information.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "219863AE8F7F094135393A01A685DD3BD164"
                }
            },
            "69E0D72B73436647D54B07B7BCFFA798EFD0": {
                "t": "Death is the only option.",
                "d": {
                    "eid": "D43726581A18954C1B5BDC337522D523BBF7"
                }
            },
            "CC272B8B79BFB24E246823E809DD7B4F003D": {
                "t": "Let's give them another chance at life.",
                "d": {
                    "eid": "3D1C790C793EC94B56691352A1D41263280B"
                }
            },
            "F524370A4004F3498A58B01364BD136AC02F": {
                "t": "Wait...! How can you!? Leave the child out of this!",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "3B1D288E275C694FFC398044345CE9FDB268"
                }
            },
            "828A9B5B15D961407E48D4B6BC750586A2FD": {
                "t": "... ... ...",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "50986E254386F14B263AB1874F1AD4366C4D"
                }
            },
            "BFC9FB8E131E264569595D24174A129ED5EF": {
                "t": "Of course the child isn't included. Someone in Magnolia will make sure to... reform his behavior.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0E92797C8216D24C738B2B9755C245F442A6"
                }
            },
            "85FB0EAF33E9B14F151B10645F3BEF757D2A": {
                "t": "As for you, despite your seemingly good intentions, you still served under a criminal organization.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "ACB7159D52BA484E918A762984DBF050BBC3"
                }
            },
            "E8A192CC80E4434E0099532415C7E63009B7": {
                "t": "The child is in very good hands, no worries! Just look at me, I was raised in Magnolia too!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "05B4B1B2416AF54D61184DD4752962C72B99"
                }
            },
            "40087AD62ABBD84F5A2A69E61F32DB339DC3": {
                "t": "You're not even from Magnolia, and you're definitely NOT the best example of righteousness.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1E0271DA9E741443744993F4102B91D110DC"
                }
            },
            "E4C0FC9E1630744BCF5A49F4EE5282A0394C": {
                "t": "If you're taking Garion away from me, I won't come.",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "1291E28E2EB1D442DA792976513078E15F1A"
                }
            },
            "E23C049A6ED705451469C6B3770BF18E985B": {
                "t": "Don't say that, Djambo.\nActually...",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "2D300C114203634A86091285A77F289855EE"
                }
            },
            "EDD8B42A30FB244CD46B5C437EF1D1B5AEF8": {
                "t": "Just a kindly reminder that I'm the amnesiac here, not you. Have you already forgotten what he's done?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "35FFA3B06542714498399CE38A8D47E98A58"
                }
            },
            "D5B348EB5DFB3147962A6A13CBBE8D70935F": {
                "t": "I appreciate your leniency, but I second his doubts. What's the meaning of this?",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "A2E645D858D7224A391A548770D0E9A1F043"
                }
            },
            "1BBD90C29EFED2477878BE24259EC256F984": {
                "t": "I'm not sure why, but for some reason, if I were to punish this man... I would feel like a hypocrite.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E1E1D98E40FA064118197CD3F98418BD46CE"
                }
            },
            "ED52077F590FE441B118D758B207EF250150": {
                "t": "I've done nothing but run away because of the title of 'Vassal'.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E7C6FAC32BEBF84F7B8A0EB5FFC90A84594D"
                }
            },
            "18F32D2D85B86844C54824D27BB77CC6DFAE": {
                "t": "This is the same. Dooming these people just because they're 'cultists' is wrong.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "38E001693908F04C97494513594FE9595BA4"
                }
            },
            "FF8C0E9893804442981925C4B52EE56112E1": {
                "t": "Wise words, Faratras, hehe.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "492236ED1D2BE445F34800A74C6AF47896EE"
                }
            },
            "BE7C30E0272F04451969F2320D0A6039A121": {
                "t": "That's... the best outcome I could've hoped for. Thank you for not killing us.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "6A25ACEA75B2D14C4F59D19591F516535F36"
                }
            },
            "D423D90A08CE304C1B690A44064F4715FB93": {
                "t": "Don't thank me. This will be your last chance to redeem yourself. Don't waste it.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "53D28A6F7B59864ABF3ABB4894B92C050B0D"
                }
            },
            "251F08D806B3734F0739DAF58238126DE6AF": {
                "t": "... ... ...",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "0B1856945E79B64EA13A65600EFE37568B51"
                }
            },
            "826FA58535D4D64947582795EF3FE04ED685": {
                "t": "Help me treat his wounds, Djambo.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "D350E644677B0645615BC0482AD8D8958A61"
                }
            },
            "B0A13D267017804E043B2FB8E6E36D104BA7": {
                "t": "... ... ... Fine.",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "F476EE706118F54A9389744298CADD5865A5"
                }
            },
            "83708AD204DD674F7A3A4BA8F2386072D427": {
                "t": "Everyone, we thought we wouldn't have to fight today. We were wrong.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C9C9AAA72A18824D170B80003CEAFD36D258"
                }
            },
            "5D6EEF798AC83248177BEDF5545D894FA37E": {
                "t": "We've definitely deserved some rest, so we're going to spend the night within the protection this fort provides.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0E28B1888CCCF744E09BC0E19772568BC1F9"
                }
            },
            "BF149D5E25AC7943A88824124BD025AA2E7A": {
                "t": "I'm sure there are plenty of supplies in here.\nTake your time to sleep, eat and drink your fill!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F2D63C0317F94744706A30B7153D3FB520AB"
                }
            },
            "BD8599625CCA0443C229C80163CEDEE3C7E3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "33DE1E2E15FC004559480EF68FB7E6286F9D"
                }
            },
            "35ED473F1326964444682F40437AF0E92CC6": {
                "t": "???",
                "d": {
                    "eid": "20568ED9811FD54D277BEA54020176FCE21D"
                }
            },
            "C92A1E6946EC03482E480F848847167176E2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F32FB2576614384D6D88FC482D3DA2666901"
                }
            },
            "5B329E0C32BB354C0D5B9B82697D0188DA70": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B670BC167B4C5746D13B99C6049B200755DA"
                }
            },
            "7832340843F2D24F8C6A26E51EB55A476094": {
                "t": "Djambo",
                "d": {
                    "eid": "A8AB63F2596BB946137B9FB13B3DA1BD00FE"
                }
            },
            "95B0836E51C128435B6B5FE6E02FDFC6CD1B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D1CB39545343C14E5A8A5FD697DCA9095A52"
                }
            },
            "D53D075E2C05E744E728DCD1731F87016E3B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "3994180995F2A5483F19D0F5B998EC369DD1"
                }
            },
            "FABC299D8157C248523844333D6DCDBFFCD9": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "72DF4CDD9DDFE44750086F17B80ED1AEB336"
                }
            },
            "2154FCA58A2D4146175AFDB4AC25EFC191C5": {
                "t": "Say what!?",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "300F3F0D1B3A7241C689A9F3B86945374040"
                }
            },
            "70C85BBE8CF8814A3F8AF5F35356154D71E3": {
                "t": "Why are you staring at me?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "778E38D80C14D246BA4A4D7182B048E2312E"
                }
            },
            "1A80D5448AFA0640A7886FD4176043D21DE6": {
                "t": "Tsk, whatever. I didn't mean to hide anything from you anyway.",
                "d": {
                    "cid": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eid": "AF4D2BF57FF7524B037995837CE5626FCF58"
                }
            },
            "313530C4207E5741593993612AD1BFD16557": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2284425166F425404E7A6403274C67669231"
                }
            },
            "B31E0B501238284F504848289C4218A47F1E": {
                "t": "Even if Amaranth has committed many crimes in the past, Garion isn't like that. He's no mere burglar.",
                "d": {
                    "cid": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eid": "694BFEDA69975945B33A2365D5E86C1C8CF3"
                }
            },
            "0BB60EFC2503E340104A9332E718333A0F11": {
                "t": "What am I thinking? I would be no different from Munie if I did that!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "62E09557162CE8491A4B43417277CBCC0D08"
                }
            },
            "735B721F95F925435F8BACC3F23D4CB12CC4": {
                "t": "Perhaps a better solution would be...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "670FAD9D244BD948174926E1F0E34B422DD1"
                }
            },
            "343C73D8883603491648FB81C7C961313A6F": {
                "t": "You may keep your life, but some time in prison won't hurt you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8D34343A7C2E724A4C4AE89970A15D3FE043"
                }
            },
            "0E0CDD553142E6431669C664EE4DA8D3CA8F": {
                "t": "I think that if my people had known ME better, I'd still be in Hoikade.\nBefore the Vassal, I'm Faratras.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7F693A097A1DB14113194A33FEC2795822F0"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A5052F73E28A7444E389EB8557D4699CD90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFB276B21A499344F09BC1D897FCDBE89661"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CA180558874B41463188E1F8D7CB2D937A2C",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9B2487E35FC424B68892318F9BFAED76100"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "7879B2B892C05443D77B04E033172C2693D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C2C4D90F34924342DF19B3839BFDB69950F9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "EE4CD9BE226EE84A6D193B84269A0710C9F4"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "C91ECF831111764D6D98BCD4022BAE327211"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "434F9D5322E3D2445F49B2310F8170F35A66"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "905B34A913EB354C424857B6F6696065A19B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "5D360BE84E4B36430C6A2DD26915DAA87A74"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "CB92A0572895554C941A7D03D1D0A4007F16"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "model": {
                        "name": "Garion.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 801,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -50,
                        "y": 29,
                        "zoom": {
                            "x": 1.85,
                            "y": 1.85,
                            "d": 1.85
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "EAD13DC86534E14F4A59713243090683D1C0",
                "expanded": false
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "param": {
                        "name": "PARAM_MANTLE",
                        "value": 1
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3EA24253752B9743C149580099F85D7B2997"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.6,
                    "idleIntensity": 0.3,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "951EA8B1056655462D0975D52B77C2023F3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF6C143D8F257443314836A6FF2D234D5E8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37FF9E9433DA3347F82B2E04C535946DC007"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "206AF9D1216EE24B0C08C256F11B5D101539"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F8C424C14A28284D1B1962124A710ADA4B6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0AF3E89D55DB614FA63907462473D6B89ABE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83AA3CDE107D524C3E49B937520D4CF6FC15"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7F810D954BC1D74FD648EEC35F648A485EF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD8599625CCA0443C229C80163CEDEE3C7E3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Garion",
                        "name": "E3-Garion_line9_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "33DE1E2E15FC004559480EF68FB7E6286F9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B151DA5952A8124E924897349E6F4A134658"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A0A84A242844248B678D336FB9285F88166"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D3903A24242D614A025A1099D1E8945A2A35",
                        "defaultText": "으윽... 왜 날... 죽이지 않았지?"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C81D8D059FD67149F46BDB7130E9BDA37BD4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D52CD3700DA074478539C985F89BE35545EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39DA7592789032411A4BC5F677364E5D638B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B59C91C7844A224C4789A4584A2E8F68BF3E",
                        "defaultText": "아까 못 들었나요? 우린 대화하고 싶어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3FB36F1C8B46044CF219A812CB03F6EF690D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A97EDEA85B37824FA0394A87B0027499F718"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9355B4F817091422F7860981D83E7B7C65D",
                        "defaultText": "아마란스 교단은 왜 나와 마왕에게 그토록 관심이 많죠?\n목적이 뭐예요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8DB214B5215A304CE5188342458FDBE379A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "271427111AE2F5437299C2B804AD1C614451"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ACCA106211FF149A24A8E415B9025AA1120"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "083247002275C84DDA4B0A635CC2A9B4BE4C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0B204CEC37EBA34EDE193986C100CD1EB3B9",
                        "defaultText": "나도 모르오...! 믿어 주시오, 난 명령을 따랐을 뿐이오!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CA890EAB67DCC349CD7BF4A6D85D8C863446",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C8F38BE86FCC141E569B3B1C5B6CFA33BB4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0E54D4E633783482E49ABF6FACD557EA7C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "847ADA2F637F54430E4BEE996BE00AFA7ACD",
                        "defaultText": "누구의 명령이죠?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6CF0C538582C604896193B476549DE9D28A1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79F853C53136E146464ACF169055476798B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB4EB6376285E740012B245245EF2F797779"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "19601A7555F365494C08E2F269CF8A945EC4",
                        "defaultText": "그건 대답할 수 없소..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4520BFE672642248D92BD3E68975A88E6AE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63F0538632C0044196887FA79D73DF703E8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEA27691350582489B3944307780B6764140"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D05EAF66473A948B52B70866478DE177E22"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05CC634C34955643C6895A29EA62B38B67D3",
                        "defaultText": "귀엽군. 자, 어떤 고문법을 쓸까, 그릇?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "206BD1AA37D5E648C96823C610C5572D7BD6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84D37C473D3CC2403A1992D8B1B11BBF7F06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A71DCD9727C5145577B42E371D443E36D22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89BCDDBE4B5A48473A8A87F2471095044660"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62F5BCA46D054347860A9D43A69466EF3FE3",
                        "defaultText": "어... 정말 그렇게까지 해야 하나요, 리아 공주?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A6C247B88904014B436837F51C6769D757A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C67E167A49188745365BA8D7A591676DC414"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "23DD97180A481045531B34741492AC7D3317"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "djambo name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "35ED473F1326964444682F40437AF0E92CC6",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "20568ED9811FD54D277BEA54020176FCE21D",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Djambo"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "djambo name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A649829118B5874C6329870235FE817240DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BD8FA7E22FA632481E9A9412F70832A01A0F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C92A1E6946EC03482E480F848847167176E2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Djambo",
                        "name": "E3-Djambo_line18_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F32FB2576614384D6D88FC482D3DA2666901",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6EFF728B3942684CEC7869A90B2484120C8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95A06E4343F0D54584586B76EA24FD5E85DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A89B915D7C93304FDC69D34596EF347755A9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2ABCC03272A534C6C3943D47F3BB2C2C473",
                        "defaultText": "가리온! 가리온!!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C53BB7C399C2445B28AEEA7A0AB721B24BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE7E0A026687F74DAA9AA9B7091D66B16104"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B19AB37256BE65442038FBD64EF5C5B4D3B7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "1C9F2B1072B43744B46926326D4D3C2F4367"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "model": {
                        "name": "Djambo.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 656,
                        "y": 178,
                        "zoom": {
                            "x": 1.7,
                            "y": 1.7,
                            "d": 1.7
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "2CCDFDFA6176424A4B5BCFC1BFAFAA2FF931",
                "expanded": false
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "param": {
                        "name": "PARAM_PADS",
                        "value": 1
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9F4EFA3D5AB2014B99090100ACCCC446F737"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.9,
                    "idleIntensity": 0.75,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "FA86842E51460545514B96F10783461E5DF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9F20E9F20DAC644D78ABB133EFDB18F2EF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "46E4AC048773754C6B2A11645E3FF1348A2C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 78
                },
                "indent": 0,
                "uid": "69C5D9683E3E55445119E074C9D67BE800BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9416A48143087849676ADD98E910DD9BAD99"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Djambo appears"
                },
                "indent": 0,
                "uid": "11BFB5CA9FD72846A96A17486473DA7E077A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "64980D278DA625415A4A22372FECA7EBF065"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "152F91496575544A1C783E690D14805F50C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DCBFFF2075FD44C517A40F59351B1C65858"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40FCDE3942ABF345F69AE293F941E0DF49E1",
                        "defaultText": "제발... 가리온을 해치지 마세요!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0D874ECD8972144C321B4491008D8ED95AA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D81FFF1E74CA534A7178CC465B690918641C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D5EB64117E3314F252922E37C4DE3822B19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF47C63D51A2C548F369DAE6C863638307BB",
                        "defaultText": "아이인가? 흠..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "04E272BB16F2334B6F684358EA335395E66C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9872B709723AA2434C9BCA47FD3B7D9B4EC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D7E83EA776B144D5E98F4E2F2F3F2407DD4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5DEBC9EF9B68264E6E3AB0D88154AC64546C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5B329E0C32BB354C0D5B9B82697D0188DA70",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Garion",
                        "name": "E3-Garion_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B670BC167B4C5746D13B99C6049B200755DA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "29954A0B861BC04738886C844450EBDEFE1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52900E01534873432879BDD47984EFE06DDB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC4FF73852E89842E8588C4714B2E5A0EF38",
                        "defaultText": "잠보... 움직이지 마. 이건... 내가 받아야 할 벌이야...\n난... 아마란스의 일원이니까..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "105D36EB0B1234430D984A923A65EF7BE922",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAC7CF3B0E34A048960B8D73BC11A7BF3A54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DAA8F9243D5C94A1A888AE340AC9D3D82E7",
                        "defaultText": "지금 날 도우면... 너도 같은 운명을 맞게 돼...\n물러서 있어..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92C786466BCF1148D5396289747532E180F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6436F8DA666DF54BEC2892838032045878DC"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "djambo name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7832340843F2D24F8C6A26E51EB55A476094",
                        "defaultText": "Djambo"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A8AB63F2596BB946137B9FB13B3DA1BD00FE",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Djambo"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "djambo name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E2511CCC3CA7F54DA14837668B0C0E619A2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D1B22263DB742459B69C4A70BD38E50210F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2DD249C12B430840C91B34C06211EB49372D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95B0836E51C128435B6B5FE6E02FDFC6CD1B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Djambo",
                        "name": "E3-Djambo_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D1CB39545343C14E5A8A5FD697DCA9095A52",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "05208D3166590844CE3AFF8283A8E45E4C14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C536C76E40087748866A7425D99B5D07A5B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C3A34D770C95E546018AF7324FD564F59F99",
                        "defaultText": "그런 말 하지 마! 당신은 내 아버지나 다름없어!\n나와 다른 아이들을 돌봐 줬잖아!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "220E90D88028E146BC197E098D1A69DCCC12",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8150F81676AE2443F489EEF7DD6D39CA1A85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A81F041F4DB30146C03B7AF5306499417468"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC17F19414B4984C4C9AED298978AD357256",
                        "defaultText": "이 사람들이 어떻게 생각하든 상관없어.\n난 당신 편이야! 언제나 그럴 거야!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF8CD0F33C10E5458F795B41ECF91D0173F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FFD0065131E8140158A39B4898186A0F5D7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D8E0E3BD7951664F508B1487D845B60BF8EC",
                        "defaultText": "그럼 저자와 같은 최후를 맞아라."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B09FFBAC5EAA0044033ACB936CA0B9988B03",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9C23706537091548855A44D4426E61229E9B",
                        "defaultText": "그런 말은 가볍게 하지 마, 꼬마야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C6D97F57091AF24DDD0913339F62411E5D23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "cruel",
                            "normal",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED4E8A1841640745F16B2B72940198FA91C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "52B7F3EB7EAA46480888AEB2EE2245B52CAD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cruel"
                },
                "indent": 0,
                "uid": "9DCED0AC9076714C7E484A0554AE7E64DD6E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+cruelty"
                },
                "indent": 0,
                "uid": "0D8284B2685EE84E7A1A01D5A9D535106BAD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "967528E553706043D99B23E25925600F654C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "0112AE2035BE634A538861034270E643A0D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ECA00F270D22844C7498043387918BA53B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D00C9E8509A6841CC780E51D4A0C1B4A9B3",
                        "defaultText": "안 돼, 제발! 저 아이는 아무 죄 없는 고아일 뿐이오..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43C347A16CA1E347F63A79D7BE83CA95AC73",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05359EFE06D8C84E1F8B56472A9B50A874AC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "normal"
                },
                "indent": 0,
                "uid": "AA8CDD500F2912487A5B6EA2ABAD836E6C77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5778694132D8144AE4B4AF078E0CCD2FC28"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "588037B17ED8B14A0C7A90A9BDA61B937FE8",
                        "defaultText": "말했잖아, 상관없다고! 마음대로 해.\n가리온을 혼자 두고 가지 않을 거야!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FD79CFF131DC114C0E38DB31312636C4B2C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6315A7D468F17845B189DFB97EAB9AAD66D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AC7BC6D390A804E6F5A3F08ED73C98FFAF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CFDE97B50BF434C9279CAA53B891BA96A8D",
                        "defaultText": "나와 다른 고아들은... 아무도 원하지 않았지만,\n아마란스는 우릴 지켜 주고 집을 줬어."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E48C453362E4E64CAA79AF867DC64C5A2E08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F981C15B63BC15452A8ADB972CC79E2A38A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1243E9382DDD648339A5BC747F3E22F36B0",
                        "defaultText": "마왕의 부활? 그게 무슨 상관이야!\n그건 윗사람들이나 신경 쓰는--"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C65006AE048CD54B21382AB1ADB149B1E86E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84BE0B494699B8425C5BC741534BF61B61EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8909C6518271A545DE4BA6E6D4920DDE294A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3E5411563D60214CEC78DC852C9CE6BED903"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D53D075E2C05E744E728DCD1731F87016E3B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Garion",
                        "name": "E3-Garion_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3994180995F2A5483F19D0F5B998EC369DD1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D6EC1A9245B2334C7E9811D5630CD680C619"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B20149F154AC74A2F38B4144A55B3C62C23"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B308236886E07846EC399E08219641FEA58A",
                        "defaultText": "그만! 아마란스의 계획을 누설한 자에겐\n죽음보다 끔찍한 벌이 내려질 수도 있다, 꼬마야."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "445F07D41087F3418D9868798A5CD37C5527",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59FFA62438EF624C4059C3F88AAA96C2EAA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87D538E12C3FB8493E395AE665B5070E7A88"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA3BE9BD890F51424A797FB4871CD03C083E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3CE2E81B5BF866416A782EB2D4922F76F534",
                        "defaultText": "흥미롭군. 이 마왕 교단에는\n별의별 사람이 다 있는 모양이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6DE32B61139EA64AFB49DEB47EACADC9BBDB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE302A52338A434F5B184832A1ABA725F223"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AA50F532311B049FB0812514448BAF899EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "543996D21FA5114A5438CD686E1992666510",
                        "defaultText": "좀 더... 극단적인 생각을 가진 자들만 있을 줄 알았는데.\n하지만 이 아이는..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3BED753B273DE441FB7B1143126432FA6B80",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34CFB849590EC3486A1963A4F428AE32E315"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0522A77834C90547CC8B6151AB0C8769EA80",
                        "defaultText": "어릴 적 내가 느꼈던 감정이 떠올라."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4CF20A26E2EF54F984B38E6A39CBF07EA85",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C275C5D6BEB774EE4082D4914B86F08C86B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBEB9B552213314EE38BEFF87909EDD4099C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E6347288F3B6449EE382F50BE676CF53D3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA47AFED2E10F54A252A17126A5884BB25BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "69471E598E51D74DFF6B98F784ED1F65C67A",
                        "defaultText": "두 공주님, 잠시 괜찮으십니까?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F448C596748786410078AF05C46A7358BD57",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0633324A2093B2471F3814D320B599E13D66"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B69C95A3130A134D6D481BF6204E4FD3E484"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD39F267283C9646DF88BFE74E5B5A76AF6B",
                        "defaultText": "무슨 일이야, 크리스토프? 지금은 민감한 순간이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F3259B381A6B44C0839A895CFC4F14FB274",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC74F043100F744D966B3547468CFAA132E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11AF7C1E869B7145862AD4066EAEFC06DD56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D305808B59C43743121B19309951135631D5",
                        "defaultText": "정찰병들이 아이들을 데리고 달아나는\n교단원 무리를 발견했습니다. 어떻게 할까요?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D9463AEA4032754EB14A74F4D3B65F446C35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A65B7D9188864647D03822845960CB9DD755"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2149AD04932F014F11386613A7ED6BB8F8A8",
                        "defaultText": "시오리, 네 의견을 물어도 될까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4B0D69E3702A1740153A9CA9EBA0E0415F96",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A967A970241BA448482A0B61F84DB6A148DC",
                        "defaultText": "헬리오스, 네 힘으로 저들을 죽여."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CFE104E346BA024DD158F650642666D5E909",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "shiori time",
                            "hellios time",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D718E49244C8747F25B5A88772E93EF6FD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBAE0C1665190845B949C53766AE7C1208B7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "hellios time"
                },
                "indent": 0,
                "uid": "2ACCED93291DC244263886D51F0A76DC55A4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ cruelty\n+ aff Hellios"
                },
                "indent": 0,
                "uid": "8A792626004B274F185A17462BA9448DDB2F",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "hellios time",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "404B343B9E378647039A1CE46B689D2946A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A426AB6D463DB04E3F1A31284043C9A8A918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10E0EAF2855EE84C761AFBA862B39120A98D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "A977A71C7C05664340291924F65474B13CAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FFD6BC492B18540C99B209315F40278683C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            3,
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48F5E8CB4325B6424C0ADCD84D711ED43432"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C1CEA042843D2424B0BD8050E714992DE1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14A58D564434E34C914BA067F3BA0FA6242C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9FA88FD607DF3454278079830C60E1B5F0C",
                        "defaultText": "차원 마법이라면 따라잡을 수 있어.\n하지만 파라트라스... 정말 괜찮겠어?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F5C09409710C774F411A1BB84326F88F19DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F319B542A397146806A7BD3154784D17A05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66D5450612A5854FB84881D98D3AC8B227E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "904737BA33EF604D255AB1D4537C05F8175B",
                        "defaultText": "확신은 없지만... 가리온이 어떻게 반응하는지 보고 싶어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "117FA8EA7A035346025B7B73D055F4DDF451",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D707A4690A51F149145A60B67ACEBF990C05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD470C1421FAE645BE489D648CAE6C8EC126"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B7D9C1E36730B14B6C6AE2C20FB82B917741"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FABC299D8157C248523844333D6DCDBFFCD9",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Garion",
                        "name": "E3-Garion_line9_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "72DF4CDD9DDFE44750086F17B80ED1AEB336",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1927318B1C3EA540E5593EB54687038F24E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54FC033078595747F06BD735B21E8A88BBAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E854CE3241292497D7A98C62A6929408DF8",
                        "defaultText": "안 돼! 제발 그러지 마!\n당신은 괴물이야...!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "52E6E40B43EBB74CE27B4D9013ABB56F2F2D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D7E4E8981BC02406B19FCF4D02DD2D1E5AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C32AB77E04EFD24A113AEBE2AB181608E102"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87928DC6764B614B8398168853830A74E201",
                        "defaultText": "이제 내가 괴물인가요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "37C318A00D8359464A19A8011DDB8E0836C5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A7C0AF044CCB349EF1AEAC72068D1DAF8EF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CCD47E520DA56464E09EB32219E8BA7A79B",
                        "defaultText": "당신들 아마란스 교단은 인류를 거의 멸망시킨 존재를\n부활시키려 하고 있어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CF88DF52397504444B285962FD3D15F36B63",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CADADDD513009442083A2856176CBB6530B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE5A462B7411754A4C0ACAB45529E9A2ED54",
                        "defaultText": "고아들을 납치해 사악한 사상을 주입하고,\n지하 연구를 유지하려고 약탈과 살인까지 저지르죠."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB95C2AB4DA1D9495F6B7E25AB2EF0CA0C54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F572E69032BA424B8E296F78C1F57D4A5645"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "961232356A5C56478F98ED45AA2E3C3DAA3C",
                        "defaultText": "심지어 마나 재앙을 건드려 기계 괴물까지 만들었어요.\n당신들이야말로 나보다 훨씬 더한 괴물이에요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4C7C62B4861E0440552B09311C78C4866BFE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C44E437738B6643A98BEA8503E187EA180B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92AEF6D446FEE84B825823B8DCD73AF1B2C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "172394127DC5F643EE7B6D08E10A87237159",
                        "defaultText": "지나친 일반화요! 우리 모두가 그런 건 아니오!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4979EEA14E1D834BC18A44E24456AF4A557C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB2445303E376540AD18C1E5D0FBA8751082"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "05EFDD4F235FB647707A1AA7646F75E5C2A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACFA714407C6724F5699D7F7C7FC97AF0661"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E077A98B836EF349097B40B916D133A99551",
                        "defaultText": "감히 가리온을 그렇게 모욕하다니!\n왜 해명할 기회도 주지 않는 거야!?"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D25CD7F9C62F54DC20AE9275889C1B96D35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C14B3351B893544D218D844F8A13E476AEC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "shiori time"
                },
                "indent": 0,
                "uid": "AF4C4E1C2CC0E8471779F129A2EC355B832B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "hellios time",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0CB82FAF4C00324D2A591875AD2D9924404B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EFA975ED293D754A9A69EE466B18A68674D1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "22C94AF8820DA84DA44B0C0805240B208585"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "350A8DD853B21745E54872B226BEEEF954AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0EAE00867058543361AD9624C66330EBBE5",
                        "defaultText": "시오리의 능력을 제대로 이해했다면,\n저 아이는 뭔가를 ‘봤을’ 텐데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0A32A1D7EA03348442B48216854FB689190",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B37A26C1A003446ED5B3E1095189CE9713B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28779A180E1547459178C96683AF938138F7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "hellios time",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EDA5F3C13456C5454F7B9F6377D2A8990B49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D7B987B7824E834B1F099B6273C46FDFBC6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "70A9B9E035D5E341396BE626E8E6CAE2C1BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D51AD598221EC547CB7A27672962133E73A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "92CB216D41634146001B309709FAAD1C1AA4",
                        "defaultText": "무슨 생각인지 알아요. 그리고...\n두 사람에게서 특별한 악의는 느껴지지 않아요."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "404954161237D642A62AB861F1C6CA5361CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A533DDB57BF8E3481A18F7E63EA8C6B77451"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "hellios time",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B118053F62717747008A7F337FCC53EB3D65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A15F185F659A0646C64B65D75C023534B5DE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "3A95A6686BDA6044C25A03B36B3A9A56EAB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DCB4E4B26F40314C9619EFD484CBE3550BAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC51CF1A73365147CE7AC7051CC2C828E068"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "962A501189F54245E88955629FC50FD37854",
                        "defaultText": "뭐라고? 설마 또 터무니없는 능력인가."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5AFFDC8777096648556A4AC72744941EB5FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F123113E6F1AE54B101B3EF95397EFF220F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAB959BE4975244A4499FFF5CF7591734FF9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "B8EF006D5153E74FD5395861C9F22CE5F3B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FF15F1135D3D54A91091B4535C8E2D49B28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E09B1F6951B78443988B14C23589B898BE4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AA0D740D50E7E14BAC6BA3E87F1D59E7667D",
                        "defaultText": "음, 맞아요... 시오리는 사람들의 악의를 느낄 수 있어요."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E2B9A06E0A9F82415C5B00E65D2305123EC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98ECF10E12BDF44B1379A6D6A390AB950F56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4C8D4509004C74AA638AD480A93BE54946A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49D60040868D06492288F0893665777D19FC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2154FCA58A2D4146175AFDB4AC25EFC191C5",
                        "defaultText": "뭐라고!?"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "300F3F0D1B3A7241C689A9F3B86945374040",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "214B851B157E044EC87B3C87F7CA14975988"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB676C2979A01041BD28C7F55E32B3D5D456"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2BA001C718A59248DF5AD5F49F8446BA5377",
                        "defaultText": "이미 확인했어. 사실이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7AC0E53D1808D44C663B2E24D29A733823FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4C8C161356FF74CF38AFEC800A552B22E7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D52BD54697FB94A8D69B103E3F41EBF70F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F65608E38BF174261785F01F2AD2B3D7759"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E09A449B6CAE47417049FE1132CD7B787AAA",
                        "defaultText": "이 일행엔 비보레라의 서커스보다\n‘특별한’ 사람이 더 많군."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B8D81DA45AFCA4468E6A67F314991CA97197",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F9CB17812713544BA891A70452A5311D039"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "D950F0E56761634A3C793B97C550FDCEDD12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5446A1F93736544E8A8A5CC3B661D2BE6982"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "70C85BBE8CF8814A3F8AF5F35356154D71E3",
                        "defaultText": "왜 날 쳐다보는 거야?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "778E38D80C14D246BA4A4D7182B048E2312E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F95E280E4FDEF3426089160475262F783651"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "454521541F65724DC679BC021BBF1E0AB376"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3EE849907829A4450B8BC37844053C225510"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FC28F195029D7486078F401277E3277C984",
                        "defaultText": "아무튼, 이 두 사람에게 악의가 없다면... 그럼..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E3DF9A55567C64475D9B80D38A0756B172D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A4A08493614B14FD20B2741E7E240E34F90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4E3C9857960874A439BFE14501921A9BDCA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "688D8EBF50B8A948CA19E57432FA7A3F868D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close message box; little pause; reopen"
                },
                "indent": 0,
                "uid": "D884FB153D95B2419E78A792EA2041B34E22",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E599A9B8BB86740332878772D6B74634FE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AD9ED06D73F11649806B08F70A551FFC54DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BC8957B3F9D3542AE59C6D9697B4AEDF870"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1684E6137391A340903B8BC51E9FCC569769"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A80D5448AFA0640A7886FD4176043D21DE6",
                        "defaultText": "쳇, 됐소. 어차피 당신들에게 숨길 생각도 없었소."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AF4D2BF57FF7524B037995837CE5626FCF58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FA55CF92BC4D84EA14AFA63094F8B491C2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE68A43C1C5E414E801BBFA3C4D9E776E73D",
                        "defaultText": "그 아이들은... 갈 곳 없는 고아들이오.\n내가 거두어 보호하고 있을 뿐이오."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DE1E4E710E64F342384BC888A9092FC06B68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FBFCDB70D38F5483C1961671EC0F4E8D086"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36B99BDE33C067462018F504E9D918584BF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FE3DA8820E20C744C23BC69488FEE2B5FECD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "313530C4207E5741593993612AD1BFD16557",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Djambo",
                        "name": "E3-Djambo_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2284425166F425404E7A6403274C67669231",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ABAB6F0320FE834A552BDA01FB682A4CDC28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9476FAA96F35D944832800B876AA5D1E3B07"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "12EA3BD5436C9242663B4EB61DA94B96A15B",
                        "defaultText": "맞아, 나도 그중 한 명이야!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1790149003394149DA38B324C143B22D1E27",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7237574A1792C548851ABDB7B57A3AB3AC62"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B31E0B501238284F504848289C4218A47F1E",
                        "defaultText": "아마란스가 과거에 많은 범죄를 저질렀어도\n가리온은 달라. 평범한 도둑이 아니야."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "694BFEDA69975945B33A2365D5E86C1C8CF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DF114ED002AB747FF4A48E294001950FFF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6253272410BE7848E34AE3B80A30017CEFD3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0FA695578C67342D76811066786FFCC3031",
                        "defaultText": "그럼 말해요! 당신들의 조직은 왜\n마왕의 힘에 손을 대려는 거죠!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0D70A2F9D3641440749E7281AC1304F2C9E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BF9C439693606463F0AD1B53BF0B904EB93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91FCE60E66E245421B8841B29CD71CBBA442"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AFC59C481F3CF14C9F39E851188A93F19439",
                        "defaultText": "...나도 모르오. 아마란스 안에서도\n연구의 진정한 의미는 윗사람들만 알고 있소."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AF6FC1676B17424F4C3AA1D1E96A3F398E7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B194792A2090044479180BF61ED3CAA50A4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C1D051E48E43343C1390958C217FF6BBC29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2E3043F35CF344B063BB964A764800AF022"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90255E968B00344A649A26C3824388ADD0A4",
                        "defaultText": "말도 안 돼요. 목적도 모르는 조직에\n소속되어 있다는 말인가요?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3127D6CC2E33994D30297A10AC521349DBAF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDC50EAB23BB704D45696C3163256F7CA257"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CF868CA3647B34D6A88B6C9EFA55FD024E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C84FFF9D525F0149888896884071DC1A3497"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AB4B2D612FD9D248988B23849D8D3C252259",
                        "defaultText": "바로 그거야!! 아마란스는 간부에게 큰돈을 줘!\n가리온은 그 돈을 나 같은 고아들을 돕는 데만 써!\n아무것도 모른다고!"
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "343A143F2ECDA14DDD7B3125DC634E332F8D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B54C757185A063451878F3C2532E8A74B073"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D62A10477B34254191191232B07ED1C54507"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82AFCDD6532E10442E3BB5724E011778B4C8",
                        "defaultText": "안타깝게도 내 부하 모두가... 내 가치관을 따르진 않소.\n하지만 필요할 때는 내가 처리하지."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7B2E1AA4AE9F64A3C4AF0A4A8C866E632E5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A774DD4063E58844936B9670446F7145D944"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3AC2BCE7904094C4D397D64C888BA39C318"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29AEE9542540F3434B5875E0BA7CF85F61CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83DDF3306F8EE249F319EDC0B564D4D17500",
                        "defaultText": "그래서? 이들을 어떻게 할 거야, 파라트라스?"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F030CB6201B0F64BAF3B8D3419537FE1E966",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "689BDC141CCEA646AA583603FFDF7355B5CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A7DA1E4668461497E2A5E51572845C1A9F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8ED8CD86EE8C64E81983AA0E344E99E6AB6",
                        "defaultText": "필요한 정보는 충분히 모은 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "219863AE8F7F094135393A01A685DD3BD164",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D1FDCE08D6151401B087A50BB7876F32FD8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "69E0D72B73436647D54B07B7BCFFA798EFD0",
                        "defaultText": "죽음만이 답이야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D43726581A18954C1B5BDC337522D523BBF7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CC272B8B79BFB24E246823E809DD7B4F003D",
                        "defaultText": "한 번 더 살아갈 기회를 주자."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D1C790C793EC94B56691352A1D41263280B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "capture garion",
                            "spare garion",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "A982AB29691A3741E00AA18480DB0BC57BC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D833578D473071491C582A535E2B7B528324"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "capture garion"
                },
                "indent": 0,
                "uid": "7E9571C617E19047AD7BCD49664295476338"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++ cruelty"
                },
                "indent": 0,
                "uid": "3C4F16BD39E0824320791BB23DDDF91A4C3C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            9,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B5DF3135603354C87183F882BF58E7B50B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80E305D434127441E68AF0A8BF4573075E1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A50768DA51E9144B3589060063E7F97093AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DC013C887D1174FB969FB5354FEAB340012"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F524370A4004F3498A58B01364BD136AC02F",
                        "defaultText": "잠깐...! 어떻게 그럴 수 있소!? 아이는 건드리지 마시오!"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3B1D288E275C694FFC398044345CE9FDB268",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B454253129B7D3401B3999841E66DBB83610"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E0E25768C396745483B2E869C072188CB5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E11FC86D7C858448499993A4D16882CE3960"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "828A9B5B15D961407E48D4B6BC750586A2FD",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "50986E254386F14B263AB1874F1AD4366C4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D88D3BE0E94B644242BDCB2D204BDDFD3FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            1,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C52C28801136C546CA7826B61F8B9B1FBF8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE4259088FD2074B7E6B8CD48BEA0A995A11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0BB60EFC2503E340104A9332E718333A0F11",
                        "defaultText": "내가 무슨 생각을 한 거지? 그랬다면 무니와 다를 게 없잖아!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "62E09557162CE8491A4B43417277CBCC0D08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "415F419266CF0248753BB879831A27740F7C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "735B721F95F925435F8BACC3F23D4CB12CC4",
                        "defaultText": "더 나은 해결책은 아마..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "670FAD9D244BD948174926E1F0E34B422DD1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4218FF265EDDA64ADC8B96739B06E5E7EF28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF19DC636BEBD14EC96AEEA43FDDA9146E40"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BFC9FB8E131E264569595D24174A129ED5EF",
                        "defaultText": "물론 아이는 제외예요. 마그놀리아의 누군가가\n저 아이를... 올바른 길로 이끌어 주겠죠."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E92797C8216D24C738B2B9755C245F442A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B310A9D446236446659BF0E3BACE8B8BB46E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85FB0EAF33E9B14F151B10645F3BEF757D2A",
                        "defaultText": "당신은 좋은 뜻이었던 것 같지만,\n그래도 범죄 조직의 밑에서 일했어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ACB7159D52BA484E918A762984DBF050BBC3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7340C8B9343D634D2A7BCB536F0D4F191880"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "343C73D8883603491648FB81C7C961313A6F",
                        "defaultText": "목숨은 살려 주겠지만, 감옥에서 시간을 좀 보내야 해요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D34343A7C2E724A4C4AE89970A15D3FE043",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6C7308E26AEE542195B9EC593EBCB624697"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83EA4748290F494E673938D7E386E67CF492"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "40922C4277EAF24DEE6962C839C749B7D98D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72ADA7A8077E54486B494E470AC9AFC97E75"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8A192CC80E4434E0099532415C7E63009B7",
                        "defaultText": "아이는 아주 좋은 보살핌을 받을 테니 걱정 마십시오!\n저를 보세요. 저도 마그놀리아에서 자랐습니다!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "05B4B1B2416AF54D61184DD4752962C72B99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "665F6AF45BA7364C0A399AF1903214CF83B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "234B1B767C60284DC939C8F15E7156D93813"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "006F266510AB564A506B97214A6982689878"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40087AD62ABBD84F5A2A69E61F32DB339DC3",
                        "defaultText": "넌 마그놀리아 출신도 아니고,\n정의로운 사람의 모범은 더더욱 아니야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1E0271DA9E741443744993F4102B91D110DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A351E0A44F36944EA8290B851164DFB30223"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDC0572E2DF7B544113924886816B06C1D5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5FF20FF078EB54CEE598552E59D24020961"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E4C0FC9E1630744BCF5A49F4EE5282A0394C",
                        "defaultText": "가리온을 내게서 데려갈 거라면 나도 안 갈 거야."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1291E28E2EB1D442DA792976513078E15F1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "228D6A259B7BE34C387BAEF6EF809BF4FCF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5702624652E499418C9A58A737B83261BAAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E23C049A6ED705451469C6B3770BF18E985B",
                        "defaultText": "그런 말 마라, 잠보.\n실은..."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D300C114203634A86091285A77F289855EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B81F3CF7FAF68497599044342F2837D5A46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87296D147EB24047786AF8E4CE3B3F8342DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1998CA5498C688414D5822C2A7786C3AC003"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "8EC0F15E8EB0D5451E1BD016625D4FCA8697"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "spare garion"
                },
                "indent": 0,
                "uid": "C3B5527F6E228245D16BC7E3DDD14A699DD8"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-- cruelty"
                },
                "indent": 0,
                "uid": "3CF9D5AA14DBA3426579F961B2A90151E4C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            6,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C387249529687040B128F849E603001AC4B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0037237A6236B14215483128F26E39883567"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "0B8F1EBB4E9AA74778990ED76A6B738ACB2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B34036F75F3C2473C4B47D54F890598B8B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A12150D18E53654B6F19DF1844300440BD5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EDD8B42A30FB244CD46B5C437EF1D1B5AEF8",
                        "defaultText": "기억상실자는 내가 아니라 너라는 점을 친절히 일러 두지.\n저자가 무슨 짓을 했는지 벌써 잊었어?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "35FFA3B06542714498399CE38A8D47E98A58",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DA1859D3402C742B349633820A5A3B56CC7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "A896A3D129CD754A0A0A9C75AE2F3C66413B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58FDCA3632F009460D0ADAB5F2CD18123ECC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5B348EB5DFB3147962A6A13CBBE8D70935F",
                        "defaultText": "관용에는 감사하지만 저도 그의 의심에 동의합니다.\n이게 무슨 뜻입니까?"
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2E645D858D7224A391A548770D0E9A1F043",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27C514ED8CF2304ED27B51601405B3CB4A0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73D0734F4EDD864C020B6F1248B6310BB22C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BBD90C29EFED2477878BE24259EC256F984",
                        "defaultText": "이유는 모르겠지만, 왠지 이 남자를 벌하면...\n내가 위선자가 된 기분일 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E1E1D98E40FA064118197CD3F98418BD46CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CC3AB6D771CE84AEF9888E012A6EAC7C0BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06472C83781744406D487DB81A4D3680E63B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ED52077F590FE441B118D758B207EF250150",
                        "defaultText": "난 ‘그릇’이라는 칭호 때문에 계속 도망치기만 했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7C6FAC32BEBF84F7B8A0EB5FFC90A84594D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9E1A6292AD7234B504909492071362BE0BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E0CDD553142E6431669C664EE4DA8D3CA8F",
                        "defaultText": "백성들이 나라는 사람을 더 잘 알았다면\n난 아직 호이카데에 있었을 거야.\n그릇이기 전에, 난 파라트라스야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7F693A097A1DB14113194A33FEC2795822F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA81703646B5084846684BB3F9D277B98F2F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "18F32D2D85B86844C54824D27BB77CC6DFAE",
                        "defaultText": "이것도 마찬가지야. ‘교단원’이라는 이유만으로\n이 사람들을 파멸시키는 건 잘못됐어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "38E001693908F04C97494513594FE9595BA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "476DE0109BE3B14C785AC659549E47132F45"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ aff"
                },
                "indent": 0,
                "uid": "1125F9D85E87894B1E48B30520412ACC7987",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7AB299F7033C1420828E6A7E3901A0B5915"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "8AC086EA4F27334DDE28DBD5D4F274113896"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B8B56AB47FAC1422719C534FD62107D27CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            5,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "735B86FD3F9863465428F8584B0E4DE2C77C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47879C5D5866674F38896CF757AE717608AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF8C0E9893804442981925C4B52EE56112E1",
                        "defaultText": "현명한 말이네요, 파라트라스. 헤헤."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "492236ED1D2BE445F34800A74C6AF47896EE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54ADEC0C100FF440FF2AE4761504997405B7"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Spared Garion?",
                        "index": 184,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "81BC54482EA7814971886533BAA8E6F1CF4D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after final choice"
                },
                "indent": 0,
                "uid": "1A0842081CE9D548943B3B17C2746D17B907"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0A3E2F44DA1E54BA27B2827612F0B753708"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D77BA2420166E747515ABB961DD8743AE7C6",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E11A7B1459FD741990A14155AD8CEFC0C26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE7C30E0272F04451969F2320D0A6039A121",
                        "defaultText": "그건... 내가 바랄 수 있는 최선의 결과였소.\n우릴 죽이지 않아 고맙소."
                    },
                    "position": 0,
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A25ACEA75B2D14C4F59D19591F516535F36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4430DF2336F4C44D76081DB6A5D5A09D3073"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CFA77A6C7D685140CE2B1B0299FA61AD4084"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D423D90A08CE304C1B690A44064F4715FB93",
                        "defaultText": "감사할 필요 없어요. 속죄할 마지막 기회예요.\n헛되이 쓰지 마세요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "53D28A6F7B59864ABF3ABB4894B92C050B0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3D223F66C54A94E673A4A924363CDC4ED62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B90075C93F92D24B9259C8A44515202A6197"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AB4CC3E513AB546737A0938B9BDFB9415B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08E6657F585F5347966978A2BDC23BCC0949"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "251F08D806B3734F0739DAF58238126DE6AF",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B1856945E79B64EA13A65600EFE37568B51",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "057AA86725AB334DD74A8DB06E64803EB2F3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Spared Garion?",
                        "index": 184,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "210E9C532C87E9440569D0B4BCF81C477273"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "39D2692E7617C144EB29923794098A67C027"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB63941C8478774AB40B1737A7509F97962B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "826FA58535D4D64947582795EF3FE04ED685",
                        "defaultText": "잠보, 이 사람의 상처를 치료하는 걸 도와줘."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D350E644677B0645615BC0482AD8D8958A61",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E80FFA5091606648382A1D275E78BA204E1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AB3B72E2C4F504EBF58D0C4F3B798D11DC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "765BD36F86B755489869F9D7BAADAAD537E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "673ED51281F9364DD0490007F6CA22F6EB0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "83F423E20EEEF546DC8AFDA1AD49CE839072"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B0A13D267017804E043B2FB8E6E36D104BA7",
                        "defaultText": "... ... ... 알았어."
                    },
                    "position": 0,
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F476EE706118F54A9389744298CADD5865A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A8485DD5339C1447F28B0A112C7B7FBD063"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "311A54FB4C6B544BA93AADB651C7370BB8F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "7D36CA8A85B7F34AA42B8707FA528F0443B1"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D77BA2420166E747515ABB961DD8743AE7C6",
                    "duration": 36,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "4116C1900E46434DC268C9747DD459E379BA"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "765BD36F86B755489869F9D7BAADAAD537E7",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E779737C550A594FCE98BD135F37F5A44E83"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "201579F957F14246E79960B63F95D1868A1A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3EFD590D15A4314C9D6848B77D32111C84A7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "5C78531A515748471D291B7816AF1FC9513D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close/open, pause"
                },
                "indent": 0,
                "uid": "884D9B2D69D7E64E1B981738C2CD057B6A29",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6E1FCEE40091C74DE938EBE3826A95622DC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22F62B7F4C11444DA54A41B7E34899FBC821"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4CD0C2A5777C44F512AF587706CE1343E4D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83708AD204DD674F7A3A4BA8F2386072D427",
                        "defaultText": "여러분, 오늘은 싸울 필요가 없을 줄 알았지만 틀렸습니다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C9C9AAA72A18824D170B80003CEAFD36D258",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C5051C33751644DEE39C021F3636C203EBB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D6EEF798AC83248177BEDF5545D894FA37E",
                        "defaultText": "충분히 쉴 자격이 있으니, 오늘 밤은\n이 요새의 보호 아래에서 묵겠습니다."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E28B1888CCCF744E09BC0E19772568BC1F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "41A4CF6577BF954B57691B62DE5A08DC6909"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC0FCA3E792B1448F27A5B96FB7EA51FEF5E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF149D5E25AC7943A88824124BD025AA2E7A",
                        "defaultText": "이곳엔 보급품도 많이 있을 겁니다.\n푹 자고, 배불리 먹고 마시십시오!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2D63C0317F94744706A30B7153D3FB520AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4D5409E4919906421E4A0200AFCAB79CF78F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F200DBA21E1E5478898F2D5FAD5B19A7205"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "099AFD3E6E7243455C294E78FB88D333393D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "7958A0E21A08C24AB05979C31E3908B54B0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            1200,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7DCB92387D83147475B14B0D8DC330BAE02"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "F3EB67D04F08D64E478B4FD7C90D77978BF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5D23E052095F6240E97A3247F7AA33A7E2DA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "294AA1FB3142C54CB1699F856046312BB36F"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "4DFF182D0255D54B0418DA37A8AFD6FBC140"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "8AB9005F7F75B344951B553529303C4A97BB"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "D54CBB82751D464626898547993DE0B2CCC8",
                        "name": "C6-06 Enter the hideout"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "425F49DA0A5055430B4B4BE36FAB228B3C31",
                "expanded": false
            }
        ],
        "stringVariables": [
            {
                "name": "djambo name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "hellios time",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}