GS.dataCache['3093FE696D594044332871D0AA708DD3B40F'] = {
    "uid": "3093FE696D594044332871D0AA708DD3B40F",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11B-6b S2 Barrels",
        "type": "vn.scene",
        "parentId": "675379D17C4B3741448AB130E167EB7A6499",
        "chapterUid": "8A78B92E5A59F446F05823F4DB00C78A28B3",
        "order": 2,
        "localizableStrings": {
            "BAD699BC51B8B84B269804B47EE9FB2584C3": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "44545CFB7081A444A18904A443A2D10357DB"
                }
            },
            "99106E82543CB241A9880C17D5A2A7E85C04": {
                "t": "Can you tell me why you're so attracted to these barrels--",
                "d": {
                    "cid": 0,
                    "eid": "13B7907A1685384FAD59DE250B8702CDBD5B"
                }
            },
            "2C2A48712F16A64AD18B85F4D64A5503171F": {
                "t": "Oh.",
                "d": {
                    "cid": 0,
                    "eid": "A9D16A7867ECC84A322828D5271847CE0A06"
                }
            },
            "AF3DEB1443DCB849E128427579A984C20B07": {
                "t": "These are... scorched Manadrops, just like the ones in the other fort.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "006B06E79CBAF3429F3A9D67F8493E7BAC88"
                }
            },
            "989AF68E2E36124AAF481995A5A2484E9193": {
                "t": "Nini, look at this. I'm not sure, but this one looks different to me.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4FE1D3C98C465441FB1A230686011B2D4A74"
                }
            },
            "E38478D01DE4E24323299E23B5050DF88FE6": {
                "t": "You're right... This one is a Manacrest!",
                "d": {
                    "cid": 0,
                    "eid": "AC83A6874E6F874F942A4CB2749647ABB0A9"
                }
            },
            "550F1A90375C3448442AF96458DDF94C131D": {
                "t": "WOOOT!!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "2D745C1D204DC74D100AE711DAF6FBA24962"
                }
            },
            "831FC0A63897314DB91938A2E14FF26BB678": {
                "t": "It seems completely unusable. But here, without a shadow of a doubt...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4BE294B834342942AD2A30366D0280C0D710"
                }
            },
            "919D240D2F56B0496988B1D18FC25B0CC5AA": {
                "t": "...Someone tried to create a Manacrest. But when did that happen?",
                "d": {
                    "cid": 0,
                    "eid": "5B7B65074CA3D74E172AAA24C5A90FCFD130"
                }
            },
            "D11343EB58075641036AF0D9904A4554F67D": {
                "t": "I have no idea. However, I also found this. Would you mind...?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "CBFE712725C1824E7A6B90D1D9516EE6B103"
                }
            },
            "928937C0517CD749913A1BD250E4CFE6C628": {
                "t": "Ah, an old scroll...",
                "d": {
                    "eid": "9ABB517E8200E448BE1927222FDD745CDC51"
                }
            },
            "CB717BD29951564C4C28D484F4C9B63A8EA4": {
                "t": "Let me read it for you.",
                "d": {
                    "eid": "AF1F85C1624F73457B6974B5EBFFAC577FB0"
                }
            },
            "D0F49A923F7DD448B54B72764C28CD9B6855": {
                "t": "Thank you, Nini.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "C961F25C2930054F6588E664BEA15D5C0867"
                }
            },
            "E22B568D04DC0745601860B46FB638F9D8DE": {
                "t": "This one is also a little burnt, as if someone tried to destroy it...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EE896F6C539C554955182E131327C4EB29AA"
                }
            },
            "C3BB069A7A856740213845C47EA1D42EE764": {
                "t": "Ahem.",
                "d": {
                    "cid": 0,
                    "eid": "3100C6866F7EF24DE92B5D7618043B55AA7A"
                }
            },
            "FCAB51AA7A4A044F2279E2C7D2A44E693824": {
                "t": "\"Our attempts at recreating an inexhaustible source of Mana, like that of the Demon King, have been a failure.\"",
                "d": {
                    "cid": 0,
                    "eid": "9BE84C4E8AA4334BB29B0AE217D2F8098B23"
                }
            },
            "535087814147024462884AB76E66617AC315": {
                "t": "\"In order to achieve the same level of energy, we need an artificial vessel for that Mana, which we have called 'Manacrest'.\"",
                "d": {
                    "cid": 0,
                    "eid": "FAEEE8C27309384D296B39D52C41F572E79C"
                }
            },
            "EC8FAEA70E10C94B1439CB7671362246840E": {
                "t": "Interesting. So, as we thought, the Manacrests were created by Amaranth.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "5AC9255047B10144DC883363E3AE1E270063"
                }
            },
            "0A71CF505CB5D0444C5919E3EC5DB3A53CFD": {
                "t": "Wait, there's more.",
                "d": {
                    "cid": 0,
                    "eid": "17E158859A404847247A60E11117864E5CB5"
                }
            },
            "D24737F50ED58641EA1AE476084878AD361A": {
                "t": "\"It is also necessary to find a person who can bear the weight of all the Mana accumulated in the Manacrest.\"",
                "d": {
                    "cid": 0,
                    "eid": "858017738B55454A6349D216423FA6EBD985"
                }
            },
            "C48F21AF5DCA97436E2B9923638003775E87": {
                "t": "\"So far, however, the Manacrests we have created have imploded, proving to be failures.\"",
                "d": {
                    "cid": 0,
                    "eid": "E091373F22E6D144826AB4D023E1762FC71A"
                }
            },
            "64943D70354BF647DC9B0FD1D823BB8F3731": {
                "t": "\"We have attracted numerous children into our circles in the hope that they would be compatible, but the chosen few have died.\"",
                "d": {
                    "cid": 0,
                    "eid": "1854CDFD64B9664C018B3FE7F1AC67D3C620"
                }
            },
            "4A15E73C8BA14041FF6ADA83144E0FF8ED44": {
                "t": "That's... horrible.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "E5226E2E4BF9D149836BA283381B0B9191E4"
                }
            },
            "1040666F31CED34A9618F9A9262E9558E7E2": {
                "t": "\"The combined forces of Magnolia and Pylum have succeeded in tracking us down. Soon we must cease our operations.\"",
                "d": {
                    "cid": 0,
                    "eid": "A10C282F2089814C6239FFD7F8E4CB323AE3"
                }
            },
            "F8ED3399532EF4400E8B06E6001F909774E9": {
                "t": "That's it. The rest was burnt, but it doesn't look like there was much else.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "E4F1576686161848431A97E8D96880C2D1E8"
                }
            },
            "E139264B47E6F2432D5ADBE5E68895C3AB30": {
                "t": "How come such precious information was just left here, anyway?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "C110A5A085533544BD5B8E6777F1A4090644"
                }
            },
            "67BCBF848C30484849689F921281C124DAD9": {
                "t": "I wonder. It looks like an old report.",
                "d": {
                    "cid": 0,
                    "eid": "EA1418041E57124CA368FB98E587DC5A0D4D"
                }
            },
            "678F70BC4EF881467A6903A867A5108AC01D": {
                "t": "The date... is thirteen years ago.",
                "d": {
                    "cid": 0,
                    "eid": "29AC2CEE61EE784F848B4AB282B8BEC15B52"
                }
            },
            "D726B4C130026546543A8221D0C4422207D0": {
                "t": "That's... a lot of time ago. So, Amaranth had abandoned their experiments in this area for thirteen years.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "CDE17FDB7A79F3466E3A1AC7CEF6799A80F6"
                }
            },
            "BF9A68265834C34BD819F0104561A9DD4371": {
                "t": "It seems so. But since the awakening of the Demon King, they've restarted their wicked experiments.",
                "d": {
                    "cid": 0,
                    "eid": "09AFEC836ED2214D1939E3D41DA3E60DF496"
                }
            },
            "0BFF812B0EDA48450028C5C5CEC99068258D": {
                "t": "The Manacrest... it's a tool to recreate the Demon King's limitless Mana.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "66996B4B4253834D395AF096BC018A774204"
                }
            },
            "21A963384A37A14A333973A899F14AEA1693": {
                "t": "And just as there's a Vassal of the Demon King... the Manacrest also needs a suitable bearer.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "19943C1E7C83174B011911674ED708024EDA"
                }
            },
            "A8843E65190A574706296D81D0759E584C3C": {
                "t": "If so, who am I-- the {SP:2}{C:1}only one{C:0} capable of using this power?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3CF329F5359AF24A00297EC290DC5350E101"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C43F5855D84B3472D3B745526131BE09A33"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AFAC8386607AF645069B0FA60256FF076B52"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "89FCC10071335247DC793BE4B92092AED7FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49177A213EBE85448938404232AAA53EE471"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A656A63D77C6F54C393B89B0AEF81C1C8BCF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2FBFA3603B61724F9268C1C904D4F851A7BA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9A8142551B7495460209349707DEEB9D3229"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E9CCA8F1A5A504E1A985F955B7753ACE444"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BAD699BC51B8B84B269804B47EE9FB2584C3",
                        "defaultText": "우후 우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "44545CFB7081A444A18904A443A2D10357DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64DA28678E15D641273AFA26EA174CD5C996"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91730DE63E66E446C18A39A10656F37C51EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99106E82543CB241A9880C17D5A2A7E85C04",
                        "defaultText": "왜 이 통들에 그렇게 끌리는지 말해 줄래--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13B7907A1685384FAD59DE250B8702CDBD5B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9C720C38CBBF444226885A8CCE5EF0EA7B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C2A48712F16A64AD18B85F4D64A5503171F",
                        "defaultText": "아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A9D16A7867ECC84A322828D5271847CE0A06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0C276C74871D645B36AE307A22328111C04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A20E67A0277A56493F18B194487A22B4F154"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF3DEB1443DCB849E128427579A984C20B07",
                        "defaultText": "이건... 다른 요새에 있던 것과 같은 불에 탄 마나드롭이야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "006B06E79CBAF3429F3A9D67F8493E7BAC88",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A3232CD6460E7498B28DCA6520079825AB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98623E534804E44E740B3B9665FEBA55D657"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF060B762CBE58492D8ADA139FED0BEE6CC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "416FF82134E611411038995321D5C2A53624"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "989AF68E2E36124AAF481995A5A2484E9193",
                        "defaultText": "니니, 이걸 봐. 확실하진 않지만 이건 다르게 보여."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4FE1D3C98C465441FB1A230686011B2D4A74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C24900468FBE24FE54888E1C2850AE6D065"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9461555B8B3D734DD01BF3D1771491E43C8C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1254A1352CF84744417A9073E1A0949D132B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B9DD9A4818D3D745A979D8575C2F2BD9EC13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9CC5BE3138E034D4A9A3AD0D878AA708567"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E38478D01DE4E24323299E23B5050DF88FE6",
                        "defaultText": "네 말이 맞아... 이건 마나크레스트야!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC83A6874E6F874F942A4CB2749647ABB0A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CD36E8D7737974E7E1AF6C6B784B9142CA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "360CCFB4496B6740CF589BD4119FDD6792BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F6816375EE8A34D857B13B9C42A355031B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "550F1A90375C3448442AF96458DDF94C131D",
                        "defaultText": "우우우후!!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D745C1D204DC74D100AE711DAF6FBA24962",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8116364647CAD3464F8A67962CBAAF559C22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE8531A27417D940208BB5A10E9F1E65EF30"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "831FC0A63897314DB91938A2E14FF26BB678",
                        "defaultText": "완전히 쓸 수 없는 상태야. 하지만 여기서는 분명히..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4BE294B834342942AD2A30366D0280C0D710",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "654FF6642AD9C64A943835E4CAB124DF74B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F1FF9A46CE29245E55ADCA55A5720A56922"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "919D240D2F56B0496988B1D18FC25B0CC5AA",
                        "defaultText": "...누군가 마나크레스트를 만들려 했어. 그런데 언제였지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B7B65074CA3D74E172AAA24C5A90FCFD130",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBE5605E7C43C746713BE4E590704F6183A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD2EFAEB69C56845957B6CD6D1A52C97F6A6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D11343EB58075641036AF0D9904A4554F67D",
                        "defaultText": "모르겠어. 하지만 이것도 찾았어. 혹시...?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CBFE712725C1824E7A6B90D1D9516EE6B103",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0D7AD195E568346750A457739FE8CB1864D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "928937C0517CD749913A1BD250E4CFE6C628",
                        "defaultText": "아, 낡은 두루마리네..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9ABB517E8200E448BE1927222FDD745CDC51",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CB717BD29951564C4C28D484F4C9B63A8EA4",
                        "defaultText": "내가 읽어 줄게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AF1F85C1624F73457B6974B5EBFFAC577FB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "read",
                            "read",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8AE94D34AF9C04F3219B49804B0860A25B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5413CA1D9DD10040EF49D0956FA2C3E05016"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "read"
                },
                "indent": 0,
                "uid": "A0E10C0126218347AD8A7054701CA9ECA0A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6387B0DC521D264BAE1A0787510249426788"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "913EE8DA7736E7494428F38144D9CA664EF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13E4B02866F0944B67592C27FD0655A701CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D0F49A923F7DD448B54B72764C28CD9B6855",
                        "defaultText": "고마워, 니니."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C961F25C2930054F6588E664BEA15D5C0867",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E27CC21128346412369BC3779EFA547AC1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B60E54BC1973294B554B83996F358E2150A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E22B568D04DC0745601860B46FB638F9D8DE",
                        "defaultText": "이것도 누군가 없애려 한 것처럼 조금 타 있어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE896F6C539C554955182E131327C4EB29AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E40B8A92B25664BFA596DB40AF82848AF16"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1B2B6BC3B514445033B4791DB45C87DDBA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C3BB069A7A856740213845C47EA1D42EE764",
                        "defaultText": "흠흠."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3100C6866F7EF24DE92B5D7618043B55AA7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "525BEE1E25AFA14593482D29D5AC6BD0480A"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E6CB78B62F303142449B3EB9CA6B892A4C6B",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FCAB51AA7A4A044F2279E2C7D2A44E693824",
                        "defaultText": "“마왕처럼 고갈되지 않는 마나의 원천을\n재현하려는 시도는 실패했다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9BE84C4E8AA4334BB29B0AE217D2F8098B23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D7005F111B95640EA7998867517BAAA94A0"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E84E0BB31A2EF34762484C271BB3ECB93C27",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "535087814147024462884AB76E66617AC315",
                        "defaultText": "“같은 수준의 에너지를 얻으려면 그 마나를 담을\n인공 그릇이 필요하다. 우리는 이를 ‘마나크레스트’라 명명했다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FAEEE8C27309384D296B39D52C41F572E79C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F3948799B6A76475A6A41E2CD717A7B4396"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B9B0F7F746AC84C891B5FC8E2ACC20B8EC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EA74BFF506A45413829D5182429E91760E5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC8FAEA70E10C94B1439CB7671362246840E",
                        "defaultText": "흥미롭네. 예상대로 마나크레스트는 아마란스가 만든 거야."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5AC9255047B10144DC883363E3AE1E270063",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "932745F22020474E6C2902B27E364555FBF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78F502376C41D44F7B786382DD2F024D4ED5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A71CF505CB5D0444C5919E3EC5DB3A53CFD",
                        "defaultText": "잠깐, 더 있어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "17E158859A404847247A60E11117864E5CB5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8EBADD865FD544F8B7AF413B3A460DB4B9F"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5A79C8077AEEB04B89781AF3B54E998FD70B",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D24737F50ED58641EA1AE476084878AD361A",
                        "defaultText": "“마나크레스트에 쌓인 모든 마나의 무게를\n감당할 수 있는 사람도 찾아야 한다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "858017738B55454A6349D216423FA6EBD985",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "267C6C2927FA7143C648F78048C8E48FC5FC"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0091D5723266D64F9C59298978C7B7084D00",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C48F21AF5DCA97436E2B9923638003775E87",
                        "defaultText": "“하지만 지금까지 만든 마나크레스트는 내부 붕괴를 일으켜\n모두 실패작으로 판명되었다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E091373F22E6D144826AB4D023E1762FC71A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E7DBBF984336446088B7470026A64342E50"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D2B809541BDA2548FC38FEE2AE8F1DCC607D",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64943D70354BF647DC9B0FD1D823BB8F3731",
                        "defaultText": "“적합자를 찾고자 수많은 아이를 우리 조직으로 끌어들였지만\n선택받은 소수는 죽고 말았다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1854CDFD64B9664C018B3FE7F1AC67D3C620",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28B04B5176BA144D1148D4F6B3A6CF8844D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A59734F1105D8454F49CCC81B6EE8CF3ED5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4F45E2D83BD5A043C28B5B992BE0BFAE9A7D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": null,
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BDBEBEB7075C3840707B98574C3B1ECA5444",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6FA653741E9F5643004811F76994D37F117D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EA5650C0DECD64E366BF781BE257A3F96AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A15E73C8BA14041FF6ADA83144E0FF8ED44",
                        "defaultText": "그건... 끔찍해."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E5226E2E4BF9D149836BA283381B0B9191E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8111340109535342A93B044486B0D97BAAF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35E5D24A826EB14D64282C07FD0F122CF062"
            },
            {
                "id": "gs.MessageSettings",
                "params": {
                    "useCharacterColor": 0,
                    "paragraphSpacing": 0,
                    "backlog": 1,
                    "bold": 0,
                    "italic": 0,
                    "linePadding": 6,
                    "lineHeight": 0,
                    "lineSpacing": 0,
                    "smallCaps": 0,
                    "underline": 0,
                    "strikeThrough": 0,
                    "autoErase": 1,
                    "waitAtEnd": 1,
                    "font": "BelgranoMS",
                    "size": 40,
                    "outline": 1,
                    "outlineSize": 4,
                    "shadow": 0,
                    "shadowOffsetX": 1,
                    "shadowOffsetY": 1,
                    "color": {
                        "red": 240,
                        "green": 220,
                        "blue": 180,
                        "alpha": 255
                    },
                    "outlineColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "shadowColor": {
                        "red": 0,
                        "green": 0,
                        "blue": 0,
                        "alpha": 255,
                        "color": {}
                    },
                    "fieldFlags": {
                        "autoErase": 1,
                        "waitAtEnd": 1,
                        "backlog": 1,
                        "font": 0,
                        "size": 0,
                        "color": 0,
                        "useCharacterColor": 1,
                        "bold": 1,
                        "italic": 0,
                        "smallCaps": 1,
                        "underline": 1,
                        "strikeThrough": 1,
                        "lineHeight": 1,
                        "lineSpacing": 1,
                        "linePadding": 1,
                        "paragraphSpacing": 1,
                        "outline": 0,
                        "outlineColor": 1,
                        "outlineSize": 1,
                        "shadow": 1,
                        "shadowColor": 1,
                        "shadowOffsetX": 1,
                        "shadowOffsetY": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "21D7F08A2D7C8542C63BF67684F3D8BE5E59",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1040666F31CED34A9618F9A9262E9558E7E2",
                        "defaultText": "“마그놀리아와 파일럼의 연합군이 우리를 찾아내는 데 성공했다.\n곧 작전을 중단해야 한다.”"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A10C282F2089814C6239FFD7F8E4CB323AE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59E913770C532242640A1C3698A34B611462"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0902E10C3F22F8478A8B7E75CA3D21D99327"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F8ED3399532EF4400E8B06E6001F909774E9",
                        "defaultText": "여기까지야. 나머지는 탔지만 다른 내용은 별로 없었던 것 같아."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E4F1576686161848431A97E8D96880C2D1E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A464096406628408159D8F3BDB9753A5B02"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "606FA93F64E5D24D551A15A38B8059A39D7C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "119684E042E64742803856589482085C4706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "37E7A89033C3D64ACF180BF7209F4F761877"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "A1625EF93E3091405F5A3581E6B7E38C5699"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "561EB4923A81C04834196C12CC6DC8C581BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E139264B47E6F2432D5ADBE5E68895C3AB30",
                        "defaultText": "그런데 이렇게 귀중한 정보가 왜 그냥 여기 남아 있지?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C110A5A085533544BD5B8E6777F1A4090644",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0A1FF642DBDF241602B76F66CBF967F5F14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B6F08263A3EA2482818B0A8204B223DBAF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67BCBF848C30484849689F921281C124DAD9",
                        "defaultText": "글쎄. 오래된 보고서 같아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA1418041E57124CA368FB98E587DC5A0D4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97A6C644619DC44C7449B2A98A7DC08D1DE9"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "80AB9F006311C94D8248FAA42D5A8029FE96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5A02B6DE7DCA44490F6AA6E7C8E469E31D5F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "678F70BC4EF881467A6903A867A5108AC01D",
                        "defaultText": "날짜는... 13년 전이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "29AC2CEE61EE784F848B4AB282B8BEC15B52",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CA032F3578EB7542C068C518C0339FBBC23C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EBA553669417834DF46BD274344C0EF49FBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D726B4C130026546543A8221D0C4422207D0",
                        "defaultText": "그건... 아주 오래전이네.\n아마란스는 이 지역의 실험을 13년 동안 중단했어."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CDE17FDB7A79F3466E3A1AC7CEF6799A80F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B06823154DE4924D6F8B1B11E5E27EE1CE32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B9C19BE17DB1C54C2568BF78DA216C554BB2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF9A68265834C34BD819F0104561A9DD4371",
                        "defaultText": "그런 것 같아. 하지만 마왕이 깨어난 뒤\n사악한 실험을 다시 시작했지."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "09AFEC836ED2214D1939E3D41DA3E60DF496",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C157998119584944818B0B7343D899296795"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA210AA57728454499884C9982DEDC982829"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0BFF812B0EDA48450028C5C5CEC99068258D",
                        "defaultText": "마나크레스트는... 마왕의 무한한 마나를 재현하는 도구야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66996B4B4253834D395AF096BC018A774204",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "832A79B622C2074234692B96A62BAB6CCF4A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21A963384A37A14A333973A899F14AEA1693",
                        "defaultText": "마왕에게 그릇이 있듯...\n마나크레스트에도 적합한 소유자가 필요해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "19943C1E7C83174B011911674ED708024EDA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A368A6B867D6F542207B74516963AFF3EF94"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8843E65190A574706296D81D0759E584C3C",
                        "defaultText": "그렇다면 이 힘을 쓸 수 있는 {SP:2}{C:1}유일한 사람{C:0}인\n나는 대체 누구지--?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3CF329F5359AF24A00297EC290DC5350E101",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A246617E31792549094AD2D7E7BFD6E39443"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8430D4724223C241292984C1A237C4E6F17C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E6A38852D8B8246097ACEB6387A730C994A"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}