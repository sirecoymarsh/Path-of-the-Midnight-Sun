GS.dataCache['D114143978FD074FB5397769994D82F912D7'] = {
    "uid": "D114143978FD074FB5397769994D82F912D7",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-1b (Talk) Rya",
        "type": "vn.scene",
        "parentId": "DF8BAB6145BEB846567B9D3341D445F10851",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 5,
        "localizableStrings": {
            "158DE1406290B845EF8B676352545E51B38B": {
                "t": "Rya, do you have a moment?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B65B38564FF5B747883949B6987CE3BEAE09"
                }
            },
            "C6EFC17A87C099473868BB4297064ABA83B4": {
                "t": "... Faratras. Did you need to talk to me?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "EFA2A9432A1F554C895B34B84B7E35D55B60"
                }
            },
            "506ECD836B47384DF2297C61572A98926B86": {
                "t": "I'm worried. The other day, at the hideout in the desert, you went through some painful memories.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "ECAFEAF179C1D74B6C48E4A14900FC8BF296"
                }
            },
            "D723A3223104224D24481B60022495015AB9": {
                "t": "And I... I couldn't do much for you. I wanted to apologize for that.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EEC10E7182ED18445C69B17519A7CC3D8DAD"
                }
            },
            "E43940CF1993A248E089F1E8E7044F5E8DFC": {
                "t": "Don't worry about it. In fact, I'm surprised you feel responsible.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "B1A1135E8D9F8446427A8ED9EF0BD2D527E4"
                }
            },
            "EEAFB7040347F842F77A3961D6C9B45D62AC": {
                "t": "Really, from where I'm standing, you have no reason to.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "5391CA7F119C884C898882F7D32DAC06040B"
                }
            },
            "113825468D04A748508995F4279A4482DF75": {
                "t": "Great. I'll see you then.",
                "d": {
                    "eid": "0E7AE1537B2F814C863A375421A278C47267"
                }
            },
            "E18989D535039640198B34A04529E6C06E79": {
                "t": "From MY point of view, I have.",
                "d": {
                    "eid": "876FB82285902840B00A3667525AF8FAAC6C"
                }
            },
            "7D4231DA8E08944F485994F29859A338AC64": {
                "t": "Don't be your usual self, Rya.",
                "d": {
                    "eid": "BB4BCE575FDB6340438B07F2548E256F7FD4"
                }
            },
            "626051D003C7724D8C2AB6483B69CBC0B481": {
                "t": "Concise and straight to the point. This is also a trait I like about you.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "971BC9353EF4254BBE5882C69DE241D3BAC4"
                }
            },
            "A8147A7964B3734B8B0A7154A90AD6036870": {
                "t": "I think the same. We never needed too many words between us, did we?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D26C88BB6F05554B5C6898B425038C2A5260"
                }
            },
            "A02112208C64754C0219C57566D48A832336": {
                "t": "Hehe. Yes, that's right.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "66A0E2AF421BB14CE30BAD020DAEA167B893"
                }
            },
            "9FEC622B911CE846389B5F029B156D1E89F3": {
                "t": "Excuse me?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A399614B63BF3247064BC375B91899A7C503"
                }
            },
            "38983EA8112EE7426B08CFF1FB4826C497EA": {
                "t": "I want to feel involved. Don't leave me out of your world.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8D69FBB6872CA84F1A19805737400FF5569B"
                }
            },
            "D82A0226465018458C3A1879B492E89DF81F": {
                "t": "... ... ...",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "CB81FE3103084949151A7BE67799F8D2D7FF"
                }
            },
            "F1220A0D7A3D004D3C2969B41F220BFACDE3": {
                "t": "I understand that it must be difficult for you, given the trauma you experienced while you were imprisoned.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5B11B5B74AFFC94BF328781581D6A3606133"
                }
            },
            "592720199E30D045906854914ED6EEDB3E5D": {
                "t": "But I want to make it very clear that you can count on me.\nActually, you SHOULD.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AA0637388C474441E3099EA26B42B04D8F84"
                }
            },
            "3E0C5FCE3D7BA2483F582AB5C52ECE478415": {
                "t": "You're right. Given how our relationship has evolved, it would be unfair of me to continue keeping my distance.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "BAD9C0602A3A23444F5B0D77436C35F038EF"
                }
            },
            "ABF5AC24475D224EA9699A13A20D577E3D02": {
                "t": "I think I tend to isolate myself as a way of protecting myself from external anxieties.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "7950903148813249326B5FC6CFE2F06C3137"
                }
            },
            "91C2C9B79DD00941BB799F23518B61F4A583": {
                "t": "But there's no reason for you to do that anymore.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "962D88B88C13E743532A8DB5C0C983CA4EB8"
                }
            },
            "22F80490773AD7420C3A792385902D2C548D": {
                "t": "... What if my isolation is actually a result of jealousy?",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "54D6705A4C82D845534ABF781CCF29713F6C"
                }
            },
            "DF423290991DA7444539BD93AC6691EEBFAD": {
                "t": "Wait, is she referring to {LT:1}?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8DB1F1CB28D5F941736A4C415812D55BEE92"
                }
            },
            "053E506F1737314F49098E26F2056AABF001": {
                "t": "There's nothing romantic going on between me and him, Rya. Not yet, at least.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C54BA7F41B723648241AD4C635BC2E083F11"
                }
            },
            "F2C9324F4FC16846DE2A7F43DD17619B3970": {
                "t": "I understand that this limbo we're in might be bothering you, and I'm sorry.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "7E67F53265B377492D1936F2D00B7D425E9D"
                }
            },
            "3440DE7149952644BB882121E4883F4078F2": {
                "t": "I'm going to make this very clear to you.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "E18E17B334873245F77B893980401629ABB3"
                }
            },
            "7C89AD4A5BA0C8434159E4B8DE83E7A4D6EC": {
                "t": "There IS an external factor that causes me a little discomfort.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "0F6BEED1102C034D8368FFD11912A666145D"
                }
            },
            "1CDEF84D6D0CA64D357A9E1108978FC9EC24": {
                "t": "What is it?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EEDD346B5A19E94D50591015A93C89F6762E"
                }
            },
            "0D24565676E75944CF687074F24E1E283F90": {
                "t": "I'd like to spend more time with you. But right now I can't.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "4D6571F958B522479829F8045950242CB5CB"
                }
            },
            "6E33060B29862346AA7BF341DFDA5A46B43B": {
                "t": "Rya...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3C0A2EBE4C0AD44775389F04379A92CC0CCC"
                }
            },
            "001605E10987844E87588D721448E64F8FB1": {
                "t": "I just hope that the outcome at Hoikade Castle will be decisive.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "642C4AD0821EF646554AF3F0142FDB3133EF"
                }
            },
            "51699CD23ABAB14F348A250752342250C10F": {
                "t": "I hope so too. This threat must be eradicated once and for all.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "86ABD30A7A04684FCE1934E1DF3C3B95664B"
                }
            },
            "9FC2224D2D19D74DD08BFE4497C350E946C9": {
                "t": "But when it is... I hope we can live more carefree lives and spend time together.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "46A63D687B8580487B392563F39809AE0F23"
                }
            },
            "F43A0F0E7307D84C86798B27B6386A830D19": {
                "t": "I'll be waiting for you, Rya.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DEFB76AD145BD246964832213EEA0CDA835C"
                }
            },
            "8E5E5005094C50416018C482C398E0B1A12D": {
                "t": "And we'll finally see the dawn of a new era. Together.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "741C879C93BCB746B579D119D2E4ECD5A11E"
                }
            },
            "FC5210F977DC804FC95881E269072FFBFED4": {
                "t": "I'm looking forward to that, Faratras.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "598FFB1F81904544F36AF6E7458D5D5937CA"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": ""
                },
                "indent": 0,
                "uid": "77FB66355366C5468B8B9A8350E27ACDD8D4",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "450EF48B0682574CD55AB0212D2BB74889A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            0,
                            0,
                            0,
                            4998,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "91CFC95466ECD2412A9BA929CD4306C3E7EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "616138E289F92449615ABB736D16FFDB7788"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "590A07D48BDD4949F97A17B02BFDFA2DBAF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBC13CFC51F16948706A59659D9E45400FCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "740926A88078D94B856B0E5483F5F597E48A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "158DE1406290B845EF8B676352545E51B38B",
                        "defaultText": "리아, 잠깐 시간 있어?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B65B38564FF5B747883949B6987CE3BEAE09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "625A2CAD29EE574DF4499F11C7B5DBD924AC"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "D92D9E2C35E56549386BF799F08B80417C73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7A635EA73F1902482F48F6A8A0C35B7873C9"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8459C51460DA364A392BFE31C192BE0418F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "540E26E8949E7647022AC2456EBC206C49AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6EFC17A87C099473868BB4297064ABA83B4",
                        "defaultText": "...파라트라스. 나와 이야기하고 싶었어?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFA2A9432A1F554C895B34B84B7E35D55B60",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E4BFE9C675FA949B368A3A7080A5F766D96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02EE99D45EDF12424C4A85419B8C1C8F914E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "506ECD836B47384DF2297C61572A98926B86",
                        "defaultText": "걱정돼서. 지난번 사막의 은신처에서 넌 고통스러운 기억과 마주했잖아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ECAFEAF179C1D74B6C48E4A14900FC8BF296",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EB4B51C6E56B14AF76ABAD5391EF93D9915"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D723A3223104224D24481B60022495015AB9",
                        "defaultText": "그런데 난... 널 위해 별로 해 준 게 없었어. 그걸 사과하고 싶어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EEC10E7182ED18445C69B17519A7CC3D8DAD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9BE480C889E94481F2A36A3C50209C20C19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "497F803F2BA148436788673208FB4F33293B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A4AAE6F473D984C15883351A6BB8009156E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E43940CF1993A248E089F1E8E7044F5E8DFC",
                        "defaultText": "걱정하지 마. 오히려 네가 책임을 느낀다는 게 놀라워."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B1A1135E8D9F8446427A8ED9EF0BD2D527E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E995937019DB0446C6893E464ABF5DBBE2D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89A300450F61D1443C1900C84051E4394F9F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EEAFB7040347F842F77A3961D6C9B45D62AC",
                        "defaultText": "내 입장에서 보면 정말 네가 그럴 이유는 없어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5391CA7F119C884C898882F7D32DAC06040B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0D5EAFF42168347180B63F7557C39B363F8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "113825468D04A748508995F4279A4482DF75",
                        "defaultText": "좋아. 그때 보자."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E7AE1537B2F814C863A375421A278C47267",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E18989D535039640198B34A04529E6C06E79",
                        "defaultText": "내 입장에선 이유가 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "876FB82285902840B00A3667525AF8FAAC6C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7D4231DA8E08944F485994F29859A338AC64",
                        "defaultText": "또 평소처럼 넘기지 마, 리아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BB4BCE575FDB6340438B07F2548E256F7FD4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "short",
                            "long",
                            "long",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E3ED4B61FE2E248F288D074C272C1F9425F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3D4B010C835B3440557B0112517EBA6D6447"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "short"
                },
                "indent": 0,
                "uid": "2F2397D52C90A045E4784CB2C48E86AE053B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EA60DA01E2C3844243AC098BD32A15DC4C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB27F5117BE1D84E088835675978B4E344AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E8767064E5292428088AC91B00302CE5082"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "626051D003C7724D8C2AB6483B69CBC0B481",
                        "defaultText": "간결하고 핵심을 바로 말하는군. 네 그런 점도 좋아해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "971BC9353EF4254BBE5882C69DE241D3BAC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A74E27BD7D81014AB7384AD314E85167BCF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0FFFE4F9174584E25286A522AA99E1CD4C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8147A7964B3734B8B0A7154A90AD6036870",
                        "defaultText": "나도 마찬가지야. 우리 사이에는 많은 말이 필요 없었잖아?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D26C88BB6F05554B5C6898B425038C2A5260",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B039B1654D15140437BB2948A885AC95166"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C99AD1DA89E46640F5995D7564C588101D74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A02112208C64754C0219C57566D48A832336",
                        "defaultText": "헤헤. 그래, 맞아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "66A0E2AF421BB14CE30BAD020DAEA167B893",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA564C2E8A86604AF91AFCF39760D4B08BF3"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "7A57CBA9514094414B38DD92D59CB0F2A1BB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "long"
                },
                "indent": 0,
                "uid": "6BC9CED3895E284A69397EF662284CBB666B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF00650F2B15454EBC091F865B9B8A2EF262"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0ACBBC318B2FB44BB67B3FC3D4DE1140CF60"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9FEC622B911CE846389B5F029B156D1E89F3",
                        "defaultText": "뭐라고?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A399614B63BF3247064BC375B91899A7C503",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3421F39052EDF148478AEF2624C0095A1183"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBDA91365C751541D559F0A9DF8C6B87B7EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "38983EA8112EE7426B08CFF1FB4826C497EA",
                        "defaultText": "나도 함께하고 싶어. 네 세계에서 날 빼놓지 마."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8D69FBB6872CA84F1A19805737400FF5569B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78237ADC69C862407E5902348F4AE8E24140"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "035DCEBE5DF8A145647920E3E293397C70EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A136DFF73DBFB541A03BBED6BFEA282A3C5E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D82A0226465018458C3A1879B492E89DF81F",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CB81FE3103084949151A7BE67799F8D2D7FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7568E3F6577A147073AF09472CF492AE2EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73C0B0E53D2356401C5A5591F06BEF58B700"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F1220A0D7A3D004D3C2969B41F220BFACDE3",
                        "defaultText": "감금되어 겪은 상처 때문에 네가 힘들다는 건 이해해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B11B5B74AFFC94BF328781581D6A3606133",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA880D3879672341E959DE723C5F4BD52B13"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "592720199E30D045906854914ED6EEDB3E5D",
                        "defaultText": "하지만 넌 나를 의지해도 된다는 걸 분명히 하고 싶어.\n아니, 반드시 그래야 해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AA0637388C474441E3099EA26B42B04D8F84",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C55314D1F6B6743C66B8745C6F75763A09A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9102A0944978E947AC2B3453EF81FF108752"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96B0362F831CD74A733A72064F2FC56D6BBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18C8E0929CE9E7462848E056B41D1EA592BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E0C5FCE3D7BA2483F582AB5C52ECE478415",
                        "defaultText": "네 말이 맞아. 우리 관계가 이렇게 깊어졌는데\n계속 거리를 두는 건 불공평하겠지."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BAD9C0602A3A23444F5B0D77436C35F038EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAE7D73D95415743805BCE558A03E6B4F9F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABF5AC24475D224EA9699A13A20D577E3D02",
                        "defaultText": "난 외부의 불안으로부터 자신을 지키려고 스스로 고립되는 경향이 있는 것 같아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7950903148813249326B5FC6CFE2F06C3137",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE27254A50BEC342D64879A31DDF3C04C417"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "452AA45338F9E6459818F7877BCC88CE2C10"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "91C2C9B79DD00941BB799F23518B61F4A583",
                        "defaultText": "하지만 이제 네가 그럴 이유는 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "962D88B88C13E743532A8DB5C0C983CA4EB8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACDAF4B66C54E24B297B73551E0468697B99"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "If Fa x Rya AND Suzaku"
                },
                "indent": 0,
                "uid": "7051063F973F0845EB8A1411F87737F756E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7249ACD474B43047891B2C42CE4422E2F2DC",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7D5420A6694D83436A7865564A2F2D23E1D3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6E4793AC46F8564DE08AFA7340DBA751F9E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2560B4898EB4204AEB1B1E57C9BA3BECF74C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F37324CA28CCD74FE46A0744B21EF8563886"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "92DC50797F43A5411679F891B5E01B207FFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E14C263A780A5742386849727AA0B81051C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "97D2AADA32F6F848F32950477C43DB48A8DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22F80490773AD7420C3A792385902D2C548D",
                        "defaultText": "...내가 고립된 진짜 이유가 질투라면?"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "54D6705A4C82D845534ABF781CCF29713F6C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "A148E684284AA34B009B2BF1F81DC18769FD"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "3A6F95A14B50B3447A7ADE203090B3552E1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "F71266612CE2784D377B37D440AF648CC9AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF423290991DA7444539BD93AC6691EEBFAD",
                        "defaultText": "잠깐, {LT:1}을 말하는 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "8DB1F1CB28D5F941736A4C415812D55BEE92",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "9F44C6310656D540D819DD737B07CB2FC93A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Rya + sanity"
                },
                "indent": 2,
                "uid": "EB37FB43830A554CE53894F2B1C01361BF54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            1,
                            3,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "CDF856630B6137488E3915583B257DBF0115"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "2A6D5C9B79A9E3407D1B712829FD19F2378C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "053E506F1737314F49098E26F2056AABF001",
                        "defaultText": "나와 그 사람 사이에는 아무런 연애 감정도 없어, 리아. 적어도 아직은."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C54BA7F41B723648241AD4C635BC2E083F11",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "FB70D42F48E2294CCF08A2D45C2563D16E5B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2C9324F4FC16846DE2A7F43DD17619B3970",
                        "defaultText": "우리의 애매한 관계가 널 괴롭힐 수 있다는 건 알아. 미안해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "7E67F53265B377492D1936F2D00B7D425E9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "3AC5D4DB4AF956454968E98318F537684BA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "B5A528E055D89249A489F95471AB7CB78BB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3440DE7149952644BB882121E4883F4078F2",
                        "defaultText": "분명하게 말할게."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "E18E17B334873245F77B893980401629ABB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E43488921AE7714E7738D2562A036376DE45"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++aff"
                },
                "indent": 2,
                "uid": "EC2736727760504CE4193492D6A16D168AF2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            7,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            8
                        ]
                    }
                },
                "indent": 2,
                "uid": "3606D41887D0164B389A65E767337AF08A36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "27381CFD5F0E174C377A4312A3388D92C649"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second part",
                    "target": "activeContext"
                },
                "indent": 2,
                "uid": "D950169C47100840FC3966C13533B5280984"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12F17C553064B240F81AEA63A5DAF25F6CDB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C89AD4A5BA0C8434159E4B8DE83E7A4D6EC",
                        "defaultText": "나를 조금 불편하게 만드는 외부 요인이 있기는 해."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F6BEED1102C034D8368FFD11912A666145D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E64005E67F9343451939BE0313D2F209A032"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D15941F76C2916481A891F868CA5285CE6AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1CDEF84D6D0CA64D357A9E1108978FC9EC24",
                        "defaultText": "그게 뭔데?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EEDD346B5A19E94D50591015A93C89F6762E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4BD962E12C4084DEB6A7F174916FC385783"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "927078142940D6439C6800D58B0A57B07D56",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second part"
                },
                "indent": 0,
                "uid": "DFB7A75F3322B24F7A3A8E9972826042C633"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EF6BCE347963143687AFC216BDC0DF5E632"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0501A1EB5F4C064F4C2AB2A4BEF221ED902E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D24565676E75944CF687074F24E1E283F90",
                        "defaultText": "너와 더 많은 시간을 보내고 싶어. 하지만 지금은 그럴 수 없어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D6571F958B522479829F8045950242CB5CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "689DFEB188F0D6460329C1B0D83CA53E5F6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6813DFF1D2FB64A05192114C81334A2230C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E33060B29862346AA7BF341DFDA5A46B43B",
                        "defaultText": "리아..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C0A2EBE4C0AD44775389F04379A92CC0CCC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DEEEB2B131C644D3689B143877066C44475"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "6A3894797867B3423469EE632D0DC63F97F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28972440020D104DAD6B27E230B4882D36DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "001605E10987844E87588D721448E64F8FB1",
                        "defaultText": "호이카데성에서의 결전으로 모든 게 확실히 끝나기를 바랄 뿐이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "642C4AD0821EF646554AF3F0142FDB3133EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C513C91345D354C655A8A91BA2081A2AF05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65744CBD7F20C54D4779BD71D817865C9F13"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "51699CD23ABAB14F348A250752342250C10F",
                        "defaultText": "나도 그래. 이번에는 이 위협을 완전히 뿌리 뽑아야 해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "86ABD30A7A04684FCE1934E1DF3C3B95664B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61EB16044FCB5048158A03413A4104462156"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if romance with Rya"
                },
                "indent": 0,
                "uid": "B43C03CA933FB5470709C4028850601D32FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7249ACD474B43047891B2C42CE4422E2F2DC",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AFD3249D7576C5453E7BDFE25E9D7AAAE49E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2B0FF0886C43544C2A69B7E2EDAFEDD59D73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "97848B8418F393451B1AC7C175A99F1F2B7D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9FC2224D2D19D74DD08BFE4497C350E946C9",
                        "defaultText": "하지만 끝나고 나면... 근심 없이 살면서 함께 시간을 보낼 수 있으면 좋겠어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "46A63D687B8580487B392563F39809AE0F23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5F18F99F397762432B39FE37D25B3E3F1CEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "34B1490D22759540341ABC42810C77DB1383"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F43A0F0E7307D84C86798B27B6386A830D19",
                        "defaultText": "기다릴게, 리아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DEFB76AD145BD246964832213EEA0CDA835C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C3D120818E94E64BCF1B2FF4C6B74580855A"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "8057DF918F50084C86695FA3435D36295A40"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "57FE335143C28540CD284E441133996BA1F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C740D2AD86375542835A69A8933D2824BCAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E5E5005094C50416018C482C398E0B1A12D",
                        "defaultText": "마침내 새로운 시대의 새벽을 함께 맞이하는 거야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "741C879C93BCB746B579D119D2E4ECD5A11E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3DC6FF911674774F807BD1E5E74F615CC2FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C926EEFA8369174FE968D018C0B56288366D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D4614177EC136424D49B338A29704919658"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC5210F977DC804FC95881E269072FFBFED4",
                        "defaultText": "그날을 기대할게, 파라트라스."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "598FFB1F81904544F36AF6E7458D5D5937CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8F30F113B60014510298946D92D3F53D6A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "00AEEB667610A94DA2382702EBA54EDCF520"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C36AB0D42F928346B05BC5A7BD5AA1973D3A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6D1F9B483583B443DC5B26E839ADD3C02B18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0,
                            4,
                            "45918E0E12BBF148635A9360998958409EFE",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "6943D29F7A5EB54B1419A9826AC6D52B7838"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E855A2A34182A643B1181424B972358DBB59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            1,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F06BF32779BE34ED429E3F1E94907ED6C1E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "40D991725A4862486948835834DFD90C00DA"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0C5691308B88134D385ADDA2065E0F57BAE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "8EF9D6C012F50046219A87D17484417CFA47"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "90C42FCD13099144751A97305B0C01D67C79"
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}