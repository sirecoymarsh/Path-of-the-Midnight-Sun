GS.dataCache['2EFF267B41FA84405E4A70A330F772345E6D'] = {
    "uid": "2EFF267B41FA84405E4A70A330F772345E6D",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C1-03d Arlene, order food",
        "type": "vn.scene",
        "parentId": "F7F581B17D00D5435868B5C374116B4EBEE3",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 6,
        "localizableStrings": {
            "22320AE21DB756414E4950220CA81396A95F": {
                "t": "We can finally rest, teh heh.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "47F3EFDB668A1544674989783A57BE4BE7E4"
                }
            },
            "AE1CE4E74CC29048715898B1769447B3116C": {
                "t": "Yeah... {W:100}I really needed it. {W:150}I'm feeling so exhausted...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C0EB01DB5BDB364B1F59E5B77898881B81B9"
                }
            },
            "5F346D3E144EC746FD199835EFC6E1D0335A": {
                "t": "It's curious...{W:200} We walked a short physical distance,{W: 200} yet it's as if your mind has been traveling nonstop for days...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E95EE4559449A74DBC59B6625BF8156D3FC3"
                }
            },
            "BEA91D0862ED41401D191B699EFEFB969A65": {
                "t": "I don't know who I am anymore.",
                "d": {
                    "eid": "30914E882B0C6244594B9BC166F43D063DB7"
                }
            },
            "8EDACE066C8D4640475B84D4705F1D78F905": {
                "t": "I'm slowly reaching enlightenment!",
                "d": {
                    "eid": "457A4BCB2D96F047831BDBB242F4314C9D89"
                }
            },
            "477F28468B5A4340B26BA99514A3B9F90B65": {
                "t": "It's truly unfortunate...{W:200} In no time, you became a completely different person.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "80D437B428BA2445868B9D3125D995497AE1"
                }
            },
            "E3415FD57940B6448E0B100717E012EAE64B": {
                "t": "And yet, I can clearly see that your memories are still buried--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7E67B688600E9145CF8B6992B7D49066D336"
                }
            },
            "BDAFB342000681486E7B647221252D32150A": {
                "t": "Would you like to order or do I have to stand here even longer?",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "7A1EF6BF780A2441BB4805C3AD3C018B1004"
                }
            },
            "DD6DE04C682C124D2D1A7D8353B19CE7C4D1": {
                "t": "I have no time to waste explaining the menu,{W:150} so read it yourselves.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "6F74F52D44DDE5461F39FBA1B2DF77332BC7"
                }
            },
            "81C736FA1BCB9846CE7A2561D5A1D0FF41DF": {
                "t": "And you are?",
                "d": {
                    "eid": "F0927D386095E6432C993480ED5A88C28C6F"
                }
            },
            "9E8E8F866EFE9341F95BDCF3469063E93B46": {
                "t": "I have no time either, I'm calling your boss.",
                "d": {
                    "eid": "DD3254E24C5F3548627B24B98EB2957E5A75"
                }
            },
            "90265E649C05D0480969B4F6E455B7D811AD": {
                "t": "You may call me Arlene. {W:200}I run this place.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "086B893B7BF2C24675591CA2CC09D9DE3525"
                }
            },
            "5C56A85813AAB7479C1ABA80C7CA1E581A7A": {
                "t": "Hahaha, you're a funny one, aren't you?{W:150}\nI'm Arlene, and I am the boss here.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "F4E77B713661C243088BDC59D3D3F20E7A33"
                }
            },
            "E5A8987D1C3B644462890637C92BA080E057": {
                "t": "If you have all this energy to complain,{W:150} you definitely don't need to be told about the menu.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "2379F2363513B149FC1A8483E96A3EEE0B8F"
                }
            },
            "EE70B3E21A4BC344C96B7DD658A76F4FA3B8": {
                "t": "Give me a nod when you have chosen.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "B7CD3CB1988A914A2B6B3A22CB9138B08B4A"
                }
            },
            "146B24535F59054DDE2A8543CFE0796EAC45": {
                "t": "Woot!{W:100} Woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "6241ADA325824544558BAC493E30F324F261"
                }
            },
            "546A46F382AF5441BD7A74B09714306FFCF7": {
                "t": "Yes, she's the owner.{W:200} She has the money.{W:150}\nYou can bite her, if you want.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "DF3294896E3A0643163A1EF8B6BDD7884A11"
                }
            },
            "8F89D53C59D7644E502AE7A6DE1911A255B9": {
                "t": "An interesting individual, wouldn't you say?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F8B29F3D539C184D398A4DE24E8AEFE42BC5"
                }
            },
            "46C3F1BA7C39814AA60AA597BF034391A3BF": {
                "t": "If you say so...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "E88C83F25E10B549268B8071010BD56AD44A"
                }
            },
            "9AA5BBF18F98424BAD8BB684F7DDFAAE6BB4": {
                "t": "She didn't even notice that Shiori is blind.{W:250}\nBut at least she took the mug and rug with her...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "45A5FBFD5684C44F8A988947E2ED65B41F17"
                }
            },
            "BABF4D5E755FE8476B5BD3C25B4DC8F99208": {
                "t": "You seem slightly hostile towards Arlene for my sake.{W:200}\nThank you,{W: 150} but there's no need for that.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "819E869648E7D64DEA6A67D69526338A3655"
                }
            },
            "A5CD04143C21824FC52B1BC4E42679DAFE20": {
                "t": "As I said earlier, I'm used to these kinds of things.{W:200}\nTo other matters, would you like to choose for me?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "B2604777206A7449277AD0720A09F2C7F1E4"
                }
            },
            "4847E8F3517DF2494F2B2FB35D653B574FB1": {
                "t": "What do you want to eat?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "EB83FCA84C0E534C7B3968769A09CAFFA7A9"
                }
            },
            "6350A3D364FCA243195AE7D5E7D8A502262D": {
                "t": "Hmm... Any kind of {SP:2}{C:1}seafood{C:0} would be alright!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7E98F0A6333DE74F5C4B0A59DB80517CF3FC"
                }
            },
            "2803F9641FA8534BCB6A6736F81F1B10D644": {
                "t": "Seafood, huh?{W:100} Got it.{W:150}\nI'll also choose my dish while I'm at it.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AA2281896CCE1440456BF979FD7E550B4A94"
                }
            },
            "B02976E59F3BA445D518A26004EBFA0C739B": {
                "t": "Woooot...{W:150} wooooot...",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "9217C634599F0840A828AAB4A89E04DDF36F"
                }
            },
            "ABF701E147089448AF788D154D4B70CD5E56": {
                "t": "Don't worry, I'll give you some of mine.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4BF07D881DE4094D518ACBA5F22F26BC6C4A"
                }
            },
            "8747381C6F12E14CDE4A867432CAA49FE979": {
                "t": "Woot!{W:100} Woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "144E5AB386AE45431288D063F312EFD8768A"
                }
            },
            "039707576B99E94F673843452B718079B0CE": {
                "t": "If you've chosen, just say it already! {W:200}I can't wait all day to take your order!",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "3C88865870A48447D82BDEA513E16B912C8A"
                }
            },
            "3AA6DB0D931910450839E5C45CA734FBC0DB": {
                "t": "And what's with that surprised face?{W:200} Pah, youngsters these days...",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "8570B1EA46396541DD2AE9E9AB0C41AB7A8E"
                }
            },
            "972E1D584927D84CA8691516CF81B630D069": {
                "t": "Defining this owner as 'acidic' would be an understatement...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B5F6A931016AF3411E5A85A8361A5CCB5084"
                }
            },
            "97D89C262CDC15400079DD25022A88580D62": {
                "t": "Indeed, we're ready to order...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "5920D87F3043324E2E68C326CD26D9AD6207"
                }
            },
            "99E2F7275A24674E8C1B96B1B227DFE0B10C": {
                "t": "What was {SP:2}{C:1}Shiori's order{C:0} again?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AA08E6A6464FE248FE4B2F90D77C54099FD2"
                }
            },
            "B4419B9E324B72492A0B15F120E70D4254C4": {
                "t": "{LT:5} for the young lady.{W:200}\nAnd I'll have this one.{W:100} Thanks.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4D9EECE43F5877432E5AF5832E8CE03BAF4B"
                }
            },
            "86CDA8AE6F1DA44FD63B35D542DE4EB49E1F": {
                "t": "We'll both have some {LT:5}, thank you very much.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "98776F2715CBC34CBD7A60C54206AB8A1165"
                }
            },
            "6FF3B5A581C267426058CED73A1221E05580": {
                "t": "Alright.{W:200} It'll take half an hour.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "7704588E9A69D647776B364196FF5E712CD7"
                }
            },
            "B16DE9C82C8F41427C5B8985F56BD8D0CC57": {
                "t": "Thank you, Arlene.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "BDE2E48B84FF84441E6963E2B9862F55F8FB"
                }
            },
            "F22B837F00CFE14F5E4B34D23CEDA613E22C": {
                "t": "... ... ...",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "DA518A4178398448C61AED2767FABDA475D3"
                }
            },
            "B13C17082BF4D74CD02B06C39AB18C4C2417": {
                "t": "... ... ...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "FF2DCB0F3908D84571189BA61224AF5B1A9D"
                }
            },
            "8DE0BB5B6FA48848311931548C2B402FD85D": {
                "t": "You're blind.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "94663DD71D26A643294A38C88FFFBE169976"
                }
            },
            "4ACDC08D141FB64B243BDAD4B19C5F3F01AE": {
                "t": "Well, it did take a long time for her to notice.{W:150} Better late than never...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4D33ADA66EE1C84F184AE812560E13BC3514"
                }
            },
            "96BABF146EC9574BAD2880F017246391980D": {
                "t": "Pah.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "5C87A73C9F781348223908F98870D674214A"
                }
            },
            "9E836F0330FAE943C01BE0028CF96FC31970": {
                "t": "And that's all she has to say...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9AFB03DA00E8284BAE8ACCB86F6233344899"
                }
            },
            "DBC84EB034F02045993AE454011BA8D0CB4C": {
                "t": "She isn't a bad person, Nini.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7AB748A517FE674F7A6B56E6ED13332C9879"
                }
            },
            "67197C7B14EDB34A7A0955E375CE0F74C550": {
                "t": "I can't stand her.",
                "d": {
                    "eid": "AE3701184F560342087BEF42A08EB44AA2EC"
                }
            },
            "229B98A523273342729A29C4D0818FDF3E4B": {
                "t": "I trust your judgement.",
                "d": {
                    "eid": "643770EF589D8342BB7B09747D9E4790EF85"
                }
            },
            "048309864DDBA845E55B6003E786A7CAAA55": {
                "t": "You shouldn't judge people based on your first impressions. {W:200}Well, not just first impressions at least.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "AE97609C611E82462E4B58A926AED9ED6D6A"
                }
            },
            "5017266E492CC549CA4A82C5972628D41535": {
                "t": "There often is a lot lying underneath the surface that we all show in our everyday lives.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "ED34E8C3162B264838486917FFF9E898F54B"
                }
            },
            "EAC0EA625A10274D014A3FA16B9226AEFB59": {
                "t": "With my power I can clearly see that she has no ill intentions, she's just...{W:150} a bit gruff.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8CA7EC9E9AD9044B103B7158419FBA9A62F1"
                }
            },
            "D64205C6132C92407A38D53143D99BC1D9D1": {
                "t": "It certainly takes a strong temper to run a tavern frequented by drunkards and thugs,{W:100} don't you think?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7C68F6BC43983247A548C232E6A318167BFD"
                }
            },
            "5CD5F7A44333C845550B83D402487865F0A6": {
                "t": "...{W:200} That may be true.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C201858712D0F1494439D9D1516EDF29DB16"
                }
            },
            "8FFB86BF797C5043331BC9C78F169162E48B": {
                "t": "Teh heh, I'm glad you joke about the situation instead of feeling down.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "30E155373BE4024FF2595C162DD7586A779D"
                }
            },
            "A3C6E3E4263B9549F61B3FB7A7578E5073A1": {
                "t": "Arlene",
                "d": {
                    "eid": "530BB83A26C367462A7A64712A09C92F5805"
                }
            },
            "6BD0491617B0E240AF6A3A33434AC3A71D7F": {
                "t": "Arlene",
                "d": {
                    "eid": "EA3A69343FFC744AF26A1191034A9548937C"
                }
            },
            "F3FCD6F98FB0074A6A2BB511799433B50FA2": {
                "t": ".",
                "d": {
                    "eid": "6D2AAD17795EE74AE58981B1CF37AE529FA3"
                }
            },
            "6DA183A528E5B04DD48A45E8427505511C16": {
                "t": "{GT:301}{GT:305}",
                "d": {
                    "eid": "636F39082B4A744E432BE7474E7F266CCC1E"
                }
            },
            "4E5F3EFE429663415838A322427E0E699A9D": {
                "t": "{GT:302}{GT:305}",
                "d": {
                    "eid": "5BA052449442244FC68AAFA62499366CF8EF"
                }
            },
            "8C0B817D2EFCC340565B8181A22E932D8293": {
                "t": "{GT:303}{GT:305}",
                "d": {
                    "eid": "56AF7E8425AA824E0508D1659A46BF1F785B"
                }
            },
            "4E3E281A13AF144D37490317F7E9F8E5E5AF": {
                "t": "food 3",
                "d": {
                    "eid": "3B4B62D26374E14DF129D3B8662D10059DCB"
                }
            },
            "6613B6F254C3C34A662AD653FAAD698FBEFC": {
                "t": "{GT:304}{GT:305}",
                "d": {
                    "eid": "FDB41F455805364E09789C07EE850C85D702"
                }
            },
            "2DA221232C8930430169A5F4E8157C93A953": {
                "t": "food 4",
                "d": {
                    "eid": "517076695214F4421A6867D8463B318E89FB"
                }
            },
            "81A3AA0E17A76641CA5A50F26BCBFCD70006": {
                "t": "... ... ...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "3A7733F675CEA44FD6382AF0DE4098B7931F"
                }
            },
            "D14A08769D26444EB12BDC747398EDDF51C1": {
                "t": "... ... ...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "A966F51A99D331452F59832828489F1F3BC8"
                }
            },
            "07D5BD4D3D053945C82BA508FE989440DA1A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EE56A7CA19860844277B41B277375C2BD9BE"
                }
            },
            "5B9A31CB74DE884E197A3D8887A3AE838E6D": {
                "t": "???",
                "d": {
                    "eid": "4B3E145E3656574EF7287116097FAF146230"
                }
            },
            "779E8CE84B8AD1441D88E1372B12F601EEF4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B71AB5E0243BE345CB9AFE762FBC2EEA2960"
                }
            },
            "13E52F867933564A246BAAD8503FC000687B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "286C1FFB895DC74E836AE1F69DAFF7F188D7"
                }
            },
            "350A877C92EF334E3529ACE63E6474CECE6B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "28D524007FFC274DA43B1A4064DCBAF0E625"
                }
            },
            "4C48239672DDD5420B68B76201B8DBDA15DE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "145EDC98077E284E547817B6DC6CE95784CC"
                }
            },
            "E61E57B6367ED74A709B6CB9E31D80615CAD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "17285FF8406A244971299CD8EB457F22200B"
                }
            },
            "5673E45B5F73F5448F28A7B101317FD76B01": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "7B80A80B2602F0495A49A0B937DC5014BAAE"
                }
            },
            "FB4137C18586E544CD5A6C7852DF7B18F52F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F688655136F3464A7278DB021405DCE79F99"
                }
            },
            "6FADBD5681B00349DD4AF4F7F01CC2A75B20": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "13750F5B774D3549307B38C50C32CCA8C864"
                }
            },
            "420F0D7E1D23124098182274E767F34EC386": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BA5A62F042BD0345AC3AC852F98A036CE927"
                }
            },
            "09C2D186870D9546668A07469ED072B3E20F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "616DB6A2589D5347EA39AD14C1C5C092E34F"
                }
            },
            "9B9441E04D21614AC89A4F1594DA957AF958": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B3ADDB66432CD343463BE6A1335FB6B08842"
                }
            },
            "08FE1F7B5FAE5249B478634101EC333AED41": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C0AF3D46210CD54E281B27824F176CE36F89"
                }
            },
            "2C37E2DA3D98784334887D32294D96FA1932": {
                "t": "I don't know about that...",
                "d": {
                    "eid": "C8938EE6640BD74E634A096054074EA60B6A"
                }
            },
            "2AC4E0A3500BF24804093CB9EA4E90664B02": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "FACE92EE549C804ED428D142D45C97E686C3"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": ""
                },
                "indent": 0,
                "uid": "18B976223FA162477F8BAF80ABDA36A59AC5",
                "expanded": true
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 210,
                        "y": 210
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "5485116E683CE34B117A7A821A73B6DCF21C",
                "expanded": false
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 39,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 120,
                        "y": -60
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "D1C09A7A2C89C44CF02A9AB12D60208CFD1C",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            4,
                            650,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3096CD089F8A249AB3A0223BD4B0CF10E66"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "EF3EA4AA8CE9E749D848E688DD15F3596134"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "F785A0503DFEE146592B311858FF60A3BBFA",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A796DE892D4AB74CFB98F106BB59C9F30C47"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "6530FD7024A1C546A44919C1B38855861CB7"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Sit_Armor.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9DEBE35D52F4D24E076BA5F9AAA85A9C6CB0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "D6590C0051F313487D6B66969CD36E7DCBFF"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Sit_NoArmor.ogg",
                        "volume": "85",
                        "playbackRate": "140"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 0,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F4BA249299D83447B77BFFB6852C0AD1EAF9"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "model": {
                        "name": "Shiori.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 707,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 450,
                        "y": 160,
                        "zoom": {
                            "x": 1.08,
                            "y": 1.08,
                            "d": 1.08
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "DBCDFA461480C34D844B4D057ADA2A131EE9",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.6,
                    "idleIntensity": 0.3,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "497EB7A4820B604BC82BC266936C0DD821A3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "EF5C877388FFD149332A5815F30FA7CDC02B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7CD957778702C6435069379332B28BBA511F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "C44CA3C6275CA44B6C3B7D7490C3845156FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "AF0193483CAB5143EF682B46ACA3BD0118D4",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9198D73352B171467B2907B2E6BFD05DD95C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "53FACEA146C657425D78AC1445E4C70E16DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76AB9BB38004C14E4F49FB677CADA9004E6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "83052D67347351484239AC7296885367D963"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07D5BD4D3D053945C82BA508FE989440DA1A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EE56A7CA19860844277B41B277375C2BD9BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C9EE10C876C4E34E7348FED29A1C9D7F1FA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "051B6A17409CC24E373AB89689723FD2E25F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22320AE21DB756414E4950220CA81396A95F",
                        "defaultText": "드디어 쉴 수 있겠네, 테헤헷."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47F3EFDB668A1544674989783A57BE4BE7E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4D79BAE7B48354278491182FC72760C91B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2A2F2966609714C4C59D417116A105538A6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE1CE4E74CC29048715898B1769447B3116C",
                        "defaultText": "그래... {W:100}정말 쉬고 싶었어. {W:150}너무 지친 것 같아..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0EB01DB5BDB364B1F59E5B77898881B81B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59CD93A086920742E41AAAC10A841A5D180F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BA486BB3D88A744AA3B2728CD230F539503"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B6E22104BBD7445772BB6D2A81CA1FC449A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5F346D3E144EC746FD199835EFC6E1D0335A",
                        "defaultText": "이상하네...{W:200} 실제로 걸은 거리는 짧은데,{W: 200}\n네 마음은 며칠 동안 쉬지 않고 여행한 것 같아..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E95EE4559449A74DBC59B6625BF8156D3FC3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6DF75196F7E724EA38ACB7220D24F3B1DCB"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "BEA91D0862ED41401D191B699EFEFB969A65",
                        "defaultText": "이제 내가 누군지도 모르겠어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "30914E882B0C6244594B9BC166F43D063DB7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8EDACE066C8D4640475B84D4705F1D78F905",
                        "defaultText": "서서히 깨달음의 경지에 오르고 있어!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "457A4BCB2D96F047831BDBB242F4314C9D89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "amnesia",
                            "enlight",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "9143DC286A51C344AA6A21516C17FE3658ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2010E10F5AE4B4452719CA1431E30F098B49"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "amnesia"
                },
                "indent": 0,
                "uid": "DBC09B7E27CCA3400079F125752EFE7BEA2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            20,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BCC575038800724AA81BAF84FF242FE3A4F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9117D8F69E7D784DBC29D424CAD22F94353D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A92E11F0995E1548602ACFE8227A6FE885ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "477F28468B5A4340B26BA99514A3B9F90B65",
                        "defaultText": "정말 안타까운 일이야...{W:200} 순식간에 완전히 다른 사람이 되어 버렸으니까."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "80D437B428BA2445868B9D3125D995497AE1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDDE01587C8D5740EE1AACC66FA959727ECF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of first",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "A33FB34E266CE94D0B7954809462006DA2DD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "enlight"
                },
                "indent": 0,
                "uid": "D5C0949487EE93458A5B23752E1A6265DECD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE1985C85659934E022BB3382F768EC76A9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A06171CE70D948427478B2D63C2C0B034531"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A29846D6539B0748FC1A3BF38552D9AB264E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8FFB86BF797C5043331BC9C78F169162E48B",
                        "defaultText": "테헤헷, 우울해하지 않고 농담할 수 있어서 다행이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "30E155373BE4024FF2595C162DD7586A779D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA70D6C113068640B599F0633A80EC0A5054"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of first"
                },
                "indent": 0,
                "uid": "6474CC0F43F32746506B7B8489A25E349566"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3415FD57940B6448E0B100717E012EAE64B",
                        "defaultText": "그래도 네 기억이 아직 묻혀 있다는 건 분명히 보여--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7E67B688600E9145CF8B6992B7D49066D336",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E72AB4F4D1E4646AE3B4D019BD1F159B829"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5B9A31CB74DE884E197A3D8887A3AE838E6D",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4B3E145E3656574EF7287116097FAF146230",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Arlene"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9AA6B9C189B235438948A5B8D24922C7DD32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "164656D7426FE44FA418F3329FB41927479C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "779E8CE84B8AD1441D88E1372B12F601EEF4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B71AB5E0243BE345CB9AFE762FBC2EEA2960",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CB99E3643160C34CAA4BEF0963B123867C0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B22FB5F337543446B42B61A8E686B7DC8D74"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDAFB342000681486E7B647221252D32150A",
                        "defaultText": "주문할 거야, 아니면 계속 여기 서 있어야 해?"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7A1EF6BF780A2441BB4805C3AD3C018B1004",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB405BF44316D841D57B76051CF7F157C515"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F09164B8664B64DBA1ABEC275C6AF730345"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB8070CC36FEA84B984903F7FCD47FDB9BFC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "33D186015C7636481F3BAFE9268804523D69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C2B91BC6CA825495988DE77366C9E112806"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E67AC5473413141EC2BBA53B8D4C19937CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B18838BF00A74143EE5BA4311BCF88B02D39"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DD6DE04C682C124D2D1A7D8353B19CE7C4D1",
                        "defaultText": "메뉴를 설명하느라 낭비할 시간 없으니,{W:150} 직접 읽어."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F74F52D44DDE5461F39FBA1B2DF77332BC7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AC80BF67A86B6409E2A8838271AFE8D9D7B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "81C736FA1BCB9846CE7A2561D5A1D0FF41DF",
                        "defaultText": "그런데 그쪽은 누구죠?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F0927D386095E6432C993480ED5A88C28C6F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9E8E8F866EFE9341F95BDCF3469063E93B46",
                        "defaultText": "나도 시간 없어요. 사장 불러요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DD3254E24C5F3548627B24B98EB2957E5A75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whoisthis",
                            "padrone",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "9EB6ABB140A7164C6D8BDAD8A505D1AB999B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7D0D1A3572CCD6482589C5973440BD18C7C0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whoisthis"
                },
                "indent": 0,
                "uid": "037848415FD7194EA53B09E28EC3E518D0B6"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A3C6E3E4263B9549F61B3FB7A7578E5073A1",
                        "defaultText": "Arlene"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "530BB83A26C367462A7A64712A09C92F5805",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Arlene"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3F66EF177CB7F44B8639CE30707B9F76F4CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "44A24A5A6C444149EF3A36F21A44DDC219C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "13E52F867933564A246BAAD8503FC000687B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "286C1FFB895DC74E836AE1F69DAFF7F188D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4B50B32604DD3446FF3887C763DD21483132"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3919D03C6ED8054CB52BD3C988BBA9E342A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90265E649C05D0480969B4F6E455B7D811AD",
                        "defaultText": "아를렌이라고 불러. {W:200}이 가게 주인이야."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "086B893B7BF2C24675591CA2CC09D9DE3525",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F59E97F4413B347522A01E8759E82EA3485"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "ordiniamo",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "34D0862E13C9D14FFB7A7638A89BADC9A620"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "padrone"
                },
                "indent": 0,
                "uid": "BBD353760D153845D198FE29B00252FE0952"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6BD0491617B0E240AF6A3A33434AC3A71D7F",
                        "defaultText": "Arlene"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EA3A69343FFC744AF26A1191034A9548937C",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Arlene"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Arlene",
                        "index": 11,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF824C8F391D21473C5BA111A26C8CF38081"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "10CA265F2BD82940080A7A20B85F1FEA7B8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C21DAB181F139342C52831548E7C8DAFD97F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "350A877C92EF334E3529ACE63E6474CECE6B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "28D524007FFC274DA43B1A4064DCBAF0E625",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "72FD01B03BDC7340807BE1860B4F28F81BDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E64218A62B6A784DFE1A7A403714E9331002"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C56A85813AAB7479C1ABA80C7CA1E581A7A",
                        "defaultText": "하하하, 참 재미있는 사람이네?{W:150}\n난 아를렌이고, 여기 주인이야."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F4E77B713661C243088BDC59D3D3F20E7A33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "776E24E68BFC9342712BD03937AE2DDD258B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "238405B72B160544B77A15B38FD1484E8D3A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E5A8987D1C3B644462890637C92BA080E057",
                        "defaultText": "불평할 기운이 그렇게 넘치면,{W:150} 메뉴 설명은 필요 없겠네."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2379F2363513B149FC1A8483E96A3EEE0B8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EFB040BC2CAFC249147AB4B0016A760A5B91"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "ordiniamo"
                },
                "indent": 0,
                "uid": "8263CB7F051B384587286DE657B12D044E54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "61D4E4608775034A5F184A645C7D749EB318"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE70B3E21A4BC344C96B7DD658A76F4FA3B8",
                        "defaultText": "고르면 고개를 끄덕여."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B7CD3CB1988A914A2B6B3A22CB9138B08B4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A876CCD45AA629402B888A73270115B7BB44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A8CFAE994498445C3297F448868C39A7241"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Dish Wood Table.ogg",
                        "volume": "80",
                        "playbackRate": 90
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 0,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4C045254509020425D19EE97C1B118247F6C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 15,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F093DD335195A0448C680B85ECF5BAFB7449"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 16,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "CFD801A49131884FA2281815169D402EBB15"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "71319CB04CDD0143170B6B0994C6E7C46729"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F4D98087737CE545B548C543E654CAC3EC04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2537621A26CD0142CE2917945EADBEF6F301"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BD3AD1F525C9254BA5593232D62CD1DF5234"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF83E90537809543565B9E74BC02A8C378DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "52E8358903E3644E5A48EA10B8544E705929"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4C48239672DDD5420B68B76201B8DBDA15DE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "145EDC98077E284E547817B6DC6CE95784CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F8B86BD76F37A948B3182FE57A65433EF8F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "686033CD05D3C34F43984067A0D4E1411383"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "146B24535F59054DDE2A8543CFE0796EAC45",
                        "defaultText": "우웃!{W:100} 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "6241ADA325824544558BAC493E30F324F261",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "43ABA1F494E1774C698A15B956A6D5479011"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "86B37F974230394D369A46A2A3D1BD3E6FA5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "546A46F382AF5441BD7A74B09714306FFCF7",
                        "defaultText": "그래, 저 여자가 주인이야.{W:200} 돈도 갖고 있지.{W:150}\n원하면 물어도 돼."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DF3294896E3A0643163A1EF8B6BDD7884A11",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1CB767428B410841062949259F693EABC502"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EADE095974AD9345BD8AABD2CF1DA3303032"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "05383A4C0FD6084F393A8EC18E212A1D078D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E61E57B6367ED74A709B6CB9E31D80615CAD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line31_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "17285FF8406A244971299CD8EB457F22200B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "52B2547C8546E94707485B81F579E9E5468A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F28B69321555A64DB30BE36302FC2AAF4FB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F89D53C59D7644E502AE7A6DE1911A255B9",
                        "defaultText": "흥미로운 사람이라고 생각하지 않아?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F8B29F3D539C184D398A4DE24E8AEFE42BC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15A6CCD9117D71432C3A9F43C1B4E23D9472"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AE128B251003D2400B6A4811B2DCC10C2AB7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5673E45B5F73F5448F28A7B101317FD76B01",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B80A80B2602F0495A49A0B937DC5014BAAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C93B63C61069714D7B68BC42FCF81DDC228D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "279BD8CE70D35541FD2ADB4130D37463A76C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46C3F1BA7C39814AA60AA597BF034391A3BF",
                        "defaultText": "네가 그렇다면야..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E88C83F25E10B549268B8071010BD56AD44A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A48A20D36A5544ADD2BE9948934655B9A1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2016023E2858214D2E8852A81F2F39252FDF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AA5BBF18F98424BAD8BB684F7DDFAAE6BB4",
                        "defaultText": "시오리가 앞을 못 본다는 것도 몰랐어.{W:250}\n그래도 잔과 깔개는 치워 갔네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "45A5FBFD5684C44F8A988947E2ED65B41F17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38D2ACD77739364BF4188D36DC6399FDD45D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D14BA35F946B52490F18DBB62F508B475385"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            12,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1253D5E6E44154B028A85E0312640E9AC42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CC871071D769347CB9A1B34E9D7B6801268"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E88A09BC97B62842B01856E58B323BA3C621"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BABF4D5E755FE8476B5BD3C25B4DC8F99208",
                        "defaultText": "나 때문에 아를렌에게 조금 적대적인 것 같네.{W:200}\n고맙지만,{W: 150} 그럴 필요는 없어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "819E869648E7D64DEA6A67D69526338A3655",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1089CF99E1BF640C34BCB2028E59D8B0A6D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5CD04143C21824FC52B1BC4E42679DAFE20",
                        "defaultText": "아까 말했듯 이런 일에는 익숙해.{W:200}\n그보다 내 메뉴를 골라 주겠어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2604777206A7449277AD0720A09F2C7F1E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05D8E22F8641174C699B3F36BECB3F42E840"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38618D274843584F392A16F678DB31EA09CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4847E8F3517DF2494F2B2FB35D653B574FB1",
                        "defaultText": "뭘 먹고 싶어?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB83FCA84C0E534C7B3968769A09CAFFA7A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8C1DDF985AC874F87480765C348B1875075"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7CE40F5494B41425248CD94EF2EEB5F525E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E06CE6C77CF5548B459E2285ABA542C413A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6350A3D364FCA243195AE7D5E7D8A502262D",
                        "defaultText": "흐음... {SP:2}{C:1}해산물{C:0}이라면 뭐든 좋아!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7E98F0A6333DE74F5C4B0A59DB80517CF3FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "170946A4543BE843173806127B7378B47958"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE92DCDF28CB884285291EE7193B0E7A69BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEF3ADF17E2FB24352492AF187F96FE8BE5E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2803F9641FA8534BCB6A6736F81F1B10D644",
                        "defaultText": "해산물이라고?{W:100} 알았어.{W:150}\n내 메뉴도 함께 골라야겠네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AA2281896CCE1440456BF979FD7E550B4A94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8F1C6ED7109854442719AB6809BD11EEB692"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E687E103805B74E4E8B0ED766A58CEF9416"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E7B14A440DA6349E129FCB5628986219A65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0B5F2EEE45AA25484378D2652B5A44F4DD2E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4186311A06FEB24FF9285998A03F4F03B89F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "A7F9FCAA4416D346F61ACD04D7A92E32F5EC",
                        "name": "Order food"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D173E3041172334F415AB9164E064FE6118B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "783423F5446D264CDB7A3E98E39840C15AB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2520CD820CEE7346D32A97B80FEF7E53CC59"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E965F6F882F6B54B4818EA36265481E5A6CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9287A8642055434F88580C76AD84C382CA99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "815C4CDC984EF64187487E024938D60E99D4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FB4137C18586E544CD5A6C7852DF7B18F52F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_SAD_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F688655136F3464A7278DB021405DCE79F99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "9D570D7F6265954D301A38E0343E35FC4E14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3091FE2D695DF440A36A04112D27E74E9EF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B02976E59F3BA445D518A26004EBFA0C739B",
                        "defaultText": "우우웃...{W:150} 우우웃..."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9217C634599F0840A828AAB4A89E04DDF36F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C4146F3F7FDBC142232BA967DA606FE83985"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D2C0E1A316FCD242A5780228F0C2E4EC28AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABF701E147089448AF788D154D4B70CD5E56",
                        "defaultText": "걱정 마, 내 것을 조금 나눠 줄게."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4BF07D881DE4094D518ACBA5F22F26BC6C4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "867AA5DB76C8C744F54999085EC2527A77A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6D723C604602D347B43B3C106C6D0AE0C6DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6FADBD5681B00349DD4AF4F7F01CC2A75B20",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "13750F5B774D3549307B38C50C32CCA8C864",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "ED6E79161EFD08410B4BC7C24503B3F5E7D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "97911A7A6151A347F85991A896A2F81512C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "7E8AF8383EB2424025393564FF57B9794587"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8747381C6F12E14CDE4A867432CAA49FE979",
                        "defaultText": "우웃!{W:100} 우웃 우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "144E5AB386AE45431288D063F312EFD8768A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A3817415892EC846D11BCCB6D3185DAD6BB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B215F6D93EA39349FB68C0C11D4578B2788A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A728FD83BFCE745984A658103D359C8F02E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AD2BBFE4BCB1247E95B0CE39466CEB40812"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4B0DBB78DCD284ADF2B43F38F2BE0288A7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FF52A4D23EA92647806AAB109BE712FDE7EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "420F0D7E1D23124098182274E767F34EC386",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA5A62F042BD0345AC3AC852F98A036CE927",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "129922181FA7D2466A4AD3D416E48FC50249"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "123CF9463D7A1346EE78F43162619596D8DE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "039707576B99E94F673843452B718079B0CE",
                        "defaultText": "골랐으면 빨리 말해! {W:200}하루 종일 주문만 기다릴 순 없어!"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C88865870A48447D82BDEA513E16B912C8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1ABA2B581B45144E48684BA8497AB7E856CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3AA6DB0D931910450839E5C45CA734FBC0DB",
                        "defaultText": "그 놀란 표정은 또 뭐야?{W:200} 쯧, 요즘 젊은것들이란..."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8570B1EA46396541DD2AE9E9AB0C41AB7A8E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B96C858C2605C146062A36D393AADE062CF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEFD32A169750546A419C4B6EC4FF211D08F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8BC0A4AA210DA248188A13C889BE18B15A1D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "972E1D584927D84CA8691516CF81B630D069",
                        "defaultText": "이 주인을 \"까칠하다\"고 표현하는 것만으로는 부족하겠어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B5F6A931016AF3411E5A85A8361A5CCB5084",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C7596F6054E14B141AF3C5CA4BFA7D2E38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "854EF2C8035603439D3A7545D26631D4A5E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09C2D186870D9546668A07469ED072B3E20F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C0.1-03_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "616DB6A2589D5347EA39AD14C1C5C092E34F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4805645104A48944F92AD9445D9ED7837B8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BA2224B7E454543EF0848A1BF442910C13C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97D89C262CDC15400079DD25022A88580D62",
                        "defaultText": "네, 주문할 준비가 됐습니다..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5920D87F3043324E2E68C326CD26D9AD6207",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9CB4D6A80F88440AD3A5B6374FB1C8E845E"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "length of list",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "51659B4D5442D241878BE9A3F1FE0E0BCAF4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "length of list",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9EB31FF87C7772488E5AAB46246B79D76694"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Same dish",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "65D0D1E0154B404D060B9EC0F6CBA20C0B7D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "evita la scelta se avete preso la stessa cosa"
                },
                "indent": 0,
                "uid": "56C06E69204CE3491D4A484769CEC3F08219",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB08DE402954F842CB0BC8817DD2384D0F9E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99E2F7275A24674E8C1B96B1B227DFE0B10C",
                        "defaultText": "{SP:2}{C:1}시오리가 주문한 것{C:0}이 뭐였지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AA08E6A6464FE248FE4B2F90D77C54099FD2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A91401F649AE94FC23A0D3036959F715454"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 5",
                        "index": 304,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F3FCD6F98FB0074A6A2BB511799433B50FA2",
                        "defaultText": "."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6D2AAD17795EE74AE58981B1CF37AE529FA3",
                "expanded": true
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 0,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 1",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CCA335045BDDF3497A7BF1F6E6BB5781942B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
                    "parameters": {
                        "values": [
                            {
                                "name": "food 1",
                                "index": 0,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE0036B373E5814EEB78C686FD7EACDD7543"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Text Output for Translations",
                        "index": 314,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi",
                        "index": 300,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "46862DD4128480495D7B5B80E39312C3F747",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6DA183A528E5B04DD48A45E8427505511C16",
                        "defaultText": "{GT:301}{GT:305}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "636F39082B4A744E432BE7474E7F266CCC1E",
                "expanded": true
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 1,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9F0A1DC761EC974540685521E17982432F7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
                    "parameters": {
                        "values": [
                            {
                                "name": "food 2",
                                "index": 1,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DAB29AF17572147DC8B27662E6A56E8519D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Text Output for Translations",
                        "index": 314,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 2",
                        "index": 301,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "17B166660650E24EB47B59773A486A9BEF49",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4E5F3EFE429663415838A322427E0E699A9D",
                        "defaultText": "{GT:302}{GT:305}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5BA052449442244FC68AAFA62499366CF8EF",
                "expanded": true
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "length of list",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B89C282C567B944293790142E39DAC3698F6"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "length of list",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "09B44B593940B445414AAA975CF45F28D262"
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 2,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 3",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7D44C0739E2D6644942829A48C86431231E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
                    "parameters": {
                        "values": [
                            {
                                "name": "food 3",
                                "index": 2,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "3DEACBD3796C7240053B77F4FA0DD0DB74E0"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Text Output for Translations",
                        "index": 314,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 3",
                        "index": 302,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DEEDD8249B7BE344CA1BD0A661D00E12111D",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8C0B817D2EFCC340565B8181A22E932D8293",
                        "defaultText": "{GT:303}{GT:305}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "56AF7E8425AA824E0508D1659A46BF1F785B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 3 label",
                        "index": 8,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4E3E281A13AF144D37490317F7E9F8E5E5AF",
                        "defaultText": "food 3"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3B4B62D26374E14DF129D3B8662D10059DCB",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "length of list",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 4,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "649360D040B9A44C616A30E6C184A3B94A52"
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 3,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 4",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A8309D0172F63747BA7895A6E6CABD572D6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
                    "parameters": {
                        "values": [
                            {
                                "name": "food 4",
                                "index": 3,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "F86C023387F9604FEF284217A17E48CA32B5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Text Output for Translations",
                        "index": 314,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 4",
                        "index": 303,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "733EB1E93256A241C95BA307F83D89B32630",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6613B6F254C3C34A662AD653FAAD698FBEFC",
                        "defaultText": "{GT:304}{GT:305}"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FDB41F455805364E09789C07EE850C85D702",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food 4 label",
                        "index": 9,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2DA221232C8930430169A5F4E8157C93A953",
                        "defaultText": "food 4"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "517076695214F4421A6867D8463B318E89FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "food 1",
                            "food 2",
                            {
                                "name": "food 3 label",
                                "index": 8,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "food 4 label",
                                "index": 9,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "D06B580E432BB844777825B07BE9CF5BF67A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9B16A20E73626641BA9B6C05D0FC2BE8C42F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "food 1"
                },
                "indent": 0,
                "uid": "7FEEB14D8D6052451C9A1D237E80D240D5F1"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food 1",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C1F18D496799244D4B88FE8894061305E140",
                "expanded": false
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "double selection",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "2209833A6439B747769A9881491A4C9D9E27"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "food 2"
                },
                "indent": 0,
                "uid": "3D3DFDF9540C624D8469EE2614598DAFA423"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food 2",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E9B3A533AA8A145203AD2091DB73BEF800E",
                "expanded": false
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "double selection",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "3FC28BB64B69C348696BE85813B304B7648A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "food 3"
                },
                "indent": 0,
                "uid": "23BB2EF72C0876425D186FD67E039D881D57"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food 3",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E637A2DF3D8F9846378A6D0459ACF4314178",
                "expanded": false
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "double selection",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "413EB3688FD3984A28891F822BC88181065E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "food 4"
                },
                "indent": 0,
                "uid": "95C6CD2748D1384F62792DF1AFAED91671BD"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food 4",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B3EA66FD5CFF6749368AB6A262EFFC7D90B5",
                "expanded": false
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "double selection"
                },
                "indent": 0,
                "uid": "F23E1653204A634ECD6A2B5563AF4BB1CB3C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EEDC6E5015F3B44FEE7BDDF4539C98B9CEC1",
                "expanded": false
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF5C62E0817128490E28F4D8374803231CBA"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1743EDF23EE5C24B8A29E85669BE7DA508FD"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "1E5077B529B06347611B7B74B76F7E02FCCF"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2AF025CB21E6D04DF95ACAA177158DFE3C9F"
            },
            {
                "id": "gs.ListIndexOf",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "index",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A0CD2ECB240A6649B358F733DE80E7CE7C5E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "index",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": -1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "682D131C1612F74E0179CD205A53DE5369BD"
            },
            {
                "id": "gs.ListRemoveAt",
                "params": {
                    "index": {
                        "name": "index",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "3768E86049ADA447045BA7C21F244C5D5139"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AF47E2C7178B314CAB09A0A8FD61AB84709F",
                    "parameters": {
                        "values": [
                            {
                                "name": "chosen food",
                                "index": 10,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 0,
                "uid": "564BF7539827B34C7B294F3218E257093C32"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Text Output for Translations",
                        "index": 314,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food name 1",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CBF222514215B14EEE09C7B5C6112C9430E9",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "chosen food",
                        "index": 10,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ID of Shiori's Food from Ch1",
                        "index": 232,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0287CF8104E7934A605A37452AB043EEFFF1",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B859C8A112CC141A589BD150F06A51B1037"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4419B9E324B72492A0B15F120E70D4254C4",
                        "defaultText": "아가씨에게는 {LT:5}을 주세요.{W:200}\n그리고 저는 이것으로 하겠습니다.{W:100} 고맙습니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D9EECE43F5877432E5AF5832E8CE03BAF4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3028ED3465BA1466F5A596689E4F34F5F6B"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of menu",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "123ACA8D69ED1844278A3B055F0A64D34C36"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Same dish"
                },
                "indent": 0,
                "uid": "36FF09A16122874C49685EC5EC6FFE628DA7"
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": 0,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "72EE0ED22EB23944A53AF6242E478669185F"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "field": 1,
                    "targetVariable": {
                        "name": "food name 1",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D66EE5F77A062344F129D141C62CA4044C28"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food name 1",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Name of Shiori's Food from Ch1",
                        "index": 232,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F8A4AB6042A21340B92BF0C2D0C62FFFE1E8",
                "expanded": false
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "food name 1",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "food name 1",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 3,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "98CBC18A112E0141377841E528A9DF416580",
                "expanded": false
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "170FB6266FED9745ED4BF926F40285277A16"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "171ACDEB0CD7C24C644A97C8B5A586F42A38"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": {
                        "name": "qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "8B35706C45418846D46967C4CB02C8C830D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D8F8C102AADA54036880533FF03FC4F05CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "86CDA8AE6F1DA44FD63B35D542DE4EB49E1F",
                        "defaultText": "둘 다 {LT:5}으로 주세요. 감사합니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "98776F2715CBC34CBD7A60C54206AB8A1165",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B32AB8441938254DDB18A7C7EE9FD8B7A9D3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of menu"
                },
                "indent": 0,
                "uid": "ACAB6AF6630619473D9965A9BEBAF1FB7E6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0752716531FE54C8F0AC23332636CD85318"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6FF3B5A581C267426058CED73A1221E05580",
                        "defaultText": "알았어.{W:200} 30분쯤 걸려."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7704588E9A69D647776B364196FF5E712CD7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEB7C0FF18B62647888BCDF36BC4383BA09E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39DC4955435F124A3308400343DF1EECACE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2EF41D540C72140928B5776A1B12A8041F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1FA270120E43724BA26B4F39AC0A4A15340D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B9441E04D21614AC89A4F1594DA957AF958",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B3ADDB66432CD343463BE6A1335FB6B08842",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FC9D9CFC3A1AC84D2E7A9F502406222771B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24E0BB1530A8E0411D887602810BE43305E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B16DE9C82C8F41427C5B8985F56BD8D0CC57",
                        "defaultText": "고마워요, 아를렌."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BDE2E48B84FF84441E6963E2B9862F55F8FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE748604245CE544C629F1506C348715A230"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D563AEDC1802E44CE86B46F82952C67B6844"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "30AFEBCE373A8246AB6921B506CDE00A51B1"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "CC089B4928AF634BA12A62905B1EC538113F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F22B837F00CFE14F5E4B34D23CEDA613E22C",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA518A4178398448C61AED2767FABDA475D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17AC35671A86E54BDF1A9C86468326BF6715"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 1,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "7D99B8D03D538340644912D4D9CADC8018DA",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0DEE5CB958C9142C65A87D1D30E1C25B29E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B13C17082BF4D74CD02B06C39AB18C4C2417",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FF2DCB0F3908D84571189BA61224AF5B1A9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DD9ECCF7E7E43444548346801D4DA57F855"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            19,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DDB0F90F388B794AAC4AA16340B10DD46C03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FEA7736112D5F1487E69F26204300AA0CF4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08FE1F7B5FAE5249B478634101EC333AED41",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Arlene_line9_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0AF3D46210CD54E281B27824F176CE36F89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A08017D531C1F741B819BCC555403D6E51E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBB1789C20DBF54127694663D03A6B51C4C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DE0BB5B6FA48848311931548C2B402FD85D",
                        "defaultText": "앞을 못 보는군."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "94663DD71D26A643294A38C88FFFBE169976",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26D508937497C743C13AC836EB72D9D814F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3952392940C0B3417E0806322ADBEF23DE72"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4ACDC08D141FB64B243BDAD4B19C5F3F01AE",
                        "defaultText": "알아차리는 데 오래 걸리긴 했네.{W:150} 그래도 늦게라도 알아서 다행인가..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D33ADA66EE1C84F184AE812560E13BC3514",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "796A4470949B6745FD98AD737DAA036251B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89F85CD677C42346AE3AF23762611913251F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37150F6E19FA4447B90B9A8338A83BFDEB10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8A03F9794AA63346436BD3D820E4A7DFD174"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96BABF146EC9574BAD2880F017246391980D",
                        "defaultText": "쯧."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5C87A73C9F781348223908F98870D674214A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7B28B44717DA841D879F8481D240C22C94B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A991BE1B31263545203AA7D4ED0B32903D1A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "CC85D74E7056284C1558ECA9C057AF714B3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "815F82BE839D524D3B4ACE1779530E59BBEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C937270310CD743557BFAE84504D508F03C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB461C8F6FBCF94DFD680583160DBEFC33B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9E836F0330FAE943C01BE0028CF96FC31970",
                        "defaultText": "그게 끝이야...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AFB03DA00E8284BAE8ACCB86F6233344899",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F89C275A6BB9614866197217A10D5B39AAD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F26FA0D58101343FD69250635DBD35E1A67"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF50F704334ED541A66BFDE7A65E741A94F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45E6AD702307D146C73ABED7E78DD8BFAEB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DBC84EB034F02045993AE454011BA8D0CB4C",
                        "defaultText": "나쁜 사람은 아니야, 니니."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7AB748A517FE674F7A6B56E6ED13332C9879",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D76C39B9780B9144EF5B28E75E8986FE105B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "67197C7B14EDB34A7A0955E375CE0F74C550",
                        "defaultText": "저 여자는 못 견디겠어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AE3701184F560342087BEF42A08EB44AA2EC",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "229B98A523273342729A29C4D0818FDF3E4B",
                        "defaultText": "네 판단을 믿을게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "643770EF589D8342BB7B09747D9E4790EF85",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2C37E2DA3D98784334887D32294D96FA1932",
                        "defaultText": "글쎄, 잘 모르겠는데..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C8938EE6640BD74E634A096054074EA60B6A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "odio",
                            "trust",
                            "okay",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA61A4E76F1AC34E203A0F05A729451922F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F7B7768E096F29479F4A9FA3757F4575D63E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "odio"
                },
                "indent": 0,
                "uid": "FD3DCE6228EC33476E3BB76754F3F94D4E86"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E5BB38796850942CB884D9448C1128D9E6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33A6D3987E09D042037A4F34D1B9420DA195"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "048309864DDBA845E55B6003E786A7CAAA55",
                        "defaultText": "첫인상만으로 사람을 판단하면 안 돼. {W:200}적어도 첫인상만으로는 말이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE97609C611E82462E4B58A926AED9ED6D6A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "887CEEE06FF8F241895B7C024FC50C8BD9B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5017266E492CC549CA4A82C5972628D41535",
                        "defaultText": "누구나 일상에서 드러내는 모습 아래에는 많은 것을 숨기고 있거든."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ED34E8C3162B264838486917FFF9E898F54B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE3D58A02AC2A0447E78FFB4E8005F54DD57"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "trust"
                },
                "indent": 0,
                "uid": "0C1FC2652807E2483158D8579BA092E86322"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAD352597EE56045408A5B1548F7809343F4"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "okay"
                },
                "indent": 0,
                "uid": "21546D587B5EF743420B8C88357B17AB22AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87E75F31621C7649C60B272812D37EBE6AD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2ADF2DA46D5484EA228C6C6C5FDD278BAF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EAC0EA625A10274D014A3FA16B9226AEFB59",
                        "defaultText": "내 능력으로 보면 나쁜 의도는 전혀 없어. 그저...{W:150} 조금 무뚝뚝할 뿐이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8CA7EC9E9AD9044B103B7158419FBA9A62F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1EB9EF37FFA844BBE4B268505F2EFCBD849"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D64205C6132C92407A38D53143D99BC1D9D1",
                        "defaultText": "주정뱅이와 불량배가 드나드는 선술집을 운영하려면 성질이 강해야겠지,{W:100} 안 그래?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7C68F6BC43983247A548C232E6A318167BFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "423596219B6A0147F248320503B1DFA171B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "98205BD31525C546395ACA78E91C3662713E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AC4E0A3500BF24804093CB9EA4E90664B02",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FACE92EE549C804ED428D142D45C97E686C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DC8AC28264B73346F32B80514E8DC0EAA51E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C7EFB1A678BC7444929DA68B89D7EBD1497"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5CD5F7A44333C845550B83D402487865F0A6",
                        "defaultText": "...{W:200} 그 말도 맞겠네."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C201858712D0F1494439D9D1516EDF29DB16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9C65D6B23CDA448EC4B4F11CB5B9A65FF56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "81A3AA0E17A76641CA5A50F26BCBFCD70006",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A7733F675CEA44FD6382AF0DE4098B7931F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D84069AE56518044BE5AFE06D86780AD8519"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5EDEA272A54C248901A53449ABCC1B0344F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F68EDFED710BA94A2A2910A2EB36FB83D70D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D14A08769D26444EB12BDC747398EDDF51C1",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A966F51A99D331452F59832828489F1F3BC8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBB4DE9B0FABB24AC76B8EF6C7E00A9E9222"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2B019EA6B55A64A5F2ADDC8E41A37B027DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4B21F2F2765714BFF5836D38E4A2E6507D1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6A9F350901A4184F567A72E58D73DCFFC493"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 69691,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 1,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        },
                        "folderPath": "Graphics/Pictures/CG Gallery"
                    }
                },
                "indent": 0,
                "uid": "BF44AC1514B2664BB75BB6259F7DE0F70CD1",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "705C17606291B64A355B2CF3EA977ACDF821"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "C8FA8488678E2446D7185BA7E86CE24A4A03"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "BFBEE9E6257F5440255B4182D02C0CDEC412"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D18AC03D837B204BA178BEB6C6D937BEEF5C"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "17E797B554D2904A7399B560826E7A869FB7",
                        "name": "C1-03e Chat with Shiori"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B2324761071ED440B259F6A53B61543B373C",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "food 1",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food 2",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food 3",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food 4",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food name 1",
                "index": 4,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food name 2",
                "index": 5,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food name 3",
                "index": 6,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food name 4",
                "index": 7,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food 3 label",
                "index": 8,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "food 4 label",
                "index": 9,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "chosen food",
                "index": 10,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Arlene",
                "index": 11,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "length of list",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "qty",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "index",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}