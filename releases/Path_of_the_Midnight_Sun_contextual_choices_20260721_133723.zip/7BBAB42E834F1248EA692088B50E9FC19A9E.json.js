GS.dataCache['7BBAB42E834F1248EA692088B50E9FC19A9E'] = {
    "uid": "7BBAB42E834F1248EA692088B50E9FC19A9E",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11A-8 Post battle",
        "type": "vn.scene",
        "parentId": "03704B7C7D05F0498F98DAB7850BE4F8CCEB",
        "chapterUid": "EF3BAE1B50D8764F0D184715C435B627D64E",
        "order": 10,
        "livePreviewDisabled": false,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "A3C61F6457C8194E8B688438932B7E86149F"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B1DC23AE4C26A841116B6A9729644968F451"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7909F7309700B94E9D38BBF9FC28D6D613DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A46CEAD4B57A34ED65851B64B99B4EC0C15"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F6E433B061534144A08BFFB67AD10A0553A9",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C45CF6C3F629441043A3A81F55946494EFE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CB714D94714A504FBA8BF0D8BC0540C586A7",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F79171667908C14FEF1A5315EE3BACB0E782"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "8410EB175A4D614BF01B3B5753218AE970FB",
                        "name": "37 - Finn"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "E41EDC40674CE0454B0B86D9B1B7D26B8A15"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "D4C156B9328792453109A140AFC5F291050D"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "C7D4892A07CD5641F25AE2D1814F428DC21C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "85B5E26E5E024346E0282910992F52C5EE66"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "D816AEC96BC5B14CF409FF659B52B1E6AEFE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "460CD29683AA1748BA4991A61140CF13F01D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            802,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0252233F2E19564A572955B7D6E20ACA9DB0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            9,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BE9CE6F3EDE1549521A87405C496E5786AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            16,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A4DA7862C23284CB03BFC029469250AD9CB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "00CB701A718E3248854B7894F2646DC96D57"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5B9D2FD80361B44EA61AF3155B89794A2513"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A6F443D716DE644A021883441F2AF71A9FA8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69C36F8E36995642CB7AAB370E907D8796E5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "893F0437009B25495059849854CBD566E7F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BF59B97C5A32B74DF79840B2E16900AAEC9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1F381C55B6245435B98FCA54DF9F03F585A"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "model": {
                        "name": "TacitusBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1400,
                        "y": 536,
                        "zoom": {
                            "x": 1.77,
                            "y": 1.77,
                            "d": 1.77
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "C7A692B411E34347624B54F4250CF0646116",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.3,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "2CDC75BF866BB046055A8913AE0EA537A8D9"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "model": {
                        "name": "TacitusBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 670,
                        "y": 536,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 15,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9459E6827EA231443F4BA861DBA02C39FB09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A37F103C0D4923451A190E2899A5B3983DF0",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DDC25E1751782413718CCA3A9D04526C4C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6DD101358FA924A156A2F838F9076CD95B1",
                        "defaultText": "다미아나..."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "85DD3E127EE6C342125A82A35BEBB439B732"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC742D3974620142D03B65B7FF3271E7D95A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1A79AAB6D420845EB0B7FF9C159734769AA",
                        "defaultText": "내 딸이... 그 아이가..."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "EA6A303B4EBF20460D3AA2226B0207970575"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9F1437C8B8D924823494D70F895F9A4ADCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F2DF79F5FE33747B33982045E00F65F8048"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63822B5141F273487E28F7857C901EE9E426",
                        "defaultText": "그 아이는 이제 우리 곁에 없어. 갑작스러운 병으로 세상을 떠났지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "257B419995C2E845953B7A415110BAA3BF3C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07E7F1E2515B544BFA3968094F13D466DE83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3D608EC3047B742415BA9C96390F26D6928"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D1DB437C677AF9487999C7410ACE4A623C67",
                        "defaultText": "아까 크리스토프와 함께 발견한 일기는 그 아이의 것이었나 봐..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D2C4094E5DA2E746298B1203EBAEED120FEC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E306F9173A6D08485F3B71B285F37DD0C892"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A37F103C0D4923451A190E2899A5B3983DF0",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E5AD7C1623CA54DC1287821444304685280"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B4C12482AE037467E58C817CD59DCE35A42",
                        "defaultText": "아니... 병을 앓은 건 맞지만... 교단이 내게서 아이를 빼앗아 갔다."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6E3D1E694EFAB74E76195A36404299EC3F08",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B81EF0BA27485646EE1930E0717D10EF221B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94CE7B463B499645501AF0D432A195A17A3B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2EDB3F550B49749D24A3F71DD4A4E1AA861",
                        "defaultText": "그들이 단순히 치료하려 했다고는 생각하지 않았어?\n당신은 그리... 협조적이지 않았을 것 같은데."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "098202FB61B508432B2B3A26C648386A62FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA08A0848822F240A329FD4610088BA6D0EE"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "flash of light"
                },
                "indent": 0,
                "uid": "9C16428F4939354B22597DB7374B3B96D901",
                "expanded": true
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "opacity": 160,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B7E8A9248810C64D79284D88317FBA5FCADB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "55E289A356CAF74C9989D4B73A9473C4BF34"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68638C5424BF774E9C39C5C691A6F0248B42",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Tacitus",
                        "name": "E3-Tacitus_line11_2b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2B3E6A975B276743693B7AF4D605C0C7CA8C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6A4658DA44D4F641AB1A8708EC2552FA02A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A37F103C0D4923451A190E2899A5B3983DF0",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AA47BF5875CF744676BAF4588CF72FD2C11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C03108211FA464B2B1BFA7237CD0DAEB2A6",
                        "defaultText": "으윽...! 거짓말...!"
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6EEFD109289BC84B5B2AA246AEBF5934A1B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F943E9D97449A44B6F6A32746D071DB1CCE6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BBA05BD08405F84A938A9CB234D7D487BC4A",
                        "defaultText": "나중에 나까지 병들었을 때, 나를 구해 준 건 그분이었다..."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3956E10E7CC7F14415880D089D06FCD43D6C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5E04BB51019B14DBA7BD835A3B13E4DA494"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26DD1B3337265440E28AF0630FE2E61BF617",
                        "defaultText": "그분은 내게 세상을 바꿀 힘을 주셨다... 그 힘은..."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "048B6ECD4B96214FAB2B77E18D5C39F17A4F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBA5A12F807E874DBC2A63110460A65ABC8F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F34632781B21448F62AF411ACC6A99C6784",
                        "defaultText": "...내 딸을 다시 볼 수 있게 하는 힘..."
                    },
                    "position": 0,
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0F0FA93197B0444C7329E330836E83CA97BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "321EA7F96291214911185074914A97E3DF90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "84BFFD619A23654ABF1A7F452FED06BE2451"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "5358809556CDE345F23AF728DE50582A6D8E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle",
                        "name": "Mana Flame.ogg",
                        "volume": 100,
                        "playbackRate": "129"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FF85878A80292840FF2BECE7C10A0B896E70"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "duration": 13.2,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5D66877C2FEFD44555791AC4AE014150BB74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            220,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "505D21322FC7B545F73825E800844A3375D6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "stronger flash of light; Tacitus disappears\nthe Scourge fog gradually disappears"
                },
                "indent": 0,
                "uid": "8DD0C08752A09245873A73518E7B62FDBD66",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "98214455175463482D8AE0B30EEF10452A4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AED382DF40CBE24B914AA279D6DB10C29D42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20DFA49D1B4AC54D630BCD966B40D62CCC48"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            450,
                            0,
                            801,
                            -80,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F8B7B1030780948D91803A4F1A9A8C91CA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA08697C6D0967463F3AC5E39955406775CA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "17A01A4D4FF535466A5BBBE8CB3AF6D8B12B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8A02776125BC94BAB7BA2E495C04F41B0CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A57E1F424A499049A63B1EA191F8E8D664E0",
                        "defaultText": "저 사람이... 사라졌어? 아직 물어볼 게 많았는데!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA824FED6522734D1D18A97600B92B2EE276",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18F0A6666CFE7045882A4373521CD07E9CFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDC7F3558E811440A96828A03FDD773B09CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA49817F191DB84A6F8AF00875B553362869",
                        "defaultText": "대모의 예상대로 마나크레스트가\n그자의 힘을 봉인한 것 같아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7E80E7F74DD30149583B29E44079B14C64FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB45F39064C5904F1E59B7126163E9C28609"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if kabeer's power already sealed"
                },
                "indent": 0,
                "uid": "A52831419B30964E0B68357020ED5AA2A308",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "93D0117F378AC0490B182CA7D0350C2C6138"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DEE686602EADD545B93BC412E85A4E4F454A",
                        "defaultText": "카비르처럼 이 대악마도... 마나로 만들어진 것 같았어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "2C3FBEE247C1D3417A3B97272452364066E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "71BBBBAC662E134E4D599C59BC4D519AEC28"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "EC1C76F8155F2440958A7B073F7E461DE548"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "147911817420F44FDF2824787F9CA188A1F0",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E59A3AA76321442EC3810F283C45409C6B3",
                        "defaultText": "이상해... 온몸이 마나로 이루어진 것 같았어..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B05EB65F10A663465318252579F84B413201",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "53979DEE8502F24082591C870C442C696F50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F27FA41C39B1054B283957B8049EDDACE1D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FC96E564DB544455F9848705DABF84D5908"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6A47F6CB9ECE4946326A9BE8A38DA427646D",
                        "defaultText": "자기가 바로 마나 재앙이라고 말하긴 했지."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3DBACCFC6D2EC44AB489CD12D6A614ABFF98",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECCF3F485D9325460568805861C916A95A47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D52B325D0104C44F2768A210A59F3331AA21"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "CE5C489A0E9AE7427828E3202EC59F91AD72"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6666,
                    "duration": 72,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "05167E213E06514D83593332E16BFCD6B696"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6667,
                    "duration": 72,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BDE844C359C4424B10384837E47166426052"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "239FF07721C7D643B018EB527F005AB2939D"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "MANA ATTUALE",
                        "index": 248,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1200,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7696F54B1FBD42425478F6752FB8FDB1CE12"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "MANA ATTUALE",
                        "index": 248,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 9999,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2DA297952B0169438E193962B812FCC15B62"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "MANA ATTUALE",
                        "index": 248,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 9999,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3D5A7EEC62EF64486C6807E560C0DE017543"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "422B49CA8A63A04CB338ADD9E56A9BFB25A0",
                    "parameters": {
                        "values": [
                            "",
                            {
                                "lcId": null,
                                "defaultText": "The Manacrest obtained {C:7}1200 MP{C:0}."
                            },
                            "",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6291D5306AFA724F643A2368A9652D3D3797"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6FE3C1466BE6D749E93B1A1763C2A8DE2900",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FD8E4B86930EB44FE43800878C02CA087F83"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E4B8B27594EE934BA84BE6F94002A06090FA"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\nmusic changes\nMana scourge disappears completely"
                },
                "indent": 0,
                "uid": "68834EC27B993846F42AAEF8E1C32D86C221",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "22A3EEBC178BB248868AD5C1242C4BB8DF8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4618C11E83E546496518F3D2909C00374979"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4860216238BEE74317499EC5C35955421164"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97EC7E4C830826446F4BA45173BE6961B665"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA2AE3760839B84A62290D47893CCB2A2F3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA87564941515347CF693AC06DAF53AA4749"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "877FA47A420FC848E81BF0274AAD4326F864"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AD9150233253744A925BEE41F8EE4EF37EDB",
                        "defaultText": "마나 재앙이... 멈춘 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "299479EF5394D64A3568CE65109C86866DEA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B0395414E6B56450C1BA1D759B0619F080C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC06C90A1AA30246418AFBC2AE5CB8E97EC1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5CB4B1DE3897624DD97A2CD2B9D659947E23",
                        "defaultText": "그럼 이제부터는 동물도 사람도 더는 타락하지 않는 거야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A78E8DB7500B47400B183F6447BDE1BDBC46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "734041373C63274D1A98E806016A9C5312BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CAE0C9E9AB03447F278ACF5C5E910202413"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A350580E43FED745200BD6C33950E99C2904"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36B8FDE1298412483E5A3182CDEEC20E1CB1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87CD9A9764CD794A357A9BE4A1D66C1017D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D559BBB463BE45484859D997C57248A65C1E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D57C18D56418646A64B1E31E0B3ACAE6843",
                        "defaultText": "그래... 적어도 당분간은 그렇겠지.\n마나 재앙의 잔여 효과는 수십 년 동안 남겠지만."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "227D244C6A8D4547EC38EC810FA724023559",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A6BC5304C5A13463B296C04A0406B98414E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DF2474471ADE14BA77B8DE0F3BFF3BF97E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7917C3A60AEB049F77AE571795A68CF3119",
                        "defaultText": "이 모든 비극 속에서도 그건 좋은 소식 같아.\n하지만 의문이 하나 남았어..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F6C1D0052519240A06930506929FB8435F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBA4F4669FDAE741123B00E5B74C6FDB15E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "123F43E022CD87434D4885E8A18918616048",
                        "defaultText": "타키투스는 대체 누구, 아니 무엇이었지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0C66AAB1097044A46091F16FE05E3003F32",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "990F3D5A9812B3452F8A80A56E01484C2A0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF0CE4DD0F7EF34D314B12A01BB4D7509EEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD179EEB0D25374B707926A5DDD23252C3BB",
                        "defaultText": "생각을 정리해 보면... 몇 가지 가설을 세울 수 있어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DAC5977E7B126843EB38F9D1B612219CADE9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BC2F5AB6A0DB2426A6850B57823F9A5B0B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C040EAEC74192843981992436838EE7E6CD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "844EA6B58B7C884E9518E625A04740BBFC72",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line28_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D819B46D555EE74BE61A6C619FD8D5622A54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F6C1D690632D694B263AC139A9204FE343A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "619CBA226CA422494219A8912CADF1FF1017"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "212B54F7501F4149FD38D6319B8C15E4777B",
                        "defaultText": "발견한 일기에 따르면 그는 불치병에 걸린 아이의 아버지였어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2C608939C87164BD27BE1C15D5E8302C3CD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C0A9F011F63A34DDE890E80B4F77050EB11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "560E5A0F4574244603683FA1376DC80EC10A",
                        "defaultText": "딸이 죽은 뒤 복수심에 빠졌고, 헬리오스가 그걸 이용했지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CEA28BBF53B324453F89E593466FEB9F67A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F79D4D688940E0492C4B9F742098CD4D4B52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD3D5C703ACC354DDF6AD5F54E39BF7C08B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2AFF19C31503245F56AAC88A93CF02DC431"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D8AAF0A4F060345BA4A6A3037033D677F27",
                        "defaultText": "앞뒤가 맞지 않아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C62C21029FEF374EFE9B35D445454C3AAA9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6968527231B2974804196DD0799D2F8DB00E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEDBABBE6DB07145B20800130E8CED8F66C8",
                        "defaultText": "헬리오스가 깨어난 건 몇 주 전이야.\n하지만 타키투스의 이야기는 꽤 오래된 것 같아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "39B121788633644CED5AF7958B621813B803",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F79C2A0A5B1653466C7B775456BD54F6D4FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE06CA525D9582430B5AC2F819EF3A6DEA79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "880825795BF6E7489048EFC6E7AEBA6B21E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "261411546D88A44A937BE72674B89517FAE1",
                        "defaultText": "그러게... 그렇다면 타키투스는 언제 대악마로 변한 거지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6EEF09403C6E444DBD1BB2D42240B2749DA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C80E4A9721925412E290F46CCCFBFAE7ABE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D810D0CF32490246F07A90F14D8B9AF759B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC079CE9004F044AEC792D725AEC573D13AB",
                        "defaultText": "그 질문에는 제가 답하겠습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B0802DAE2F88F8411F2A37A895A0B7EB6A64",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C85E2C3E877C114A4F192B09B77840DF5097"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC4161BA11088646527B10834B90118616CA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "360EE7DD0A58F6469028383380ACB93DACE0"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9FB60133514CB649ED18F752465956E4809F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "85A020A921C4004F489BC9A71FDFD3B19B7E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9FBB766E9C8BD346F41A5A984608924FB135"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DFC3C105171FF745A97886133028AA79C054"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "model": {
                        "name": "Finn.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 350,
                        "y": 30,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "1B8BDCAC703B944AE03B92C10D5086B049F3",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.7,
                    "idleIntensity": 0.75,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "4AF435DD78188844FE5B85A1887FB62E7DDA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "26048DF65C37C346761B6C491E9B1DC94563"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\nFinn main"
                },
                "indent": 0,
                "uid": "1A2762133F02C64C3F5AFE3322BB933F1E4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F36C9E4518516499B183DD5A1FEE37C9514"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8113DF82491B344EB41AD0E80700CFFEF2D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DDCA1B3009A6247BE6BB241CD1052457407",
                        "defaultText": "로이스. 아까 도와줘서 고마워.\n상처는 다 치료했어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "424DD2C1136F03407C9A6B004D8EBEEFDA2D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C533ED4496E49441E89DCD05904F653AFE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6990EE427E6AC14B9379B5A040BCA2ED1AFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CFE26D2E33F165497B582A55BDB48D89E909",
                        "defaultText": "네, 덕분입니다. 대모께서 맡기신 일과...\n좀 더 개인적인 일도 마쳤습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "814AEE99939B194D058B406898C6CBB070A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75F485484614D748CA293D45EBCB01D5E181"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0FB3C9C4A7B05415D88A315A6046CAF2AEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9DB16A956D58240283AB8C5C9D4BC2E8EA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D30EAA4C3006954B387AE9E3E203E306564A",
                        "defaultText": "내 취향에 비해 비밀이 너무 많군, 성기사.\n인내심이 바닥나기 전에 말해."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "061BCAF8259365402969020468D9E1F91C00",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B88EE1D8A5BD74E640B3E07D9402DC6E232"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "942ECD350FDC544BD11AC70163F2289F8DB7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "971F350816C33147E4596368A7C7FAD2675E",
                        "defaultText": "...먼저 사과드려야 합니다. 여러분께 거짓말했습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8553F76D69F0F842EA1839C761862351EBFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85AB7CA2904A2940A8594A3464C09B4DA2A5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "02C8EF0C85AA17455438257004992EEFC75A",
                        "defaultText": "핀"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7705270E04C89548CF7935F0C2685F7D3708",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Finn"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5F9B06747478144DB24A9E25B7D20F006467"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E77B21BE7931454686280A32A2F8163D67F5",
                        "defaultText": "저는 로이스가 아니라 그의 쌍둥이 동생...\n핀 발리노르입니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1073B5ED1E74D543BB9BF361B16965E4EAE0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E16ED085774E2348EE6B0D79D8F36CCBCDAB"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D6F26C2F272E614B220A2C05973CDEF01571",
                        "defaultText": "로이스와 형제라고?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AB82C1FE24272848381833224FE72E255448",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8A12DA18567A3048347B8BC7A970E0E2B634",
                        "defaultText": "어쩐지 그럴 것 같았어..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "95B97537811326417519C286934CBD9BE3E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "twin",
                            "saw",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A56075828FCB143EF98164183B725E01B4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "329EDAD302FA86426C184EB4803D4252F270"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "saw"
                },
                "indent": 0,
                "uid": "56F9170881C5D449964B89B4B362B81211A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "10E6BA0E7392114E6D8B10301CFBA6B37A45"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2528E9921B04E1420C2B7EB53D65E78ED41A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0BE868BA06FFB64FC88A0AF485C22A294D9F",
                        "defaultText": "헤, 역시 대모께서 가장 아끼는 사제답네."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D00E38106BCC944A6F699D75B2B398398210",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8327E124ABEF144848A5566ECA4E2009551"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "532374838A32F9453D09A707EED3607E0EDE"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "twin"
                },
                "indent": 0,
                "uid": "83F78CB82BB18241109A2E8563D9D1FE40A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4E42D001591E444F639080566DE74B36492"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB42404443AB3543DB2B3DF69F46B694C1C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A963497010E3846CC083E21BB7AE72019C5",
                        "defaultText": "정체를 숨길 이유가 있었겠지. 그래도 우리를 도왔으니\n그것만으로 충분해."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA2AFDCE6C3823422E398F05F18CAE26C0F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35A1F02F2B2EB94C2778AB47C60DD278A343"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1210239673F5B34EC9389422BB1BA1675D02"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44738D6866755345692808645A61B72B07D3",
                        "defaultText": "용서해 주셔서 감사합니다, 파라트라스 님.\n제 형의 이야기는 타키투스 사건과 깊이 얽혀 있습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F5A9715E5AAD494BD05B85528832C60E7581",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E35B7298C0A024A8F4855348364751ACFD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2EB7581C8470E64227897AB68DB09ABA9DDA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "69ED95F19E31714B7E3A3DD14C5EBA5F1CFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C15E91C39037E24D3F49E725A09368FD8918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1E9E9555D86184F7A4A1FC5D75FCB4FD1C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DA65390074D493433549AFC36A78FFF795B2",
                        "defaultText": "짐작하건대, 인형 수집품 중 하나였다는 얘기는 아니겠지."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "08EFB569637DC1437C9A0385B505FBBA4304",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D6EF58B5E9281459738B6470D1999B0B6C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD3BE77F22DF074CE63B96F1E045985B376F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "400DC8F0643A624FDC591B552EC46F45F6AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "71A0747B25CD90402E797D63CF7E86899193",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "E3-Finn_line11_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D135659713E9443B68A51F5EF5DCDFB180D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6E679DB17CF91049573BE1E4379950C79466"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8234DE434EBF424A1A1BE18754667F3529C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08CC7F57572FE0464A48A8D4DCB812B810FB",
                        "defaultText": "오래전... 로이스는 타키투스에게서 딸을 데려갔다고\n전해지는 부대의 일원이었습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "91B1B07E5E52D84F4B3AD192B7E34CF37B0E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EDC794C233C884D953A9B4524CD61381B68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9477A72F8360374DF27AF4E6D2CA3B56BF25",
                        "defaultText": "성하께서 소녀의 병을 고칠 수 있길 바랐습니다.\n하지만 아이는 곧 세상을 떠났습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC6C3CF05BA6D14FF91B1E45DA719EBEC9C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB497F2C0FAC3448DE2B2A25668B2ABB04C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EE620148274C244E20896FF7D2A38AD77046",
                        "defaultText": "몇 주 전, 대악마 타키투스가 제 형을 찾아왔고..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8A40F7CA19CBE043AE7BD4C1197A005221D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C64301D36708E64526497F029EDEEF49020F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5C8031E847CF2419718E574002E2BD19F2C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF0166F58081F14CF97831479E6D8CE9E052",
                        "defaultText": "더 말하지 않아도 돼. 네 상실에 애도를 표할게."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4DFCB5B57B5F2477868CAB142A5EE05F22A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "862BED155B72D34BBB6A7E086BFD16470CCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76B748D8908917477889D2B8F32EB20D868F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA8222B05F7DA4465E7814B8164E74F2FA2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F8F0DEC65F91304C50288DA6BC9295AE0F88",
                        "defaultText": "...형은 죽지 않았습니다. 하지만 심각한 부상을 입어\n평생 다시 검을 들 수 없게 되었습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E88322B4494BA542184A77B16E1F32B7AE9E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "657C1F2C5DA8114163398FF39CA36AD33575"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1053E6DE555B064D3D6A9B136B175EDC4105"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F275B1382462347335A07D18ED012B35B6A",
                        "defaultText": "그리고 몇 주 전이라면... 마왕이 깨어났을 때네."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A67164867C48B74F044893C7CFA68878B4E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B3287F9086F87406B59C4220ABCEA80B8A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E70D0393DC5274C8949EA00C29FBF9D22C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D1210554A20184AFD19CEC40C869330EC32",
                        "defaultText": "마을 사람들 말로는 타키투스가 사라지기 전에\n심한 편두통을 앓았다고 해. 그런 괴물이 되다니..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA80F9F1337898460B39FFF60B35BC480560",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5988F024395432478729D6D9780DB6CE64D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75F291D13D035249B659E4B662C84089CEDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F16304080088F641464A9B20DC3A0B847D79",
                        "defaultText": "심한... {SP:1}{C:1}편두통{C:0}?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8EAB45AF6681974FDF8AAF32FAE5B67E7661",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "002CF54644F6054DC4686B960C6199CD1869"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "83ADEB6F8FF06448570852C2FD3A4ECD47CA",
                        "defaultText": "니니가 겪은 것과 똑같아..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "354D9AFF89E6234CD7589A73F3AC7F71ECC4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C91E4FFD1FB3964930888086E8E93D839147",
                        "defaultText": "아까 우리도 겪었던 것과 같지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "77F7D88E9CE7134B6D8826B84C0211C03367",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D2C402094ABA2451A29654730315E0E4704"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "029D0EA73D3C6547BA888828EA39381F611F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "35F3D9397D51C244EC68E111645295EB4D74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49CE247C7A17B141F4798BD32F643E6E098F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9A6DB8B6ABFD447333B10F39100F95CB34F",
                        "defaultText": "설마... 헬리오스의 저주 때문에 기억을 잃었고\n괴물로 변하기 직전이었던 걸까?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA2ED4EB12601641952844A28E1C6CA2CBBF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F01AD995F5E78433D88FBA406E3F74CA0A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40347E0E40EE8843CC881DC0F1824620976D",
                        "defaultText": "타키투스조차 인간이던 시절을 거의 기억하지 못하는 것 같았어..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5F7EAB431583E841DF8A166274ECFCEB65CD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E55A41D6959C304E345841565E00D476725E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB5D88095201C2449E3AE1554E008CA3F458"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CB95E4D35AE9744FC3B590937EBA5E35AC5",
                        "defaultText": "하지만 니니, 네가 기억을 잃던 바로 그 순간\n나도 함께 있었어. 아무도 널 저주하지 않았다고."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BE5DCCD05CF4F747E928B2F9F9DC0B31F0B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "005CEB2A1404F2422C49997770EA1177A84E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6793C2B61EAF54BC43B8EB53E73602C2A87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDFE103521F4E245FA2B1824C8F72202EB1C",
                        "defaultText": "더 일찍 저주받았고, 그때가 되어서야 증상이 나타난 거라면?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0A5951791423994B8D58BF245AD10477F4DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDCCE26A6B9C51461A5B9D95318C61AE86A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EB7930151B4A842266B9EE8503BC696587E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "CBFBC2C021F9E841413BD075ED1FE67E5C2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF675DD5140C144B584ABFD0CA588DF727C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA9B66425A7343432F5AA0D84098AE7F7160"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5F43FCAC7DA8C6400F8A03431E93B8E6D7C0",
                        "defaultText": "이봐, “더 일찍”이라니?\n마왕은 21년 동안 나타나지도 않았어!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F395FB2C180479446B39D116C1A92F898A55",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E83D3A41A81E54E4C2A05484198F1DA14AC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if you've been to midbar"
                },
                "indent": 0,
                "uid": "2B4A5F1857FEF5469F1ABA31325295E87A87",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D1D1FCC64812441277845058FA961E5C13E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B7F6B27E73B8F8464F8BC955E3AFB9B00ABC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E2899520731EB54D0569041125CD0D3E27CE",
                        "defaultText": "그보다 훨씬 전이야, 크리스토프.\n이 저주가 유전되는 거라면?"
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "BA9D3CDC1E1D88434D2A3C94414031BD0195",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "774FF01C2485634A8D5B04E9278951D51AAC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E68183D4713D8146AA4A59493A6CF726A3BD",
                        "defaultText": "그러면 미드바르에서 발견한 “누군가의 혈통이\n저주받았다”는 정보도 말이 되기 시작해..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D31949BB0184C2424A5A21883BE096E44DE1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2DE5797D22BCF046473B62718CC156895C2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "271F0183750D274E3A9A812509CD715AB6CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1AB459822D734140B67889A7F65022A31677",
                        "defaultText": "하지만 그렇다면 그 수수께끼의 연구원의 정체는..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D2205E707AE67649042B76399BAFAD4474FD",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "B1CF6CBE2A3774418C7A9476E0C6B25F9193"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "C57F9BDD6CDF5440E138DAB213BAF0F91AA3",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6519FE9810687453F78C32935D061C5615F",
                        "defaultText": "그래, 가능성이 작아 보여도... 아직 풀어야 할 수수께끼야.\n나도 언젠가 헬리오스에게 저주받은 건 분명하니까."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "376093151A233549665AD99348E5B25E4DDA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8784F71622D35545137830C2D044F0836CAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52A53A015C1002420D58E2B4A1AB51C48C8E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "43F87B042C9173492A8951392AC405650E6C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05BAB24B2F84A74F758A3115DBEFA02C0DCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED7BAB5F30DFE44F3319B7938481464A6E91"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67B020E2660008450988F402D6CC37BE09DE",
                        "defaultText": "이 시점에서는 모든 가능성을 고려할 가치가 있어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BDBC61A68DFE2541325B064381AC79D6C1A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1665715B0DA27847288AC63431859DF0FAE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D185EBA72D0B6044AE087BA0FD0AFECE23DB",
                        "defaultText": "하지만 비보레라의 본부에서 피비 여제와\n모든 일을 논의하는 편이 좋겠어."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A232F1505D764047832A0757A503F75C59FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7F0726C5C03064B1B7B2003644E96DB5C9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BCD715065C08848BD99D302F1C328788D6A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E28547185D8DD5403A198CE1222EEA006361",
                        "defaultText": "알겠습니다. 여러분도 많은 일을 겪으셨군요."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7663E66A9D01E442695B59D896B9D0822DB8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B09CA428464404462E7ACB41C410534E4317"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "46C5A1E4866E044DA0186265144787A30524"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "66CF5CC2570D5044FC3AEF177AC9AD62E263"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D68B337E40AA3449C02B39B6262753C22BCE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Finn",
                        "name": "E3-Finn_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D57B5A419CC214237388E0356F78DCA1886",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "02C442091065434DF44844E628DFEC852ADD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE0D0FFE7BF758432F4AFFE3D3A6A11D6259"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA885D0A0CEE514E548A17B8E7AE8281BC3B",
                        "defaultText": "계속 여러분과 동행할 수 있다면 영광이겠습니다.\n로이스가 분명 그랬듯 여러분을 섬기겠습니다..."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E641173862149342958B04A177F544E23942",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D702C92D219E0346C08AD511051B2BDBD94E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E16DB8D5956C040187B7E8907CEDED43CB9",
                        "defaultText": "로이스는 파일럼 모두의 귀감이었습니다.\n저도 형의 명성을 이어 가고 싶었습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A7F450648DA78744B00A62E4728715A7B6BD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEBCF0AF7DAB284B6F89C961A68EB13E33B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85EE47B06ACAA24C450892D6C311E1265524"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F71552833205B64C391AE0B2884D56CB6CDF",
                        "defaultText": "정체성 혼란은 겪을 만큼 겪어 본 사람으로서 말할게...\n우리는 지금 여기 있는 그대로의 널 받아들여."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4220DC0127492847214ACAB491F6D4419F3D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F929EF86F62044A3A88A3E948A7F9347DE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A68630AD5B6C8744607B83D59751243758A3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99C6E02D8B79B047E65A6125DDF841D0613E",
                        "defaultText": "하, 좋습니다. 성검 핀 발리노르가 여러분을 섬기겠습니다."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14A97FDC915E514B8148E6880E3A43D3DD1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B7D0EAB5FCA6446171956D80156F1256FB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3AA48622C781441B64919A42EFC1095B6C2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "1510E78C89B6D544D21855C5D53CB2D32C37"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D948F45386A295415A7840C8590B27CE4042"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "FBBCE16C6BC6B848837984897F8379BF78BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A9730BC6F13A749A0693825C7154C5EF893"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0766CD8D5BBC514A9A3AF5C10520166B4331"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21EC41244FF1764145493527906876FFE196"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76E0803870E0924ED44BA11660716BB96E10",
                        "defaultText": "그럼 여기 일은 끝난 거야?\n매 순간 헬리오스는 더 위험해지고 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C40C66C8916C6141F7680C615A3F32855751",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4C58FEC89DDD447073AD3F8925D7D6CA064"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "477340F689DE2244016BB70940AA6AD6A79E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F15345C2942E1475E0947A7F168BA8E356B",
                        "defaultText": "흐음... 누군가를 잊은 것 같지 않아?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51A52E4C711D77451448D179539E7D952D34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6245ABB93FB0649BE6BDE21303B40F3CA25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0950342700CE144306BD2F6F9ECCBC02BB9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3399AA34695B01496F79011200B3284F8748",
                        "defaultText": "하. 그 쓸모없는 도적 말이군. 어디 갔지?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "914BDD023F1F8241287BC9A2843499357FD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A27D55E326B52470F3A74D82AC2AE67361A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9C06B7F36A9C343E44BFD725944D58235CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "C36139F346BCE24F144824D6D9CE7B1414F9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABF0E21962B02149A04A2E666CE8757C3472"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "32CD64F63162D240777BB1C4D4BCB467F911",
                        "defaultText": "렙토 레트뤼프를 찾는 거라면\n타키투스의 인형을 들고 선술집에 갔어."
                    },
                    "position": 0,
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "64C9C7EF19BC774116893FE2C7906CB875B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D8B3F39497CE44C11897098BF83AC92E7C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "150B73662AE845471C1B5532DFE0A072BFAC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8EEAFAE0340D7435D3AC3D6496565BA010A",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0231E5A718754349A7392E050669F407DF34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDCCEBA00A48134A0F4B79290FD4712DBB63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C2FDA0D9A8F674AF53973A36CB3C54F89A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6DEF6E8D9E78964A3A188DC4A6B3C0413E69",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "974CC01E512A284D2A4A3B250C6519D68243",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "803E3EB78632C3427B1AFBE287BB7A3FE27D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97BF866C8C983442B488E151847F1FB53F44",
                        "defaultText": "더 문제를 일으키기 전에 찾아가는 게 좋겠어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FB4672972F0C44424B9A815393683DC0B53D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26073AF895A07247189948F1D50ADFB5ACFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6D2600B1E26A74520089526626FC6F5BEAC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5412CB2F9828D1441F597E97179B700B273C",
                        "defaultText": "으, 응. 동의해."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0F1BD036893A24E947B2997344EFCCADBA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "238AF59B2F3F5849B7894BE3EE26B8C9984D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "D52DC6748F06A141765A93B65EB619EADCCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3A3207224E808420868B9C7775F059727D5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "1DE520282AB7B749461B13F900D69A5BB85D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "92C8A7271BDE7246CD7A3E44885A847CCB4B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C83A5BDA7F89C1453F7AF429C0F24E89936A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            5,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F37880091FE7F64B8828C21168276D685799"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "CC8C29E7129BC444A15B17552FBE6E5ECA28"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "ABC349FD2E31534EAF083B952AD35DFA4A52"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D9DC60387F906448A78A8242F08B1E6F15A3"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "C4C058636574254175698961DA8465026CDD",
                        "name": "C11A-9b Purified Tavern (Exploration)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FCD1B52032A573483B2998B6F4B7DEEE58E3",
                "expanded": false
            }
        ],
        "localizableStrings": {
            "B6DD101358FA924A156A2F838F9076CD95B1": {
                "t": "Damiana...",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "85DD3E127EE6C342125A82A35BEBB439B732"
                }
            },
            "A1A79AAB6D420845EB0B7FF9C159734769AA": {
                "t": "My daughter... She...",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "EA6A303B4EBF20460D3AA2226B0207970575"
                }
            },
            "63822B5141F273487E28F7857C901EE9E426": {
                "t": "She's no longer with us. She was cut down by a sudden illness.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "257B419995C2E845953B7A415110BAA3BF3C"
                }
            },
            "D1DB437C677AF9487999C7410ACE4A623C67": {
                "t": "That diary I found earlier with Cristoph must have been hers...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D2C4094E5DA2E746298B1203EBAEED120FEC"
                }
            },
            "1B4C12482AE037467E58C817CD59DCE35A42": {
                "t": "No... She was indeed ill, but... The Church took her away from me.",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "6E3D1E694EFAB74E76195A36404299EC3F08"
                }
            },
            "F2EDB3F550B49749D24A3F71DD4A4E1AA861": {
                "t": "You didn't think they were simply trying to treat her? I'm guessing you weren't very... cooperative.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "098202FB61B508432B2B3A26C648386A62FC"
                }
            },
            "9C03108211FA464B2B1BFA7237CD0DAEB2A6": {
                "t": "Nngh...! Lies...!",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "6EEFD109289BC84B5B2AA246AEBF5934A1B9"
                }
            },
            "BBA05BD08405F84A938A9CB234D7D487BC4A": {
                "t": "When I later became ill myself, it was He who saved me...",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "3956E10E7CC7F14415880D089D06FCD43D6C"
                }
            },
            "26DD1B3337265440E28AF0630FE2E61BF617": {
                "t": "He gave me the power to change the world... The power to...",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "048B6ECD4B96214FAB2B77E18D5C39F17A4F"
                }
            },
            "7F34632781B21448F62AF411ACC6A99C6784": {
                "t": "... to see my daughter again...",
                "d": {
                    "cid": "A37F103C0D4923451A190E2899A5B3983DF0",
                    "eid": "0F0FA93197B0444C7329E330836E83CA97BC"
                }
            },
            "A57E1F424A499049A63B1EA191F8E8D664E0": {
                "t": "He's... gone? We still had so many questions!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "DA824FED6522734D1D18A97600B92B2EE276"
                }
            },
            "EA49817F191DB84A6F8AF00875B553362869": {
                "t": "I think his power was sealed away by the Manacrest, like the Matriarch predicted.",
                "d": {
                    "cid": 0,
                    "eid": "7E80E7F74DD30149583B29E44079B14C64FC"
                }
            },
            "DEE686602EADD545B93BC412E85A4E4F454A": {
                "t": "Just like Kabeer, this Archdemon seemed to be... made of Mana.",
                "d": {
                    "cid": 0,
                    "eid": "2C3FBEE247C1D3417A3B97272452364066E2"
                }
            },
            "2E59A3AA76321442EC3810F283C45409C6B3": {
                "t": "It's weird... it's as if his entire body was made of Mana...",
                "d": {
                    "cid": 0,
                    "eid": "B05EB65F10A663465318252579F84B413201"
                }
            },
            "68638C5424BF774E9C39C5C691A6F0248B42": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2B3E6A975B276743693B7AF4D605C0C7CA8C"
                }
            },
            "6A47F6CB9ECE4946326A9BE8A38DA427646D": {
                "t": "Well, he did say that he was the Mana Scourge itself.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "3DBACCFC6D2EC44AB489CD12D6A614ABFF98"
                }
            },
            "AD9150233253744A925BEE41F8EE4EF37EDB": {
                "t": "The Mana Scourge... has been stopped?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "299479EF5394D64A3568CE65109C86866DEA"
                }
            },
            "5CB4B1DE3897624DD97A2CD2B9D659947E23": {
                "t": "Does this mean that no more animals nor people will be corrupted from now on?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A78E8DB7500B47400B183F6447BDE1BDBC46"
                }
            },
            "9D57C18D56418646A64B1E31E0B3ACAE6843": {
                "t": "Yes... At least for now, I assume. And the Scourge's lingering effects will remain for decades anyway.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "227D244C6A8D4547EC38EC810FA724023559"
                }
            },
            "F7917C3A60AEB049F77AE571795A68CF3119": {
                "t": "In the midst of all this tragedy, at least this seems like good news. But one doubt remains...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6F6C1D0052519240A06930506929FB8435F4"
                }
            },
            "123F43E022CD87434D4885E8A18918616048": {
                "t": "Who or what was Tacitus?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A0C66AAB1097044A46091F16FE05E3003F32"
                }
            },
            "BD179EEB0D25374B707926A5DDD23252C3BB": {
                "t": "Putting my thoughts in order... I can formulate a few theories.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DAC5977E7B126843EB38F9D1B612219CADE9"
                }
            },
            "844EA6B58B7C884E9518E625A04740BBFC72": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D819B46D555EE74BE61A6C619FD8D5622A54"
                }
            },
            "212B54F7501F4149FD38D6319B8C15E4777B": {
                "t": "According to the diary we found, he seemed to be the father of a terminally ill child.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "B2C608939C87164BD27BE1C15D5E8302C3CD"
                }
            },
            "560E5A0F4574244603683FA1376DC80EC10A": {
                "t": "After the death of his daughter, he indulged in a desire for revenge. And Hellios took advantage of it.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CEA28BBF53B324453F89E593466FEB9F67A5"
                }
            },
            "9D8AAF0A4F060345BA4A6A3037033D677F27": {
                "t": "Something doesn't add up.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "C62C21029FEF374EFE9B35D445454C3AAA9D"
                }
            },
            "CEDBABBE6DB07145B20800130E8CED8F66C8": {
                "t": "Hellios awakened a few weeks ago. Yet this Tacitus story seems pretty old.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "39B121788633644CED5AF7958B621813B803"
                }
            },
            "261411546D88A44A937BE72674B89517FAE1": {
                "t": "Indeed... WHEN was Tacitus transformed into an Archdemon, then?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6EEF09403C6E444DBD1BB2D42240B2749DA4"
                }
            },
            "FC079CE9004F044AEC792D725AEC573D13AB": {
                "t": "Allow me to answer that question.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "B0802DAE2F88F8411F2A37A895A0B7EB6A64"
                }
            },
            "1DDCA1B3009A6247BE6BB241CD1052457407": {
                "t": "Royce. Thanks for your help earlier. Have you finished patching up your wounds?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "424DD2C1136F03407C9A6B004D8EBEEFDA2D"
                }
            },
            "CFE26D2E33F165497B582A55BDB48D89E909": {
                "t": "Yes, thanks to you. I was able to complete the task assigned to me by the Matriarch... and a more personal one.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "814AEE99939B194D058B406898C6CBB070A6"
                }
            },
            "D30EAA4C3006954B387AE9E3E203E306564A": {
                "t": "You have a few too many secrets for my taste, Holy Knight. Speak now, before I get impatient.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "061BCAF8259365402969020468D9E1F91C00"
                }
            },
            "971F350816C33147E4596368A7C7FAD2675E": {
                "t": "... First of all you have to excuse me, I lied to you.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "8553F76D69F0F842EA1839C761862351EBFD"
                }
            },
            "02C8EF0C85AA17455438257004992EEFC75A": {
                "t": "Finn",
                "d": {
                    "eid": "7705270E04C89548CF7935F0C2685F7D3708"
                }
            },
            "E77B21BE7931454686280A32A2F8163D67F5": {
                "t": "I'm not Royce, but his twin brother... Finn Valinor.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "1073B5ED1E74D543BB9BF361B16965E4EAE0"
                }
            },
            "D6F26C2F272E614B220A2C05973CDEF01571": {
                "t": "His brother?",
                "d": {
                    "eid": "AB82C1FE24272848381833224FE72E255448"
                }
            },
            "8A12DA18567A3048347B8BC7A970E0E2B634": {
                "t": "I kind of saw that coming...",
                "d": {
                    "eid": "95B97537811326417519C286934CBD9BE3E7"
                }
            },
            "0BE868BA06FFB64FC88A0AF485C22A294D9F": {
                "t": "Heh, as expected from the Matriarch's favorite priestess.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "D00E38106BCC944A6F699D75B2B398398210"
                }
            },
            "4A963497010E3846CC083E21BB7AE72019C5": {
                "t": "You must've had your reasons to hide your true identity. Regardless of that, you still helped us and that's all that matters.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "FA2AFDCE6C3823422E398F05F18CAE26C0F5"
                }
            },
            "44738D6866755345692808645A61B72B07D3": {
                "t": "I appreciate your forgiveness, Lady Faratras. But see, my brother's story is strictly tied to Tacitus' case.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "F5A9715E5AAD494BD05B85528832C60E7581"
                }
            },
            "DA65390074D493433549AFC36A78FFF795B2": {
                "t": "And let me guess, he wasn't just another doll in his collection.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "08EFB569637DC1437C9A0385B505FBBA4304"
                }
            },
            "71A0747B25CD90402E797D63CF7E86899193": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4D135659713E9443B68A51F5EF5DCDFB180D"
                }
            },
            "08CC7F57572FE0464A48A8D4DCB812B810FB": {
                "t": "Many years ago... Royce was part of the team that allegedly took Tacitus' daughter from him.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "91B1B07E5E52D84F4B3AD192B7E34CF37B0E"
                }
            },
            "9477A72F8360374DF27AF4E6D2CA3B56BF25": {
                "t": "We hoped that Her Holiness could cure the little girl's illness. But she died soon after.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "BC6C3CF05BA6D14FF91B1E45DA719EBEC9C7"
                }
            },
            "EE620148274C244E20896FF7D2A38AD77046": {
                "t": "A few weeks ago, Archdemon Tacitus showed up at my brother's and...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "8A40F7CA19CBE043AE7BD4C1197A005221D4"
                }
            },
            "DF0166F58081F14CF97831479E6D8CE9E052": {
                "t": "Say no more. I'm sorry for your loss.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "B4DFCB5B57B5F2477868CAB142A5EE05F22A"
                }
            },
            "F8F0DEC65F91304C50288DA6BC9295AE0F88": {
                "t": "... He didn't die. But he was left severely wounded and unable to lift a sword for the rest of his life.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "E88322B4494BA542184A77B16E1F32B7AE9E"
                }
            },
            "4F275B1382462347335A07D18ED012B35B6A": {
                "t": "And this happened a few weeks ago... just when the Demon King awakened.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "A67164867C48B74F044893C7CFA68878B4E6"
                }
            },
            "2D1210554A20184AFD19CEC40C869330EC32": {
                "t": "The villagers said that Tacitus was suffering from severe migraines before disappearing. To think he became that monster...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "EA80F9F1337898460B39FFF60B35BC480560"
                }
            },
            "F16304080088F641464A9B20DC3A0B847D79": {
                "t": "Severe... {SP:1}{C:1}migraines{C:0}?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "8EAB45AF6681974FDF8AAF32FAE5B67E7661"
                }
            },
            "83ADEB6F8FF06448570852C2FD3A4ECD47CA": {
                "t": "Just like you, Nini...",
                "d": {
                    "eid": "354D9AFF89E6234CD7589A73F3AC7F71ECC4"
                }
            },
            "C91E4FFD1FB3964930888086E8E93D839147": {
                "t": "Like the ones we had earlier, right?",
                "d": {
                    "eid": "77F7D88E9CE7134B6D8826B84C0211C03367"
                }
            },
            "C9A6DB8B6ABFD447333B10F39100F95CB34F": {
                "t": "Could it be that... I lost my memories because I was cursed by Hellios and I was about to turn into a monster?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "FA2ED4EB12601641952844A28E1C6CA2CBBF"
                }
            },
            "40347E0E40EE8843CC881DC0F1824620976D": {
                "t": "Even Tacitus didn't seem to remember much about his life as a human...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "5F7EAB431583E841DF8A166274ECFCEB65CD"
                }
            },
            "4CB95E4D35AE9744FC3B590937EBA5E35AC5": {
                "t": "But Nini, I was with you at the exact moment you lost your memory. You weren't cursed by anyone.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "BE5DCCD05CF4F747E928B2F9F9DC0B31F0B0"
                }
            },
            "CDFE103521F4E245FA2B1824C8F72202EB1C": {
                "t": "What if it happened earlier and the symptoms only started to appear then?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "0A5951791423994B8D58BF245AD10477F4DE"
                }
            },
            "5F43FCAC7DA8C6400F8A03431E93B8E6D7C0": {
                "t": "Whoa buddy, \"earlier\"? The Demon King hasn't been around for twenty-one years!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "F395FB2C180479446B39D116C1A92F898A55"
                }
            },
            "E2899520731EB54D0569041125CD0D3E27CE": {
                "t": "Long before that, Cristoph. What if this curse is hereditary?",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "BA9D3CDC1E1D88434D2A3C94414031BD0195"
                }
            },
            "E68183D4713D8146AA4A59493A6CF726A3BD": {
                "t": "The information we found in Midbar would start to make sense... about someone's \"bloodline being cursed\".",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "D31949BB0184C2424A5A21883BE096E44DE1"
                }
            },
            "1AB459822D734140B67889A7F65022A31677": {
                "t": "But that would also mean that the identity of that mysterious researcher is...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D2205E707AE67649042B76399BAFAD4474FD"
                }
            },
            "F6519FE9810687453F78C32935D061C5615F": {
                "t": "Yes, as unlikely as it sounds... It's still a mystery to be solved, as I was undoubtedly cursed by Hellios at some point.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "376093151A233549665AD99348E5B25E4DDA"
                }
            },
            "67B020E2660008450988F402D6CC37BE09DE": {
                "t": "Every option is worth considering, at this point.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "BDBC61A68DFE2541325B064381AC79D6C1A2"
                }
            },
            "D185EBA72D0B6044AE087BA0FD0AFECE23DB": {
                "t": "But it's better to discuss everything with Empress Phoebe at our headquarters in Viborera.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "A232F1505D764047832A0757A503F75C59FB"
                }
            },
            "E28547185D8DD5403A198CE1222EEA006361": {
                "t": "I see. It seems that you all have been through a lot too.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "7663E66A9D01E442695B59D896B9D0822DB8"
                }
            },
            "D68B337E40AA3449C02B39B6262753C22BCE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4D57B5A419CC214237388E0356F78DCA1886"
                }
            },
            "FA885D0A0CEE514E548A17B8E7AE8281BC3B": {
                "t": "It would be my pleasure to continue accompanying you. I will serve you as Royce undoubtedly would have done...",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "E641173862149342958B04A177F544E23942"
                }
            },
            "3E16DB8D5956C040187B7E8907CEDED43CB9": {
                "t": "Royce used to be a role model for everyone in Pylum. I wanted to keep his memory alive.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "A7F450648DA78744B00A62E4728715A7B6BD"
                }
            },
            "F71552833205B64C391AE0B2884D56CB6CDF": {
                "t": "Believe me, from someone who has had enough of an identity crisis... We're fine with the person you are here and now.",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "4220DC0127492847214ACAB491F6D4419F3D"
                }
            },
            "99C6E02D8B79B047E65A6125DDF841D0613E": {
                "t": "Heh, fine then. May the Holy Sword Finn Valinor serve you well.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "14A97FDC915E514B8148E6880E3A43D3DD1A"
                }
            },
            "76E0803870E0924ED44BA11660716BB96E10": {
                "t": "Are we done here, then? With each passing second, Hellios becomes more dangerous.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "C40C66C8916C6141F7680C615A3F32855751"
                }
            },
            "4F15345C2942E1475E0947A7F168BA8E356B": {
                "t": "Hmmm... Aren't we forgetting about someone?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "51A52E4C711D77451448D179539E7D952D34"
                }
            },
            "3399AA34695B01496F79011200B3284F8748": {
                "t": "Hah. That good-for-nothing thief. Where's he?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "914BDD023F1F8241287BC9A2843499357FD0"
                }
            },
            "32CD64F63162D240777BB1C4D4BCB467F911": {
                "t": "If you're searching for Lepto Letruffe, he took Tacitus' doll and he went to the tavern.",
                "d": {
                    "cid": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "eid": "64C9C7EF19BC774116893FE2C7906CB875B0"
                }
            },
            "E8EEAFAE0340D7435D3AC3D6496565BA010A": {
                "t": "... ... ...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0231E5A718754349A7392E050669F407DF34"
                }
            },
            "6DEF6E8D9E78964A3A188DC4A6B3C0413E69": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "974CC01E512A284D2A4A3B250C6519D68243"
                }
            },
            "97BF866C8C983442B488E151847F1FB53F44": {
                "t": "We better find him before he makes more trouble.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "FB4672972F0C44424B9A815393683DC0B53D"
                }
            },
            "5412CB2F9828D1441F597E97179B700B273C": {
                "t": "Y-Yeah, agreed.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A0F1BD036893A24E947B2997344EFCCADBA4"
                }
            }
        },
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}