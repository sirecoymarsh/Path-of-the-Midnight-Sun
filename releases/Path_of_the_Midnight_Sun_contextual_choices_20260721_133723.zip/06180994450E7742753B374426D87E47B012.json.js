GS.dataCache['06180994450E7742753B374426D87E47B012'] = {
    "uid": "06180994450E7742753B374426D87E47B012",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C1-03e2 Chat with Shiori (continue)",
        "type": "vn.scene",
        "parentId": "F7F581B17D00D5435868B5C374116B4EBEE3",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 8,
        "localizableStrings": {
            "30B63AD326F7A2408D2AC314B0C89748B20E": {
                "t": "Here's your order.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "05E84074510C44433D4A02D4D2B9CF34DFE3"
                }
            },
            "7F4C63BA6FC7C64BF429857364A27E1E2269": {
                "t": "I don't even have to tell you this, but if you let it cool down it tastes like dirt.{W:200} Just eat already.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "90DC004A72028141C0581901A0AA43177ECB"
                }
            },
            "A7CE90C23333094F472A1FE2B3B584672830": {
                "t": "Drink it as soon as possible. {W:200}If you leave it there, I'll consider myself offended.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "CFF166CE04E67245BB1BF443666A61EA42E1"
                }
            },
            "D876CC64298C8147CC58AB73FA0DBA22EF9C": {
                "t": "Huh...{W:100} Thanks...?",
                "d": {
                    "cid": 0,
                    "eid": "46B9F04F4D26274748587422D56412BB39A5"
                }
            },
            "207D57BC6BCCE245C75AF6D663EC9E83A5E4": {
                "t": "She touched Shiori's hand to give her a sign.{W:200}\nThat was unexpectedly considerate of her.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "912774635326634A044BB097AF9A3F232D01"
                }
            },
            "287FA68F0FF4994F753A61F3B509B292DA25": {
                "t": "Well Nini... {W:200}Bon appétit!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EA4D37DC88CCE245D79906469C6367499B07"
                }
            },
            "E00CE97148DB4543B68B2D12EB1E5BA55E05": {
                "t": "Likewise.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4EEFF16B1EFCE5466049CC4177052ECDA0F2"
                }
            },
            "1654CBEA17DBD7469E7A99D8B5803EF72B81": {
                "t": "It'd be embarrassing if I didn't remember how to eat my food...{W:150} I do remember, right?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "537437CF0848A8486D58D5B52244A6929D7A"
                }
            },
            "9C7F060B69A2E541375AE588702BAD71F8CA": {
                "t": "It had something to do with the {SP:2}{C:1}Inventory{C:0}, if I'm not mistaken...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "3304AB091D026742ED188B796C60E93C76F9"
                }
            },
            "F7CCF2D0217F6342923AC0F606B4AFD60C71": {
                "t": "You really enjoyed it, didn't you?{W:150} Teh heh.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CAA3745A8CEC954DDC4AA1181A5378A46DB3"
                }
            },
            "AEBC0A636EA79642F96B0DA7B7E2A53AFC49": {
                "t": "It was good!",
                "d": {
                    "eid": "66A432B57709594814391DF6C669FE5FA182"
                }
            },
            "058207CE857AF6457C7927D5905B915AE66F": {
                "t": "Actually, no, but that's fine.",
                "d": {
                    "eid": "CB83CFAA544A7444881BB4F8499F1C2E2D19"
                }
            },
            "E90C027218E2D5426F1911D195D5471D1E19": {
                "t": "I'm glad.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8C3D0CDD7BB41140C6094427585104127A95"
                }
            },
            "63BFD5A20C8F2944754B9A22BEAB40946BFE": {
                "t": "Oh really?{W:150} What a shame.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "13890B9B6402424DFF394601082E38F3474D"
                }
            },
            "0D524978409CD540891A2A600CA034777DB3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "299D6297807E764A5B087A314C0F50B8D37C"
                }
            },
            "2679858D3AD50448C71824E2200B72C7F175": {
                "t": "As for me...{W:100} I really wasn't able to drink this.{W:200} I asked you for seafood and you ordered beer?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5FA87B145E8EF247852AD3174767B6A6FEB9"
                }
            },
            "FD9A39F38F8DD14DCF8BD3065502A24B8C1C": {
                "t": "You must have thought, \"Let's get Shiori drunk!{W:80} It sounds fun!\".{W:200} Well, know that I did NOT appreciate it.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "32712CAB8A1D044FE69A4CB2D9FF5F14BA36"
                }
            },
            "4021EFCE79C906423A7B2098444D6E49FAC0": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EDB0D8071B5A054460297D85262C7B4E8D71"
                }
            },
            "7327C1D3747C9643179A1B06ACD4F22061BA": {
                "t": "As for the dish you chose for me...{W:200} It wasn't what I was expecting, but the steak was quite good.{W:100} Thanks.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CBCCABCB608F474C588A96A88E87C9328ABB"
                }
            },
            "6933E5575F3FC545E43BC298EB0D1CD9EB67": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1FEABF301A9010484E7903726DB6DD4B6916"
                }
            },
            "A232AFDB8785054A11586D525C29E5FF67CA": {
                "t": "By the way, I loved the soup!{W:200} The little pieces of crab were truly delicious.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C21E94F44B39674CD8886B27810FF6CDB82C"
                }
            },
            "615B9A367A12C2442719A648EF7C5BE11CF6": {
                "t": "Thank you so much for choosing this for me, Nini!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2A122EF63484514B925A7094E5F761BD7AD5"
                }
            },
            "063E356F1BF0F1406A184CB250C7D81B1D41": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9776394F747E094EF86AEA319E20B9AFF804"
                }
            },
            "DB736B5817DF3848CC785560C9B640E990DA": {
                "t": "By the way, I wanted to eat, but you just ordered...{W:200} water?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7DD70F23321C53461B993941A951536546E3"
                }
            },
            "9AE0784816CEA746648A7FB6569FA2E3E02A": {
                "t": "Not that I mind, I just find it a...{W:200} peculiar choice, shall we say.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "6E093D9860B1F44F30083631276989F93E9D"
                }
            },
            "B94DBC3B9D04D64CBE8B45B7971F76A18A1A": {
                "t": "I'm glad you enjoyed it.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "D67B776F75AF574AFE290C974A192989BE73"
                }
            },
            "28C30AA521E7554B5C8A6648A78A7773B06D": {
                "t": "Hmh hmh!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5D29C56E960AB2460C3AB327F63752435A92"
                }
            },
            "3A7E0ECD9BAFA243D72BB7428147CC6F9976": {
                "t": "I...{W:150} huh, I'm sorry.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "DFCC8A1D5B4DD946ED28DBF41C56C778C9D8"
                }
            },
            "4E0CA9216578424260889CB54EA5249D6157": {
                "t": "... ... ...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3DFECEB094901540470BD254A0097988FF72"
                }
            },
            "E35975A09EF7F84DF78B6EC1E66CE22B376A": {
                "t": "... ... ...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "83E6890A0C58164A768A7301112F6CDF65EF"
                }
            },
            "5F78D1A85863B44A4D1A9602ABF138E81FA0": {
                "t": "You're forgiven.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0B2EB8EF6129B1461D1B6E697AA9CA3CD8D1"
                }
            },
            "CE4470DA98752144E318227222F8C72394F8": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "EBB214F71F8A174A3749B5646E8D0A31903F"
                }
            },
            "3F13B2515208F642D49B54B2135FEB70A4FE": {
                "t": "Alright, alright... {W:200}I'll give you some of mine, as I promised.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "2D49E8FC7437514CD648D5A7702C4F90D4DD"
                }
            },
            "D9D19FB94C9F82496B692F47C6DB4AF78D15": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "083854C21CA487495A2939967E11238D7FDA"
                }
            },
            "31F5A44793EF164EFF8B6C4271E3550F26B6": {
                "t": "Woooooot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "A0A26EE62ED7514BE22A6118B9D78B5DA1F0"
                }
            },
            "CD42C4227142F640426B02D120F83B9F7B27": {
                "t": "What a huge appetite, for such a tiny animal...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F9B73DE56C5A71492B98C0081EE88FA4C784"
                }
            },
            "E8764CB528E5F34E571986A320AE26A202EA": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "47DBBC64584FF844A15B75551E7E051CADDD"
                }
            },
            "31A3D18353CC184D2028E50117E4C3153B25": {
                "t": "I suddenly feel...{W:150} so tired.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "70B61BDD1F5C614B38197372442EBA2FD9CB"
                }
            },
            "B7F35ED654388741EB1B6EC30126E0ED163D": {
                "t": "Feeling sleepy, now?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2BBAAB807E9EC4400D58ECA624AA83534A66"
                }
            },
            "9DD19AD07E9F88442C39B074271143F6F01C": {
                "t": "I'm sorry to quit so soon.",
                "d": {
                    "eid": "601E03C55576D340F4791EE1A359FAC3D150"
                }
            },
            "29A2DB2E413F11449C3899276E9604416588": {
                "t": "Yes.",
                "d": {
                    "eid": "AE5E8AD23D016743B309D5048C6F8DE0A79A"
                }
            },
            "96AB29251C2D774E04381FC47F017DA66B3B": {
                "t": "It's understandable.{W:100} After all that happened today, it's normal you're feeling like that.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "54659D7C1D6E25417C381B9793E0B4571646"
                }
            },
            "0B8A891E5306434DE86B1FF3992E0DB6BEC0": {
                "t": "Let's go take our rooms then.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E4B145C3489CB045F46A79A31E2412DDC159"
                }
            },
            "3314DBB99492464BDE4A4DF678F58B2523EE": {
                "t": "Finished already?",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "942365831F8F0144F689D953A3FB474B4AAE"
                }
            },
            "3E9C79E831CA4249343BF48580E3286BC843": {
                "t": "We'd like to sleep here tonight.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F98D9CF87868C7429A88417743E0F51C5E00"
                }
            },
            "662C95886A8A26476928929616253CFD4DD2": {
                "t": "Yeah, sure.{W:200} Are you booking a double room or two singles?",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "84A3B6A496A65240FF3BE6B8A9A40D9979DD"
                }
            },
            "1F06C57F7A5B464CC33A4CD72A0EF092DAB5": {
                "t": "Double room.",
                "d": {
                    "eid": "0CBE63CF23A01243461ABF219DDC9D031A54"
                }
            },
            "D5C5B16B795F254D8A7BE582B69EF48B92EE": {
                "t": "Two single rooms.",
                "d": {
                    "eid": "11ABB207272BE248B529E8873DDDF9EE3714"
                }
            },
            "E717452241383948B958094223DBA2B77BB3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4AD4185080470840A74825615AD67383B1C8"
                }
            },
            "6C703AE6150FF647A268E35460C3E70AF712": {
                "t": "B-But Nini, we don't have that kind of relationship...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EB361AFE89D44845714A1E940F5FD71940C5"
                }
            },
            "6ECFE888509A29442F4B7B70293CFE534CEC": {
                "t": "Uh... {W:100}oh, right.{W:150} I, er, just remembered we don't.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C66EB1B45E64344DC01A8FD6FAE0A244E571"
                }
            },
            "738A3BBE2EEA3248942AC179A19C562547A3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B457EFDD5D4EF14DE68ACD356F8D13880862"
                }
            },
            "A80CBFA649B8F540C57B2D210E5A842CE9DD": {
                "t": "That was cute, though!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4B2BBD1148235645F8487A8627CA4ECE6D15"
                }
            },
            "2B09E96829CE45456C1B12E9095C3D8781AE": {
                "t": "If it weren't obviously a tactic to seduce her,{W:200} I could have sworn you lost your memory, haha!",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "A0AA3D10234D574D5649211212CF78C439A5"
                }
            },
            "2AF174747924F546E0486C25BBB73BC08C4A": {
                "t": "... {W:150}That's actually the case, though!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F3911BA7934931444F5A7A36CE5B51D72CBC"
                }
            },
            "24BF76B20E4FA749724B96C199BC265DFC5D": {
                "t": "How strange,{W:100} I could've sworn you were a couple...",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "9A242CD66B35864ED598E0A18F04D92BE83D"
                }
            },
            "9F86275791A3784FEA89FE800A9295DF02B2": {
                "t": "W-We don't have that kind of relationship, hehe...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "753E0579150EC44B8D5A3040D4E57082B850"
                }
            },
            "1D504FE11F91164D112B07944A2813A68D30": {
                "t": "Hmh, what a curious reaction...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9FFC8CDD90B4D84F3C69E178662EB7A756C9"
                }
            },
            "DC56CA317B31164EAF8BA0270CE380D2F90C": {
                "t": "You can pay tomorrow morning.{W:150} Here's the keys.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "F62AF9887217A44F3B8BE4B1764C2D980461"
                }
            },
            "44E771EA3B48A842DD09E5652718059FA447": {
                "t": "Make sure to return them. {W:150}It wouldn't be the first time I break some customer's bones.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "1D5DE8C422074245C02A87B499F036D2962B"
                }
            },
            "CAF44CBC7B08614D6A3A64767B25449E706D": {
                "t": "Something tells me she isn't joking.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6F7BBA6F2299C74387883175C04931DE9CD6"
                }
            },
            "934034644CCC4542866AB0564A57BFD4508E": {
                "t": "Woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "1FD5059C5D020544A918970146310F2C6F9F"
                }
            },
            "C9C4352B0EE7734F6418D4556FA992AA8B84": {
                "t": "Dogs are allowed, I don't care as long as you pay.",
                "d": {
                    "cid": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "eid": "5178A7A78123514594284701E571CA22D580"
                }
            },
            "8DAF51677CC3274BFF59F9C626F76001C6B8": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4F0981515E40E84A577B0718C09E059641CB"
                }
            },
            "1699F6775B32944475890136B9CA3882CDA3": {
                "t": "I'm going then, Nini.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7843E4360F858142A26A2195CD251A6A8A8A"
                }
            },
            "67C40DFE8CE1554E9A886DA8AC27CCBE40DB": {
                "t": "Tomorrow we will continue our mission and try to recover your memories.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "31A453CD245CE742225BA8F6807266CD4FE3"
                }
            },
            "FE1B6D6D81900045F81B7C11294E6A128B83": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9019E365564AF44C141BD4A3E02F48695A9F"
                }
            },
            "606FAD7C2165614113089CC2390B02BF0999": {
                "t": "Sure. {W:200}Goodnight, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "996029222CA2414ED65919E5E6DCEB4A447F"
                }
            },
            "9DFC7C1217FE684E56698FD352A835D7C764": {
                "t": "Goodnight!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F6FBCEF52448764F708AEFF6077203383103"
                }
            },
            "65D97C3428BBD14F3A799BB040A2F10D4060": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A265121378197744B36931D15149DB6F5B17"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E6DCFAED29A7C94915283534CAA811E17E14",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 4,
                "uid": "E7CA6D404410904C663A9EC89A324281F8F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "AF0193483CAB5143EF682B46ACA3BD0118D4",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "A4C0ED761582F5400A59323023B573CAE486"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "model": {
                        "name": "Shiori.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 707,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 450,
                        "y": 160,
                        "zoom": {
                            "x": 1.08,
                            "y": 1.08,
                            "d": 1.08
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 4,
                "uid": "E09E8D0F56A3174D0D6ADFB03EF453EE95D0",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            800,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B9C93DC228AF7404D29E82384DEB4138549"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            13,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97D9D6176FCE98443D69CF15C7E4B8DDBA05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96CA5BA9547E7148EF79D682BD0866B8B3D4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "31F7F3C103302448E869D343C907154ABEE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            15,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4808A72441FD83492079AE64F469F282A330"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "799D29A6228BD2478858B047AA0B11795C0B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "CF63BA9C30B73841C47B1697D7A0BC7B4ABA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D9DCC7C81827674CC4795672D1A67FADD1DD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "33F4AA0D116CD147DE2B5F8308E9F4FE544D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "FB6811572D9FC64EDF288851A64C97CB8A58"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "3FCC669E41DF474A2B1B62259FCE028854E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AC0CE004954FD846804BD0F48B3A02B61FBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D507F79B6F426441E0394BD27791772977CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4BA12E58CB1A64A91288BA17070C04B0301"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Dish Wood Table.ogg",
                        "volume": 100,
                        "playbackRate": "110"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "362806C57E17E148941BFC98F68E16AE8B11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEEC60254FEB814AB9486867D4FFCF5E8A21"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "30B63AD326F7A2408D2AC314B0C89748B20E",
                        "defaultText": "주문한 음식 나왔어."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "05E84074510C44433D4A02D4D2B9CF34DFE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF95B5547931C54D0D29D8417E37F776E141"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi",
                        "index": 300,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8830FB5214B0174A5A7A6C5864BBE3375A10"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "A61006745779B54F95583F031E23AAF3B85A",
                    "field": 0,
                    "targetVariable": {
                        "name": "Testo Multiuso per Eventi 2",
                        "index": 301,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AB4C81BA4D799647322A672534BB489484AD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Testo Multiuso per Eventi",
                        "index": 300,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "19B2F5741556F248E38B70E3DF8C19BED463"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ON = Eat, OFF = drink",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B5A0115B181AD2442D6A6943E045AB16DE3D"
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Testo Multiuso per Eventi 2",
                        "index": 301,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "52196F9A10B5E74CBB4ADF16B6B775A10BB6"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ON = Eat, OFF = drink",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C5C910BC82B1944B9B2A10C4A81750F5A924"
            },
            {
                "id": "gs.ListIndexOf",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "index",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "name": "Testo Multiuso per Eventi",
                        "index": 300,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3381B5F3406E334C2B2A94641FECEBF2C0B2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "index",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": -1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "994400D71108764AA078DC22AC319419A05B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ON = Eat, OFF = drink",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A67720B724A7B4491488FB55B7641FF905FF"
            },
            {
                "id": "gs.ListIndexOf",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "index",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "name": "Testo Multiuso per Eventi 2",
                        "index": 301,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A751A90F1D03F24AA02981F6B20389A04FE7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "index",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": -1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FA689C3C565FC6470A99AF37839BAC6F9E47"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ON = Eat, OFF = drink",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "102247A24587254B1D5B5FF5C845B91C7E04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "884879EC8AF1964A2E6B75D32B3909EB3393"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "ON = Eat, OFF = drink",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DFFF64236E6BE441E68B14A440BD9DAE0915"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F4C63BA6FC7C64BF429857364A27E1E2269",
                        "defaultText": "말할 필요도 없겠지만 식으면 흙 맛이 나.{W:200} 얼른 먹어."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "90DC004A72028141C0581901A0AA43177ECB",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "39C2CA97111CD746FE2A3AD72298F8FB0F9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A7CE90C23333094F472A1FE2B3B584672830",
                        "defaultText": "가능한 한 빨리 마셔. {W:200}그대로 두면 날 모욕한 것으로 알겠어."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CFF166CE04E67245BB1BF443666A61EA42E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0D3641D1E052241992BFEA813FB60BB87D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "017B4541402BD1476588BCE880012001CEF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D876CC64298C8147CC58AB73FA0DBA22EF9C",
                        "defaultText": "어...{W:100} 고마워요...?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "46B9F04F4D26274748587422D56412BB39A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "466B85706CDFA94E294B6355FD828BF5036E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB22ECD863D3A94A1E095762B6EC9A5B0C3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "747ADEA1431DE546B83985C489752A64A3D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "207D57BC6BCCE245C75AF6D663EC9E83A5E4",
                        "defaultText": "신호를 주려고 시오리의 손을 건드렸어.{W:200}\n뜻밖에도 세심한 면이 있네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "912774635326634A044BB097AF9A3F232D01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "386DBE6F3FDB17422A8A0C57E6D503F1557E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FA18AFB75B82544232A0055B248A1E745BB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "EF44C1E43D219543A718423949C1271312F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07"
                        ]
                    }
                },
                "indent": 0,
                "uid": "03CA7834815599476359CE620039E03B2EAA"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Indice 1",
                        "index": 71,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E40BE20E2C31D141CD782D22DBC2DD8372E1"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Indice 2",
                        "index": 72,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "765638907A76F0452338AF05C0D6678BB846"
            },
            {
                "id": "gs.LoopCommand",
                "params": {},
                "indent": 0,
                "uid": "A679B8B04A50734E4389ABE312FE1CA89FB3"
            },
            {
                "id": "gs.ListValueAt",
                "params": {
                    "valueType": 2,
                    "index": {
                        "name": "Indice 2",
                        "index": 72,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "91FC81D85EF519416939F445B7DE2A5D6722"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "item qty",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "DABBFDB50E7CB648CF7B34744383D904B220"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Hide Item Quantity?",
                        "index": 172,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "58E4884F60FC5543076B2F32BCD1BFE27F89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            {
                                "name": "ID item",
                                "index": 0,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "item qty",
                                "index": 1,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "D920D5937A5DF84C1D58A5399A0BFD2176E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3C5AFBD03D9E87465B89D4420622BBE6292A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A7DF594E1108E0450E398BF067AC10BE05AA"
            },
            {
                "id": "gs.EraseHotspot",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5200
                },
                "indent": 1,
                "uid": "95DFFF868ED7814E38797164A2D54A4D7D48"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9000,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "4EBBEDEC920DB241932B60D38484BE19B1C8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9001,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "3F0EBEB964BF964DBD481BD805A4EDFFCDEF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9002,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "BAC9D97F7E4339459149295756076FDE4AA1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9003,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "10DB3ECD8D9D6743232A1F8895BE03E52F1C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9004,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "F3AB580B1644B541BA8AC58291C7FF71E082"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9005,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "CB831A9127C3134A01882AE134F1E7FBF803"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9006,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "140575659191E346BE582213A05A94DF572E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9007,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "D4849B898F3FB641987939467E38EEC27BD7"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9008,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "4DB6ABEB8CA4F643F228DB74E1FF38E94991"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9009,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "1A22F70F96AF754E044B4864083193F711FC"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9001,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "165B3AA10A3C344EF079A597BCBCE4EF0BBE"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9002,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "F32EB0652770764A4749027719AADBAE6080"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9003,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "8150A7452BFB6246CF49F4C89285A7F3BF99"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9004,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "BC1B85B25F59444228894CE198D05A4A95D5"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9005,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "112DF09A42BF0447FD6975B2D48C229759E0"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9006,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "C39D5FFB0613554B691A5259FE60F6C2AC72"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9007,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "730E4DAA989F944EC71AB5055538BAC99422"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9008,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "1DE041201A593140F559E791F63ACC2E31A9"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9009,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "979E84F185BD3145A51BAB86C429179B6E07"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 30059,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "1425C92A6955834440092C040343F58323F9"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5200,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "278F85004ED2184A713A32B14E80A39FCE20"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5201,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "244648967C8EC14D410835B42256BA208E4A"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5200,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "0EBF3F62127E224A57184DA3CF37A731BFB3"
            },
            {
                "id": "gs.EraseText",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5201,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "810358E64FFFB7476B59D44169C31DAD1626"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0A5394441DFE9942C23BB1177D61A379F547",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            1,
                            1,
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "B8C3D63D24E9B34CE2196CF1E45489A50072"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E4831F3317563146355A608581506433848C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "AC40DE99590D46444578A6E7449948BBAE78"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Hide Item Quantity?",
                        "index": 172,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "18C2A1241F27754C8178FBF59402A0734153"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "^ è solo grafico"
                },
                "indent": 1,
                "uid": "349C538E90554745042A23D58D5B96B57A94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "16BEA919453249461948D4029C18A41D46B5",
                    "parameters": {
                        "values": [
                            {
                                "name": "ID item",
                                "index": 0,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "item qty",
                                "index": 1,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "176A501C8DD4064FC578B596281CA36A7B88"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Indice 2",
                        "index": 72,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "5176AC9E343F744F233ADB464BCB10954960"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Indice 1",
                        "index": 71,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": {
                        "name": "Indice 2",
                        "index": 72,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C63DB35B73EA13438C0B6B942A4CE9F72A34"
            },
            {
                "id": "gs.ListClear",
                "params": {
                    "listVariable": {
                        "name": "Lista per eventi speciali",
                        "index": 539,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "FE773B87505DF2456D28C3D4AC6C821336C0"
            },
            {
                "id": "gs.BreakLoopCommand",
                "params": {},
                "indent": 2,
                "uid": "6A8528442EAA5545A57A29678DF03A984548"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "1F14C1877C30A5437C4BD56191E51B2F8F14"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.02
                },
                "indent": 2,
                "uid": "325E386841B2734B093A64C4B9120323E09A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "270F4B6B2396C44F3F19CEB43ABA2E764192"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            12,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6FD776D7061B449DE18788119B04C20CB48"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "707993D9456003423948D623F1A65F15CD30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A00030345C2F1244D238F6F475014C25A175"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "287FA68F0FF4994F753A61F3B509B292DA25",
                        "defaultText": "그럼 니니... {W:200}맛있게 먹어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA4D37DC88CCE245D79906469C6367499B07",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "830B1C9344A9974B1F2916D8DB646C48E84D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1687BC7C94BD78452B499947A87BF2423829"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E00CE97148DB4543B68B2D12EB1E5BA55E05",
                        "defaultText": "너도."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4EEFF16B1EFCE5466049CC4177052ECDA0F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78EF3EDA89591141546BC1E554B03141D87C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D4D64F86178154F092A7895CD22DE5AEF44"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1654CBEA17DBD7469E7A99D8B5803EF72B81",
                        "defaultText": "음식 먹는 법까지 기억하지 못하면 곤란한데...{W:150} 기억하고 있겠지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "537437CF0848A8486D58D5B52244A6929D7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1CFBC27426F1547DA2B6A5412067828BAE0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "74D82CA3352C024A738823483B911855426E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C7F060B69A2E541375AE588702BAD71F8CA",
                        "defaultText": "내가 틀리지 않았다면 {SP:2}{C:1}인벤토리{C:0}와 관련 있었어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3304AB091D026742ED188B796C60E93C76F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5907561B2314294D8258BB863A9C25B3158C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A56902381937E6472339B641DC3629B97181"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8E0C72C411F727472B185C667E8DE7AF6C55"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FD5E08821AB2224CEA0975233463D3185FE0"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "@@@@@@@@@@@@"
                },
                "indent": 0,
                "uid": "09D53CFC007448427A88F1E1D7C10D096A3D",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 8
                    },
                    "targetVariable": {
                        "name": "Vecchia Sazietà",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "729A1E0243C39947434B84B60EFD7790FC85"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Vecchia Sazietà",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "385182273C1AE3484488F5B714E4FEE41DDF"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 9
                    },
                    "numberValue": {
                        "name": "Vecchia Sazietà",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "9603122325B34847EE1AAE27B7B8AA043003"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Shiori tavern event",
                        "index": 221,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2C1C61AF6EA9F4457A3BB3114F08254B05E0"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "99D92583808AA74FC1398406E30E92111C06"
            },
            {
                "id": "gs.LoopCommand",
                "params": {},
                "indent": 0,
                "uid": "327E7FBF4C6584463D896FF61F09E5748D46"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.02
                },
                "indent": 1,
                "uid": "767D00AF2D4EB343845994404A47455254E1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Rompi Loop Blocco?",
                        "index": 179,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "B03418840007E5483A397FC5A3D55C8CE7C1"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "8250514061A0E64420184C473962F83751BE"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 220,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "5D3335E7593050447F3A8DB27B6CFCC64A6D"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "ATTUALMENTE NON IN GIOCO",
                        "index": 81,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "7DB7552C345A944EC06A96F60A1812D7AA51"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "FORCE SIDE MENU OFF?",
                        "index": 146,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "01BCF476336B374DD32B31E7BFDC8226124E"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "388476D9768C764FFD28BBB9505C90287A99",
                        "name": "Aren't you eating?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "0141CC9A82367641832A33276648EA191C3E"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "FORCE SIDE MENU OFF?",
                        "index": 146,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "FA9C5D848142B9486E1B1A272792E9DC4788"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "35A7325C5F69D54649798619C19961D9FF60"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "B842A8CA14EB41403A1B12323228F9ED98EE"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Rompi Loop Blocco?",
                        "index": 179,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "9BC81BDB838C604E057BEED972412795B5D7"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sazietà",
                        "type": 0,
                        "value": 9
                    },
                    "targetVariable": {
                        "name": "Nuova Sazietà",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "9320438A5B05A64A12799BF7EB54094572C2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Nuova Sazietà",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "Vecchia Sazietà",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "A2B15660645C75464448F5A1BC030FF771C0"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "3111B3077C68E54D823A4775933766C6A986"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 2,
                "uid": "68ACFFCD32FF064FA61A2707067AD4EAABB6"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "FORCE SIDE MENU OFF?",
                        "index": 146,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "DEACB759310E8947CA1AC000298566C4D77C"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Shiori tavern event",
                        "index": 221,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "77A8A5C95E9FE54EC87983D78BADFD373F9B"
            },
            {
                "id": "gs.BreakLoopCommand",
                "params": {},
                "indent": 3,
                "uid": "F40B208D7A48C64A8B6823D03887F2DA2C75"
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 7,
                    "number": 1067,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 10,
                    "numberValue": 0,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "CE54B8E561BB444D8E890E644323F3933654"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "DAI CIBO A SHIORI"
                },
                "indent": 0,
                "uid": "997CB44C303F374EEC7882286DE4DCE8E066",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BB507128AE7B549D1984852B721A361A621"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 1,
                    "target": 0,
                    "sourceVariable": {
                        "name": "Testo Multiuso per Eventi 6",
                        "index": 305,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": "",
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CEBF222F66BBA6420C9B1A5820BB46A9FE14",
                "expanded": true
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "9CD432E8076BF34ECA4887B30B4A24F40A7A",
                    "field": 0,
                    "targetVariable": {
                        "name": "ID beer",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4F35F3844ECB3541E30B277227DE57B67516"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "ID beer",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "522CFDB93A4F984D02893D4677B242124591"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "Slot attuale in formazione",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "slot",
                        "index": 5,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "09CD565449F8294A172B4F1115F90F1DBC69"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "slot",
                        "index": 5,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 5,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4A215A9D1D26F54E204828264FDCE1A9950C"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Cura",
                        "type": 0,
                        "value": 150
                    },
                    "targetVariable": {
                        "name": "cura",
                        "index": 6,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "54C4BBF156579142FA78ECE6536C857B5D54"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Nutrimento",
                        "type": 0,
                        "value": 2
                    },
                    "targetVariable": {
                        "name": "nutrimento",
                        "index": 7,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "800142D6904E484A36785ED52E62DAE7D2B9"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Sollievo",
                        "type": 0,
                        "value": 9
                    },
                    "targetVariable": {
                        "name": "sollievo",
                        "index": 8,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F8A6D9A389BF81406A5BA604B5F4F806FAE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            {
                                "name": "slot",
                                "index": 5,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            0,
                            {
                                "name": "cura",
                                "index": 6,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8AC4E74D8BA38344167812C4C05B92C33384"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "75089B917831A544735869A652C67A8D8114",
                    "parameters": {
                        "values": [
                            {
                                "name": "slot",
                                "index": 5,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "nutrimento",
                                "index": 7,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "57CAC82B2A27F3475868E2685134A1B6663C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6190FE1C2E16674D7B7BE636788066C1715C",
                    "parameters": {
                        "values": [
                            {
                                "name": "slot",
                                "index": 5,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "sollievo",
                                "index": 8,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "434F9E374A2E6444258A0AF74BA24B347DA2"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Riprenditi i vecchi items confiscati"
                },
                "indent": 0,
                "uid": "3A80C8C04026F34FE04ABB5548D5ECDC6143",
                "expanded": true
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista eventi speciali 2",
                        "index": 537,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5B4DA7B73AA1D342BC1AE4E4777CC280BBA1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "357CF39356267749FE29265630C4C9A758DE"
            },
            {
                "id": "gs.LoopCommand",
                "params": {},
                "indent": 1,
                "uid": "15EE81FE55E2C0442C68E1D66C554B1F65DC"
            },
            {
                "id": "gs.ListShift",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista eventi speciali 2",
                        "index": 537,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "BBC41FEF81027244956A67414809C2C80CFD"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "param": {
                        "name": "Quantità",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 2",
                        "scope": 1,
                        "index": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "A95B4E8832151148905B1B02CD4045E62FF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AAAF05F148E4A240D72ADBD24601F5AF0A30",
                    "parameters": {
                        "values": [
                            {
                                "name": "Testo Multiuso 1",
                                "index": 1,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "Numero Multiuso 2",
                                "scope": 1,
                                "index": 1,
                                "domain": "com.degica.vnm.default",
                                "changed": true
                            }
                        ]
                    }
                },
                "indent": 2,
                "uid": "67E583083F49E24FB0299E216AD4D91FD088"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "Lista eventi speciali 2",
                        "index": 537,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "1269DCFF8853B040FA5B82A0817982588CC2"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0
                },
                "indent": 2,
                "uid": "32ABC07D22D9C14D8C480F02FFB1F57179C7"
            },
            {
                "id": "gs.BreakLoopCommand",
                "params": {},
                "indent": 3,
                "uid": "362B630888A038466A5AD53426F404F5891C"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 2,
                "uid": "07C54E4A401BD74854994EA2DB348F6FC5A7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.02
                },
                "indent": 3,
                "uid": "7A56464185A0774CBE3912D89A57EF2E0A9E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "riprendi discorso"
                },
                "indent": 0,
                "uid": "67A681352A0F314ABF2889573E2E87172B52",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "IN EXPLORATION?",
                        "index": 156,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C8C210C27C2FA84E667B1AF01D5CC14A205A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "FORCE SIDE MENU OFF?",
                        "index": 146,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C70A5A1E5FAC014E9349C671BF636B52F1C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E06818213722140557B5884208D51B0CBF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29A87BD27FE1334B5B0903B69441AC4B15CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "176F622E11AA0745B149E8A42AB0EF98E276"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7CCF2D0217F6342923AC0F606B4AFD60C71",
                        "defaultText": "정말 맛있게 먹었구나?{W:150} 테헤헷."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CAA3745A8CEC954DDC4AA1181A5378A46DB3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3B4859A83AB1140854830533EDE74841F61"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "AEBC0A636EA79642F96B0DA7B7E2A53AFC49",
                        "defaultText": "맛있었어!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "66A432B57709594814391DF6C669FE5FA182",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "058207CE857AF6457C7927D5905B915AE66F",
                        "defaultText": "사실 별로였는데, 뭐 괜찮아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CB83CFAA544A7444881BB4F8499F1C2E2D19",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "nom nom",
                            "fameee",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "291BAF206BB9714527390453DECFD08CF980"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "71FE1A4754F2764885798DB7186E628401DA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "nom nom"
                },
                "indent": 0,
                "uid": "81E5E4DC8F5FC142316AF693121A9D5EEE65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49F0E7E000A90448707B6E616D8BD9863F97"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E90C027218E2D5426F1911D195D5471D1E19",
                        "defaultText": "다행이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8C3D0CDD7BB41140C6094427585104127A95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E23A494D3B0C7848EA6B45E8BEDDE3F1E1C6"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "dopo cena",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B79401141F36774C7048F427A243985EA37F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fameee"
                },
                "indent": 0,
                "uid": "95BAD0B595EAF24B24386D060BD2D60CBC9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E73A91108EDCB34AAB0B5BC955C1A8CE603E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63BFD5A20C8F2944754B9A22BEAB40946BFE",
                        "defaultText": "아, 정말?{W:150} 아쉽네."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13890B9B6402424DFF394601082E38F3474D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C63987C949E4B0498C1A6C69B0563D7D5944"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "dopo cena"
                },
                "indent": 0,
                "uid": "7C96B94604FFD646305AC23739A034F0EC8A"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "F93B23EE2C30854DCC5B1C70CDBAA49A2A9A",
                    "field": 0,
                    "targetVariable": {
                        "name": "ID steak",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "705F8C1C3A3E9543359A1A368D99196DF020"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "A61006745779B54F95583F031E23AAF3B85A",
                    "field": 0,
                    "targetVariable": {
                        "name": "ID crab",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8CC9DC778A01A74DF47BF6712B5CA17CA1F8"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "4BE0921B0375824E39486375D29E6D610E31",
                    "field": 0,
                    "targetVariable": {
                        "name": "ID water",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "554951336C80F349520877447362C607BAD3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "ID beer",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AEBEFF2E3D44A4436B1B3AC84F1CE571A785"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            10,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "96DBCA603FF7F7460E5B04C10D56EEE8B82F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E1FF6F77678EC447E229F971653A926CD891"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            8,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E1826A406176C1476059D666672ECE2DC7A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "877D1DB0202E234FCD78C1C0A31BFAFD572B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D524978409CD540891A2A600CA034777DB3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "299D6297807E764A5B087A314C0F50B8D37C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "79FE47B13622224F94892B47F04C2E1D774F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D211B8371FB80445F38BA9E54299FC22E214"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2679858D3AD50448C71824E2200B72C7F175",
                        "defaultText": "나는...{W:100} 이걸 도저히 마실 수 없었어.{W:200}\n해산물을 부탁했는데 맥주를 주문한 거야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5FA87B145E8EF247852AD3174767B6A6FEB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CA17262C67D5754AA41ACDD2395E3FFFE465"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD9A39F38F8DD14DCF8BD3065502A24B8C1C",
                        "defaultText": "\"시오리를 취하게 만들자!{W:80} 재미있겠지!\"라고 생각했나 봐.\n{W:200}전혀 고맙지 않았다는 건 알아 둬."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "32712CAB8A1D044FE69A4CB2D9FF5F14BA36",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "ID steak",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E16DC37A2FC8D1427288E3A8452F8158271D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2EC30C773A6FE844972B88F5437C3A4E79F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "D53331B727E94540F91AE682F279CD16C3E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4021EFCE79C906423A7B2098444D6E49FAC0",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "EDB0D8071B5A054460297D85262C7B4E8D71",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6BFEC5627FDDC344D26B84D2484C473F733D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "922B06F54569D44DE5692A15A69965BBDCCE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7327C1D3747C9643179A1B06ACD4F22061BA",
                        "defaultText": "네가 골라 준 음식은...{W:200} 예상과 달랐지만 스테이크는 꽤 맛있었어.{W:100} 고마워."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CBCCABCB608F474C588A96A88E87C9328ABB",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Appreciated?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "350686C5374B97427D382D514E39A7EF1497"
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "ID crab",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "58656D9C324D044CF88B2C184FDD4E540A02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AD5050548DD21948DF49A7D86646DE190676"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9D58FD965A54D24511581CF92B67279EB865"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "541053388523F44CC268FE05A9BD294A7A6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "2C350636479023491C4977C538411DBA6653"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6933E5575F3FC545E43BC298EB0D1CD9EB67",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1FEABF301A9010484E7903726DB6DD4B6916",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "158E77DA8F3C33418219A111F9957BF5F4AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E250175259021340B61AAF38CF71CCF001A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A232AFDB8785054A11586D525C29E5FF67CA",
                        "defaultText": "그런데 수프는 정말 맛있었어!{W:200} 작은 게살 조각들이 정말 훌륭했어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C21E94F44B39674CD8886B27810FF6CDB82C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2E92C6357BEFE049BF295E46D1E054D87275"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "615B9A367A12C2442719A648EF7C5BE11CF6",
                        "defaultText": "이걸 골라 줘서 정말 고마워, 니니!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "2A122EF63484514B925A7094E5F761BD7AD5",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Appreciated?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8EAA270E29FA55452F084344282398614DC0"
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "ID item",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "ID water",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1FA356333204B84FCA8BC06787A7070F87EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "21E7BD1E6F44C042744BEB5361D59001DF69"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "063E356F1BF0F1406A184CB250C7D81B1D41",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line27_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9776394F747E094EF86AEA319E20B9AFF804",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "8996B92B1A7F004BDD28DBA1EE90B2116294"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF9523B032A1934F9429DDD5B8CAF6D7C9A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EF1C65C54C98B440C22A2619E7F60AC930B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB736B5817DF3848CC785560C9B640E990DA",
                        "defaultText": "그런데 난 뭔가 먹고 싶었는데, 주문한 게...{W:200} 물이야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "7DD70F23321C53461B993941A951536546E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "027F19757ED8A1459E3BD5F32A35064686A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AE0784816CEA746648A7FB6569FA2E3E02A",
                        "defaultText": "싫다는 건 아니지만, 꽤...{W:200} 특이한 선택이라고 해야겠네."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "6E093D9860B1F44F30083631276989F93E9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBF935B447EA4049824A8D682B025A33382D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6864289D77C58941811A8523D84880AF0B09"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Appreciated?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "73FA065360FF1549A76BFC22EF8B1CD0C922"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B94DBC3B9D04D64CBE8B45B7971F76A18A1A",
                        "defaultText": "맛있게 먹어서 다행이야."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D67B776F75AF574AFE290C974A192989BE73",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D774C465E97424BF379A4494EB8EE04103C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E2F1F4148809E84B3068BF464621A155E7C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "31389C087D93334FE91812480E8119B0E464"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C806A9928D3C5945AA48B8E42E1D74872B0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "93B545A63446114D1D9B9AD78327D7756CD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "28C30AA521E7554B5C8A6648A78A7773B06D",
                        "defaultText": "흠흠!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5D29C56E960AB2460C3AB327F63752435A92",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "AE8BA85939F9D5444E38A8283D121D0755D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A7E0ECD9BAFA243D72BB7428147CC6F9976",
                        "defaultText": "내가...{W:150} 음, 미안해."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "DFCC8A1D5B4DD946ED28DBF41C56C778C9D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3665C8C67797A6483888DB38E25895D0F22A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            18,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "492D25A21CA0464D631BC1465C9F7D72A9C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1D86D5757EC1B44AF158CBA6B2A2EF771EA4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E0CA9216578424260889CB54EA5249D6157",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3DFECEB094901540470BD254A0097988FF72",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "2F268BF031EBB5483B7AC7E3A9FD2A01B353"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            19,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C150AC2F4429A441EA08C3C4D2A31A0EAF44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "83ADFA016D6D834B8539F6A8B5AB95ED93E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E35975A09EF7F84DF78B6EC1E66CE22B376A",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "83E6890A0C58164A768A7301112F6CDF65EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "70F6AF9D2D0F6944DE3ACD7244D52B1F2B9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D1FF49521DD974290596DB6F48E6B4A3A2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E3E00AC48AA138453F9866256DB81894558B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A5562D845C3CF44F0C9A6068FC9B7249202E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "F50C815E3A7A4141098913F785BFBEE37F69"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5F78D1A85863B44A4D1A9602ABF138E81FA0",
                        "defaultText": "용서해 줄게."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0B2EB8EF6129B1461D1B6E697AA9CA3CD8D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02E0FA81473E304FEF1BE9911A910BEA727B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0FEC95C74E47624C600A14345A57C187C8D7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 1,
                "uid": "792BA5B696F5854DAA8935C7F715D5DE98D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1BB568582C61A7439D2899B6AA212E0B982B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "0271B1FC28310241113BCE71AE73899B7EA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "65D97C3428BBD14F3A799BB040A2F10D4060",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A265121378197744B36931D15149DB6F5B17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "A7D30BB76A17A948AB2815D1EA9C3E06D728"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4E7EAB9580B718432F1A4C70152896CEAB4C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CE4470DA98752144E318227222F8C72394F8",
                        "defaultText": "우웃 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "EBB214F71F8A174A3749B5646E8D0A31903F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "20F1786765B8514FBA186A0643BE71CE8B3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6B7872C49971214B520A3084CC874A718F70"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F13B2515208F642D49B54B2135FEB70A4FE",
                        "defaultText": "알았어, 알았어... {W:200}약속대로 내 것을 조금 나눠 줄게."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "2D49E8FC7437514CD648D5A7702C4F90D4DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1AFEC428936EE240EA4868A327E101A52D8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "123D42429F24174F617BFA54D7FC898A04D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D9D19FB94C9F82496B692F47C6DB4AF78D15",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "083854C21CA487495A2939967E11238D7FDA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "703CC6743BF9E346462925A8BF3B00A596FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F1B3A7B893B4144A71290A32B5217BAE4F6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "87348E6444AAD84731083AA31614E20E5D54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31F5A44793EF164EFF8B6C4271E3550F26B6",
                        "defaultText": "우우우우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A0A26EE62ED7514BE22A6118B9D78B5DA1F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A9E7B4C48650F84FDA1A3DC52A2F02195674"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "32E3E1176D12134DC029742944BCA02908AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 1,
                "uid": "194DBD6A74E48145E14B53E397B1DE08023F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5AD7251176E9A844E75B8FB05C4A026665AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8FCE981D4252394FFB6B6F155A7D8F0875C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "4B1026490E2F94453C8B69E2D12ECD608874"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD42C4227142F640426B02D120F83B9F7B27",
                        "defaultText": "조그만 동물치고는 엄청난 식욕이네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F9B73DE56C5A71492B98C0081EE88FA4C784",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD21AE104B2C07448078B4764B35336FBB2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "D71939EE44AC5542394A1677D407EEA9E6C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F535AD1D71ADF34562591004A277CEB84272"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "05F79F51675C2843CD0932711615544E0EF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            800,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43EFF2A2215CB248537887553375014942A6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "9EC6E19E87FC084E5A5B8E97F778B23CF37B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            100,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "356F549D6B99014F637A9691F62A659F15FB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "27D6EFE97D55C642A379EFD240A548FBCDA2"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 45,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B01AC5D474D6474BF47B5650FADA1D68C920"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "174D51C025DEC346ED2A71D1499EC7CC3710"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBEAA86D79D1E64DC809AB18B948073B3303"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C94204D12F1684EDE3808A233F38C8B6DEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "091654A751274843736A6720D1C761829084"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E8764CB528E5F34E571986A320AE26A202EA",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line28_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47DBBC64584FF844A15B75551E7E051CADDD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "01EE7EAD852453451B9AD262E7C0B8C7BF07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "379B747E755481439F3A7647D2B2651C4D1F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31A3D18353CC184D2028E50117E4C3153B25",
                        "defaultText": "갑자기...{W:150} 너무 피곤해."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "70B61BDD1F5C614B38197372442EBA2FD9CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BDA72826C401845AF5AECA8007A94364E9F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E3117032F1B24411D59C542EE50044938CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7F35ED654388741EB1B6EC30126E0ED163D",
                        "defaultText": "이제 졸려?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2BBAAB807E9EC4400D58ECA624AA83534A66",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B923FDD5326A234D9659E4A98F6C069AF7F9"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9DD19AD07E9F88442C39B074271143F6F01C",
                        "defaultText": "벌써 자러 가게 돼서 미안해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "601E03C55576D340F4791EE1A359FAC3D150",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "29A2DB2E413F11449C3899276E9604416588",
                        "defaultText": "응."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AE5E8AD23D016743B309D5048C6F8DE0A79A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "letsgo",
                            "letsgo",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E7B679A6E95C446257A6C24928C40BF1609"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "12D032521DF85645C928B84655DEB91954CB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "letsgo"
                },
                "indent": 0,
                "uid": "DE364976743CD149378AFD45D876B17A1719"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "944C0FD27DBAE0410529DBE3A7F9385EA9E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AD705C739A86240A278F684EE2274D2FBBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "830210E76935B8486838BC163C4A15C24828"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96AB29251C2D774E04381FC47F017DA66B3B",
                        "defaultText": "그럴 만도 해.{W:100} 오늘 겪은 일을 생각하면 피곤한 게 당연해."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "54659D7C1D6E25417C381B9793E0B4571646",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A14F194F106E814DDA180CB39F152793DC5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "306E986523796449276968275D0970A5AA96"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0B8A891E5306434DE86B1FF3992E0DB6BEC0",
                        "defaultText": "그럼 방으로 가자."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E4B145C3489CB045F46A79A31E2412DDC159",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B91036F417665454F585E171EC2FD107FF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "96330EF41914124A2308DC62EFD1B39B452B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "FFA4ED2933D854429E5AFD118820433D891F"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Sit_Armor.ogg",
                        "volume": 100,
                        "playbackRate": 117
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1F05D41844CD2247CD0950549A7F3765CF29",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "981CA27875AD62464E4A4DE10164B33171F3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "598A59181CE615497158C5C69B2F8A8E4A1B"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 54,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "13FBEA5A8E40094D0B197C5740BA7F46E58E"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 54,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "uid": "FC8C1B6322905546D548D244F3F00CBAC323",
                "indent": 0
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            4,
                            900,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "730FA42A82DA27441B19CA82973F0C64BE22"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "AE98A23E34174243CE68884260B4BBE00927"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B811984E4F871242CB4B970739B94559C2D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E439C469C85C04AB63B794436EB498EB479"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF224ECA3AD7F1478F7A61F3EBD610ED3CD1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B95F01B9970056447898EA38FE269A115393"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1308345C5BB30345AF99F0585C1C9443B179"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3314DBB99492464BDE4A4DF678F58B2523EE",
                        "defaultText": "벌써 다 먹었어?"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "942365831F8F0144F689D953A3FB474B4AAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D00ADBD5584654477D8904345440697A7E09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            750,
                            1,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E62FA1610401E1425A398E779FD7CFE75B6A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF7695C434F84148526BF328178981B3F31B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D71AE48B8C5AC346E94914E54B2AE47672B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E9C79E831CA4249343BF48580E3286BC843",
                        "defaultText": "오늘 밤 여기서 묵고 싶어요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F98D9CF87868C7429A88417743E0F51C5E00",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81EE4CEA8BD0B542455958D31A2583681121"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B48CBD23551178405699C938D2DBF92F4F71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "662C95886A8A26476928929616253CFD4DD2",
                        "defaultText": "그래.{W:200} 2인실 하나로 할 거야, 1인실 두 개로 할 거야?"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "84A3B6A496A65240FF3BE6B8A9A40D9979DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5019E42076D5C84842895F95198849AADCEE"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1F06C57F7A5B464CC33A4CD72A0EF092DAB5",
                        "defaultText": "더블룸 하나요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0CBE63CF23A01243461ABF219DDC9D031A54",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D5C5B16B795F254D8A7BE582B69EF48B92EE",
                        "defaultText": "싱글룸 두 개요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "11ABB207272BE248B529E8873DDDF9EE3714",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "matrimoniale",
                            "singole",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "E68F06FA312C4148F349A7074F04F8F25F8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AF04BCD11E0C81481F495CD30E4452634DF2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "matrimoniale"
                },
                "indent": 0,
                "uid": "776B6F084E93F348DD89A0D4DE38B71C8DBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4AD56C7233F634F7E5979A7F4929B414321"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "557D123A62F6234877591A13A285A4F68CA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B8E38CC22B32464B535B67E242CA8697FB5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E717452241383948B958094223DBA2B77BB3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4AD4185080470840A74825615AD67383B1C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "037F6E8C8A7D694ABD2A3E523880911F2DF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E999C06E8BC3844FF51A9790A46FF0650962"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C703AE6150FF647A268E35460C3E70AF712",
                        "defaultText": "하, 하지만 니니, 우리는 그런 관계가 아니잖아..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB361AFE89D44845714A1E940F5FD71940C5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05BF222D7AA9224CFD0B5C17854AEDF655C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E9F3C562DEAA844486A8667DA2ACEA90785"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6ECFE888509A29442F4B7B70293CFE534CEC",
                        "defaultText": "어... {W:100}아, 맞다.{W:150} 그, 그런 관계가 아니었다는 게 방금 기억났어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C66EB1B45E64344DC01A8FD6FAE0A244E571",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B200F8E4A4C8146C88ADE2163503ECA8E87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            3,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED3788DC6F4DF4430B8A0C8700A770699914"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D3FE6612CFDB645E418525810079C355D2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "738A3BBE2EEA3248942AC179A19C562547A3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line24_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B457EFDD5D4EF14DE68ACD356F8D13880862",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D9D9FD0963A06940221831334A8A5D458C06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBD2BAB274E5084080483F71A9D3CBC09436"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A80CBFA649B8F540C57B2D210E5A842CE9DD",
                        "defaultText": "그래도 귀여웠어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B2BBD1148235645F8487A8627CA4ECE6D15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "613EBAC82EB83748A6188336EEAA310B6694"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A5955BDB05E7B64E903B18D021F337AF04F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D0CA8645B324449985A3E8568ED2353C4E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B09E96829CE45456C1B12E9095C3D8781AE",
                        "defaultText": "뻔한 유혹 수법만 아니었다면,{W:200} 정말 기억을 잃은 줄 알았겠어, 하하!"
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0AA3D10234D574D5649211212CF78C439A5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A5176D743D5B54A6659AC48579C4CFA3DDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D61FA40C97D9644E8E58E3F7F76588D3BB2F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AF174747924F546E0486C25BBB73BC08C4A",
                        "defaultText": "...{W:150} 실제로 기억을 잃은 게 맞는데요!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F3911BA7934931444F5A7A36CE5B51D72CBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F883AFA54CC84433148EEF0ED2CDE442572"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "andiamo a nanna",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "A825EFFD614B1942918B9E242D505996B7ED"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "singole"
                },
                "indent": 0,
                "uid": "41E8ACA93B1CF54BDD1B701616CFE9BFBFE6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "970458C73A81844D014878D35425117B70AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED84954F1A1C824C227A6F22001E5C29F592"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24BF76B20E4FA749724B96C199BC265DFC5D",
                        "defaultText": "이상하네.{W:100} 분명 연인인 줄 알았는데..."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A242CD66B35864ED598E0A18F04D92BE83D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AE746387AE69841B9981D851AC145B6595A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B13F36E2C87B647705BBE35EEE38B99E356"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59248B70581DD249782921A42A0107516CFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E7515129D28774C8949E4619B94ABFFB8C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9F86275791A3784FEA89FE800A9295DF02B2",
                        "defaultText": "우, 우리는 그런 관계가 아니에요, 후후..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "753E0579150EC44B8D5A3040D4E57082B850",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "029CA5353FD1A942C0395823D79F06B70ADC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CD53B41089193484C7A5BF25FBFF0349F8B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D504FE11F91164D112B07944A2813A68D30",
                        "defaultText": "흠, 참 묘한 반응이군..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9FFC8CDD90B4D84F3C69E178662EB7A756C9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C3B5D24719CA5484A3B1E17E8F6B0779B64"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "andiamo a nanna"
                },
                "indent": 0,
                "uid": "D882489E0818B049EE8B0075C3E8C9B8BF62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            13,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF9DE4AA1518F14ED81A0EE22B42559861B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "939C86B162EE004474395AC3C28F4334F4DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CB42ABC8196854F1368B870152AD76D6DD2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "409A730D37D1F444D23ADED72109F1026CA3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC56CA317B31164EAF8BA0270CE380D2F90C",
                        "defaultText": "돈은 내일 아침에 내도 돼.{W:150} 여기 열쇠."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F62AF9887217A44F3B8BE4B1764C2D980461",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B0E8186F3F9E5547A64B3E776250AAD4CCA3"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Keys_Metal.ogg",
                        "volume": 100,
                        "playbackRate": "100"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B08390687E5CC3442A181C4642023A7A5E35",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "F49F36211CCA3946EC29AC288E80B86A0A30"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44E771EA3B48A842DD09E5652718059FA447",
                        "defaultText": "꼭 돌려줘. {W:150}손님의 뼈를 부러뜨린 게 한두 번이 아니니까."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1D5DE8C422074245C02A87B499F036D2962B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30E61C1389F6A240A4592DD2C05EDD51AD14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E46E5C17777A5471E284476231D2EEB9194"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1591A2159877654F804AECF75302CC40A2E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAF44CBC7B08614D6A3A64767B25449E706D",
                        "defaultText": "농담이 아닌 것 같은 예감이 드네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F7BBA6F2299C74387883175C04931DE9CD6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "48F9E9934F47074CC41A7D22D62439CEE0FC"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4262824A14039648FA795493BD1A9A21192D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "3EFE070467FD844F032B96E7FC7BD17A1A10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "94F3261010D4F8434B7B1CE0A123A072D538"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "410CCE8E29631344DA6A7746DF070152B8DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "934034644CCC4542866AB0564A57BFD4508E",
                        "defaultText": "우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1FD5059C5D020544A918970146310F2C6F9F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E477AA413AD3874CD73B09D06A4E881FA05D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F214FCF83969384FFC8AE20156739EC8E1C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "9DC295BF57E4C946008A28B9B64E032F13CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9C4352B0EE7734F6418D4556FA992AA8B84",
                        "defaultText": "개도 들어와도 돼. 돈만 내면 신경 안 써."
                    },
                    "position": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5178A7A78123514594284701E571CA22D580",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBFA0E763F7B824CEF1991F3A835C08E95BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6CC99DE21E89614B014B49244FF934ECDEE2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "86C213F67634C74B972850B19CC387DF0C97"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "DDB28D5164C952421F7AB91046E2E8FB82CE",
                    "model": {
                        "name": "TarmenArlene.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Tarmen",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 704,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 994,
                        "y": 373,
                        "zoom": {
                            "x": 0.25,
                            "y": 0.25,
                            "d": 0.25
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "43FBA2E872DE5349220868F5210957B64E00",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "DDB28D5164C952421F7AB91046E2E8FB82CE",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "041F15571B33124B515A49217814845F7587"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "E43DB58448B9954F757B62B3F80A4015CBDF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE579D5371F5654A9C59A138DB42D5313934"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            7,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EFA68FA735568740F359F757C3BBFC8E3A36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FC5B6EFF6CE7F947291B15A889AEF241C97E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0E1E4A481B5A94F2D3B3AF2353058E06731"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "32F6C44C6497214DA368E9E38BC8DFEF6A84"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8DAF51677CC3274BFF59F9C626F76001C6B8",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4F0981515E40E84A577B0718C09E059641CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4E152B854ADEC94ED18ADA91D4824EE2A174"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16F7152469ADD24D6348EA6683208366C002"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1699F6775B32944475890136B9CA3882CDA3",
                        "defaultText": "그럼 먼저 갈게, 니니."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7843E4360F858142A26A2195CD251A6A8A8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E65BA3E2F072746A56B24382B625EEE9FE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67C40DFE8CE1554E9A886DA8AC27CCBE40DB",
                        "defaultText": "내일 임무를 계속하면서 네 기억을 되찾아 보자."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31A453CD245CE742225BA8F6807266CD4FE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4077676D381E614F16486467C81886191BCD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "97C029FB7ED3F446926BFF9845F6BF76593B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE1B6D6D81900045F81B7C11294E6A128B83",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9019E365564AF44C141BD4A3E02F48695A9F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6D733BEE222B214AAB8976C2A16E0DE613C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C44A3B56169104F419B1AB5CD0C32040654"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "606FAD7C2165614113089CC2390B02BF0999",
                        "defaultText": "그래. {W:200}잘 자, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "996029222CA2414ED65919E5E6DCEB4A447F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "549A932406AA54428959DCB42163E252439B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3C84BAE3739124A425B43F5771699CCDF18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4C52A8B302AC448895806D462A2FDF0B855"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9DFC7C1217FE684E56698FD352A835D7C764",
                        "defaultText": "잘 자!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6FBCEF52448764F708AEFF6077203383103",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A644B8893189484C5A7B55F38529A8D24127"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C58EB5C08A0C1040B19A9602CC05D6C433DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07"
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB8429373F140445F87999D34D03B5C664A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BEC7C508AF3B145105AAC31CCD5E4844BB7"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "04B8654752D0984FAF284D02EA8A64850797"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "50494663836EF24F6A6A4965203B5E3A1C7E"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "model": {
                        "name": "Shiori Overworld Model.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1645,
                        "y": 407,
                        "zoom": {
                            "x": 0.32,
                            "y": 0.32,
                            "d": 0.32
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "85D660D8701E0047334A44533D59F0A90992",
                "expanded": false
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "param": {
                        "name": "PARAM_COAT_TOGGLE",
                        "value": 1
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "D334902D8D32D740427BC0A22771B0E9F9EB",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "632E784C6DAD23462F8839F4D4C2D654EC86"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "CBF4FFFB917FB246AE88D4E2A973A66B630E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Ornières' bedroom"
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBACA6005F63F44F4668C4C3B540B097ECDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A43EB2DF38ADD2412C2875A1ACD0835EEDBD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "9DB407F006D0414F2908C9E2A7DF09FD9D72"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F9F306780DE4F144734AE4A5F23E021E92D1",
                        "name": "C1-04 Tavern day1 goodnight (Exploration)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CA3FA6064F0DC5429F391BF5B85142442DEF"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}