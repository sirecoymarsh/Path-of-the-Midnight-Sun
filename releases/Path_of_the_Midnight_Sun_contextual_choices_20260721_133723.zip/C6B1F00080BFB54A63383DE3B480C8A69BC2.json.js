GS.dataCache['C6B1F00080BFB54A63383DE3B480C8A69BC2'] = {
    "uid": "C6B1F00080BFB54A63383DE3B480C8A69BC2",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-03d Talk - Kalevala",
        "type": "vn.scene",
        "parentId": "6686822D92318647E8384993AE3B8120C996",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 5,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "E004A5678C95504E854969359529BE9BB573"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "model": {
                        "name": "Kelavala.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 258,
                        "y": 52,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "4F07E3BA4915754BF118ADC6E06E386DFB03",
                "expanded": false
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2E89B7306C85B240425980557F9EBF5C3F83"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "CA5529881E4A214DF9580047A111DC696506"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC79030E7469F4418728D6E1ADEFABFC083D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D8AB8E58BF2574B5719006637DA4FDF512A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C356A5B9EE198436C2917070A6795FCB06B",
                        "defaultText": "잠깐. 너는..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B433D90C3F8BB14D40788B25062E2165F17F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F79ED864D658046A4389EF7F8C61FA48B6D"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "duration": 36,
                    "waitForCompletion": 0,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "0BA106DE351CB5455C9A68F4F731F6FB7C96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "26FE8B4E15CDB04E811817C238EFC4A05D0C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "32968B9C3874044FF96AE163A1326A66F5FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CCB2A514A2A914497698DF6B14AF0DA7AA5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E500C8B8377FD64DFB8963A6B1F392362EF9",
                        "defaultText": "좋은 술을 사랑하는 믿음직한 음유시인.\n언제나 그릇을 따라 최전선으로 갈 준비가 되어 있지."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "921B8D4670392540D789BD818DDD241338B2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2A8BF6485C714433C6B92B4B0E421EB9448"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A99025B26C7B11424139EE31113C39BEF761"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61C1F9517EA0154BD61B59A050C7BB407615",
                        "defaultText": "칼레발라. 아직도 우리를 따라오는 줄 몰랐어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92CCB66527B2554EE3594462FD794E30AA79",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DF594982F18B0459D38DE95C4E3105748F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CDEB8FF62E7F044B288ABD257C83DE710E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AC964FE64D08443EF58F4354CF612148010"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48A7B3EF4170F3496A682622C27C2A69B47E",
                        "defaultText": "어젯밤에는 조금... 이성을 잃어서 날 못 본 거야.\n하지만 오르니에르 경이 한참 전에 합류를 허락했어."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5ABD3EE9FBDA24FCD88A7D6651C31141F46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7623B346C630649ED5A5824BAEBF683EAFD"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "10E24DC26DF4204D506941D5D20A3079DE4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D49886AE2C813644020A05136A7C932A5B37"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A0E98ECC3F23A543EE398060E1944DE9D80F",
                        "defaultText": "그 {LT:1}... 언제나 내 뒤에서 멋대로 일을 벌이는군.\n흥! 따끔하게 가르쳐 줘야겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "32EE40CB7A1317458839E3A28A8BC8608DA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6468A36C182220449999064785FDBDF15CBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EBB3140293796486D582414D08C52E30148"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5603F2A05F730246641B58416709869C1D66",
                        "defaultText": "그건 그렇고, 이제 몸은 좀 나아졌어?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "48695054560DA340936A3003C338C2323905",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A757463067D208407A680B1402EA49E4C8B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE6DB8022573304375888C806B1305FD15E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD2A75B783F7C64F764A1C144AEBA29D46C3",
                        "defaultText": "그렇지는 않지만 곧 괜찮아질 거야. 아마도.\n그런데 왜 나에게 그렇게 관심이 많지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F682289009ED014B619A65E96E06F18C623A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "746192C8591557477A59A32325BF2263EF54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2488C0EB6349A54D6B49361437097DA9D5DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC0651114FECF3408C69DCE50D6C7BC504A2",
                        "defaultText": "그 답을 얻고 싶다면,\n먼저 내 질문에 답해야 한다네."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "500C24A78CF37746B96AC8D10DA8917F42B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7379A191AF4F7493518117553CC4CD857DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C438AB6C45EB6640B88AF4126763831CBA9A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B4500998614C64F101BBA81CFF6BE662487",
                        "defaultText": "제피라를 알고 있지?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9CA1897F1CFAE04A7658CBA7B10EA6E0B4F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE1F2DAF943B084ED24AA3E3000841EDD27A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BF6EF3E6C6DD94202592BB71EF51822E9FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94229088953A614C2F2A9D763268018A6132",
                        "defaultText": "{SP:2}{C:1}두 번째 그릇{C:0} 말이야? 물론이지!\n마왕을 억제하려는 강인한 의지를 언제나 존경했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A9B5921126C914B0F6898149510C502FF9E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A92041B96A8FE64B97795980B5049E5DFF5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA85CA98427045493D094DD8892FBCA7BECC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A33007CF11BBC54E9D488F91C41033B09B56",
                        "defaultText": "내 방에는 그녀의 그림도 있어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "01D7B99F89FA484C3949BCE2739B204FE432",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A28B842F1F157049317934B1FD97B8EB2A7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1CFA26860A655477558C8459C1B697D23DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E65B22391A983947098A785690C3F94C59B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1351702F3A8284452C6AD29314E1D9369525",
                        "defaultText": "그분은 내 할머니셨어."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51B4680D049C754B0A895E1944F3693DE715",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "242617F1279BD844812902E71718FF94EAE6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(Ashley) Oooooh!  Now his interest makes sense!  Gotta wonder how young she was when she had his father/mother though.  (Yes, I poked back into the backgrounds folder to see if I could see her picture. Nope! And I don't recall who was who on the legendary heroes CG, but they all look pretty young.)\n...Guess she got the chance to see her kid grow up."
                },
                "indent": 3,
                "uid": "36A455240ACF8845EF5B3B02F9965C89A9B9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3F522F7B5DC255436568DED34077FC3A2592",
                        "defaultText": "네 할머니가--"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "62B6F9310F68914C631B3CE7874FC27CC10B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B0D4871B5C61D148E99952C43467102FB804",
                        "defaultText": "세상에. 전설적인 인물처럼 보이진 않는데..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FED2757430369748FF4BF9F47ACBFC938ED1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "grand",
                            "oh wow",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD85A3654CC1914D8428C0857A02238759F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F810EA5A9AA0A4422B6AC713AB8C33B4D945"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "grand"
                },
                "indent": 0,
                "uid": "3AD23FD520F4D4422408327392704C58C448"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A289F0C41296344FF548131067B1E74BBDB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBBA80538B07474D484ABEE5B92E0545F4E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF52AEE431F1B140FB380BF47B97ED4E290F",
                        "defaultText": "그래, 대부분은 이 사실에 놀라겠지.\n나한테는 할머니 같은 고귀한 ‘기품’이 없으니까."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BE1A2AB76761154AA2391D6464447FDDD95A",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "D41C3A6F47E8C74BCF3BFC26D81F45200571"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "oh wow"
                },
                "indent": 0,
                "uid": "39B0D7F779EAE54E565A7163F0B6F70A1FDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F24919EA23F8A14E7E488AE7A4B0D6C244A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C79974D576D361432B7A7917426D0BC63543"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "70D1D55355C026457C2BFBC6D50AE701A17B",
                        "defaultText": "칭찬으로 받아들이지. 실제로 나도 나 자신을 그렇게 정의하니까."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "34E7E32929BA6544B589E1E08278F7A18ACF",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "AC393F0F8BCEE7471418AA39437B7F4C6D2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0D9F618303FB54C251A0688232DF70B5FF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "520A8BBA2D430844775A7781CAFE82F607C8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "542964629711C44BC17B0764C20B84AA4308",
                        "defaultText": "무슨 말을 하려는 거지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "40E5B3E40BC57640E03B4910C504C7D6DDC4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C079AE1B879E57418279A4964454D480D7BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE0D644928A4D14E2E7A7507D8347B6D5DA7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A6FE7169274F43492B98B420E2D981E057EF",
                        "defaultText": "제피라 할머니는 무엇보다 의무를 우선하셨어.\n그 영웅의 후손이라면 나도 같은 의무에 헌신해야겠지."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A71BCDD17FA13042883914278C1FDF425EE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "726E76089505194E5358A25823DE5175D025"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F77DECE7A01F749A65A0A5569986BD5238B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "662CA5DB8AA9094B28280B36C0A7E8EB0879",
                        "defaultText": "하지만 자유 없이 짊어진 의무가 고귀할까?\n생명 없는 책무가 정말 필요할까?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "91A0B8CC4EFD774D9679DC64179D0ABD5088",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8720683689CD29425348F21772C2C56214F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE76578E3ABD9740216A6793143C7E3166A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D0AC18C4256574EAB798FD8991701CC6268",
                        "defaultText": "무슨 말을 하려는지 모르겠어, 칼레발라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FFE64FEF4BE65548C82A8AF808EEF3AD872F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E136ACE985FE5245419ADE972B5E694C8E2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E36F38286E627240B93A43A7F4838140907A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "645A020B4A93054E54685DF186F0077DA4F0",
                        "defaultText": "위에서 강요한 의무가 아니라 나 자신을 위해 살기로 한\n선택이 옳았는지 계속 고민했어."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "60948D7C4FFF9543648B5A4797BD533B982C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A037E75B74785642937AD701249E14F65E07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85BFA5E14B8125419579EAF866BB9864CC62"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D3F9E26864BC74F670ABF7066565595EB98",
                        "defaultText": "너도 언젠가는 같은 의문을 품었겠지. 네 답은 뭐지, 네 번째 그릇?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "76309F5B6CBF874DAC2960F3B8420BD54412",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "863E7E5D5086D441BC0830A489E06FD87D6B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8DA165AC93119847E778E036574198570F12",
                        "defaultText": "어떤 경우에도 의무가 우선이야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8D98FA0940D8704E344B6F630D6A6BA6DD07",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3F56A1130DD84445926BFFC4D41A44DCBB6C",
                        "defaultText": "언제나 자유를 우선해야 해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E085B771437E864E8C3978125DB18AFD7F6A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "EFEA6CEB6E5C314D342AF7085C22AA4A8918",
                        "defaultText": "가치관도 상황에 맞춰야 해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D15FF04549B0614AF80B73F21BA676BB9807",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "duty",
                            "freedom",
                            "situation",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "3344F997787B184A638A9C1180D3A6790100"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "989F328A0A5A4249418916655554EB3B5D01"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "duty"
                },
                "indent": 0,
                "uid": "0B90B5BE4FCFF148F22ABD52E342A5D446DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "D79F59B21282D5459558D3333AC1D9A915B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A9AF8B114CE1048728907D9200BA3B64128"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01D4F4B67D21E04E1F5A8C92915999571EC0",
                        "defaultText": "하지만 자아를 희생한다면 정말 끝까지 의무를 따를 수 있을까?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "60DB8A7F2632F241D55A05841D65FB94A20C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "290FEC66374A93468D2A1BD4087B264B1465"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "171A87E86094D24F60892D44FBE1C96B0665"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "41689A8F8C0F57428519CEF224047A253EBD",
                        "defaultText": "의무를 따르고 싶은지 아닌지의 문제가 아니야.\n어떤 사람에게는 선택이 아니라 필수니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6743119E6DFF9444822ABF558C0B313CB05E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32BC9DC5858B424425887181F9A3AF79F551"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D4FC5BF8CBFA242076A2A735649CFD726A9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D8775F233503E74B5D3939481933EBC425E7",
                        "defaultText": "공적인 역할에 가려져 사생활이 계속 희생되는 게\n조금도 걱정되지 않는다는 말이야?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47A7C57131FEE4413C794AF83B42A1445231",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A2BDCD677E5E74666880777E21075EF69CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1BA779D4E3BC643EE39FF55CDDCDE2D8BDD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44F844A74095C8492C1968C5AA99B5BC84D6",
                        "defaultText": "물론 걱정돼. 하지만 받아들이기로 했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ABF4D8E210A6314509896115191E2AA40F29",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "E4A7D2E34ADF04481E3A90A3B0C508227B8B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "freedom"
                },
                "indent": 0,
                "uid": "E2431FB80F91F3412C284247E37706866554"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "B32C62BB849F1145FB195FD431EA449F87B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED36E2D0617CD7411059F94244CFBB37B102"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D2A3E494100F14D555BA84882B5D3BCE47B",
                        "defaultText": "하지만 그건 책임에서 달아나는 것과 같지 않아? 때로는 타협도 필요해."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A2EA687472E3442EE3BB0577EC4C18843F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "013C3CF92F91744D702AA80101DC4768938F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD1528743C93254299880C4223ED7E0E314B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E3A91A077D0D444825864310A24C7892180",
                        "defaultText": "경험에서 우러나온 말이야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3A8655CB85C2F24C9F3A6AA26A08C2EEA406",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3F5E02688A436410A280735038CE64FA075"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "393D094F81AC5142FC891B72151BDC02AE89"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6727318D4109534A112AF501E238E3978A19",
                        "defaultText": "하! 곧장 본질을 찌르는 솔직함이 마음에 드네.\n그래, 어쩌면 난 불안하게 만들던 삶에서 도망쳤어."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A13639D4AE8B14C6C380E13534E15BC3BF8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C165A09D15CCD1427C693918B008DFD69A1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "248E2C043A1BA94B778A2312FABC8F7D8BFF",
                        "defaultText": "하지만 넌... 달라 보여."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "017242862E37F340AD6B89B7B2DC24379A7D",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "1AAA0DB43484434F8F1B9EE7165C411A362E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "situation"
                },
                "indent": 0,
                "uid": "43890FC94BBC204210681F21790B11349C06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33CEB83C5B4D9644F8593A264CED574C953E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2846AFFE5AD6424DFB99C3331648DCF5EC58",
                        "defaultText": "참으로 현명한 태도야. 모든 것이 그래야 하듯 완벽한 균형이지."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "52136F668F3D2641DC881505217083AF25D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DC024ED48216943DF480CC55A32440D3E4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CDA5C619457E840353A4B68A406AEA376E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB7CEDB8888BB647D03BC91934DDCC9369B2",
                        "defaultText": "하지만 그런 균형은 모두에게 허락된 사치가 아니야. 그리고 어쩌면..."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2D0A343026C614DEF68D574206BEA9CC5EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0BEEAAB6FAA104FD03A7E15E788566C4B73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EEA7EF977B022446199ABA52D53B796CD31E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A27439C94D6AC64A8189D5155A274CF218B0",
                        "defaultText": "어쩌면 난 그 몇 안 되는 예외일지도 몰라.\n그래, 마음 깊은 곳에서는... 늘 알고 있었어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2EC913729D7B54C42089F382B2CB4EB14C5",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "3BF912663BADD9488B390E977CED3F8F79C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "52C622C54F032148CC0A9CE99B5D2F701886"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C41EB12571F9D145A32A1421A8B6863B23D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC0B9CD08AABB846007B3E52CB7270354DAE",
                        "defaultText": "난 언제나 의무가 버겁다고 생각했어.\n평생 하루도 빠짐없이 ‘평범하게’ 태어났기를 바랐지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0060A1A087B22640658AAB53C0161505AA16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E455E2BA930AF44DB48A7E35199DB0882D71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF0B417D1B41754ED07A76F6EE1FE03CBEDF",
                        "defaultText": "하지만 네 이기심 때문에 수많은 사람이 고통받을 것을 안다면\n정말 모든 걸 놓을 수 있을까?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4F35529E5DD6D84A5A4A3CE5A50DA20781C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8821D04452D3840051BF93826DE9AF6BC96"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB4BF248703E974EBB38C6E3517E340A08E6",
                        "defaultText": "지금의 내 모습을 선택한 건 아니지만...\n다른 누구도 이 고통을 겪지 않게 하기로 선택했어.\n그게 내 정체성이며 내 삶에 가치를 주는 것이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "502143278DA710480B2874983264A5F23C4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07356EA46C77C3490F1B63E8B0F0AF08A4A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "612DFCCF7443B74C43285A354A4E09408F09"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "163D0F758EAFE142581B68F331C236E18F0F",
                        "defaultText": "그게 당신의 답인가, 파라트라스 님?"
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2DFC635B76A7084EA27A51D934BCA82E4C57",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7DC251D48F6714DE54AE108B6EF84534EC8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5FF1E53A384A484F6A3AB7D2017D0C5BCD8C",
                        "defaultText": "그래. 내 결의는 흔들리지 않아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8A4CC74A6300C842588A73389908A7CCAE69",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "10D181766E069148B89BD331C71A45B29A08",
                        "defaultText": "지금으로서는 그래."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C4D159927D11E647A669FC2530613BD9FEE8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "yes",
                            "yes",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B30D74E0C7D684A113A765214A7C9D1EE5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B45024F4871C8945661A9E02292A366054E5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "yes"
                },
                "indent": 0,
                "uid": "42A288C982E8184FFA3A9A62C047ADB66484"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "C55C88625842A24DA21B2FD41639DBA95E76"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1445FE7F1DBD274DE25989F1A4513A8F822E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1A23AA981E2074D357A018310E186C0FFED",
                        "defaultText": "수십 년이 지나 닮은 손주들이 다시 만났네!\n동전의 양면처럼 나란히 마주 섰네."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B7A12A881DB94247E23B4FB3C15C77028D44",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3418A65429D2E84AA11897B69E519E3F433F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE70245167FA934EB07B1064E283A0100C83",
                        "defaultText": "우리는 다를지 몰라도 그릇으로서 보이는 의지는\n내 할머니를 떠올리게 해, 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8351E05E1172784BDA59FFF04990EDA43D39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A5093C0317DC245A13A94330DF5DF939EBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            1,
                            7,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC863A927EA736402C687C16093D97CF62DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A27E7DB632A5B542F9995D48A10519BA1AF0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA2B28E52ECD824BCB5839070D86D4D85962",
                        "defaultText": "내가 제피라를 떠올리게 한다고!? 저, 정말 엄청난 칭찬이야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "08D9FE3A88A4004B967B3D34E6A21294B243",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED9565F5394087426A6B0586F0E7CE21096A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F2E09E36E9DC8431E2BF4A47D823DE81782"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A31C73F9A9A8342899B2147DF8F9A3EDB4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F160B232243AE14E1F4879D817C1FA556AA0",
                        "defaultText": "할머니도 네가 이걸 가지면 기뻐하셨을 것 같아."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7BD6E4DA3DC7D74F6C09EDF1E622F20305AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "105884C3454A22403078B7E273D6670A8ED5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80F79D2553A1284F562B66C1AE48F9EB63E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB2174248C0E354B3F69C4276C31007EA5F2",
                        "defaultText": "잠깐, 이건..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "265F5CDB37E94046966AE1E160AAAC42DC65",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66241A6C68FA364EBB98A0385112E14684D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "771BAD5826B6B64B9658B425188BE7A8F46E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1549B6E9909AB24B5C5B45E21BACE42A9FC3",
                        "defaultText": "할머니의 마나 펜던트야. 마나 생성을 강화하는 강력한 촉매지.\n이만큼 희귀한 물건은 한 손으로 꼽을 정도야."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E98737C450F6F841937BFFE3898E0124C8FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDDC52A823C9F446A5984902AC4FF525C210"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F92B8E3A52D9B347E95B1B130CA5D3B63810",
                        "defaultText": "제피라 할머니는 엄청난 마력을 지녔지만 마나 제어는 뛰어나지 않았어."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0970E404A763447092B44D43E168B214648",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "616ACDB8750D874D486AA69442657C6F9A93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "117929783F332444F038A695FB4D680C4589"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84BDE2E44271A74F577A2C474C80C564E6BE",
                        "defaultText": "아이러니하게도 지금 너도 비슷한 상황인 것 같군. 분명 도움이 될 거야."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C87529B631206424B7B0B238237EED4265D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1ED83D728FBA57494E79870763508C011AD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24038079185DC84A6F19C6D37F9819E50C7B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0676B66B97BF33438A2AD84489D92520A67C",
                        "defaultText": "“도움”이라고? 이건 국보나 다름없어! 정말 나한테 줘도 괜찮은 거야!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "89A0CC6E9BD5D54D85790BA1721E4D73C1B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF763CD56C3E744B8418CEF45097CFDEC374"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02D90DD48C18124CE7097618A3B87FFF21E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E8EC8A982DF914DA86B3780A9372ADA63A0",
                        "defaultText": "받아 줘. 그 대가로 바라는 건 계속 너희 일행과 함께하는 것뿐이야.\n네 행동은 내 노래에 진정한 영감을 주거든."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2F630B28537E9245137B3121752F2179AB69",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EB726448505B343DE6B00367702D98EB2B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBAC02D118DB2545372AE9E362B168336732"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D307D8892E20F7484318C8F22A0CDE9DC3A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0311BE5092E2034F93688BB62C6E859C7032",
                    "parameters": {
                        "values": [
                            "971C11145F39E2448C6AA5A3D74C31D0331C",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FF4BC593E9E7544D55AF0D5615B6ABD313B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EEC637476CA0C44DB639DD3814A41B3AF9DE",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6FEFCFCE8C1B1347762ADB17270E007C3578"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D71A4FFB152EF543EB2A2B640721247F4B58"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "you get the Mana Pendant"
                },
                "indent": 0,
                "uid": "B4D9FC41261CA84B703858B9998E9ED0AD6C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85CAA8850BCE114780798524F22921E05EB9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0334BCA159B2041662B550114F65B4874BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "376FB83E60FB77476C292C388DC2A8648E7D",
                        "defaultText": "그럼... 고마워, 칼레발라."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "94B7C4396749674DB3896EB4983BCE5EB39E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F84B83CD60BF834F01397BD7F127B98E977A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E89692796247D64BD15A50E458BAD6692980"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "327BD5641187234FBB096358E8A2C2A7BF4A",
                        "defaultText": "그럴 필요 없어. 아, 그리고 마지막으로 하나만..."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6BFCF5ED52CA754BCE2B39903046B03099CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30374CDC4B49C745721AC8A867F8874EFEC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57BA2BF35A3F264D727AC6526837FFB8833A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF3078108221144B846889463F2B6F055AE5",
                        "defaultText": "뭔데...?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3BEC3F668ECF934CD27A75253BF36FAA76A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8A518A98DEF94411B7854C17BB0BFAC5AF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1C4309981CC014BA24B4002BE01A4745FF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "675328C1232A2545682ABDC3B9BC2A80E3C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24EB07F8281AB846AD59D026F2CE6A2F900F",
                        "defaultText": "아마란스 교단을 조심해. 그들의 주된 목적은\n마왕의 부활보다 훨씬 끔찍한 것일지도 몰라."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E4005F1E7AE7C94F291A105128400C51828C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6F1A32B4D730541102964288610BACED55D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2BDD84629D463429A5BCD01F0C2D10D51B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EBE77E1189D0354012996D338E88E808000B",
                        "defaultText": "마왕보다 더 끔찍한 것? 하... 솔직히 상상하기 어렵군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B34B38E635D85445A28DF13642FF133E9D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB50E6CB742D9647356BC2E1FA80CBE94450"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A42DC6FE406425442D1ADF57CE2534C16A92"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD76E838162C874B5A8BD5038B4243343149",
                        "defaultText": "이해할 수는 없지만 주의할게-- 콜록!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CEAE5C9682EF7441BE882209CA4DDA37DEFE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1CA4F9A3F54024ABF7B2C9682BCEF3384F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D93E84CB50ED2742F96AD87169C411148835"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "35A4BE8672D29148886AF886D2CE2C6FFC97",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34D03EC478FCA64870390F82E0FCB8D474D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "535027105140F44C382927E7C64ED14C612E",
                        "defaultText": "지금 네 가장 큰 바람이 학살을 막는 것임을 알아.\n운명의 딸이여, 자신과 세상에 평화를 가져오라."
                    },
                    "position": 0,
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E8014537905662491C486F2038E8B383D525",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D2949C5011698040AB09C3059B95C388495F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7B1FD974E925145445B44642DC9FAA4E8F0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D24A001D4E54274C5E5B0305EE5B4558FC27"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "duration": 72,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B88075FD7E137546DC688C834145507B3631"
            }
        ],
        "livePreviewDisabled": true,
        "localizableStrings": {
            "5C356A5B9EE198436C2917070A6795FCB06B": {
                "t": "Wait a moment. You're...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B433D90C3F8BB14D40788B25062E2165F17F"
                }
            },
            "E500C8B8377FD64DFB8963A6B1F392362EF9": {
                "t": "Your trusted bard, lover of good wines.\nAlways ready to follow the Vassal to the front lines.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "921B8D4670392540D789BD818DDD241338B2"
                }
            },
            "61C1F9517EA0154BD61B59A050C7BB407615": {
                "t": "Kalevala. I didn't notice that you were still following us.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "92CCB66527B2554EE3594462FD794E30AA79"
                }
            },
            "48A7B3EF4170F3496A682622C27C2A69B47E": {
                "t": "You were a little... out of control last night, so you didn't notice me. But Sir Ornières let me join you a while back.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "D5ABD3EE9FBDA24FCD88A7D6651C31141F46"
                }
            },
            "A0E98ECC3F23A543EE398060E1944DE9D80F": {
                "t": "That {LT:1}... Always taking the initiative behind my back. Hmph! I need to put him in his place.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "32EE40CB7A1317458839E3A28A8BC8608DA1"
                }
            },
            "5603F2A05F730246641B58416709869C1D66": {
                "t": "Regarding that, are you feeling better now?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "48695054560DA340936A3003C338C2323905"
                }
            },
            "FD2A75B783F7C64F764A1C144AEBA29D46C3": {
                "t": "Not really, but I'll be all right soon. Hopefully. Why are you so interested in me?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F682289009ED014B619A65E96E06F18C623A"
                }
            },
            "FC0651114FECF3408C69DCE50D6C7BC504A2": {
                "t": "If that answer you wish to earn,\nmy question awaits you in turn.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "500C24A78CF37746B96AC8D10DA8917F42B8"
                }
            },
            "9B4500998614C64F101BBA81CFF6BE662487": {
                "t": "You know of Zephira, correct?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "9CA1897F1CFAE04A7658CBA7B10EA6E0B4F4"
                }
            },
            "94229088953A614C2F2A9D763268018A6132": {
                "t": "The {SP:2}{C:1}Second Vassal{C:0}? Of course! I've always admired her strong resolve in controlling the Demon.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3A9B5921126C914B0F6898149510C502FF9E"
                }
            },
            "A33007CF11BBC54E9D488F91C41033B09B56": {
                "t": "I even have a painting of her in my room...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "01D7B99F89FA484C3949BCE2739B204FE432"
                }
            },
            "1351702F3A8284452C6AD29314E1D9369525": {
                "t": "She was my grandmother.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "51B4680D049C754B0A895E1944F3693DE715"
                }
            },
            "3F522F7B5DC255436568DED34077FC3A2592": {
                "t": "Your grand--",
                "d": {
                    "eid": "62B6F9310F68914C631B3CE7874FC27CC10B"
                }
            },
            "B0D4871B5C61D148E99952C43467102FB804": {
                "t": "Oh wow. You don't look very legendary...",
                "d": {
                    "eid": "FED2757430369748FF4BF9F47ACBFC938ED1"
                }
            },
            "EF52AEE431F1B140FB380BF47B97ED4E290F": {
                "t": "Indeed, this knowledge may be surprising to most. I'm aware I don't have the same noble 'aura' as hers.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "BE1A2AB76761154AA2391D6464447FDDD95A"
                }
            },
            "70D1D55355C026457C2BFBC6D50AE701A17B": {
                "t": "I take that as a compliment, as that is indeed how I'd define myself.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "34E7E32929BA6544B589E1E08278F7A18ACF"
                }
            },
            "542964629711C44BC17B0764C20B84AA4308": {
                "t": "What are you trying to say?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "40E5B3E40BC57640E03B4910C504C7D6DDC4"
                }
            },
            "A6FE7169274F43492B98B420E2D981E057EF": {
                "t": "Granny Zephira put her duty above everything else. As a descendant of that hero, I'd have to dedicate myself to the same duty too.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "A71BCDD17FA13042883914278C1FDF425EE4"
                }
            },
            "662CA5DB8AA9094B28280B36C0A7E8EB0879": {
                "t": "But oh, is duty noble if borne without freedom?\nThese lifeless obligations, do you need 'em?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "91A0B8CC4EFD774D9679DC64179D0ABD5088"
                }
            },
            "9D0AC18C4256574EAB798FD8991701CC6268": {
                "t": "I don't understand what you're getting at, Kalevala.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FFE64FEF4BE65548C82A8AF808EEF3AD872F"
                }
            },
            "645A020B4A93054E54685DF186F0077DA4F0": {
                "t": "I've been wondering if what I did was right -- to live for myself rather than for a duty imposed on me from above.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "60948D7C4FFF9543648B5A4797BD533B982C"
                }
            },
            "1D3F9E26864BC74F670ABF7066565595EB98": {
                "t": "Surely, you must've faced the same doubts at some point. What's your answer, Fourth Vassal?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "76309F5B6CBF874DAC2960F3B8420BD54412"
                }
            },
            "8DA165AC93119847E778E036574198570F12": {
                "t": "Your duty is absolute.",
                "d": {
                    "eid": "8D98FA0940D8704E344B6F630D6A6BA6DD07"
                }
            },
            "3F56A1130DD84445926BFFC4D41A44DCBB6C": {
                "t": "Always prioritize your freedom.",
                "d": {
                    "eid": "E085B771437E864E8C3978125DB18AFD7F6A"
                }
            },
            "EFEA6CEB6E5C314D342AF7085C22AA4A8918": {
                "t": "Your values must adapt to the situation.",
                "d": {
                    "eid": "D15FF04549B0614AF80B73F21BA676BB9807"
                }
            },
            "01D4F4B67D21E04E1F5A8C92915999571EC0": {
                "t": "But can you truly follow your duty to the end, if you sacrifice your sense of self?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "60DB8A7F2632F241D55A05841D65FB94A20C"
                }
            },
            "41689A8F8C0F57428519CEF224047A253EBD": {
                "t": "It's not a matter of wanting to follow my duty or not. For some people, that's not a choice, it's a necessity.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "6743119E6DFF9444822ABF558C0B313CB05E"
                }
            },
            "D8775F233503E74B5D3939481933EBC425E7": {
                "t": "Are you saying that you're not even a little concerned about your personal life constantly being overshadowed by your public role?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "47A7C57131FEE4413C794AF83B42A1445231"
                }
            },
            "44F844A74095C8492C1968C5AA99B5BC84D6": {
                "t": "I actually AM concerned, but I've come to accept it.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "ABF4D8E210A6314509896115191E2AA40F29"
                }
            },
            "2D2A3E494100F14D555BA84882B5D3BCE47B": {
                "t": "But isn't that tantamount to running away from your responsibilities? Sometimes making compromises is necessary.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "3A2EA687472E3442EE3BB0577EC4C18843F6"
                }
            },
            "6E3A91A077D0D444825864310A24C7892180": {
                "t": "Are you speaking from experience?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3A8655CB85C2F24C9F3A6AA26A08C2EEA406"
                }
            },
            "6727318D4109534A112AF501E238E3978A19": {
                "t": "Hah! Straight to the point, I love your candor. Yes, maybe I escaped from a life that made me anxious.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "4A13639D4AE8B14C6C380E13534E15BC3BF8"
                }
            },
            "248E2C043A1BA94B778A2312FABC8F7D8BFF": {
                "t": "But you... You seem different.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "017242862E37F340AD6B89B7B2DC24379A7D"
                }
            },
            "2846AFFE5AD6424DFB99C3331648DCF5EC58": {
                "t": "It's a wise stance indeed. Perfectly balanced, as all things should be.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "52136F668F3D2641DC881505217083AF25D4"
                }
            },
            "DB7CEDB8888BB647D03BC91934DDCC9369B2": {
                "t": "But that kind of balance is a luxury that not all people are allowed to have. And perhaps...",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "B2D0A343026C614DEF68D574206BEA9CC5EF"
                }
            },
            "A27439C94D6AC64A8189D5155A274CF218B0": {
                "t": "Perhaps I'm one of those few exceptions. Yes, deep down... I've always known.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F2EC913729D7B54C42089F382B2CB4EB14C5"
                }
            },
            "EC0B9CD08AABB846007B3E52CB7270354DAE": {
                "t": "I've always thought that my duties were exhausting. Every single day of my life I wished I was born... 'normal'.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0060A1A087B22640658AAB53C0161505AA16"
                }
            },
            "DF0B417D1B41754ED07A76F6EE1FE03CBEDF": {
                "t": "And yet, when you are aware that so many people would suffer for your selfishness, can you really let it all go?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4F35529E5DD6D84A5A4A3CE5A50DA20781C0"
                }
            },
            "DB4BF248703E974EBB38C6E3517E340A08E6": {
                "t": "I didn't choose to be what I am now, but... I chose not to let anyone else experience this pain. And that's my identity, what gives value to my life.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "502143278DA710480B2874983264A5F23C4D"
                }
            },
            "163D0F758EAFE142581B68F331C236E18F0F": {
                "t": "So, that's your answer, Lady Faratras?",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "2DFC635B76A7084EA27A51D934BCA82E4C57"
                }
            },
            "5FF1E53A384A484F6A3AB7D2017D0C5BCD8C": {
                "t": "Yes. My resolve won't waver.",
                "d": {
                    "eid": "8A4CC74A6300C842588A73389908A7CCAE69"
                }
            },
            "10D181766E069148B89BD331C71A45B29A08": {
                "t": "For the time being, yes.",
                "d": {
                    "eid": "C4D159927D11E647A669FC2530613BD9FEE8"
                }
            },
            "B1A23AA981E2074D357A018310E186C0FFED": {
                "t": "Decades later, similar grandchildren rejoin!\nHere they are, like two sides of the same coin.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "B7A12A881DB94247E23B4FB3C15C77028D44"
                }
            },
            "AE70245167FA934EB07B1064E283A0100C83": {
                "t": "We may be different, Lady Faratras, but your resolve as the Vassal reminds me of my grandmother.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "8351E05E1172784BDA59FFF04990EDA43D39"
                }
            },
            "FA2B28E52ECD824BCB5839070D86D4D85962": {
                "t": "I remind him of Zephira!? T-That's a huge compliment for me!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "08D9FE3A88A4004B967B3D34E6A21294B243"
                }
            },
            "F160B232243AE14E1F4879D817C1FA556AA0": {
                "t": "I think she might've been happy if you had this.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "7BD6E4DA3DC7D74F6C09EDF1E622F20305AE"
                }
            },
            "EB2174248C0E354B3F69C4276C31007EA5F2": {
                "t": "Wait, this is...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "265F5CDB37E94046966AE1E160AAAC42DC65"
                }
            },
            "1549B6E9909AB24B5C5B45E21BACE42A9FC3": {
                "t": "It's her Mana Pendant, a powerful catalyst that enhances one's Mana-generation. You can count objects of such rarity on the fingers of one hand.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "E98737C450F6F841937BFFE3898E0124C8FB"
                }
            },
            "F92B8E3A52D9B347E95B1B130CA5D3B63810": {
                "t": "Granny Zephira's Mana control wasn't the best, despite having a ridiculous amount of magic power.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "C0970E404A763447092B44D43E168B214648"
                }
            },
            "84BDE2E44271A74F577A2C474C80C564E6BE": {
                "t": "And ironically, it seems you're in a similar situation now. I'm sure this could prove useful.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "3C87529B631206424B7B0B238237EED4265D"
                }
            },
            "0676B66B97BF33438A2AD84489D92520A67C": {
                "t": "\"Useful\"? This is akin to a national treasure! Are you even sure you want to give it to me!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "89A0CC6E9BD5D54D85790BA1721E4D73C1B6"
                }
            },
            "5E8EC8A982DF914DA86B3780A9372ADA63A0": {
                "t": "Please accept it. In return, all I ask is to continue to be a part of your group. Your actions are truly inspiring for my songs.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "2F630B28537E9245137B3121752F2179AB69"
                }
            },
            "376FB83E60FB77476C292C388DC2A8648E7D": {
                "t": "Well... Thank you, Kalevala.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "94B7C4396749674DB3896EB4983BCE5EB39E"
                }
            },
            "327BD5641187234FBB096358E8A2C2A7BF4A": {
                "t": "No need for that. Oh, and one last thing...",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "6BFCF5ED52CA754BCE2B39903046B03099CC"
                }
            },
            "FF3078108221144B846889463F2B6F055AE5": {
                "t": "Yes...?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3BEC3F668ECF934CD27A75253BF36FAA76A8"
                }
            },
            "24EB07F8281AB846AD59D026F2CE6A2F900F": {
                "t": "Beware of the Cult of Amaranth. Their primary objective may be something far worse than the resurrection of the Demon King.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "E4005F1E7AE7C94F291A105128400C51828C"
                }
            },
            "EBE77E1189D0354012996D338E88E808000B": {
                "t": "Worse than the Demon King? Hah... It's hard to imagine, honestly.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4B34B38E635D85445A28DF13642FF133E9D8"
                }
            },
            "CD76E838162C874B5A8BD5038B4243343149": {
                "t": "I don't understand, but I'll pay attention-- Cough!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CEAE5C9682EF7441BE882209CA4DDA37DEFE"
                }
            },
            "535027105140F44C382927E7C64ED14C612E": {
                "t": "I understand that your main concern now is to avoid a slaughter. Go and bring peace to thyself and the world, fate's daughter.",
                "d": {
                    "cid": "35A4BE8672D29148886AF886D2CE2C6FFC97",
                    "eid": "E8014537905662491C486F2038E8B383D525"
                }
            }
        },
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}