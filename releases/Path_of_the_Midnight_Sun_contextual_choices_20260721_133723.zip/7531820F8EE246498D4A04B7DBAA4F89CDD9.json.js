GS.dataCache['7531820F8EE246498D4A04B7DBAA4F89CDD9'] = {
    "uid": "7531820F8EE246498D4A04B7DBAA4F89CDD9",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "06.P1 - Nana",
        "type": "vn.scene",
        "parentId": "41A72FC066D381405D48FA1251543766AF13",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 1,
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "Legame",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Legame Celia",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "Nana",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4737FC6F54F4254B4D0869987CE4D85FECA7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71AE0C003B4A884BA92A3407D63A33DD1726"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2B63D54B42DA644C251860068C38F3C0FF8D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "risposta2",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "F37FE3FC1C0C884F0B0ABEA985A0A3498083"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "67E1F13B2289624E2C49BDD9CCBADC8869F8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F51DFFA577AD8742005AFCC1A2F29FC9BF3D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FB129DA35883F142C4199075348B98C25503",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "497EE6D3479457410E0806F29A7DA05184A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64340ABF18823647592AFC89C58B6BF710DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC55407F6BCC134590794CF20EC789391881",
                        "defaultText": "이봐, 이봐!!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "886025E849B14447774A245638CB96317303",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F6FAC5D11DDE742BE1A68C8264A538831BC"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "Legame",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB0E87CE67CAF5463678D6814D598B772070"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Legame",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "248DDAC9384A85447A1A13688744848DB272"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B743BC167B46D54DB37836D764BDDE24200F",
                        "defaultText": "아... {W:150}너구나, 나나. {W:150}아까는 고마웠어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "3267AC894BFD864FB9591F072EB3485216DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DEB6BBCF3629C44E0238FAE1D7280FEC14CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C6DBAB49F6D7646528937A898D633B82FBE",
                        "defaultText": "그런데 왜 항상 날 빤히 쳐다보는 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "7C5FBD2C7E82D343F32B56C5AD6C30336DE5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "545356A08591944CD9890CE2CA37ED0A1D0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C271E1AC7A0BE44CCC5B85485C9C287ED7FA"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "B046EDE29095C8426F3BE779544CEEF26E88"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24318C23526726466268D4175E79439C5FBC",
                        "defaultText": "아... {W:150}안녕, 꼬마야. {W:150}왜 계속 날 빤히 보는지는 모르겠지만\n도적들과 싸울 때 도와줘서 고마워."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "7DD92C7A5D7E764C4D998CB1356CA534526C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5C51D4418F3DE2495499F33003C4DB428402"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Nana",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A08A4A541591B74D7518E29670233C02D54A",
                        "defaultText": "Nana"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3053D72C7533564058383829D02D92DE7199",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Child"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Nana",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4AAEDEE178E05147428B25A33FC7D49BC98C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "98673DCF38BDD742A80A91C0D16965AD46EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "391F70701643534B269804332196A22B2C61"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "14D584C868F0C048FE7A36356CC742453C98",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line8_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "7874A82A1820B64B6A7AFC766B974BB8BBD8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "D3EF60999810A34B221984830B976926F281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A3C7EFCF948CD04BBB881C59CB2D9FDA225F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50E301FF2EEBD844B648FB035ED87CA8F8E3",
                        "defaultText": "난 \"꼬마\"가 아니야! {W:150}이름은 나나! {W:150}나-{W:40}나-{W:40}라-{W:40}고!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8E80BCB07668854E4D89785879590F5D4996",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "756B4EA28AA9154DFC7A325466A6DB6F4E75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDBCC6D00CDC244BA459384672BFD581B5EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B37687784FA686433D49D6B4218B9B6EA5FB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0D8B24E6D642141F818AE37DD3375AF3D71",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C65DD66B44D6284ACD8BE4D19219D869D638",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FF01F3109FB8B147CA1A5CB9DA0884507680"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "388092B59F2628478A7BD5940C819798B240"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BFD1A218F9B234F627AF6B1182D993A1130",
                        "defaultText": "난 사람들을 항상 빤히 봐! {W:150}나 같은 천재는 최대한 많이 배우려고 그러는 거야!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2123770A8A93F246C68B89643139A5FE128E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F256E0B73FF1484F326AD5539717B49E4080"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "442D19E9269E0348D35925A1405B3EE2E3A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E18C51EA592DF2482C1879A3C983341EED41",
                        "defaultText": "어... {W:150}그래. {W:150}그래서 정확히 뭘 배웠는데?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EC9C8FF275E4A7413438C0B14F02EBD6495C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3635C314D8DF4438C89F94310CC893DC901"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E56754933B12A34A4818E3F963293F49437E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2B177F92320A74CA108BBD96FDDAB0B6423"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B40A60FC8907064853993A4041B3350C250A",
                        "defaultText": "어머? {W:150}내가 너무 눈부셔서 네 관심을 끈 모양이네."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "31BBA3646E9D2342778B41E44BF20F9E1877",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE352848413FF9482C9AC349193AFB5C6690"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DF75E45448216440598735895212080980C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABFBDA220280F24AD60B334344E52A87649D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D87C1C6B5F5A304000180232F0EBB8BF5437"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A7123C45175158438D7B780936F346E3EADD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "863D19C043F966405178EBE50296ACBE0E91",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EA9B5002754711483E0A3B949A8D7A98BD8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66FFBEA56A7C54443F9A5E148B4547383130"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E16229E80602894B2D68923766DD81146272",
                        "defaultText": "우웃 우웃!?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4C2C65732461524593892250235843AB4D65",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68922B4A17B5914A0F9AC895D12D236B9CAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E157FCFE3C6E3648A57B4E233061A5424A96"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "816D3C1819C4864ECC6A1658D164B5754E72",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line32_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA19A32989E9734A1049F0F87CB63C2E06B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2BF4B9118B06A84D3A7923A30B22DC37F8F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C094FC73DB8E8421608A1963E998E312CE7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6F41A39012814249C73B86B62DEE84A53D65",
                        "defaultText": "어... {W:150}루코스 앞에서는 \"눈부시다\"는 말을 피하는 게 좋겠어.\n널 납치할지도 몰라."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "837020DA0B22E94D9119CEF1B6EB0066FE7F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EC4A726692D784834681CF278A6F5FAA8F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8649B5435123547B45840B85A208DA9CF21"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B3605C512D4A3648175A68E580D7B89BBD99",
                        "defaultText": "알겠어. {W:150}이 개는 정말 고상한 취향을 가졌네."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ED22136E540B77478228F9A7AAA63A51B741",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "477D637D77EE354E8579C905C7D442EEC969"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85EFE53A3D4EE24D4B8B2D06FC8BCAAFAE67"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53DC5A59118E7348436835C63B0591C89C0D",
                        "defaultText": "이제 무슨 대화를 하는지 모르겠어..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0DF9A20462E5F140912BB91011D1ACDC8E89",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BF836D309B9214D5E3ACD449B1BFD96BA37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A5A5E4404D61443EA39C254F6E4B60D25DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "323A8855829687417458F5022D39F85FDEBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78CB92E48426F549CE192DB2908470AA707C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EADF443C14C4C141F318EAF848DD91A4015C",
                        "defaultText": "숲으로 가."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5686707B433D19451E4907276A7C910FC70E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D84295A284031443D569FE4030A00300B7CE"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E76ED05A7131064BB10AAA20C96B10981DA3",
                        "defaultText": "뭐?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "818ED95459C00847289B96B2ADF7928B5BFB",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F9461F343830A44A364A9052FCD71654A2AE",
                        "defaultText": "어…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5D14864756FC174ADC8AFF36B0E8D55EE777",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A7B949762634D84DDF4AB1A7EB8CA9401F3A",
                        "defaultText": "요즘 애들은…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EF40B5489CCDE24A333817524E50543F3FC9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B1E99C6E378B934A001A6872C8BEA2A25AEF",
                        "defaultText": "무슨 숲?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "328D842512EDA14E649A4EE8D953B0608B35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "risposta",
                            "risposta",
                            "risposta",
                            "risposta2"
                        ]
                    }
                },
                "indent": 0,
                "uid": "7303683021C335418D38F3068C955A568515"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D737C8798A7A15499C28FCA4CC0B094146F2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "risposta"
                },
                "indent": 0,
                "uid": "BACE48F343C2B6403C480BA3EF67FECB172A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "916D1CAF65C728433A581448CFCDF3B55678"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "38B804457D17454FB8994A33FB2217783F96",
                        "defaultText": "잘난 척하지만 네가 나보다 모르는 건 당연해. {W:150}그러니 내 말을 들어."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "92008B4F46A0F44ECF9B7775300480498471",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A55E673476536420F8AB5D3C3FDF8CB9CEB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "risposta2"
                },
                "indent": 0,
                "uid": "235844450680914F8569CF77A9AB167C2434"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6231F090801AB744D22A9B12E552786939CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "913D74A34446324C6848BC35117DDB689F9F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "415C7A745FBF52408258C8490475A0BD531E",
                        "defaultText": "아까 네가 엮였던 도적들... {W:150}은신처는 타르멘 밖의 설원 숲에 있어."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D64992ED4513634DFB1B0D54DC83592EAB55",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4255377425F3944C9778D7B2E8DDC83E57A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B2344426BF194454149C226269AB6E62AF1",
                        "defaultText": "여기 이 조그만 개와 달리 놈들은 정말로 사람을 납치해."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B6284BED5F85344CA47BCE02CD3809F9000F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA5663030C30E9406A5A95751BCB9A43412A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B62D7AD972949845FF484F7608A55F07F8F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A9B74A2A668FF54F5B2B2FF6BC1EB47929AA",
                        "defaultText": "네가 오기 전에 토비아스라는 사람에 관해 말했어...\n{W:200}위대한 나도 더는 알아내지 못했지만."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A1BF80E30A1D7345EC2944C3E3738630D547",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E17EBFBF87BCA44F812B62E51387B8F1C122"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "targetVariable": {
                        "name": "Legame Celia",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "06677D8E067B7149F67B58706AD590CEE51A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Legame Celia",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "833F84718EE8A14CBC48EBF8B9FC72A68B07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "BA0E2AB74018C245A59AE333E21CB53BA1DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53431AFA836AD845044AF3087F7CC1872D98",
                        "defaultText": "토비아스라면 그 여자... {W:100}셀리아가 찾던 사람 아니었어?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "852A18D91ED3274F9588A79625FB093529EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "4A6302567E97C845396AAEE54A4AE1C6697F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7483619D63390244AF6A2244DFC302147C15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B83EDF7122D024CFB6AF55689FA3869745D",
                        "defaultText": "놈들과는 이미 해결할 일이 있어. {W:200}가서 진상을 알아내야겠네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "69CA1A4A51DA6149D55B8BC87C08E3B59726",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3386F5AC8BC0B245C33BA7B6D3ED354F47B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "658E67265AF905450838D3A227FF606FD444"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C50D7D3B7D8C5945645AFFB4B3C816CBD227"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E540542A7E84E84EDD6ABCF1BA420BC82F9A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BE76A0CD1E3C154A3D6B5E11C46AC86D23B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F35F78257475024F3188F438119346D59701"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2AC33EB3046F243AE79B677AD95D034474E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAD441B130F8F44F0A4A2003CA2EA597ECEC",
                        "defaultText": "자아, 특별 정보원 나나의 이야기는 여기까지!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4356F5101720924FFA6AB3D5F93F078E3A45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A24FAEAD3ACA154DCD7B0173CDFB28152AC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7D0C6D884AA944D7339FD31B7C976658D1A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "7ACC8EFD56BE7146C738DC550A975BBC5581"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "941F16F123D41142438ACB111C5B71A7E24B"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "81282E7E3572354A2F7ADD97DF12D45A444D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1BD8725E0D9E344CE22BA0F8C56A41689C28",
                    "parameters": {
                        "values": [
                            "Snowy forest"
                        ]
                    }
                },
                "indent": 1,
                "uid": "A481ED1E4EC5F7423D6AE5453888DEEE71BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D1D322CB2E2602402C88D2428C77C01E35E6",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "9C183FF77213D245F68BA8F20664927BE39F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "C85B260B51F61341809824E73830D0E3F666"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 1",
                        "index": 286,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CC4429238AB0934F90691E269FDB91AF4783",
                        "defaultText": "5846EF1F38D981406F5882B79DCF9EF641AD"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "BC0F80031736154B92694DE937B6E0866992",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 2",
                        "index": 287,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7EDAE6E707A73342A8198A47BE23DAABF466",
                        "defaultText": "7B5400C4157E734BF15955A26E01F8AD3B13"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "56371AE65B14754FA4093CB51109E0E0B8F2",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 3",
                        "index": 288,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D7780D4F2693B8471C7B20C16A2A89F393F2",
                        "defaultText": "32CC41207FE1934C696B6F58CCE56CC74B18"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "7D6F95577B76824B9D493713849E89907CB9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Location SCENE 4",
                        "index": 289,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2E4D502224F8D34D152A8F3715C36386D0E7",
                        "defaultText": "6B44171462B5414F14681F4436A0D46D46A5"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8B895C7037AE544C107A7CE7E54736BB27DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "86CBAC798809154F145BAB489EC84573234C",
                    "parameters": {
                        "values": [
                            "'Sly Owl' Tavern",
                            {
                                "name": "Location SCENE 1",
                                "index": 286,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            0,
                            "FABULOUS ARMORY",
                            {
                                "name": "Location SCENE 2",
                                "index": 287,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            0,
                            "Ornières' bedroom",
                            {
                                "name": "Location SCENE 3",
                                "index": 288,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            5,
                            0,
                            "Snowy forest",
                            {
                                "name": "Location SCENE 4",
                                "index": 289,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            -5,
                            0,
                            "",
                            0,
                            0,
                            0,
                            "",
                            "",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "268EE58E3C41224FFD29C3B564E672DC499D"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 10",
                        "index": 169,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3F8C0F327993D14EA7196B78A46B9DFB9E0F"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Legame",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "20623D627C08F64D773987B3109C9D438E56"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "8973725F2BF2934F8C2A9664BCDEF49D874C"
            }
        ],
        "localizableStrings": {
            "AC55407F6BCC134590794CF20EC789391881": {
                "t": "Hey, HEY!!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "886025E849B14447774A245638CB96317303"
                }
            },
            "B743BC167B46D54DB37836D764BDDE24200F": {
                "t": "Oh... {W:150}it's you, Nana. {W:150}Thanks for earlier.",
                "d": {
                    "cid": 0,
                    "eid": "3267AC894BFD864FB9591F072EB3485216DD"
                }
            },
            "24318C23526726466268D4175E79439C5FBC": {
                "t": "Oh... {W:150}hello there, kid. {W:150}I don't know why you keep staring at me all the time, but thanks for the help against those bandits.",
                "d": {
                    "cid": 0,
                    "eid": "7DD92C7A5D7E764C4D998CB1356CA534526C"
                }
            },
            "50E301FF2EEBD844B648FB035ED87CA8F8E3": {
                "t": "I'm not \"kid\"! {W:150}The name's Nana! {W:150}N-{W:40}A-{W:40}N-{W:40}A!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "8E80BCB07668854E4D89785879590F5D4996"
                }
            },
            "A08A4A541591B74D7518E29670233C02D54A": {
                "t": "Nana",
                "d": {
                    "eid": "3053D72C7533564058383829D02D92DE7199"
                }
            },
            "3BFD1A218F9B234F627AF6B1182D993A1130": {
                "t": "I always stare at people! {W:150}That's what a genius like me does to learn as much as possible!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "2123770A8A93F246C68B89643139A5FE128E"
                }
            },
            "E18C51EA592DF2482C1879A3C983341EED41": {
                "t": "Er... {W:150}sure. {W:150}And what did you learn, exactly?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "EC9C8FF275E4A7413438C0B14F02EBD6495C"
                }
            },
            "B40A60FC8907064853993A4041B3350C250A": {
                "t": "Uh oh? {W:150}I'm dazzling enough to have caught your attention, I see.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "31BBA3646E9D2342778B41E44BF20F9E1877"
                }
            },
            "E16229E80602894B2D68923766DD81146272": {
                "t": "Woot woot!?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "4C2C65732461524593892250235843AB4D65"
                }
            },
            "6F41A39012814249C73B86B62DEE84A53D65": {
                "t": "Huh... {W:150}Better avoid saying things like \"dazzling\" near Luckos, he may kidnap you.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "837020DA0B22E94D9119CEF1B6EB0066FE7F"
                }
            },
            "B3605C512D4A3648175A68E580D7B89BBD99": {
                "t": "I see. {W:150}This dog has truly refined tastes.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "ED22136E540B77478228F9A7AAA63A51B741"
                }
            },
            "53DC5A59118E7348436835C63B0591C89C0D": {
                "t": "I'm not following the conversation anymore...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "0DF9A20462E5F140912BB91011D1ACDC8E89"
                }
            },
            "EADF443C14C4C141F318EAF848DD91A4015C": {
                "t": "Go to the forest.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "5686707B433D19451E4907276A7C910FC70E"
                }
            },
            "E76ED05A7131064BB10AAA20C96B10981DA3": {
                "t": "What?",
                "d": {
                    "eid": "818ED95459C00847289B96B2ADF7928B5BFB"
                }
            },
            "F9461F343830A44A364A9052FCD71654A2AE": {
                "t": "Huh...",
                "d": {
                    "eid": "5D14864756FC174ADC8AFF36B0E8D55EE777"
                }
            },
            "A7B949762634D84DDF4AB1A7EB8CA9401F3A": {
                "t": "Kids these days...",
                "d": {
                    "eid": "EF40B5489CCDE24A333817524E50543F3FC9"
                }
            },
            "B1E99C6E378B934A001A6872C8BEA2A25AEF": {
                "t": "What forest?",
                "d": {
                    "eid": "328D842512EDA14E649A4EE8D953B0608B35"
                }
            },
            "38B804457D17454FB8994A33FB2217783F96": {
                "t": "You're acting superior, but it's a given that you know less than I do. {W:150}So just listen to me.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "92008B4F46A0F44ECF9B7775300480498471"
                }
            },
            "415C7A745FBF52408258C8490475A0BD531E": {
                "t": "The bandits you got involved with earlier... {W:150}Their hideout is in the snowy forest outside Tarmen.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "D64992ED4513634DFB1B0D54DC83592EAB55"
                }
            },
            "7B2344426BF194454149C226269AB6E62AF1": {
                "t": "Unlike this little dog here, they kidnap people for real.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "B6284BED5F85344CA47BCE02CD3809F9000F"
                }
            },
            "A9B74A2A668FF54F5B2B2FF6BC1EB47929AA": {
                "t": "Before you arrived, they were talking about someone named Tobias... {W:200}but even with all my greatness, I couldn't get any more information.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "A1BF80E30A1D7345EC2944C3E3738630D547"
                }
            },
            "53431AFA836AD845044AF3087F7CC1872D98": {
                "t": "Wasn't Tobias the person that lady... {W:100}Celia was looking for?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "852A18D91ED3274F9588A79625FB093529EA"
                }
            },
            "8B83EDF7122D024CFB6AF55689FA3869745D": {
                "t": "Well, they already have a score to settle with me. {W:200}I assume I'll get to the bottom of it.",
                "d": {
                    "cid": 0,
                    "eid": "69CA1A4A51DA6149D55B8BC87C08E3B59726"
                }
            },
            "AAD441B130F8F44F0A4A2003CA2EA597ECEC": {
                "t": "Aaaand, that's all from your special informant Nana!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "4356F5101720924FFA6AB3D5F93F078E3A45"
                }
            },
            "5C6DBAB49F6D7646528937A898D633B82FBE": {
                "t": "Why do you always stare at me, though?",
                "d": {
                    "cid": 0,
                    "eid": "7C5FBD2C7E82D343F32B56C5AD6C30336DE5"
                }
            },
            "F51DFFA577AD8742005AFCC1A2F29FC9BF3D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "FB129DA35883F142C4199075348B98C25503"
                }
            },
            "14D584C868F0C048FE7A36356CC742453C98": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "7874A82A1820B64B6A7AFC766B974BB8BBD8"
                }
            },
            "C0D8B24E6D642141F818AE37DD3375AF3D71": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C65DD66B44D6284ACD8BE4D19219D869D638"
                }
            },
            "A7123C45175158438D7B780936F346E3EADD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "863D19C043F966405178EBE50296ACBE0E91"
                }
            },
            "816D3C1819C4864ECC6A1658D164B5754E72": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "FA19A32989E9734A1049F0F87CB63C2E06B8"
                }
            },
            "E540542A7E84E84EDD6ABCF1BA420BC82F9A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "BE76A0CD1E3C154A3D6B5E11C46AC86D23B3"
                }
            },
            "CC4429238AB0934F90691E269FDB91AF4783": {
                "t": "5846EF1F38D981406F5882B79DCF9EF641AD",
                "d": {
                    "eid": "BC0F80031736154B92694DE937B6E0866992"
                }
            },
            "7EDAE6E707A73342A8198A47BE23DAABF466": {
                "t": "7B5400C4157E734BF15955A26E01F8AD3B13",
                "d": {
                    "eid": "56371AE65B14754FA4093CB51109E0E0B8F2"
                }
            },
            "D7780D4F2693B8471C7B20C16A2A89F393F2": {
                "t": "32CC41207FE1934C696B6F58CCE56CC74B18",
                "d": {
                    "eid": "7D6F95577B76824B9D493713849E89907CB9"
                }
            },
            "2E4D502224F8D34D152A8F3715C36386D0E7": {
                "t": "6B44171462B5414F14681F4436A0D46D46A5",
                "d": {
                    "eid": "8B895C7037AE544C107A7CE7E54736BB27DD"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}