GS.dataCache['2CDF59687EA1A140071A8FE43A3A2484C1CC'] = {
    "uid": "2CDF59687EA1A140071A8FE43A3A2484C1CC",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-1b (Talk) Shiori",
        "type": "vn.scene",
        "parentId": "DF8BAB6145BEB846567B9D3341D445F10851",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 6,
        "localizableStrings": {
            "2C9680945D9B15412278F3626F925B20BD9D": {
                "t": "Hello, Fa!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A45AF40A7847814E719A8825BC337B4260E8"
                }
            },
            "39F53BD846A5724ECA08A422F5178A416093": {
                "t": "You seem to be in a good mood, all things considered. I'm glad.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A48C7B948337254985695EE279C7BF6F0D60"
                }
            },
            "EA898D323BECD34B3868DA494250593531CC": {
                "t": "Oh? You didn't expect that?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "61BCA9057B64C144CB29E4D700115F4F5EF3"
                }
            },
            "BD60031C1825A54A7F397F66D5588F34F093": {
                "t": "After everything that has happened, I was afraid that you might still be suffering.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "35B2F27186FB3443477A81D9AC88DF3250CF"
                }
            },
            "CAAFCDBB87F0D44B782819E0C29EA20BC75A": {
                "t": "But you seem to have adjusted to this new lifestyle, even if only a little.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E1B3795056902245CA6B1545D3EEFC25B527"
                }
            },
            "9ADA1BA168217443B058C162A86C526D5704": {
                "t": "Well... Every day is a challenge.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DB2E9EA721D202424D6B276842AE3452BA25"
                }
            },
            "7E628CFC677634421A198D33B065A840C0B4": {
                "t": "However, everyone in our group has their own problems as well, don't they?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2A5A2C4C2D5BA84394681968408852D99959"
                }
            },
            "98E4F6463263214C4D1AD684F86DA3F5F62C": {
                "t": "Yeah... Apparently, we've all been through a lot.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "067A9FD44DB1874A2B488AB02CD4C08F7884"
                }
            },
            "1A1D3C191FEA514D370B596738999B37E251": {
                "t": "But no one loses heart. We all move forward, despite the hurt and disappointments.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9A497BFE729C1541EA1B2423039E05C060EC"
                }
            },
            "9370E9BF7F41A64BD01B91C827F07D4250DD": {
                "t": "It's getting a little better.",
                "d": {
                    "eid": "FCC8E69186FC8342DF89F979689E15E9C970"
                }
            },
            "A285DDE155532045275AB9613978A7191669": {
                "t": "We can't stop now.",
                "d": {
                    "eid": "BA33198B478A574F191B30E54B464B7ACD57"
                }
            },
            "11EE5CE51B87E24C349B60483ED5A3938168": {
                "t": "That's right! Compared to when we were last in this palace...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D5DA11BF3ACF624AFA5A4921FBEEFDAD4FF2"
                }
            },
            "1762372355F7914D762AE561B711D9776371": {
                "t": "...our future seems a little more hopeful now.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C5E55E4692DCE848924B5A41F4CCCE104F4D"
                }
            },
            "2343B0E56E8BD848584A18F13EA12801AAB9": {
                "t": "Back then, I had just lost everything. But you were there to comfort me.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DFD1F13135305746952987A7CF336F855CE9"
                }
            },
            "D13E81DA7040F6449058C3A575B3F0487B8B": {
                "t": "I want you to know, from the bottom of my heart, how grateful I am to have you as my sister.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D45C52B37934904DE138E9666E8B86A4FA68"
                }
            },
            "F22425A86DBA9547512A5EF4095882D55CC7": {
                "t": "Teh heh! Me too, Fa!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "301A8FBA26315641260A9204BC18B0AA03CD"
                }
            },
            "EB8A541A64124246D14B880814D6433DE6A5": {
                "t": "...I'm still not quite sure what our blood relationship is.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "56BF4D671DE46540053BA492B4751EE9DCDE"
                }
            },
            "5359899C8E3B5047B87BCBC002BE3330A36C": {
                "t": "Huh... that's true.",
                "d": {
                    "eid": "69DC13DD1B665544DB39DA688C74EE03E39F"
                }
            },
            "1966591B515C8844003B3E307AEF925AE1B3": {
                "t": "Is that a problem, though?",
                "d": {
                    "eid": "45B327EF99C99843863BF4D20FF8C3213BDB"
                }
            },
            "060ABADB62C9284EA65B0BF4B0028B407219": {
                "t": "You're my sister. Period.",
                "d": {
                    "eid": "F2FD0F4820C91744032A28C588AB18AFB5B5"
                }
            },
            "47AC37F058A031446B88DFA56B827599C25E": {
                "t": "I wonder if we'll ever find out more about myself?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "691A87DF445E594CB0881904B332D91A26F4"
                }
            },
            "403172AD6C85574DBB2975608B357A0531C0": {
                "t": "Well, even if some things are unknown to us, we still have some certainties in my opinion.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FE2483AC6F805644801997092EB0F9BF5758"
                }
            },
            "B9D0BDB452322641BF589D2464469C3BEA51": {
                "t": "Come on, Fa. I know you can be more... delicate than that.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "544391510CD985449D2B7937AEF0C64AE0AC"
                }
            },
            "29CB2918125B9740B77A2C0600F5A0BCF308": {
                "t": "I don't want to impose myself on her, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FDECD8261B2124449B5A99E5B15C3DDA9929"
                }
            },
            "99D13783293B34422F2A8A807E33F7E64C67": {
                "t": "I find it easier to not dwell on these things too much.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0B175E5E2EBEA541E76948B4E266EE98C009"
                }
            },
            "154C408D58F1254A9D7B822736B59A515328": {
                "t": "What do you mean?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "4575D635322C26433289B643118B29D68AE9"
                }
            },
            "C3778E926FB8944692198555983A2290CBB9": {
                "t": "It's not blood or family ties that determine what a bond should look like.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EAC46D549D7828421F9ABAB55FC08D438E5B"
                }
            },
            "195577EB6A266848D639D8562D9795552A0D": {
                "t": "To me, you'd be my sister even without those red eyes, Shiori.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FE54DBD952E593458A6A551825E795EA61A0"
                }
            },
            "1D3B5E98701FB14A1F68E52987C43513C340": {
                "t": "... ... ...!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "1AFC20CF1A43474F0849F5D6DACFE65734AC"
                }
            },
            "6E0AE1BB6D4ED7477C99E1D218F2FA00AFF8": {
                "t": "That's not fair. You can be really embarrassing sometimes, you know?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9856B3826F38D944D23931A1D132893A8D86"
                }
            },
            "26E7D99A15E1E3490C3B52B8FBCA16214548": {
                "t": "Haha. Perhaps you're right.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "02F4C086086412406128F9750A5158BC0BC9"
                }
            },
            "D285DFFD4D00D843065A2F751279E7A2F8E3": {
                "t": "And don't worry, I'll protect you. I won't let this world ruin your smile.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "14AA5A84256B0647956B46E7317D8A6CF4B6"
                }
            },
            "5EB5FDEE6EB3B541D15AFCA3CC04302E1C0C": {
                "t": "Hey, I'm strong too! And your smile is worth protecting as well!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "582BA96129F3704C3B3BD1A35B9B2E2E7C7C"
                }
            },
            "931BA2D36BF7C4437D883708D8477CCCF620": {
                "t": "Right. Then we'll keep watching each other's backs, sister.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E648B02535C9064F29487CA3BA0A66832018"
                }
            },
            "C754C2AC362ED44C165A65D15DB319FAF1B9": {
                "t": "Hmh! Together, we can do anything!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2133019D5277314C8D2833985976A4557132"
                }
            },
            "F3A716B514D1204F6C6B44968C630255368E": {
                "t": "Hey, sister.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "29AA608B35C7D246775BD392CF427289CD8C"
                }
            },
            "8A8416D4828AE2406F3A4B00AE8927CDD775": {
                "t": "It's true. We have already defeated two Archdemons, and had some time to elaborate our traumas.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "435A9E5E70F1B643535A5366ED1F05EA894E"
                }
            },
            "B8AAE80E8B935644BD09A111943E58FCC6AF": {
                "t": "Although...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "457B5BB22A56B841621BC5A73CAEABF09E99"
                }
            }
        },
        "livePreviewDisabled": false,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "20D5764182B847459E39F3950F302531643C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            4998,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "28A3021B54DF5649F86B1292031B53821BCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8026F2634E8F0140FB68D6277DDEB6D62B7E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A65CC320410B243F74AFD242892CD79A683"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 45
                },
                "indent": 0,
                "uid": "A249C65E60FF784AB68A4E09E79A93C47765"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD9FDDD15E064241C72B9E28992A32D600F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C22A4AAF56C8B942956B79C7676125657E66"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3A716B514D1204F6C6B44968C630255368E",
                        "defaultText": "안녕, 동생아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "29AA608B35C7D246775BD392CF427289CD8C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7378F6E977E3B5466F1A07908F169A52AC34"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "F373A1592D27C24A4E2B43B579AD957D0629"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "3CE99AB26C32484E68795F431B8AA3CF74FA"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "754D541B7E997745462BA2F2D0E092912A6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE3406FD667628428B6B71B681CD29E26752"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C9680945D9B15412278F3626F925B20BD9D",
                        "defaultText": "안녕, 파!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A45AF40A7847814E719A8825BC337B4260E8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09B7C81B817C0540815A7D60BAE9A3BED439"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2490EDA153BCE84A466B4062E2DD846CCDD9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39F53BD846A5724ECA08A422F5178A416093",
                        "defaultText": "상황을 생각하면 기분이 좋아 보여서 다행이야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A48C7B948337254985695EE279C7BF6F0D60",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4E9443F852FD44D4A4B6367EE0EAB638491"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6599E60954A814B058AC112BAD3F3F210AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12E5C06A0F180342548A3E51E7CFBDB1D545"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA898D323BECD34B3868DA494250593531CC",
                        "defaultText": "어라? 그러지 않을 줄 알았어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "61BCA9057B64C144CB29E4D700115F4F5EF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D858F5078550284C9829C5B8B311AA52DEDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "055072283E9DE341EB895B74A849B1523EFA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BD60031C1825A54A7F397F66D5588F34F093",
                        "defaultText": "그동안 많은 일이 있었으니 아직 괴로워하고 있을까 봐 걱정했어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "35B2F27186FB3443477A81D9AC88DF3250CF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32C75D8615D7184BC85A17B8D2DE47832CB5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAAFCDBB87F0D44B782819E0C29EA20BC75A",
                        "defaultText": "그래도 조금은 이 새로운 생활에 적응한 것 같네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E1B3795056902245CA6B1545D3EEFC25B527",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D945C0B37471245D4780967E5FF972995E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE48D536213C3643582944336BC4A60FD14F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            11,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B784B669976344419C1B63A156AEAA33A0E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90F674779E1F784B284B41913DA597A9E546"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9ADA1BA168217443B058C162A86C526D5704",
                        "defaultText": "뭐... 하루하루가 도전이지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB2E9EA721D202424D6B276842AE3452BA25",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20DC30AC17E7154DDC4905276158C341C365"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E628CFC677634421A198D33B065A840C0B4",
                        "defaultText": "하지만 우리 일행은 모두 저마다의 문제가 있잖아?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2A5A2C4C2D5BA84394681968408852D99959",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C25A9CB703C9D14FC7286A201573F75A0FCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D18042A8E9A0843B879EFA46C9D250DAFB7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98E4F6463263214C4D1AD684F86DA3F5F62C",
                        "defaultText": "그래... 우리 모두 많은 일을 겪었나 봐."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "067A9FD44DB1874A2B488AB02CD4C08F7884",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98D3CEB4469C85422D183054B938F6A708EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89F1495B826879467F4B135439FC9B5208CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9DB573430EAD44BC7287F09E790F0DD81AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A1D3C191FEA514D370B596738999B37E251",
                        "defaultText": "그래도 아무도 좌절하지 않아. 상처와 실망을 안고도 계속 앞으로 나아가."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9A497BFE729C1541EA1B2423039E05C060EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BBBD11D34E932488E38C6E614D5ECE190AD"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9370E9BF7F41A64BD01B91C827F07D4250DD",
                        "defaultText": "조금씩 나아지고 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FCC8E69186FC8342DF89F979689E15E9C970",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A285DDE155532045275AB9613978A7191669",
                        "defaultText": "이제 멈출 순 없어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BA33198B478A574F191B30E54B464B7ACD57",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "same",
                            "same",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "63D601157D06C44A645A2FB70200D679B8AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C8CC9D086877144588596B55F5B35E114A56"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "same"
                },
                "indent": 0,
                "uid": "B7AF95455CBFD14D730852A6CBE9A66FCDC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DEA484038B2D8421F7AF8C50528004DA9B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C7F25C777F55740F8786D9484DC7CE14E9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D78960E53FD6F34AFF09CFF68EB47EBC6374"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "11EE5CE51B87E24C349B60483ED5A3938168",
                        "defaultText": "맞아! 우리가 지난번 이 궁전에 왔을 때와 비교하면..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D5DA11BF3ACF624AFA5A4921FBEEFDAD4FF2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAD3F0EB3FF6684F485A3D73E812390DE6C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1762372355F7914D762AE561B711D9776371",
                        "defaultText": "...이제는 미래에 희망이 조금 더 생긴 것 같아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C5E55E4692DCE848924B5A41F4CCCE104F4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B07982434C6414D7B3AB4F207CADB70C4DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50F900F93B3D034CEE991FA4B91FA73241A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A8416D4828AE2406F3A4B00AE8927CDD775",
                        "defaultText": "그래. 대악마 둘을 이미 쓰러뜨렸고, 마음의 상처를 돌아볼 시간도 있었어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "435A9E5E70F1B643535A5366ED1F05EA894E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA7CDCA95D5C774C014BF0E31DD794E95F1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12D053438BEED2423D1B89715282B35C86E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2343B0E56E8BD848584A18F13EA12801AAB9",
                        "defaultText": "그때 난 모든 걸 막 잃은 참이었어. 하지만 네가 곁에서 위로해 줬지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DFD1F13135305746952987A7CF336F855CE9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4203CC2562DA943C558E5F1AAE0B9DE8879"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D13E81DA7040F6449058C3A575B3F0487B8B",
                        "defaultText": "네가 내 동생이라는 사실이 얼마나 고마운지 진심으로 알아줬으면 해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D45C52B37934904DE138E9666E8B86A4FA68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "618285EA1742424E8979BB32B5AE23E8CC36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69AD390D31BB41417D3821B767D1582E4180"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA22CEDE7BA7E443C01A8E50A3EA9DEB4CE4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F22425A86DBA9547512A5EF4095882D55CC7",
                        "defaultText": "에헤헤! 나도 그래, 파!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "301A8FBA26315641260A9204BC18B0AA03CD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EEE75FD7819BA04F1C8909C54F838C973D59"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8AAE80E8B935644BD09A111943E58FCC6AF",
                        "defaultText": "다만..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "457B5BB22A56B841621BC5A73CAEABF09E99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F311A482B185849930928922F120795A002"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            20,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "006FB32A3CA4724431386CE3695866B5E6DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7682BB0C3220F246043B8C8292545DF735FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC0E8961769E474F3D6983D517F01C73CD43"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB8A541A64124246D14B880814D6433DE6A5",
                        "defaultText": "...우리가 정확히 어떤 혈연관계인지는 아직 모르겠어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "56BF4D671DE46540053BA492B4751EE9DCDE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "856ED02F15BA8142360BC6D292E72C34E1C7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5359899C8E3B5047B87BCBC002BE3330A36C",
                        "defaultText": "아… 그러고 보니 그렇네."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69DC13DD1B665544DB39DA688C74EE03E39F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1966591B515C8844003B3E307AEF925AE1B3",
                        "defaultText": "그래도 그게 무슨 상관이야?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "45B327EF99C99843863BF4D20FF8C3213BDB",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "060ABADB62C9284EA65B0BF4B0028B407219",
                        "defaultText": "넌 내 자매야. 그 사실은 변하지 않아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F2FD0F4820C91744032A28C588AB18AFB5B5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "polite",
                            "after choice",
                            "rude",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "36BC1668928D36429849C5D90B7F4A10B8C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "874756A02227C243AF39F3563E018B5BCD88"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "polite"
                },
                "indent": 0,
                "uid": "FF4B5D8E3178A24141395E52D8ACC55094CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "832D24296AB2E6414E3A04420C57E3C4C668"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "47AC37F058A031446B88DFA56B827599C25E",
                        "defaultText": "언젠가 내 정체에 관해서도 더 알게 될까?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "691A87DF445E594CB0881904B332D91A26F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F13F65B345F8744A0384E7769599BA50534"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5BD9799922DF44DBC39DDD516EBEC8F49A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "403172AD6C85574DBB2975608B357A0531C0",
                        "defaultText": "모르는 게 있더라도 확실히 아는 것도 있다고 생각해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE2483AC6F805644801997092EB0F9BF5758",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32CCF38360FE62410E3900D5C54524DBE2D9"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "4DA88E0C71632246F249ECB4CC1BD630E894"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "rude"
                },
                "indent": 0,
                "uid": "29CE0D4035F3114E7968EC918BB4B5F3BD1A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(+cruelty)"
                },
                "indent": 0,
                "uid": "479C1AE15576834E8638F2A08B31E5A6BD16",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4AB133531F45849592BCC475532DDCFCD85"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "255B77BD8888624DF45A7EC6BD3AB5043194"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9D0BDB452322641BF589D2464469C3BEA51",
                        "defaultText": "어서, 파. 좀 더... 섬세하게 말할 수도 있잖아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "544391510CD985449D2B7937AEF0C64AE0AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5E81C5B45BC2844AD88CC52C6106EE66F8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EAEAD0F14593649686BCFC71B19A7DC2622"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29CB2918125B9740B77A2C0600F5A0BCF308",
                        "defaultText": "내 생각을 강요하고 싶지는 않지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FDECD8261B2124449B5A99E5B15C3DDA9929",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AFD6F5905CD7240FA3B72480A9870BEAD5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7ECB7487C92494F0E6A22B2A9F79AEECCB4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99D13783293B34422F2A8A807E33F7E64C67",
                        "defaultText": "이런 일은 너무 깊이 고민하지 않는 편이 마음이 편해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B175E5E2EBEA541E76948B4E266EE98C009",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DE21A037EACD7422E5A9B72C2997473F10D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "2C7909FA78DD3349A4586267BD96633A2D29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90CCE2CC4467A44AA9883A986A845D4E8303"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46DF2A2F24DAA645261969783DC2458FB246"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31A7618B9CC4784C2419BEB4D1221726490D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "154C408D58F1254A9D7B822736B59A515328",
                        "defaultText": "무슨 뜻이야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4575D635322C26433289B643118B29D68AE9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4D41FB1226A2241EE794237ACD5C65739D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95D6FC4D1D7E104FDC1A986078C5B947ADC5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C3778E926FB8944692198555983A2290CBB9",
                        "defaultText": "피나 가족관계가 두 사람의 유대를 정하는 건 아니야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EAC46D549D7828421F9ABAB55FC08D438E5B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "876456A1368F974D67292BC9C88F491B934C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "195577EB6A266848D639D8562D9795552A0D",
                        "defaultText": "그 붉은 눈이 없었어도 넌 내 동생이었을 거야, 시오리."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE54DBD952E593458A6A551825E795EA61A0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42F27685670F004B1F2943616290FBB9E572"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++aff +sanity"
                },
                "indent": 0,
                "uid": "DBCEB3CC596B394F1B0815C618548CAF1714",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            7,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D80AD80958D78745A78A58D2BE3CF156F8E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C78B5E5014534446FD89D5C28DA3E21AC42F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "451231647E8243464558FF436546E4B88971"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D3B5E98701FB14A1F68E52987C43513C340",
                        "defaultText": "... ... ...!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1AFC20CF1A43474F0849F5D6DACFE65734AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA5D591A91B2E6431A38D3070C067DEF4EA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAC5556D848955430B7907663E2E64925817"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B00C496168C22141305A73A1B662656940E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E0AE1BB6D4ED7477C99E1D218F2FA00AFF8",
                        "defaultText": "반칙이야. 너도 가끔 정말 낯부끄러운 말을 한다니까?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9856B3826F38D944D23931A1D132893A8D86",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E0DDD14993FF843951975E33CEAE41A530D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "182BC2BB08EDB44C0D0979750F7D145C3E7A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26E7D99A15E1E3490C3B52B8FBCA16214548",
                        "defaultText": "하하. 네 말이 맞을지도 모르겠네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "02F4C086086412406128F9750A5158BC0BC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68F054DE6444014C4838B565EFF3E7CF5A48"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D285DFFD4D00D843065A2F751279E7A2F8E3",
                        "defaultText": "그리고 걱정하지 마. 내가 널 지킬게.\n이 세상이 네 미소를 망치게 두지 않겠어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "14AA5A84256B0647956B46E7317D8A6CF4B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09B99E3262E84747F05B9AB25D5E341C09B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE2D924813B2034DD06A4CF83C4AB12849C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C3A8146449382499249CEB7845A03455649"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5EB5FDEE6EB3B541D15AFCA3CC04302E1C0C",
                        "defaultText": "나도 강하거든! 네 미소도 지킬 가치가 있어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "582BA96129F3704C3B3BD1A35B9B2E2E7C7C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E36A246388B526494E59D327BA63F02FF5D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E8C483D92B873459C1B5E53987B2A7DD672"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "931BA2D36BF7C4437D883708D8477CCCF620",
                        "defaultText": "그래. 그럼 서로의 등을 지켜 주자, 동생아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E648B02535C9064F29487CA3BA0A66832018",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F697A6285BAD742A52BBD36607A6E0BDA68"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1B3B7D45EFF68407A39D2E7BD8014B44DF0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C754C2AC362ED44C165A65D15DB319FAF1B9",
                        "defaultText": "응! 함께라면 뭐든 할 수 있어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2133019D5277314C8D2833985976A4557132",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "646A6DFF8C8229482D5BB9C8D88F9141536A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB2E0B611651244F2449B6A6BD080B8321A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7B28FDF42A8164BD10AABE72E7B392066B6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "375051A617D801403A2BBEF45B41657C4F49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "13D9D9DA2D58C345C56A46355D8D4051FEE8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4AE3F8CF6D88034BD209C2748C93ED202137"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            1,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "311B9AAE7BDE11460918BAC14982C9FE99EF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "E85B92606AFCA54AF489F0F4161B3D158771"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0A96510D5D40D948AE1A99B19757753670C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "8EF9D6C012F50046219A87D17484417CFA47"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5D8EC05B2C4CC140405B00284243E8EC8777"
            }
        ],
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}