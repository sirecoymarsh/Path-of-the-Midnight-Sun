GS.dataCache['CE6FC2231EEA124BA3486C33A50532B05547'] = {
    "uid": "CE6FC2231EEA124BA3486C33A50532B05547",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C002-03c After Battle 2 (Meet Alvano)",
        "type": "vn.scene",
        "parentId": "A82A81ED63F1A5455A887F81F814BD41F19C",
        "chapterUid": "8F0F11BF32BEA44F8D6871B6601039C7CB03",
        "order": 8,
        "localizableStrings": {
            "7ED7A1DD7E9F364E7F8B3CC6D48406D1CC82": {
                "t": "Im... {W:200}Impossible...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "2255A6142B4B15435288F5A786F6CF4E0751"
                }
            },
            "C9FD73642328D443AC1A1DF374D403F318A5": {
                "t": "Phew! {W:200}It was an intense battle,{W:100} but I hope this serves as a lesson for him.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "9E9118DA5242C94A30786CF49CF32E0021D8"
                }
            },
            "A6DD2D0F7D19364B28495BB8A54A5E4A6375": {
                "t": "Do you understand, now? {W:200}I haven't been slacking off as you seem to think.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D37AD78647E1774C2F992B7756E336F857D4"
                }
            },
            "4D5E6A0F0A600848CA3AC465F124119C1C00": {
                "t": "No offense,{W:80} but I seriously hope you don't become the Vassal... {W:150}since that means I'd be dead!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "15D715EA1473B445DB49340152512AC53D42"
                }
            },
            "D30AEECF4A39B8421C6890C5C8D859216613": {
                "t": "Sigh, but at least...{W:100} this should've taught him a lesson. {W:200}He's a talented mage, but a bit too arrogant.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "298912A4305D61429D19C96671C681A2706A"
                }
            },
            "F59593867B8D5144707AA230EAF24ACB12B1": {
                "t": "Oh oh oh! {W:200}What a splendid display of strength and composure.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "9CDFFB7230A2654E3C6883759D9CF64259DF"
                }
            },
            "D2F0DE0888126246CC1ACF83064C3934CF5A": {
                "t": "Lyvonis",
                "d": {
                    "eid": "19E1143C705531455619E008884BB9A5FFD7"
                }
            },
            "334ED1589E609044C349A2A787973C94A7F8": {
                "t": "I won't let the Demon King break free.",
                "d": {
                    "eid": "960A83A16095F347176B0124B50D5D5034E4"
                }
            },
            "230208AC86993747059BD044A7FCEF94AB72": {
                "t": "This is no competition, Lyvonis.",
                "d": {
                    "eid": "5C4AC6EE03F443493499CC12722FA90D4C0E"
                }
            },
            "9A64BE905DE0824AFA186145966BA7B18F62": {
                "t": "You'll never be on my level anyway.",
                "d": {
                    "eid": "C46CB3A564757241BF1BD331E9B5C7AD9894"
                }
            },
            "FB93AD998CC370470E588A041B0D9995114B": {
                "t": "It's good to see you motivated.",
                "d": {
                    "eid": "386AB08747D084447E6AAF3255681EDFCE71"
                }
            },
            "168872629EA5254E115A03C2B0002C88B7DD": {
                "t": "",
                "d": {
                    "eid": "C5236E87240D534C839B5DB5484BF973F2CA"
                }
            },
            "1BAA7BD51592434B457B6A14ECE65DACB1B3": {
                "t": "Yeah, he's definitely too aggressive, {W:100}regardless of his reasons.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0C5C62B17D26834BF86962949B3497130C01"
                }
            },
            "B612CAA685BBE84F529807C2CEEA6103084E": {
                "t": "Better focus on my training, as Master Alvano says.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0CD05FFC7F4D264F6F5B5C27449B4CECF350"
                }
            },
            "05ACF9212E1BF94DA63A9BC7D9521F7874BA": {
                "t": "... ... ...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "829525BD5C6953421C1AD5B2A756DF8071CA"
                }
            },
            "12C22DE2190EA247BE0A482208C8805CFD4D": {
                "t": "Bring more soldiers, please.",
                "d": {
                    "eid": "9C83CBEB90F97346648AB9D2E23499E05B7D"
                }
            },
            "B1377F107611A34D25184FB03D3F0354E10F": {
                "t": "Join the fight too. Or are you scared?",
                "d": {
                    "eid": "63FB46F87D1D854F4838A2E53E6CC27AC009"
                }
            },
            "69C335E081B1174B2A78E2686A4F26CFA4B2": {
                "t": "Pant... pant...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F7D3251F67BE334A3C689EE61C1C095DDA60"
                }
            },
            "3B1208693CB631493F2B1B426182269C0730": {
                "t": "I'm really starting to feel all the fatigue...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2239E0CB4BD9D74F33082D78C0885BFD13A3"
                }
            },
            "4BE41BBD2E0F47403F6ACF85BC819056FF0C": {
                "t": "An exceptional display of skill, Milady.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "D124CAE39898F84747485AA563C56888FBBA"
                }
            },
            "95DC3E0509FAE4410098F4D5E8551F1F03ED": {
                "t": "Your precision and control of Shadow magic has improved yet again. Well done.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "E62E7B5277033842DD0ACAF8D3E55E79D45B"
                }
            },
            "2F41CA3D828941430B3A2914620288C60DB3": {
                "t": "Appreciated... ",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "21D529A109D7C542D20A19A81C5FE5EA1720"
                }
            },
            "89399E9D100B444F306B6BA2E27434F29C41": {
                "t": "How long have we been training? I was so focused that I kind of lost track of the time.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "772EB304567FF34D41593BD0FA08CB44C439"
                }
            },
            "9DDF2E4E7B02B74C180860314D0FDADEF96D": {
                "t": "It's been three hours since we started.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "15A03D1B5A85834FF959BA065DCC72087A15"
                }
            },
            "DE1AFA4C6A39F342CA280B803BD214B63BF8": {
                "t": "Three hou--",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "490F2F7C28D3614FF478DDC52C51500EB877"
                }
            },
            "09A88893343664477F18CFD4F468383DA643": {
                "t": "Seems like I got carried away again!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FD415AA17E1EF742CD5AFB82F3B5D4040854"
                }
            },
            "CDFDFC4E97A8074B3A890DF7116F81851BF4": {
                "t": "I need to go. I have a lot of... paperwork waiting for me in my room.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DBA7840D4651E14EEB8BA237BF3EDB75D2E2"
                }
            },
            "DE952B8A4303634A5D29B4973A6F731A1FD7": {
                "t": "Oh oh oh! Don't overdo it, Lady Faratras.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "2985503F6328024B324AD1C32F24294D6464"
                }
            },
            "33321A252A3EE24256784481A931C93E9D03": {
                "t": "You've truly mastered the Neregis spell... {W:200}Argh...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "FE92D0666C9483489C78AE52D05F8D5D5905"
                }
            },
            "8FD6312341D5D249BD480978BB1E02596F22": {
                "t": "Even if you didn't use it...{W:300} I could tell by the way you fought that you had mastered the Neregis spell...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "D1D4103C7867B342890A4A45B18720FF129E"
                }
            },
            "A54337C44C25D849D738FB65FC7467917B10": {
                "t": "I've always taken my duty as the Vassal very seriously, Lyvonis. {W:200}And I'm sure you'd do the same if you were in my shoes.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FBB5DF714F3FA145FD3B4C6191D60D1117AD"
                }
            },
            "A154E3132421324ED859E787B2E49DAF1FF2": {
                "t": "... ... ...!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "7804F0FD5F8CF044476B083927222638B876"
                }
            },
            "E12AE9284CF7C44E4E99E94181291A20C26A": {
                "t": "I will learn the Neregis spell too... {W:200}And I'll show you that I can be a better Vassal than you!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "55A4359E571C124D287A35648387D3736046"
                }
            },
            "359CD26374373944C34B32972759369D4201": {
                "t": "If I failed... {W:200}I seriously hope you'd become a better Vassal than me. {W:200}But I don't think you're quite there yet, young man.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "52021DD286FBE042E579C1C77A79D26831F5"
                }
            },
            "221FBFF23E7FD1463B8A26B96178854C6E01": {
                "t": "Nnnnngh...!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "1DA77940643D864B9B383D12C93AF4E699DB"
                }
            },
            "22899837155B604BCA6880F04E595227BF3A": {
                "t": "???",
                "d": {
                    "eid": "83A4959C5E078643CF8A5691F4E128D2343A"
                }
            },
            "0A940E4318B5A1409B5B1FB13A0078A8C6A7": {
                "t": "Alvano",
                "d": {
                    "eid": "537AE8AD52FC054AC92A4B3781B659101453"
                }
            },
            "0C39EFA09921474E30696FE206DBEDD80C9D": {
                "t": "The perfect balance for any respectable Vassal, {W:100}I'd say.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "3AA793286DB6D4481A9964856A59FDAA573D"
                }
            },
            "514CB74B784A1743A83B9842E0FF1C2127D9": {
                "t": "Master Alvano! {W:200}I'm pleased to see you again.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C38F988F0971B24E207A9E26E7FBB71B8400"
                }
            },
            "1203A8D93682C143A07B6DA83C4287F97D21": {
                "t": "The pleasure is mine,{W:100} Lady Faratras.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "736EFD7A706428464D1BAE853E6AF0FFA0DF"
                }
            },
            "BEE67C3536464845EE58C975E21D7C194D4D": {
                "t": "... Greetings, master. I didn't expect to see you here today, but I'm nonetheless grateful for your presence.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "AFED9036471C1444552B289503BAC2E7E00E"
                }
            },
            "36E9B3A1635AE340117A7AC7AC83F702C5E9": {
                "t": "My meeting with Queen Munie ended early. {W:200}I'm glad to see you're doing well, Lyvonis.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "E4AD890E14863246E25B7656517742512E34"
                }
            },
            "055FF0258DDC6647423AF5D24E90F1FEBBAA": {
                "t": "It's all thanks to your teachings, master.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "3069E5461950674F661A8E24583450F7B3FA"
                }
            },
            "659C2B3D55C1464461882391769D9CA51432": {
                "t": "Soon I'll become the best Vassal that Hoikade has ever seen.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "2BDD2D088A351149C26BC66656B43972866A"
                }
            },
            "EF5D089F1BBF734CA1587AC7D57D5DF97C72": {
                "t": "Better than HER,{W:150} for sure...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "17CEEA5365133443626AE9136486FEA7DD1B"
                }
            },
            "AB3931BA6860A641A68AE655528B9DE7CEE3": {
                "t": "My, my,{W:200} I see you still speak to Lady Faratras in that manner of yours.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "5BC324631A8A64477758191566B41679C548"
                }
            },
            "C6C7712E67DCC841CF2A3730A8304181695F": {
                "t": "Rivalry can be a powerful fuel for your growth,{W:150} but it can also burn you from the inside.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "1F8773CC334BA341A768B7D87B8ED232A540"
                }
            },
            "974AADF5965F424F6A49AEF483124E35CADF": {
                "t": "Master Alvano is right. {W:200}You should relax.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3CE8476E43EBC54C187B9486F90AEC18AB64"
                }
            },
            "BFCB44744F06A94F9D1B52533B1347206BAD": {
                "t": "... ... ...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "4287C29555AFA143412AB9E5DDC1339EB499"
                }
            },
            "549BFF8657975040698AB755283A85FFB491": {
                "t": "Lyvonis is quite burnt already, to be honest.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CED1725F4E67D645916AE7331019C21F6869"
                }
            },
            "2D7D2AB301E529484159BD74B57FDB6C7B53": {
                "t": "How dare you!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "739452BC9BAC244AC43896F3BA9CC9B6583C"
                }
            },
            "77F1E2CD5B803840031ACA03A9D84D9420FD": {
                "t": "There's a reason why I keep acting like this, you know?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "1D4C24488015434CB14B26E386A0686C4E25"
                }
            },
            "020B520F5896444CD56BDC52F46446D3D712": {
                "t": "It's because no Vassal ever died of old age. {W:200}Eventually, the Demon King will {SP:2}{C:1}break the seal{C:0}, {W:100}killing them in the process.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "B201B5940AC21149354BC581E6BFE75066F9"
                }
            },
            "B07FA2A72590714B814AD403AA101F92D19E": {
                "t": "Deep down, {W:200}you know better than anyone that Faratras is different, my pupil.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "ACDD02CB0016754A2E0AEBF94A32DB96CC71"
                }
            },
            "93A3E0AB9FDDD74A492AFDC85AF56DF6E98A": {
                "t": "It's true that the previous three Vassals were overcome by the Demon, {W:150}but none of them endured 21 years as Faratras has.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "2591646A5298374A8F7BB0D0A078246DF365"
                }
            },
            "A21A5E4C55CCC145C55AEBB06A7E4E73001C": {
                "t": "We should start worrying only if Lady Faratras shows any sign of corruption...",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "A356F8D13C25374F3C9A6245B8BEC39A5FE3"
                }
            },
            "0E61D2785E52B949351AEBF03EBA51024DA7": {
                "t": "With all due respect, {W:200}it's not a matter of 'if', {W:100}but 'when' it happens, master.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "B2BEC3D000B3F14B861A72F16C8534E57C99"
                }
            },
            "C8C88AE068C44546692935F12F402D4F8CBF": {
                "t": "I'll need to be ready at that crucial time. {W:200}I have to surpass Lady Faratras and ensure even more than 21 years of peace for our people.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "78C8A6A73D4452452C7A2E34855A4B7F39D3"
                }
            },
            "9EBF7D05514F044025497E284D4B424BCCCF": {
                "t": "Your sheer optimism is disgusting.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "E92570235B5CF848294A171750FA6457D561"
                }
            },
            "6B86B3E0017F2646D61ACDC69E20E3AD2907": {
                "t": "You're wrong.{W:300} If I don't become better than you, all our efforts will be useless in the end...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "C0FA0EC07DBCA84FE078E9668A076EE44DD0"
                }
            },
            "C388A6626EC624466E2881B82CE877D1493D": {
                "t": "Just wait and see!",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "2E6DD1E89B72C14AF41A30951AEDA89E524D"
                }
            },
            "D24AE52A5B5C884A8C4BF9F33D791EE9057A": {
                "t": "You may flatter me however much you want. {W:200}It doesn't change the facts.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "5FC2CB1343CA41459A8A2797D238CB531347"
                }
            },
            "1EE465D882448844CD195DD1D2BF1D3706FC": {
                "t": "You were dead from the day you were chosen as the Vassal, {W:200}and this applies to me too. {W:200}But you lack determination.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "1C4888BE44730046F9199FF6A8AB8BE1AF97"
                }
            },
            "2076109936CE074F1F2AD14564D091712307": {
                "t": "Calm down. {W:200}I appreciate your enthusiasm, but we're here for training.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "924F7EFC1EDA254FC68AD298F38C8CDCAB0C"
                }
            },
            "D8C1AB7342C3234F0D28F0C3813909A3A0B0": {
                "t": "My teacher,{W:150} I've successfully mastered Neregis.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "82B908973340734D16588C8001855C2D313D"
                }
            },
            "0B0C60BD4414534AE3193E57E6F7F9B82E68": {
                "t": "I caught a glimpse of it earlier! {W:200}That's truly impressive... {W:200}It took me 30 years to get to your level.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "B6FA142361BBC74F281A41A696793B46884C"
                }
            },
            "026E25444D788445518A6E620C46D3B7E0FE": {
                "t": "Would you like to show me your version of the spell, Milady?",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "456D5CF92051D3449C6B6EE3407EC8D55906"
                }
            },
            "C309D46F163BC24F017AA9E2BC3B8880C87E": {
                "t": "Sure thing.{W:200} Come, Lyvonis...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "61A864AB32DED64CC169B1315AC7304AE21E"
                }
            },
            "282D33E28BD1E844F578D7354CD1F7B26A5F": {
                "t": "What?{W:150} Why me?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "659734409D0A134DED5A6D163F7E16766C98"
                }
            },
            "4FB1702F4DFA574B7E79DAA11C3F11F87549": {
                "t": "Everyone here seems exhausted. {W:200}Can you lend us a hand and find more people?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F9DFE7D33C366640605A83F9DC67F7FB19FC"
                }
            },
            "2C147DBD50AA16474599C950CF369A3B2DBE": {
                "t": "As if...!{W:150} It's just that...",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "75C916E85BB58544C39B8555E3B762C25A45"
                }
            },
            "E83CC7193AFD0042952B5266AED67D0AE97D": {
                "t": "Then lend us a hand.{W:200} This will also be beneficial to you and all of our people, right?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "436797658404C14FAE6AD96905FD02273CD2"
                }
            },
            "F5C551727B48284E1C3B1C350CB6E274C0DB": {
                "t": "Hmph,{W:150} I'd rather train by myself.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "00F1F7219DB7A14B881AB074FA1CECBE09E2"
                }
            },
            "E32FCEBF52F9514E121A20C426BC34B5B934": {
                "t": "Forgive me, Master Alvano. {W:200}I'll see you at the next lesson.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "297407577E36954A2E8B9FC124651E49C6C4"
                }
            },
            "1F5EF3A03F90C747EE8B4187E474403F8B3A": {
                "t": "I apologize for his behavior, master.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "70FC6ACD30ED614742581ED5F52F0CFBC9EB"
                }
            },
            "7F4788D314DF35474D3ADE60368854203AEF": {
                "t": "Oh, don't worry about it. {W:200}He's still young, but he's smart.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "16B2EDB13AF9E8416969704244F3A8EB1C4E"
                }
            },
            "5613B99E212E934ED67B90233A5474A93E38": {
                "t": "You know better than anyone how strenuous this role may be. {W:200}But I'm sure he'll overcome his internal struggles as well.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "27CD13C453201744BE29F521DF3509FE0B8F"
                }
            },
            "E70BE3C07DFAF145CD1B25B259F4F08FADC1": {
                "t": "I hope so.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1D9B67AA37B4344FEB9B8CA5727D3C247A88"
                }
            },
            "3B2D99D578AF274CE849905789D1B77F9EE2": {
                "t": "Well... {W:200}shall we do this then?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "11DA568F7041364D1028F50906D8683CC8FC"
                }
            },
            "5056B33F9852454B44397D045630180A3F78": {
                "t": "Yes,{W:100} let's get started.",
                "d": {
                    "cid": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eid": "58361813219FC640F52A4D2089B444A91EE3"
                }
            },
            "0EE5CDAF5E22F2460788C958F62E21B86039": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5ECB49D43432084C175B2E45F2BA0A2A01A8"
                }
            },
            "16950BE689A6A24CF47866212471B977E859": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E470FC7A1F622647A74AF743C0EA72767F74"
                }
            },
            "FBE404754D5CF84AD11ACF14223278777D5F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "AEDBA9036D7DA448DB1AF3C1F4CF8D13EAD2"
                }
            },
            "8E23496A08D6E9454B28F0E24046868EA44E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "52D34BEC6F7BA2490538A4F1662CDC4D50C7"
                }
            },
            "16BAB03C7C4F104A2C0B4F130ECA03512C67": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "0CD046C1591878420699BD846ACAD0838124"
                }
            },
            "3487DF958A0DA148437A6D82A3C5E9EA18F2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "6181349F86FF954B7D8B3810DB3B107AFB4E"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "After battle 2"
                },
                "indent": 0,
                "uid": "A05489677A741341836A1C528751BBF50A6C",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "53D1D4D06E46D5478759D75841EB0D40066B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3DEB305830A034720197C86876E2CFB59D8"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "8170261A4AA8F640E92BEDA55D509CB1BF38",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FC9570BE5B252742CD0853762B127C5E4806"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "8A2520CA199B184E115856619447C2519D57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "69E3FC256D630746035999B1870F61D23F3C",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "530174B559164746A87B6A66F02B12D5E700"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 100,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 299,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 51,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "17FD47985FD241458A2807395D7648EE36C6",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "7D72E7178753804DF65B9824F8751718A688"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "400C78621C0335403768F0D05504E41978DB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B8A5F80E3366C548493988F7E867B6916341"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1300,
                    "duration": 36,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7AB21B50647CD4456D18E65922B5477995E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0026EFF49ADFC543844A87C1ABABAC9C4D3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0269AFA46E249149A1892488A70EB55D3F20"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "08A57CAD5C0DA442F84B3D5688EC206747A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F901704F1052D747E92AB7746E6A88D14B46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F917A8270EC4416F9A284995957A858AE2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7ED7A1DD7E9F364E7F8B3CC6D48406D1CC82",
                        "defaultText": "말... {W:200}말도 안 돼..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2255A6142B4B15435288F5A786F6CF4E0751",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B2FC1AD43EA3844652A21670D6301B5CE7B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "33321A252A3EE24256784481A931C93E9D03",
                        "defaultText": "정말 네레기스 주문을 완전히 익혔군... {W:200}크윽..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FE92D0666C9483489C78AE52D05F8D5D5905",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F254E6D55C1163420B1AD5E169FD9C6AE8A0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8FD6312341D5D249BD480978BB1E02596F22",
                        "defaultText": "쓰지 않았어도...{W:300}\n싸우는 모습을 보니 네레기스를 익혔다는 건 알 수 있었어..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 2,
                "uid": "D1D4103C7867B342890A4A45B18720FF129E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7CC0D747800C546D7689F733409A9518F8A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9FD73642328D443AC1A1DF374D403F318A5",
                        "defaultText": "후우! {W:200}격렬한 전투였지만,{W:100}\n이걸로 교훈을 얻었으면 좋겠네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9E9118DA5242C94A30786CF49CF32E0021D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA10376C8EE172415B7A38B590DAFEBE06FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDD3D7D63D7549486E19FC906EC8CD162F5E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A6DD2D0F7D19364B28495BB8A54A5E4A6375",
                        "defaultText": "이제 알겠어? {W:200}\n네 생각처럼 내가 게으름을 피운 건 아니야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D37AD78647E1774C2F992B7756E336F857D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EB9F0FE6F07D748BE69935327F0B33D7E14"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A54337C44C25D849D738FB65FC7467917B10",
                        "defaultText": "난 언제나 그릇의 의무를 진지하게 받아들였어, 리보니스. {W:200}\n네가 내 입장이었어도 그랬을 거라고 믿어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FBB5DF714F3FA145FD3B4C6191D60D1117AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFCB1B742D4006401C283C4850076659A23E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C6A0B45E9C6F5141E83B6F53A69017CB473A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE7ECAC324B12344CA8AFB639710CFDD2D57"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A154E3132421324ED859E787B2E49DAF1FF2",
                        "defaultText": "... ... ...!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7804F0FD5F8CF044476B083927222638B876",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7092D9C78890D546799BC922E336416503DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E12AE9284CF7C44E4E99E94181291A20C26A",
                        "defaultText": "나도 네레기스를 익히겠어... {W:200}\n그리고 너보다 더 나은 그릇이 될 수 있다는 걸 보여 주지!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "55A4359E571C124D287A35648387D3736046",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51801E5C93A42747DA386D18FEF7A81F1A34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AFC2FF06FF1254C5C6B0DF288A3547DBEDF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D5E6A0F0A600848CA3AC465F124119C1C00",
                        "defaultText": "기분 나쁘게 듣진 마,{W:80} 하지만 네가 그릇이 되지 않길 진심으로 바라... {W:150}\n그건 내가 죽었다는 뜻이니까!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15D715EA1473B445DB49340152512AC53D42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBA939B9813AD948C559C03556DCAC8311B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D30AEECF4A39B8421C6890C5C8D859216613",
                        "defaultText": "하아, 그래도...{W:100} 이걸로 교훈은 얻었겠지. {W:200}\n재능 있는 마법사지만 지나치게 거만해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "298912A4305D61429D19C96671C681A2706A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "128A184A26450348582BB2B7AFD20D22E77D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37F7EAE921EAF2489E6AB437C6E1DFD7F314"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "359CD26374373944C34B32972759369D4201",
                        "defaultText": "내가 실패한다면... {W:200}네가 나보다 나은 그릇이 되길 진심으로 바라. {W:200}\n하지만 아직은 멀었어, 젊은이."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "52021DD286FBE042E579C1C77A79D26831F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C084CBA56D239487639C4B1AA818E925235"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B47C25A5358B65403E19E3B1BDAA10DFAA7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28FCD84F4B0335471F581E63A98EF3A642D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "221FBFF23E7FD1463B8A26B96178854C6E01",
                        "defaultText": "으으으윽...!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1DA77940643D864B9B383D12C93AF4E699DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95A0453A7A5713435B594647D652439521AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DCAAFD42606C44FDF9ABA94B2CD2D334672"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "22899837155B604BCA6880F04E595227BF3A",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "83A4959C5E078643CF8A5691F4E128D2343A",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Alvano"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7CFCFADB19C1F94F46186C0827FE37EB1D23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EAA2361048731438B1B741495D0A7879713"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "730F465E090ED44D5749934102451C45D69C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F59593867B8D5144707AA230EAF24ACB12B1",
                        "defaultText": "허허허! {W:200}힘과 침착함을 참으로 훌륭하게 보여 주셨군요."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9CDFFB7230A2654E3C6883759D9CF64259DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A24D3AB92125C9439279DFE1EF2218662392"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A6FF6D80041D34B463964637633FF24506E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "EA4C706E66CB244B93488147ADD2B803545D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "03D86805478B114C6D59D1C50EF7C5A1C775"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 100,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -250,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 51,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "08AAF0256DA1864D595892F24EB18CE48B0F",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "9230EB898C48294F0D29D2C81850928CFF77"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "83033B551C0815469A38C1925EC3E3D7B818"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "model": {
                        "name": "Alvano.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 100,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 2060,
                        "y": -90,
                        "zoom": {
                            "x": 2.1,
                            "y": 2.1,
                            "d": 2.1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 51,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4806959D9473044C573A084184C9C43AD68F",
                "expanded": false
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "field": 6,
                    "numberValue": -210,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0
                },
                "indent": 0,
                "uid": "B9E82C44863B044BAD19528296832AE249C3"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1.2,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "768E7B780BC56840E9194A179459E0A7DE5E",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "5FB36BB552BF12472369800141FA791C8DE5"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Alvano.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FF0DF63D6575D8424C4A9044C239084A04F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "9922E0384BF67141A37A6BD64916ECCCD8E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "B6EE7AD6786298480C19F570CF041228A8FB"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B7E8FEA33065644059482C37CA3690E64E06"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0A940E4318B5A1409B5B1FB13A0078A8C6A7",
                        "defaultText": "알바노"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "537AE8AD52FC054AC92A4B3781B659101453",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Alvano"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DDA721F1816C334D9F9B38B376F737966C73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9110782728CEE748342AB7025E26A6B1F2C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D671C5D4B85344EDE5A21D8B73164F93F38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "783A9FDE4AEB7448D888F0958A9D3D6DA462"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C39EFA09921474E30696FE206DBEDD80C9D",
                        "defaultText": "존경받는 그릇이라면 갖춰야 할 완벽한 균형이라고,{W:100}\n저는 생각합니다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3AA793286DB6D4481A9964856A59FDAA573D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "193FA4A405DCB041F57AD9213925EA1319FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53CB5D237D08B642313BAB711912981F67AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "514CB74B784A1743A83B9842E0FF1C2127D9",
                        "defaultText": "알바노 스승님! {W:200}다시 뵙게 되어 기뻐요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C38F988F0971B24E207A9E26E7FBB71B8400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB0F83419ABA954B278A53A6C7561F03B660"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AA5A93A01820346CD88FFB8816EAD2BF6CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1203A8D93682C143A07B6DA83C4287F97D21",
                        "defaultText": "저야말로 반갑습니다,{W:100} 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "736EFD7A706428464D1BAE853E6AF0FFA0DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDBEAFA87137E34CDD185321570E488C9E03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37A8D37D2FBC44490A486749928C193BF511"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BEE67C3536464845EE58C975E21D7C194D4D",
                        "defaultText": "... 안녕하십니까, 스승님.\n오늘 여기서 뵐 줄은 몰랐지만, 와 주셔서 감사합니다."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AFED9036471C1444552B289503BAC2E7E00E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "815321DF5DCEF94ED248B19790A0C5FB3E27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D293B1FD810DC143125BDCB3337053BDDCF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36E9B3A1635AE340117A7AC7AC83F702C5E9",
                        "defaultText": "무니 여왕님과의 회담이 일찍 끝났단다. {W:200}\n잘 지내는 것 같아 기쁘구나, 리보니스."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E4AD890E14863246E25B7656517742512E34",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A258B0C25AAD74BB14BBFD55A66EB78FF45"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "491BA2EC169613457B586A9464EAD41A38E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "055FF0258DDC6647423AF5D24E90F1FEBBAA",
                        "defaultText": "모두 스승님의 가르침 덕분입니다."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3069E5461950674F661A8E24583450F7B3FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCC920195B13984F6C79CE23142977EDE17D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "659C2B3D55C1464461882391769D9CA51432",
                        "defaultText": "곧 호이카데 역사상 최고의 그릇이 되겠습니다."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2BDD2D088A351149C26BC66656B43972866A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7943784C809FA64D1C9804C3EA3289787B50"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3C86FDD03211584ADF9812E2647239814ABB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EF5D089F1BBF734CA1587AC7D57D5DF97C72",
                        "defaultText": "적어도 저 여자보다는,{W:150} 확실히..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "17CEEA5365133443626AE9136486FEA7DD1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A99566C62229D94068686BB3DAE24CE43292"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Alvano.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "serious_smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7D85F534891465478C4B0A8587BD50D71283"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "C59995BF6DE1C74E077A58188B7C8C754DB2"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1.2,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "620E09671B2C24414D1B7315A1F6ADAD73EB",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FE767EA2E28B04BC22887191093A87B86D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AB3931BA6860A641A68AE655528B9DE7CEE3",
                        "defaultText": "이런, 이런.{W:200}\n아직도 파라트라스 님께 그런 식으로 말하는구나."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5BC324631A8A64477758191566B41679C548",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC950AA387B216441D69C280771002174675"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6C7712E67DCC841CF2A3730A8304181695F",
                        "defaultText": "경쟁심은 성장의 강력한 연료가 될 수 있지만,{W:150}\n안에서부터 너를 태울 수도 있단다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1F8773CC334BA341A768B7D87B8ED232A540",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B183E6985BD5540E218D4A1762DF71024CB"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1.2,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "BF60C93E7797014F221ADFC22E40060D4C97",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Alvano.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D83CB9BC847E5649844BB9431D600C8F3597"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "this changes based on Fa's cruelty"
                },
                "indent": 0,
                "uid": "894AD4728E0CA040CA9AD9F522AF166ACBFE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44DBE6BE5052A242CD5A74115AFCAD23F658"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "param": {
                        "name": "Cruelty",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "Cruelty",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2B8F725F476DA94CE5687C33B84D869EE6FD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Cruelty",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 50,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EACA113E05C0074C604B38C6BDCEB02FC8B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "974AADF5965F424F6A49AEF483124E35CADF",
                        "defaultText": "알바노 스승님 말씀이 맞아. {W:200}진정하는 게 좋겠어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "3CE8476E43EBC54C187B9486F90AEC18AB64",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "621C347B1312554BEA2A571578C274A92C95"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ED2E3102381FA345EB3ADD499AD3172DDFF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BFCB44744F06A94F9D1B52533B1347206BAD",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "4287C29555AFA143412AB9E5DDC1339EB499",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A818CC8068DB434BF48BD758EC9991F04AF4"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "AD0600B11104E143CF8ACE5694EEA8AA90AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "549BFF8657975040698AB755283A85FFB491",
                        "defaultText": "솔직히 리보니스는 이미 꽤 타 버린 것 같지만."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "CED1725F4E67D645916AE7331019C21F6869",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7EAB82EF31C1304A3A6B5931575EF19E2E6F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4EC8ABD5017852484C5A96E8E093877B2487"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "41A664626962F34CA24A17D60250AF3B1FD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D7D2AB301E529484159BD74B57FDB6C7B53",
                        "defaultText": "감히 그런 말을!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "739452BC9BAC244AC43896F3BA9CC9B6583C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "98EF8A121118B3493C2B9D29CA6917DA5B3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD88A7C72A46734CAB2AC55947F88D5D4A79"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77F1E2CD5B803840031ACA03A9D84D9420FD",
                        "defaultText": "내가 계속 이러는 데는 이유가 있어, 알겠어?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1D4C24488015434CB14B26E386A0686C4E25",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACD857784D0008477A8839E70CDFC9C87DC5"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F009D8E67DC34146AE8A7898967954638313"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "020B520F5896444CD56BDC52F46446D3D712",
                        "defaultText": "그릇은 누구도 천수를 누리지 못했으니까. {W:200}\n결국 마왕이 {SP:2}{C:1}봉인을 깨고{C:0}, {W:100}그 과정에서 그릇도 목숨을 잃어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B201B5940AC21149354BC581E6BFE75066F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E37CB567782A740966AE0433BF0586F2C12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DF4A9368AE418459579FB64FE0F822E3835"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B07FA2A72590714B814AD403AA101F92D19E",
                        "defaultText": "마음속으로는,{W:200}\n파라트라스가 다르다는 걸 누구보다 잘 알잖니, 제자야."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ACDD02CB0016754A2E0AEBF94A32DB96CC71",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "529CFE9E4AA6014E1419AAF3124AD25B8320"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93A3E0AB9FDDD74A492AFDC85AF56DF6E98A",
                        "defaultText": "이전 세 그릇이 마왕에게 잠식당한 건 사실이지만,{W:150}\n파라트라스처럼 21년을 견딘 이는 없었단다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2591646A5298374A8F7BB0D0A078246DF365",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "197F91804C1955487C0A3169F6C9E3D634BB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A21A5E4C55CCC145C55AEBB06A7E4E73001C",
                        "defaultText": "파라트라스 님에게 타락의 징후가 나타날 때만\n걱정하기 시작해도 늦지 않아..."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A356F8D13C25374F3C9A6245B8BEC39A5FE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "109B1C4690D3914A7B191EF71E9CDFFB3AEE"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1B19645F4347B54E21383798EA1EF795760A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B00DB745578A2481D381B384529C4BF546A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E61D2785E52B949351AEBF03EBA51024DA7",
                        "defaultText": "송구하지만,{W:200} '만약'이 아니라,{W:100}\n'언제' 일어나느냐의 문제입니다, 스승님."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B2BEC3D000B3F14B861A72F16C8534E57C99",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A12DF10F499C52443878FC912AEF6393032B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A295E5319384C644F27B1AE824EA7DBB7CB8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8C88AE068C44546692935F12F402D4F8CBF",
                        "defaultText": "그 결정적인 때를 대비해야 합니다. {W:200}\n파라트라스 님을 뛰어넘어 백성들에게\n21년보다 더 긴 평화를 보장해야 합니다."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "78C8A6A73D4452452C7A2E34855A4B7F39D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7868C401020F7496C2B11B7FFC46C3F2625"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "you two/Lyvonis",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D2F0DE0888126246CC1ACF83064C3934CF5A",
                        "defaultText": "Lyvonis"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "19E1143C705531455619E008884BB9A5FFD7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "334ED1589E609044C349A2A787973C94A7F8",
                        "defaultText": "마왕이 풀려나게 두진 않을 거야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "960A83A16095F347176B0124B50D5D5034E4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "230208AC86993747059BD044A7FCEF94AB72",
                        "defaultText": "경쟁이 아니야, 리보니스."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C4AC6EE03F443493499CC12722FA90D4C0E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9A64BE905DE0824AFA186145966BA7B18F62",
                        "defaultText": "어차피 넌 내 수준에 절대 못 미쳐."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C46CB3A564757241BF1BD331E9B5C7AD9894",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FB93AD998CC370470E588A041B0D9995114B",
                        "defaultText": "의욕이 넘치는 건 보기 좋네."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "386AB08747D084447E6AAF3255681EDFCE71",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "rest assured",
                            "no competition",
                            "not my level",
                            "good job"
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E291535496F964E0E1895555D0E65F3C663"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4077438F6C1A3244776AF0F66EF3EF5C55EF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "rest assured"
                },
                "indent": 0,
                "uid": "93EF79A86CFAA740A7999638E0E1D2AB6D23"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "1"
                },
                "indent": 0,
                "uid": "5AD4B4013FFDF444E98A63D4423E29A41E3B",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "39EDCD1B4E20C84E2C692F005619EB85CEE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6DFA30E8F29B5487C1ADB31C9B8C9D39567"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9EBF7D05514F044025497E284D4B424BCCCF",
                        "defaultText": "그 지독한 낙관주의는 역겨워."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E92570235B5CF848294A171750FA6457D561",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D58BC04D063387445F68B5F7FFE9F4DAE903"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of final question",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "88201E4F3C9FD54A1C4B1EF4410240A600CB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "no competition"
                },
                "indent": 0,
                "uid": "5E57459481863545146B1B067AB70E216F25"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "2"
                },
                "indent": 0,
                "uid": "007020E16D07234F9D6BCC59860307C534DE",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E2E76E099182F4445E78F4A7968A2B6C6D3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05E4F18F9ECEF24EBA4A1F93C8DD73CD9799"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B86B3E0017F2646D61ACDC69E20E3AD2907",
                        "defaultText": "네가 틀렸어.{W:300}\n내가 너보다 나아지지 않으면 결국 우리의 모든 노력은 헛수고가 돼..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C0FA0EC07DBCA84FE078E9668A076EE44DD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1007991326030442D19A6F10505329FA044"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of final question",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "AF99185969B48244862971F27973BBF9E908"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not my level"
                },
                "indent": 0,
                "uid": "174104BF3EAB3645EF2A5E471D6E4FC6B3AB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "3 - more cruelty"
                },
                "indent": 0,
                "uid": "B0CDD80C729F3146B1892C73D78EC80A2192",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "313FEF72699B374B0B5B93D4A6BAE1ECCB3C"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E9374C05176DA8486F893E1921FFF9663618"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E69E831193425243AA3993C2E987F8CBBEDF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C388A6626EC624466E2881B82CE877D1493D",
                        "defaultText": "두고 봐!"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2E6DD1E89B72C14AF41A30951AEDA89E524D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "409BF55B5B8AE24AFF4A93023669D5B06BD2"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "you two/Lyvonis",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "168872629EA5254E115A03C2B0002C88B7DD",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C5236E87240D534C839B5DB5484BF973F2CA",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of final question",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "AEE8267273ECF94E7F4ABE44BBF8718A163D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "good job"
                },
                "indent": 0,
                "uid": "9D97B0888797D6463818BBC80CB826DEED96"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "4 - less cruelty"
                },
                "indent": 0,
                "uid": "88AC88C6877F574B0A3AA818268B70E50CC8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "093535AE313591461D9A31E1B4BBDFBE8BAB"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F25171E8168CE2467D8BD73642B6F61CC04E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22903A7144026244676AAAA1F96FFEA96B0B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D24AE52A5B5C884A8C4BF9F33D791EE9057A",
                        "defaultText": "아무리 날 치켜세워도 좋아. {W:200}사실은 바뀌지 않아."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5FC2CB1343CA41459A8A2797D238CB531347",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8D98994651143495D4B96136ABF37CC00D0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of final question"
                },
                "indent": 0,
                "uid": "B88DE7FC5EFC90436B3972C4144834CD662E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "final"
                },
                "indent": 0,
                "uid": "9DDD963242B0E84C2749918582A179CA7AFF",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1EE465D882448844CD195DD1D2BF1D3706FC",
                        "defaultText": "넌 그릇으로 선택된 날부터 죽은 목숨이었어,{W:200}\n나도 마찬가지지. {W:200}하지만 넌 결의가 부족해."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1C4888BE44730046F9199FF6A8AB8BE1AF97",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B32A0402A07D645B80B4FD44855728229DF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "////it says either \"lyvonis\" or \"you two\" based on the previous answer (edit: removed due to voice over)"
                },
                "indent": 0,
                "uid": "D21F09ED841A9347C36A3016CC2AC2662A85",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Alvano.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "serious_smile.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E7815E3F0CDAC247BD2B12A93FFBBB9F195A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "4A39F317615C83494C98FF652B783051AE82"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1.2,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "18EA201D8038A44598796251A6C2448D270E",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6BDCA6C626C56143E37A3637E4CB7F227D26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2076109936CE074F1F2AD14564D091712307",
                        "defaultText": "진정하거라. {W:200}\n열의는 높이 사지만, 우리는 훈련하러 왔단다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "924F7EFC1EDA254FC68AD298F38C8CDCAB0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "126C90F054200743C949ACF1D3533086ED7C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "expression returns to default after this sentence."
                },
                "indent": 0,
                "uid": "BC0AA0B1725827451C39C7385978A037C1AA",
                "expanded": true
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DA8DCED438FA5347F1296035C0165F4DD455"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2427392F8B990745337A4505A11D0AA2761E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1BAA7BD51592434B457B6A14ECE65DACB1B3",
                        "defaultText": "이유가 무엇이든 확실히 너무 공격적이야,{W:100} 저 녀석은."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0C5C62B17D26834BF86962949B3497130C01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D750D2244016643B83869066BB66A01B1CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B612CAA685BBE84F529807C2CEEA6103084E",
                        "defaultText": "알바노 스승님 말씀대로 훈련에 집중하자."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0CD05FFC7F4D264F6F5B5C27449B4CECF350",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "598F9E0396D2044EBC18896364D43EDD7CB8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1BF56FEC7DCC984EE71AC1C4CD579326D6DC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D8C1AB7342C3234F0D28F0C3813909A3A0B0",
                        "defaultText": "스승님,{W:150} 네레기스를 완전히 익혔어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "82B908973340734D16588C8001855C2D313D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9845B5992880140B139E789BE455593B33D"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "eyeBlink": {
                        "enabled": 0,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1.2,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "0C4CA9975D7D30475B88C079489F3F0A8164",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "E3941DCB9F73D4444C58C204C7FF16A84EA5"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Alvano.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "idle.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "83733A818E869749299A782791C029663D7B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E93FDE041EA0624A4C9A23A26B91CA9ED0ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0B0C60BD4414534AE3193E57E6F7F9B82E68",
                        "defaultText": "아까 잠깐 보았답니다! {W:200}정말 인상적이었어요... {W:200}\n제가 그 수준에 이르기까지는 30년이 걸렸지요."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line50.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B6FA142361BBC74F281A41A696793B46884C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E93995E5655471494C1B7DB21E2C3B2AFE25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "166BECC3665B1941B25BB1B37AEDA19B574C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05ACF9212E1BF94DA63A9BC7D9521F7874BA",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "829525BD5C6953421C1AD5B2A756DF8071CA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59F344C2386EC245E46AADE9569DFD15D9B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5915021B776F7441684BCA676FA4F2551915"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "026E25444D788445518A6E620C46D3B7E0FE",
                        "defaultText": "직접 완성하신 주문을 보여 주시겠습니까, 아가씨?"
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "456D5CF92051D3449C6B6EE3407EC8D55906",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E0F7EFA53EA25447B188C3602C8CA65E1B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42AF3C1C81EDB444E97B06343FCD2A4BE565"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C309D46F163BC24F017AA9E2BC3B8880C87E",
                        "defaultText": "좋아요.{W:200} 이리 와, 리보니스..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "61A864AB32DED64CC169B1315AC7304AE21E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF7AAC3D5608B44A7F7904160395B949D112"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "12C22DE2190EA247BE0A482208C8805CFD4D",
                        "defaultText": "병사들을 더 데려와 줘."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9C83CBEB90F97346648AB9D2E23499E05B7D",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B1377F107611A34D25184FB03D3F0354E10F",
                        "defaultText": "너도 싸워. 설마 겁먹은 건 아니지?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "63FB46F87D1D854F4838A2E53E6CC27AC009",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "more soldiers",
                            "u coward",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "195D9574530AC84CEE2A5136D3C5BD76DFF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B838979F8E2F674C19089736F45BC6C70C1E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "more soldiers"
                },
                "indent": 0,
                "uid": "B13DA92160C3F3403668F2E2C119E5F5271A"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "upset.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0515355E412C7947018A7A027A480AE5CAB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA1AA49232C228423F8B01C25F18E2414CEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "282D33E28BD1E844F578D7354CD1F7B26A5F",
                        "defaultText": "뭐?{W:150} 왜 나야?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "659734409D0A134DED5A6D163F7E16766C98",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "197E4EED1E139840B58ADFA1723498C5AEA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "297134643EA423496F8933E0E8E22831D4CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FB1702F4DFA574B7E79DAA11C3F11F87549",
                        "defaultText": "여기 있는 사람들은 모두 지쳐 보이네. {W:200}\n우리를 도와 사람을 더 찾아 주겠어?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line57.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F9DFE7D33C366640605A83F9DC67F7FB19FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "986C7E8E8250834A274A6B06D064D0814627"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of teasing",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "48094E211EEF4441F36887A1807069013AB0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "u coward"
                },
                "indent": 0,
                "uid": "35B48F5923F848487328D956D46DC51CE671"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FD0FD7B45EA234A3C18146306E0BC48D205"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "shouting.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C5B77A8F1FD5284C2B8819888D9B430A8676"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD04D36E10680649C28872975D200A6BBFD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C147DBD50AA16474599C950CF369A3B2DBE",
                        "defaultText": "내가 못할 것 같아...!{W:150} 그게 아니라..."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line58.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "75C916E85BB58544C39B8555E3B762C25A45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "921571D11989F449201973C2E466D4DD5931"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6B74D555607864D697938867E5C25EE32E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E83CC7193AFD0042952B5266AED67D0AE97D",
                        "defaultText": "그럼 우리를 도와줘.{W:200}\n너와 우리 백성 모두에게 도움이 될 테니까, 그렇지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line59.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "436797658404C14FAE6AD96905FD02273CD2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2F9034F39E89645782AC0950B41BF152D68"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of teasing"
                },
                "indent": 0,
                "uid": "52CC9172216471421888D20702AC3D67E508"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0CAE0727D3EE7413E8B80180163AF597B8F"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "tsundere.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8EA7CA874E2BF74FF079B8D573529F272936"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B460F180850C740834964812263010653DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F5C551727B48284E1C3B1C350CB6E274C0DB",
                        "defaultText": "흥,{W:150} 난 혼자 훈련하겠어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "00F1F7219DB7A14B881AB074FA1CECBE09E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A4B0FE872994241703A87E792954A44CD4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1FDFA7AF19BB3547A16A90A9483A9DC38F55"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E32FCEBF52F9514E121A20C426BC34B5B934",
                        "defaultText": "죄송합니다, 알바노 스승님. {W:200}\n다음 수업 때 뵙겠습니다."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "C0.2-03c_line61.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "297407577E36954A2E8B9FC124651E49C6C4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E228ECC1B2D2744721AD7907AD93C572106"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8525E9250E93414C6B29F3B7DB59A47F9DE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA3A81403A672049320A7570BF15076D546E"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "660F78EB8281904EA248D9146EDB5A108B46"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "739442DD37DAD241D44A0509FC0A568D5C87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "716959D838B8B243AE3AAFF455E31C5926C3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "881BFFC86D0F12486E8B8D657CDC523EEC97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "986B5B9A05DB3746034BD072E268D8149CD4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F5EF3A03F90C747EE8B4187E474403F8B3A",
                        "defaultText": "저 아이의 행동은 제가 대신 사과드릴게요, 스승님."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line62.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "70FC6ACD30ED614742581ED5F52F0CFBC9EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF7E6BF87488A24DBF992DA22692C8FEA02D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD32F6A52FA4B94CF379A74221FE83BE5ACD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F4788D314DF35474D3ADE60368854203AEF",
                        "defaultText": "아, 걱정하지 마세요. {W:200}아직 어리지만 영리한 아이니까요."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "16B2EDB13AF9E8416969704244F3A8EB1C4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B087BD6A758C8740146A6BC666FE56B603C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5613B99E212E934ED67B90233A5474A93E38",
                        "defaultText": "이 역할이 얼마나 고된지는 누구보다 잘 아시잖아요. {W:200}\n하지만 내면의 갈등도 이겨 낼 거라 믿습니다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line64.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "27CD13C453201744BE29F521DF3509FE0B8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A56AFC1E0C1A234A4F4B59F5F0D4E689E139"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32BA89D42C8D314105888782F52CB314D8B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E70BE3C07DFAF145CD1B25B259F4F08FADC1",
                        "defaultText": "그러길 바라요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1D9B67AA37B4344FEB9B8CA5727D3C247A88",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA0627F46816854F029B06D25C36152E953F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B2D99D578AF274CE849905789D1B77F9EE2",
                        "defaultText": "그럼... {W:200}시작해 볼까요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C0.2-03c_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "11DA568F7041364D1028F50906D8683CC8FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A05FCF0924FF674DCB9A8C965EF33C2B3489"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EF2413B5E3AA5426B1AA638F038DEE27037"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "88FFA3366AC9C940B47A22277ED3A80D89B3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5056B33F9852454B44397D045630180A3F78",
                        "defaultText": "네,{W:100} 시작하죠."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "C0.2-03c_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "58361813219FC640F52A4D2089B444A91EE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1371D8264116B2419598D2C3D13905161CA4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FE7D9DA3FA79348323BE2097E7525CC5515"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 105,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "7279572F135D9244C3288824BC9355F61FAB",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "8BFB0BAB2E442546D91954519FE4DA8AF757"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "timeskip"
                },
                "indent": 0,
                "uid": "8D0B787D69AD174A44786C0196C439B985E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CFFC4186FC5604BBE899954A02A8B329FD1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0049407A14CA9549DD1A15147D8C4306EEC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "3715DFCF1863484B984A7F654F96E66AA3AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "CE31D05125A5744FC568A4C0B209680E1403"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "model": {
                        "name": "Alvano.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1520,
                        "y": -90,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "AF5D7F457C8B5447C85A3CC3B915686C9974",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "1EFE085C1293664BE74882747E0FAD965890"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B2470BC604C9C6422458E071EB169794963B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "9ABD01803A5A3541C828DED82ECEFD2D4EF8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1300,
                    "duration": 90,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5D1230F77DFFB44A697A75155CAB1A6AC354"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "C4B1F41B679972401108D376EB1A9E2E9C75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EF8ADFC42F0D7647236834B0C026A22D71D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "508868B9152796489D0AECB78581E2097CD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CB5D2F020709654DA56A37E94D96A63E9760"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0EE5CDAF5E22F2460788C958F62E21B86039",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line35_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5ECB49D43432084C175B2E45F2BA0A2A01A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "145EE7188C2FC74FD11A2AD34A786CF4849F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2CB96A21A40B4438A3A8E7618B671108F68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "69C335E081B1174B2A78E2686A4F26CFA4B2",
                        "defaultText": "헉... 헉..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7D3251F67BE334A3C689EE61C1C095DDA60",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC9EBB287B2596458E8A2AE5C07470F37E9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62F0A3860A21784C4618CC45A61DA76BCDC5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B1208693CB631493F2B1B426182269C0730",
                        "defaultText": "정말 피로가 몰려오기 시작하네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2239E0CB4BD9D74F33082D78C0885BFD13A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7371C93F3B3277478B1ABF474B9FC0EE1B71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E5FA1EEC03D4994F06199B38340613F86209"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "16950BE689A6A24CF47866212471B977E859",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "E3-Alvano_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E470FC7A1F622647A74AF743C0EA72767F74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B0B33F6F38BC68422B594852ABAE46BC70A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D38ECC058B922343BE080AA31FF6B0AB248D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4BE41BBD2E0F47403F6ACF85BC819056FF0C",
                        "defaultText": "대단한 기량을 보여 주셨습니다, 아가씨."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D124CAE39898F84747485AA563C56888FBBA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C376E7B7546A741C50BFC73A4A40295F658"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95DC3E0509FAE4410098F4D5E8551F1F03ED",
                        "defaultText": "그림자 마법의 정밀도와 제어력이 또 향상되셨군요.\n잘하셨습니다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E62E7B5277033842DD0ACAF8D3E55E79D45B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "638ABCE46665B74CD67B5271BEC6B9E35B2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2B0BA9882F6E844A216A15A62299B4FA79E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FBE404754D5CF84AD11ACF14223278777D5F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AEDBA9036D7DA448DB1AF3C1F4CF8D13EAD2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E354A6C67C5EF746087927923E67B801D7B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E5F860720B5654D1F08FC85F6EF9788AD20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2F41CA3D828941430B3A2914620288C60DB3",
                        "defaultText": "고마워요..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "21D529A109D7C542D20A19A81C5FE5EA1720",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7864C76B221C8949258935A1FE5B5410D1CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "89399E9D100B444F306B6BA2E27434F29C41",
                        "defaultText": "얼마나 훈련한 거죠?\n너무 집중해서 시간 가는 줄도 몰랐어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "772EB304567FF34D41593BD0FA08CB44C439",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61C4A6958C8B084E52581975B8414334DED3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            180,
                            200,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF8DE9708C530840140AA966A5F709556D63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E3BFA01A4521F04A747B03730FB687E93801"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E23496A08D6E9454B28F0E24046868EA44E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "E3-Alvano_line13_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "52D34BEC6F7BA2490538A4F1662CDC4D50C7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C118A0BF67D0A54AAD78B836FCD7D111E592"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16EF2C545C456549509AB775740C2CE297E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9DDF2E4E7B02B74C180860314D0FDADEF96D",
                        "defaultText": "시작한 지 세 시간이 지났습니다."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15A03D1B5A85834FF959BA065DCC72087A15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C57A88EF342D314A4E68FE14D588472F5BDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7AA7805359AF5245BA4A4B84B29B1A5CA32C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "16BAB03C7C4F104A2C0B4F130ECA03512C67",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line30_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0CD046C1591878420699BD846ACAD0838124",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "63BCB23E14E9F34D9019CB2676E07820AD4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDB9BE097D859744152AA78755810DE01D62"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE1AFA4C6A39F342CA280B803BD214B63BF8",
                        "defaultText": "세 시가--"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "490F2F7C28D3614FF478DDC52C51500EB877",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20F4C270143F56499D883C12C6491D693420"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22F37C13913D354CCC6907574ACECB434ADD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09A88893343664477F18CFD4F468383DA643",
                        "defaultText": "또 너무 몰두한 모양이네!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FD415AA17E1EF742CD5AFB82F3B5D4040854",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "238B300D1A494242886BC208AEFACBB54B7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4FC078F78D5C4450308FD40E606514839CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDFDFC4E97A8074B3A890DF7116F81851BF4",
                        "defaultText": "가 봐야겠어요. 방에서 기다리는... 서류가 산더미라서요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DBA7840D4651E14EEB8BA237BF3EDB75D2E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9204B9903F74514D756925455DAC8DDF5B1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F6122CB0375B444521A8184A2D6A69B7B52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "654F8AC75E9A8546FD393914BAF3450C912C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3487DF958A0DA148437A6D82A3C5E9EA18F2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Alvano",
                        "name": "E3-Alvano_line8_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6181349F86FF954B7D8B3810DB3B107AFB4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "27A0C5C2525D754B4B4A7B74627AC9629F55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE0E46F2204DD447034B71266ACAA58B081B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "53C21BBA431B1143072936D7089ADB4D757F",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A134EB0D6633D24AC048EA328D024A4C6620"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE952B8A4303634A5D29B4973A6F731A1FD7",
                        "defaultText": "허허허! 너무 무리하지 마십시오, 파라트라스 님."
                    },
                    "position": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2985503F6328024B324AD1C32F24294D6464",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2699D86547F942493A18BF85E57AFE9B0ABF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A4592752DD1114698381BD462A1EC293F0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3351935F3FFAB74B16395F16F902F779C1EE"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D056D30D0B87D648FD4B47E445976C26604D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 21
                },
                "indent": 0,
                "uid": "D1450CB0134AB54CBD1B8F42BFB1DE5D26E2"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "53C21BBA431B1143072936D7089ADB4D757F",
                    "model": {
                        "name": "Alvano.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 730,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 987,
                        "y": 484,
                        "zoom": {
                            "x": 0.4,
                            "y": 0.4,
                            "d": 0.4
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 33,
                    "waitForCompletion": 1,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "F9138E2D8DBE6744003A8172A1E1F29C0A67",
                "expanded": false
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "E7A4B56B5846604BA398CDF5B2CEE97C7FB4",
                        "name": "P2-04 Training grounds Exploration"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "30D841641C78E04E963B2AB43990B5B20FDE"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "you two/Lyvonis",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "Cruelty",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}