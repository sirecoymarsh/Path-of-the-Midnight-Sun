GS.dataCache['8F26A9277C8DE142211B4B37369D25DB55E8'] = {
    "uid": "8F26A9277C8DE142211B4B37369D25DB55E8",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C3-01 In the forest - Meet Ornieres",
        "type": "vn.scene",
        "parentId": "07B52ED66061E04FEA897F640D20451EF056",
        "chapterUid": "420B33D281484446613AEC618F65228E94D9",
        "order": 0,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "43A7CADB5EF5A0419B1B6C164BC7E4F51D1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "884C9BFC73F37548EF68A3F7B7F6B9910EC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1146D0E77EEE924649795C1328D274F0E6C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF5C883120251442A888C79767004597C2B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            15
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7CB14466CA78244210A8F425147C70115C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            14
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1BD09F99ADD354DC68B01E859A8D2A4FF44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            "",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "FA7886D06BB0C34EFF889F07C42B71FBB46C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1E8C396462160048620BB661717B45EFC46C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3C8C96874E7A0644396AF8D6DA49576C855B"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AA8CE1A283EE754BBF384E1318DF2464EB72"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 1
                    },
                    "targetVariable": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0
                },
                "indent": 0,
                "uid": "D67D0EF7778A874C3F39EDB1DF2753E7BAB1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4
                },
                "indent": 0,
                "uid": "9960366814E81043B169931497758D063B82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            {
                                "name": "Numero Multiuso 15 bis",
                                "index": 174,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "4D7B6D3B15E3074A9A4A88647BF5FB71A292"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "45918E0E12BBF148635A9360998958409EFE",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "B52AD64D3B01C344A2495607903CBD806335"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "859D24FA6E3EC643606BA682B7A7621815F6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "cura Rya e Cristoph del tutto"
                },
                "indent": 0,
                "uid": "25CB205E6A05614B512A0653C6BF7E1F2751",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            7,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6363DA7877E3B140B6595C4209A4DC655AFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            8,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B654EFB5707B134467794BA89BB85C27ED71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7F032ED40BBD344D8E48EA4634631B75AA85",
                    "parameters": {
                        "values": [
                            10,
                            100,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC1D49EC8742B44D2B6841103D6506A6764D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE"
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCD8A080781F714DC118EA6880BB2378E08E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "835CEDE415E8C84D224ADC940C05BF432D01"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810"
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4C0A14001F51344F588E8D45620B5A62292"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "613C21DD4A4253499C2A45A6FA130254058E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Checkpoint freq. (0=nor, 1=low, 2=off)",
                        "index": 2,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4187B5858C1C944FE16ABA280EDE3EE3141F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 1,
                "uid": "E48306AA76BC0845C51B0FD0D9A6B3A99187"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "E3F730CC7C752346A70A5DE2DA87F7BBE7DC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 1,
                "uid": "890034729150734D225BC661BE307AC6C1CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "178B9D6F21FB074D732B790735DF4091DF06",
                    "parameters": {
                        "values": [
                            20,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A136182B62F8A44CF33880884A88214FF523"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDF6B53A1F880249FF8B69B8FE0D39696A6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            15,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EB64D6D2F92334C6E6B3803250CD23D1DB5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "0391EC8C0FDE7341563842B31F4D1BE85709"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "034491BC98D9F847736ABF661B27F31A7730"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "EFF7C0F1645CF849AA2B1B4142A42C29178C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0094B55C0DB517451A4AAFD01531BD439B2F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D28B8AD78E38D2426A7BEA70A66FF0534A0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "51FE568238DE384B4F8A0356581EC6A54FA8",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D673B46E5CD9F44FAA9994236E4EF35E7328"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FDE03B6C9E5C614C497A951943F1C2EE240C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8A7311352B9534DF7286D628583DCC55FA3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E85423C682CF8146E35AD6C39576B7BB0E66"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E09255E897E9944D6A1B115701562E122F03",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F93C355B5EDA80479879C86339B25A9CC407",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "893F3A13721B87464D29CB05F9C85C24B98F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F70DE1B43EBBF74AE2994167470398D58056"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA92A86356A65742DD2802C43717BA00BEDD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10D117234602724C2F18D610DFE5C94E623C",
                        "defaultText": "많이 동요한 것 같군. 아직도 아까 일을 생각하고 있어?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1D4B082B1671154D5349B6F1AE9D49249C6D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA49EDF75444334BED487CD8A677947112D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F14D7AC8F92404E17294DC67B167CC8B3BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D957DD213392846D1691645E91B32D1EBC4",
                        "defaultText": "어떻게 안 그럴 수 있겠어? 이 고통이... 도무지 사라지질 않아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EC48BE50858A854D780874027FEE96BBF487",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FF417216F14D54C1B698382D51ECB617864"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5289DC057F3368412179DFB8E68B9936941A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "560214F4191F2642D17971F3F58D97A12E0D",
                        "defaultText": "... 그래."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "60AB4AAA5B53774960298AE34AB290022188",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3B52B86486F324CA58A4513634C4CD3B550"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70E26B1D061E6446599A1DC4F772A9856EDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FEDC03BF15ACA443A37B3625E6F148DF1DB0",
                        "defaultText": "놈들이 우릴 쫓아올지도 몰라. 필요하다면 다시 싸울 준비를 해야 해."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "348FB72A5C2CC54C985A42A7FD471E4987A6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07B8A0091F28D94AD07B29B12E8A3E8BDB1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8C7050EF751CE542E189C6C676000D2AB6E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "742E58403C6AD8435C0AEEB5BACB1BA2D39A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line33_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B6AC510D65F7D34B09196836CB8F41C5E526",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "83286D02090CA64C0C6A791229FDB58250AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF36B2D71F9DF941783B1F87CE2AB2B59B8C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1252E2E86AB53341744B4C533DB5748531ED",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "72661CB841FC3149686BC6A4692D59C011F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B755A1C282FB744601493246333A0168713B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6216668F1FF4B642D5192AB48B3A1ACC34AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F04694D284E5254E658B21D3340D57A2A476"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC898D3218029140CE4ACCC5DEE0F6AA0E93",
                        "defaultText": "파라트라스 님?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "87428B6A5C15B1433729A6677CD574B203C3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5062B3E32E29434EB759BF15B6C3DA30D4AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8A2EEA21042464BE54B7C417EFE7EB5854B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FD40538915163542E658CF928E9A22331C20",
                        "defaultText": "ㄴ-나도 알아, 알겠어!? 단지... 난 살인에 익숙하지 않아.\n죽여야 하는 게 내 백성이라면 더더욱."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74823CDF23CC97405E5A7F73EA6EF4B35817",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F486E38535F334F931BAF11567BE1526476"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "154756B6905CA840A758BDF6D07C0FF477BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "633D007B7787664287494AC26AB295C763F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8291017B5E31B847D538FE4100A9E3F4530D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29DCBD0E6D468643F95A5E21D88507F5D6FF",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line27_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3FE48F0D3F60F7464E38D8D675E5E8EF735F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FB742ED56ECA5745CB4A81B8B7AAB33780B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "688D49B70890194CF449E7A7EAD1CA754BF6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "584DA6C8390EF740DC48F2295FADE37BDDBD",
                        "defaultText": "... 미안해. 내가 배려가 없었군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AD253A025FD47741AE0808C679098777FA9B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "647CC06B6EFBE245EC4B8862C53F34325337"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC03E85A49F9814C5749516197EC991A356B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B5E58DBB8866C541B43962B54AC1BA40CE34",
                        "defaultText": "아니, 괜찮아. 서로 감정을 상하게 할 시간도 없으니까."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "08FEB89C9602C248E23A46C1B89670979559",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F01DA7B273F2B74DF77B2651BC62698B93FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF16F90B931407401248C887E01E6AC7B353"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A4A362013D430241A94B75636293B8C0D466"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "231D0E5930C608403C1B59D2B0A3B9DF8248",
                        "defaultText": "지금은... 흔들릴 때가 아니야.\n진정하고... 생각해야 해.\n나는... 그릇은 침착하고 냉정해야 해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6D6A906868D95548A49967361C251DDB27CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C9D6D604C9A774DCB5B1A263845BD3F521D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A712BC7C40E6C546205B4D2557661F9C3849"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5BB734A001ABF249290B0C358611F5A9F1C2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "220A20528B9425452C395C03227407DE155B"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "D04CFCB74B97C44D903A9196C2F335DB9BF9",
                        "name": "Tutorial Sanity & Hunger"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C5584AE79EDA040C7390361646109556A22"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "BD4EA0BC0F89C242EB3A3D469326D6D32A26"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A4D6D3679BEFF54F2009D7851C095B00D504"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "639D6A4486370742131BC69677C9E29F2B2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "635527D62A588546E56BE854A74E3B9FDCD5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EEBAB9023B2E44E308B9DE4693C94F89143",
                        "defaultText": "언젠가 비상사태가 벌어질 때를 대비해\n추격 전문 부대를 만들자고 제안한 건 나였어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D2D428C4786293406F8877C73F64515A9401",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFCD5A08450096487019D3A064F8D522DDEF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CBD2D6F371ED144A652B1BD150AC7F394701",
                        "defaultText": "무니가 분명 그들을 보냈을 거야. 내 생각이 나를 겨누는 데 쓰이다니...\n아이러니하지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "535C83117D28264B5599E1D5D0CFF22CBF05",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9932135E943DC042599AF217E5D473B003BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC5CBB4C4BB5334F8F5A1DC1C51385810FC0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "234D94A330DEF641A5694CA2154AC7C6F0C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "095CFA7A2D2E68446109D08460B16526D196",
                        "defaultText": "확실히 그렇지. 하지만 내게 생각이 있어. 어쩌면 우리가--"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E93FBA4A8D09F446DC58C34735D9FB61C7FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD9ED2027480974BA68962328F74D9889261"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10FFBB0465E525423878E8E1055945716486"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE688D3F4FD5F8435C88E6082E3E62D3A5B1",
                        "defaultText": "이름조차 모르는 남자의 생각을 들을 순 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B216DBAC7BF9004EC958E8F7A341C4F50096",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E953A3A1362DC747288A1364E7F8465A8CB0"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Hellios",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E1A40B049FCE06414688AF512A87B84C429D",
                        "defaultText": "Hellios"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1BEBA47C666A074F405A6FD50973BE834D95",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Hellios"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Hellios",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4420A477777C1147D149365299C862972DC3"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Hellios"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Hellios",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0B6B31FF3A0B17427718F3B01CC5E4690E5F"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AF4010B54C32274CE79A6849136238271A16",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Hellios"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Hellios",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "16FC2DF1566AD54711887EC265A3623C8683"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40989EA18F3B584F1A398F67381FA8A09D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCB1E3E85EF8244D6769F07712D24F96739E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B97BFB3F58860847BD8A5AB8DA0DEA4611DC",
                        "defaultText": "하하, 맞는 말이야.\n헬리오스라고 부르면 돼."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3811720093E4C64FE379AC56F12C06FE7E46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ACFE76530BE614B9999CAA419AA625E1345"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            10
                        ]
                    }
                },
                "indent": 0,
                "uid": "52E32BAD4880E8451D681B79583051EB7885"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FE163BA4B01504F4A28494586326615A31C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26BFD7BB349AF541BB8936A4C0ABE2F3C6C2",
                        "defaultText": "헬리오스라고? 정말 바보 같은 이름이네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1AFC828A2FA56545554B3231E26861927B05",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A772C855BE1B5408E6B8F57B550B5B38279"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D772F61527D914DF28906127707E6D6A983"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82363DDA69A1D248F94A9D84F4997E1160E5",
                        "defaultText": "웃을 줄도 아는구나..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D25B6C950962C94F9F28CA8525274A4C8AA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53BB2498247E994E1549ED6002D34A07DD14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8ECE4F208442E14D56783DF7A3F093F5C5D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25A5D8B2271148432E38BF557A7316E4CF0C",
                        "defaultText": "가자... 헬리오스. 낭비할 시간이 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A918AFD411C43497E189AC42E3BFA32A03E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E23E5533ECA1446168B97E67A2450689327"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5469638510F31945604B0FA39CBD3597EDBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37E346E23B30A244499947F3580EB14ADD8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "83C8B5E344D6384008081EA704CBA71EEE90"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E2921F3820C834898186EA1B848D89D053C",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9ABFBF8A59E90843692B2AD20B9BAB191889",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "441F934B022FC847835B0B173A440E519737"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A0C39923B8C3146B88A7026F5B7B3D58519"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25E2A8F16C4A9645872870D871B74137AD91"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "EF6EA2CC81F9154321099161334E75BC6377"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2501E50779EDB743A988AE52866C863FA2FF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "91752621506ED8425C489C929EB61C4715C6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F1B4DE5222B88846E14B8DA77DEF874E234D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C42F15AF2CAC3248C2699771058334EEF3A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE044F5B8C0A064DDD4B22013CB8F6118CD5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D33FCC05007D74D535ACCE92A46B431ECCA",
                        "defaultText": "ㅈ-잠깐, 뭐 하는 거야!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B4700D75754394FC57B53522BC825DC20EC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "002BBAD83948A44D0D295D47C8328FD0BDDE"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "076FE4E064DC53400919D1E776DDC77BB3EF",
                        "defaultText": "(움브라를 시전하고 방어하세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF0BAD943900624AA079CB9536BF72FF786D",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "43C0359A05A7B543DF2A3A771D4F809AE3B2",
                        "defaultText": "(기다려보세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "19E539AB14194644B85979F58B3E7E691349",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "defend",
                            "wait",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "C18A014903F6E843E1788A45DD9AB8BC8D98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D0A54CB66954848B939E089181897ABEE81"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "defend"
                },
                "indent": 0,
                "uid": "E79067FB421D7640EC198F76CF5ADB754839"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97DC9C427000E34A0D4A231778FDF13F73F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            650,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8E821AB66A86841AF1B55A80C4C4E90737B"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Faratras attack Umbra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "22BFF9CF63C42247DE580C88904D6F8C0899"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2100,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "829924F4481D4245CC89DEB475823AEEFD94",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 10,
                        "y": -282,
                        "angle": 0,
                        "zoom": 4,
                        "horizontalFlip": false,
                        "data": {
                            "x": -3,
                            "y": -133,
                            "zoom": 4,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 1903.9,
                            "height": 1734.0500000000002
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6DFC371D4803384DDC68F72038B4640DE344",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2100,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -68,
                        "green": -109,
                        "blue": -68,
                        "grey": 52
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EC4EA4A890216541BB187793C78F495F40F3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "0FC4A65357DA29456478E6A84EB644CFD4F2"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2100,
                    "duration": 3,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A94102EA105C74424B3A4DA6F170BE73B805"
            },
            {
                "id": "gs.StopSound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Faratras attack Umbra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E230D3D27121494A7E08EE56A621F90E9E1A"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hellios Hidden Blade.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E57601562ADD784BD468B6053FEAE7487A6C"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2101,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "3662BFEA49DF9441F73942E1CEF4EA5D97F5",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": -28,
                        "y": -330,
                        "angle": 0,
                        "zoom": 1,
                        "horizontalFlip": false,
                        "data": {
                            "x": 148,
                            "y": -30,
                            "zoom": 1.5,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 1257,
                            "height": 1183
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F29F508C232C35403079D4E1F7CFDFAA250F",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "560B8B855AA7F442154AC919E078D8919B56"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2101,
                    "duration": 1.2,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9F308B43055DE64A516887C12543B20E6B97"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "84C4449873E75246931A8F64F636C62B674A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6356480C8D9A884E2568AF91AB4402C72DA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34530BD668AC244E973936E2BF7B50DB6F93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4A200A652FD194C522B181092726C8F6B6A",
                        "defaultText": "ㅁ-뭐지? 움브라 주문이... 사라진 건가? 아니면 저자가 튕겨 낸 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "399AAB8112923542E769BCB9F97463E12740",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD4C16A97C5E27475F1BFDE8E23579F5DC8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "330F0C714A60D943DF7A3442BA1B87D0C483"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "585D6C152272684B2E6BB780A17A7D597088",
                        "defaultText": "잠시 가만히 있어 줄래? 널 해칠 생각이었다면 진작 처리했을 거야."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "41728A343442C843B70BA2F1F1A1BBC8B447",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86831948264D944C627826B8145C9500AB30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            3,
                            1,
                            0,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92B8F3AD82E40149C8787FB3DCC1D9C76D86"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D15A304C53B9784F646B5826520D10F2B0DE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B315F421679C4412729F4D0ACD9DD9C4B1F",
                        "defaultText": "저... 죄송합니다.{W:250} 부끄러운 모습을 보였군요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "17E66A569CCEE041248B653286C884E895DC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B91BD10B2664F1413E79807361854C1A5D13"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "wait"
                },
                "indent": 0,
                "uid": "DEA83C321A4028474D696576480A79ED4579"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94A7DEA66B787446D569A985DF30685EE7AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B4D474FE5A4E6544772B92661359FC2A4262",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0F16FA726AD73482228D1574A4DA98304B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59BC255702BFA242A20B9224439692747582"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "PARAM_ANGLE_X",
                        "value": 30
                    },
                    "duration": 12,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "waitForCompletion": 1
                },
                "indent": 0,
                "uid": "7AD71F878629E84D7C4BA101DDD4DBCC6FC8"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "PARAM_EYE_BALL_X",
                        "value": 1
                    },
                    "duration": 12,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "waitForCompletion": 1
                },
                "indent": 0,
                "uid": "7260AAB942527740838905C6B1749EF6673C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "037917F154A1124CEC786433F2DEE4E41040"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6CC9226916A3A647963AFBB2DA48379265C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C2746BE8AB385432E883F66377361D2E838",
                        "defaultText": "모습을 드러내라."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-01_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5029A38B8478074C809A97C12E81992470B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "860EF03E271F0743A07B2439C747B268EBC0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "886FBCB6112DE045425A9638FEFD36C8F09E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "D45F72CC3356234A725B22B8F0FC2798CD77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "40F95A893C002740314A98E603758B960D7A"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6E51ACBB9017024AF0697AB5D42F09839DBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            750,
                            0,
                            799,
                            250,
                            50,
                            -10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30C2C1CD8B1D874BC089EFB810C036F3FD63"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -20,
                        "green": -20,
                        "blue": -20,
                        "grey": 30
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9639884F510FA24F76293CA384AE53E83B6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C6B9CAD1FED06450F9B70437C48A9B618E6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "CF9670674CADE8450448EE23AAAA07F92222"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7DC3D996353EA744C9294F4403152DAC3ECA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22E4FA0474E0E749FA8A5A926663F0514C5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A1EF8695633E348FC48FE992EAF3F7C2CD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5B7361B60959747D67AD85727873AFFCDE9",
                        "defaultText": "기... 기사?{W:250} 역시 추격당한 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CFA916CB1826B1406359E573F2C4CB4650CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AD557548FC6E94794697765E1F624D90FED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3EF17CA226152149F4098258997A7E057FC4",
                        "defaultText": "아니야...{W:250} 갑옷이 분명 호이카데 양식이 아니야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "429D78AB7F60A645C22AB9E6349D67EB56A2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EEE7BF2063F6341293A8A44A24842AA6441"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E35DA1462ECF5454E398AC150E7CAD53D63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A414AF1F215B544E88892CB5E75E40EFD076"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97F035FD352F634FCB2867C2D5B8D11CCAFC",
                        "defaultText": "누구냐?{W:250} 당장 정체를 밝혀라!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CC873AD42DFE014B631B38D54259CEEC9B5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "65D7FB603382834D4359EED48B6AF22C9D7D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6705E27141B724455368FA56EC8828C04039"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8C22423A2649E840A23B2CA44013BE244E15"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B2F038D013EFD442874B6378F0EF9E9A5D44"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "67423BB353E774461518D8093EAF25608DE9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "286532321036A345A6482636749258A86477"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            600,
                            1,
                            0,
                            -85,
                            10,
                            15,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C270433C2A5833497D68ACB3C9C287A88187"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6B75C0D53F86B0469C89A2A3F977E0B907EB"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "Orni's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0136C57F5FE5C2411C08731531C20BAA7CA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "211640743933E54CA148BF53BE50D93B361D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B86881E24EAE44F1F3986F6BC723AA50FF1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B05B94647252A647A18B1C26EA1687FAC737"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "004FAD3954DF5547499BE2E3B22F3A428A7B",
                        "defaultText": "갑작스러운 결례를 용서하십시오.{W:250} 파일럼 성검단 단장, 오르니에르 경입니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "12DCFA5569D6A34C4F6A1DC5232A2DDAEA73",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86FFFD6C14D44848589A3F57AE98D5273C51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09A22A3D19DF2440982927534643C8B3BAD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20F1F85076F411472E2941458CF06F3D010A",
                        "defaultText": "성검단... 단장이?{W:250} 여기에!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CA46B14D6A7314421F7920D86E693B3AE4E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB1923D66967854E5D7BF0C826050185212A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3797A5943823E04274995DA2ECA2F303762A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC26EBE87F8E624D4C8A2D86C955319E7634"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "941A3AD31A405243C15BB042D36FF12C1FD6",
                        "defaultText": "오르니에르 경이라? 흥."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-01_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "91EC87084C936044778A58870F4DECF10CCC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D132521651381494E5899907FFAC28B64CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36AB5F3D08341543EC8B76735B5902F0E36C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E324EFA42C67574A165A3F63B4A4D81844C4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5EA11F7489BD943158997D5A2423D1F31CA",
                        "defaultText": "우웅! 우웅우웅!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1688F8F5897434444F0B6A646281D9E42AC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F79153DD024519453A5BC6139C394D0D30E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE7AB8DD7D967741314BCC21E36C1528E90C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D34A20BD87C3784F08798FF86459225F26C0",
                        "defaultText": "개...{W:250} 인가?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "681F14165228E54B9F89ADF4C8643958A9E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46AC93945A673545588913922A90C58A2418"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "785CE95D8279A34D6C194A6729B0D3DB69F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7E8FF503ABD8347D55812A641630FD65893",
                        "defaultText": "솔직히 좀 귀엽네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FD1E4D5C8064C649CB6B35244FEBB77BCCF7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4990F1EA7066B64EE63A99A4C913B0759887"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24B482B0884520401858F503589069FB5826"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A8F291D7AD23740F11BFDE18138261F11D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F52611127A927142194A8525C97F005DA7E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AD4297A66CF2346DE58B3C4DBC14624BC3C",
                        "defaultText": "쉿, 지금은 그럴 때가 아니야, 루코스."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7AF90FEC85F6A2446D992DB7F00862200954",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BA132529742AC243B8183628E2896C90F687"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD27BDF84B91F84FFF6914F82541E12F8A4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07D0750A39CDE44C961AE8D71AD54E348A9E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "357B73D02844D2447828B36445ED0F8E4F92",
                        "defaultText": "실례를 무릅쓰고 말씀드리지만, 파라트라스 님. 함정일 수도 있습니다.{W:250}\n필요하다면 이 남자를 처리하게 해 주십시오."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-01_line39.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FCAC26456AB42049808BD9F84F5B81B9001B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA8CE4FA5A3662441399FF60C4883533ABD1"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F03F671981D672469639E9514B20B91BE86A",
                        "defaultText": "(그를 멈추세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4CC989073DBB37408588E868637E758F6C3B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "C6D96E5D4309384E2B4AC014B6E09547C801",
                        "defaultText": "(상황을 생각해 보세요.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D08C4050402F25408528CC202EBCAAB07368",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CB878739881C354C6629E904EF50B039D0EE",
                        "defaultText": "빨리 끝내."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "461EB216748E3443C38BFD3815ADAB9C8AEE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "sameend",
                            "sameend",
                            "quick",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7C37955239F624F34585FB5BA7B5E649D17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C15E3D034CFD5841042B0E03F6E9B8AF42CC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sameend"
                },
                "indent": 0,
                "uid": "239C03236D6648414438A412E1E2EF4674E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9125A27A82FA54437F3B12D5E9107CC76BD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BC9D36791173F1437749ABC83F435615539F",
                        "defaultText": "서두르지 마, 헬리오스.{W:250} 지금 파일럼과 외교 문제를 일으키는 건 피해야 해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A1E7959001F5084E132B97F46C1F33E2EA15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29DEE49102D261447E6B629265F7C1551C9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11C7B97F9D2A254BA0692A64DD738457FC12"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after threat",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "CA6AA3FF492C294265081A15D8A512C0CF88"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "quick"
                },
                "indent": 0,
                "uid": "597D66A867E8F3493D9880F9267F5EFEB9F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            0,
                            2,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C1C18AD61CF26425249BC08F31717BB724D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CAF320E5DD9F348738BE815F9832452AB29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B131B3A8489EF347272B8F31201EFA35D9F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "224FDCF77744664F375B11C8F475DA5891CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E155EE2721BAF146973A5494CC2261109585",
                        "defaultText": "저, 잠깐!{W:250} 너무 갑작스럽습니다!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C0.1-02_line75.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E1B4554923F6D245D4899AE532FFEFC51231",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "246BF4128F90A248F79AB644917F15E87278"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after threat"
                },
                "indent": 0,
                "uid": "9B9377AF41DF07447178FD14D6EE0326D67C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "497B53D341C52047513A63B37AEC48ACEC5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09AF1B393AC8A840889BF918F9AFB1056D54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE47F80A79537249576AF431B0EA01D3F53D",
                        "defaultText": "방금...{W:250} ‘파라트라스 님’이라고 하셨습니까?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AD00CFC88F28F74E6F396E090ECC5F30468C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C5B37506211A348571B7F22E97DA2E4B9D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F04A4C939F6034C7D7A2AD491A08F93799E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B717C4335EDC74B2879A9A4CBFCD44CD67D",
                        "defaultText": "... ... ...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5DABEE7699FDF344D919FFA664F8861C211A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "256CEF03006B8146A179BC057D0BB926340A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B0A277214E1B845E4886AA27515975C2A79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D91087958798C747AC49E410ABAA27589613"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AF06040563BA8461A088B037401D43569FF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "925C059214990549707918F9354A5A439F97",
                        "defaultText": "숲 한복판에서 뭘 하시는지는 모르겠지만, 마침 당신을 찾고 있었습니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FC2D4B545476444B2B3BED3861C06AD36D5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89F3B67222B7C549AB2A7EF227CD19571FB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9048BB4327EE284843791EC1995D30943173"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5951D26C8100974E2F6B7CD238F897E2C49C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7885B591131856442339FF15141DF03704C6",
                        "defaultText": "들어 봐요, 경...{W:250} 오르니에르라고 했죠?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "014B5F3622D537436E8AE4B669EFFC1E4BFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6128659C16730940A919F8E38C577BAAB1ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9F29E7F3659D445601985A6617BF5C2EF96"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F409AD6358D0F540286953D2766CD36C68AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "406B7926755D12494C78D9609C1F33FEF978"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "9102FAF26558B64908781DE3B4C25B6B5689"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C56A7EA855E1E842FD4A6AB3E375CCC74B9B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "F4FD7623617A304E4939B514B13903917678"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2F0DA04A677BC44068593606BF0B51DFE5CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B63179455E2E24F6F8991B6F9C92470106D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F401931926F6E94BF91BA9D5C7DA1EC67311"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ACBB0EFB73126545A35BFB6297071DE9292A",
                        "defaultText": "오늘은...{W:250} 힘든 날이었어요.{W:250} 그리고 지금 더 급히 처리할 일이 있어요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1C29DCFD3522214B2018A21571782C818CCE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE4425E138C8E64B92688D68B1D2CB775E41"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B88DAED9ADE754BCB297266DF6DCDEFBB40",
                        "defaultText": "호이카데 성에서 기다려 주시겠어요?{W:250} 곧 만나러 갈게요..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3BC3AA511A48E44EAD2B70E58887BC9540F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66BE0EB377F76840BE998968E33BC55F8F91"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EC62B22744B7749CA1976A1A03B5FB3A644"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "300DAAD10527504FAF2AD581AF28EFECD4F0",
                        "defaultText": "호이카데 성이요?{W:250} 알겠습니다. 하지만--"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F62BD4D169E1334794597D14ED8EBE8E2C45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F04E50678C8C864AFA4B4FF123AFCF60272F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0560074913DA4248C41B2A44E91C21B39395"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C51B1C876DA854C717AD4E79B9F8680AFE9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "F0FC9A873026B74B314A8B02F3EE7E8CBC82"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC01456E1B07A446541883F9A99E3A1E40D7",
                        "defaultText": "으아아악...!!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E2-Ornieres_line5_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9348917C05AC2846339812B760CF3E840FE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D65BEA0083318046B909EFD95C4F679B5869"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D28C37A39104C1403A587E2583FA4401CD62",
                        "defaultText": "으윽...{W:250} 왜...{W:250} 하필 지금?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D5D0D346189836476138EB33ACA097EA428A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F47536C05BAA924F842A9D19FC0EB5CE1CE1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F29A10E42A33F443184A8456F82046682E30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DDDA17030BCE044DFE1A83A2E7B381B0EAF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6CCA56D56148C145AD98C6E80A5EC923B417",
                        "defaultText": "아가씨, 이 남자는 상태가 불안정해 보입니다.{W:250}\n아까 말씀드렸듯 사칭범일 수도 있습니다."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-01_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D3BA8FE42C7392488A69DAA453608DE1A12C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "362C36E07B682148D25A4B73DA2760BDECE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2DEB41F9185F094BE45985B071910EC85272",
                        "defaultText": "그 부대가 곧 올 거라고 했지?{W:250} 도착하기 전에 준비를 마쳐야 해."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-01_line50.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F0C90E7B4505C545B489FC19250073EE188D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "50D3D2EE269A18406E3B4CC88834673FF173"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5D6A33E893BE048A019E9D7E31D212057AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A1B092292804847184935D4C53F19FB259C",
                        "defaultText": "잘 둘러댔어, 헬리오스.{W:250} 저 사람도 충분히 헷갈리겠지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7EADB2F70AB7A941AB4812D84797C0C6C988",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD7B86EE05334248B9490AF2F27204185FB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B673B3427506D245454A0D138631EB4BA8D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63F52F0026F66145A84B125560308E39AC5F",
                        "defaultText": "그래. 지금 여기서 지체하면...{W:250} 위험해질 수 있어.{W:250} 어서 가자."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BC8696BC4C0F6043F5397180216272D840AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3E7316D858ED04FA61851C19B3D27B71E29"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "11F99F5D8CCF7543D2483E18C02EC686609F",
                        "defaultText": "그럼 다음에 보죠, 성검단의 오르니에르 경."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-01_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D417D5217C8E214B0089497405CBC4E5C029",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "182F1D1848C7484AED9A3BE6FDC460AEBD19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B5FA259138C064F8B3ADDC864B98A6B6035"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6B00C86533E054F8E58E1D4E064DADDB3DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAA6EA0611BB374644998A93F2213605F4F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B82661684154D74EF858EF83512F2E93A6DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "42EF5FB785F7864F107B700620BC8BEF4969",
                        "defaultText": "으윽...{W:250} 기다리십시오...!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C03-01_line54.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6A6A2CE8173E424AB56954E5FE570047EE62",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1B16ACF7E6FA74B946A709775C8C8F3D4B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F50670B444AC334B1A499981F433480E277E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CC3DF499611A244A5828D7747C27985B57B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE8E3AD1200492415B0A2F84691C26D2A4ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EE856898C3B18488778EF85DB928DC3B946"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "A33703EF1CD1324F6178CB144A1696B7F8E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0FCB0E08691534B800A46A6C553BE946471"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9B3F90DB2CCDB34B320A92D3AA2E3174A010"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9E687FEA771F724A43996A6143368EC1DFAD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "004F144021D3984AE13A9542DB692BD6D723"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "9B402F906168704C636B97C13512358CA8CE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "4C35C07F957443433869059878A14CD5F088"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "8CB6BBB23CE91549AC481085BD9D57869DA1",
                        "name": "C3-02 MAIN MAP Forest"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8AA3CFCF4F7F2242D16871A40A01E493363F",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "Orni's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Hellios",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "localizableStrings": {
            "E09255E897E9944D6A1B115701562E122F03": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F93C355B5EDA80479879C86339B25A9CC407"
                }
            },
            "10D117234602724C2F18D610DFE5C94E623C": {
                "t": "You look shaken. Are you still thinking about what happened earlier?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "1D4B082B1671154D5349B6F1AE9D49249C6D"
                }
            },
            "9D957DD213392846D1691645E91B32D1EBC4": {
                "t": "And how could I not? This pain I'm feeling... it just won't go away.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EC48BE50858A854D780874027FEE96BBF487"
                }
            },
            "560214F4191F2642D17971F3F58D97A12E0D": {
                "t": "... Yeah.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "60AB4AAA5B53774960298AE34AB290022188"
                }
            },
            "FEDC03BF15ACA443A37B3625E6F148DF1DB0": {
                "t": "They might be following us. You have to be prepared to fight them again, if necessary.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "348FB72A5C2CC54C985A42A7FD471E4987A6"
                }
            },
            "1252E2E86AB53341744B4C533DB5748531ED": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "72661CB841FC3149686BC6A4692D59C011F5"
                }
            },
            "AC898D3218029140CE4ACCC5DEE0F6AA0E93": {
                "t": "Lady Faratras?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "87428B6A5C15B1433729A6677CD574B203C3"
                }
            },
            "FD40538915163542E658CF928E9A22331C20": {
                "t": "I-I know, alright!? It's just... killing is not something I'm accustomed to, especially if the ones I kill are my own people.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "74823CDF23CC97405E5A7F73EA6EF4B35817"
                }
            },
            "584DA6C8390EF740DC48F2295FADE37BDDBD": {
                "t": "... I'm sorry, that was inconsiderate of me.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "AD253A025FD47741AE0808C679098777FA9B"
                }
            },
            "B5E58DBB8866C541B43962B54AC1BA40CE34": {
                "t": "No, it's okay. There is no time for hard feelings, after all.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "08FEB89C9602C248E23A46C1B89670979559"
                }
            },
            "231D0E5930C608403C1B59D2B0A3B9DF8248": {
                "t": "This... isn't the time to waver. I need to... calm down. I need to reflect. I... the Vassal must be calm, composed.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6D6A906868D95548A49967361C251DDB27CE"
                }
            },
            "8EEBAB9023B2E44E308B9DE4693C94F89143": {
                "t": "I was the one who suggested we form a squad specialized in pursuit, just in case we had to cope with some kind of emergency one day.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D2D428C4786293406F8877C73F64515A9401"
                }
            },
            "CBD2D6F371ED144A652B1BD150AC7F394701": {
                "t": "Munie surely sent them after us. To think that this idea of mine would be turned against me...\nIronic, isn't it?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "535C83117D28264B5599E1D5D0CFF22CBF05"
                }
            },
            "095CFA7A2D2E68446109D08460B16526D196": {
                "t": "Quite so, yes, but I have an idea. Maybe we could--",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "E93FBA4A8D09F446DC58C34735D9FB61C7FC"
                }
            },
            "DE688D3F4FD5F8435C88E6082E3E62D3A5B1": {
                "t": "I won't listen to any ideas of a man whose name I don't even know.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B216DBAC7BF9004EC958E8F7A341C4F50096"
                }
            },
            "B97BFB3F58860847BD8A5AB8DA0DEA4611DC": {
                "t": "Haha, you're right.\nYou may call me Hellios.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3811720093E4C64FE379AC56F12C06FE7E46"
                }
            },
            "26BFD7BB349AF541BB8936A4C0ABE2F3C6C2": {
                "t": "Hellios, huh? What a stupid name.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1AFC828A2FA56545554B3231E26861927B05"
                }
            },
            "82363DDA69A1D248F94A9D84F4997E1160E5": {
                "t": "So he CAN smile...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D25B6C950962C94F9F28CA8525274A4C8AA6"
                }
            },
            "25A5D8B2271148432E38BF557A7316E4CF0C": {
                "t": "Let's go... Hellios. We don't have time to waste.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4A918AFD411C43497E189AC42E3BFA32A03E"
                }
            },
            "6D33FCC05007D74D535ACCE92A46B431ECCA": {
                "t": "H-Hey, what are you doing!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5B4700D75754394FC57B53522BC825DC20EC"
                }
            },
            "076FE4E064DC53400919D1E776DDC77BB3EF": {
                "t": "(Cast Umbra and defend yourself.)",
                "d": {
                    "eid": "CF0BAD943900624AA079CB9536BF72FF786D"
                }
            },
            "43C0359A05A7B543DF2A3A771D4F809AE3B2": {
                "t": "(Wait and see.)",
                "d": {
                    "eid": "19E539AB14194644B85979F58B3E7E691349"
                }
            },
            "F4A200A652FD194C522B181092726C8F6B6A": {
                "t": "W-What? Did the Umbra spell just... disappear? Or did he deflect it?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "399AAB8112923542E769BCB9F97463E12740"
                }
            },
            "585D6C152272684B2E6BB780A17A7D597088": {
                "t": "Stay still for a moment, won't you? If I meant you any harm, I would've disposed of you long ago.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "41728A343442C843B70BA2F1F1A1BBC8B447"
                }
            },
            "8B315F421679C4412729F4D0ACD9DD9C4B1F": {
                "t": "I... I apologize.{W:250} That was embarrassing.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "17E66A569CCEE041248B653286C884E895DC"
                }
            },
            "B4D474FE5A4E6544772B92661359FC2A4262": {
                "t": "... ... ...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "E0F16FA726AD73482228D1574A4DA98304B8"
                }
            },
            "6C2746BE8AB385432E883F66377361D2E838": {
                "t": "Show yourself.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "5029A38B8478074C809A97C12E81992470B1"
                }
            },
            "A5B7361B60959747D67AD85727873AFFCDE9": {
                "t": "A... knight?{W:250} Were we followed after all?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CFA916CB1826B1406359E573F2C4CB4650CB"
                }
            },
            "3EF17CA226152149F4098258997A7E057FC4": {
                "t": "No...{W:250} his armor clearly isn't Hoikadian.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "429D78AB7F60A645C22AB9E6349D67EB56A2"
                }
            },
            "97F035FD352F634FCB2867C2D5B8D11CCAFC": {
                "t": "Who are you?{W:250} Identify yourself at once!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CC873AD42DFE014B631B38D54259CEEC9B5F"
                }
            },
            "20F1F85076F411472E2941458CF06F3D010A": {
                "t": "The... Captain of the Holy Swords?{W:250} Here!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CA46B14D6A7314421F7920D86E693B3AE4E7"
                }
            },
            "D5EA11F7489BD943158997D5A2423D1F31CA": {
                "t": "Woot! Woot woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "1688F8F5897434444F0B6A646281D9E42AC5"
                }
            },
            "B7E8FF503ABD8347D55812A641630FD65893": {
                "t": "It's kind of cute, I won't lie.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FD1E4D5C8064C649CB6B35244FEBB77BCCF7"
                }
            },
            "2B717C4335EDC74B2879A9A4CBFCD44CD67D": {
                "t": "... ... ...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5DABEE7699FDF344D919FFA664F8861C211A"
                }
            },
            "3A1B092292804847184935D4C53F19FB259C": {
                "t": "Well put, Hellios.{W:250} That way, it should be ambiguous enough for him.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7EADB2F70AB7A941AB4812D84797C0C6C988"
                }
            },
            "742E58403C6AD8435C0AEEB5BACB1BA2D39A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B6AC510D65F7D34B09196836CB8F41C5E526"
                }
            },
            "29DCBD0E6D468643F95A5E21D88507F5D6FF": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "3FE48F0D3F60F7464E38D8D675E5E8EF735F"
                }
            },
            "E1A40B049FCE06414688AF512A87B84C429D": {
                "t": "Hellios",
                "d": {
                    "eid": "1BEBA47C666A074F405A6FD50973BE834D95"
                }
            },
            "4E2921F3820C834898186EA1B848D89D053C": {
                "t": "... ... ...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "9ABFBF8A59E90843692B2AD20B9BAB191889"
                }
            },
            "004FAD3954DF5547499BE2E3B22F3A428A7B": {
                "t": "I apologize for the intrusion.{W:250} I'm Sir Ornières, Captain of the Holy Swords of Pylum.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "12DCFA5569D6A34C4F6A1DC5232A2DDAEA73"
                }
            },
            "941A3AD31A405243C15BB042D36FF12C1FD6": {
                "t": "Sir Ornières, huh? Hmph.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "91EC87084C936044778A58870F4DECF10CCC"
                }
            },
            "D34A20BD87C3784F08798FF86459225F26C0": {
                "t": "A...{W:250} dog?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "681F14165228E54B9F89ADF4C8643958A9E7"
                }
            },
            "0AD4297A66CF2346DE58B3C4DBC14624BC3C": {
                "t": "Shhhh, this isn't a good time, Luckos.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "7AF90FEC85F6A2446D992DB7F00862200954"
                }
            },
            "357B73D02844D2447828B36445ED0F8E4F92": {
                "t": "With all due respect Lady Faratras, this may as well be a trap.{W:250} Allow me to dispose of this man if needed.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "FCAC26456AB42049808BD9F84F5B81B9001B"
                }
            },
            "F03F671981D672469639E9514B20B91BE86A": {
                "t": "(Stop him.)",
                "d": {
                    "eid": "4CC989073DBB37408588E868637E758F6C3B"
                }
            },
            "C6D96E5D4309384E2B4AC014B6E09547C801": {
                "t": "(Reflect on the situation.)",
                "d": {
                    "eid": "D08C4050402F25408528CC202EBCAAB07368"
                }
            },
            "CB878739881C354C6629E904EF50B039D0EE": {
                "t": "Make it quick.",
                "d": {
                    "eid": "461EB216748E3443C38BFD3815ADAB9C8AEE"
                }
            },
            "BC9D36791173F1437749ABC83F435615539F": {
                "t": "Not so fast, Hellios.{W:250} Right now, a diplomatic incident with Pylum is the last thing we want.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A1E7959001F5084E132B97F46C1F33E2EA15"
                }
            },
            "E155EE2721BAF146973A5494CC2261109585": {
                "t": "Uh, wait!{W:250} This is all too sudden!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "E1B4554923F6D245D4899AE532FFEFC51231"
                }
            },
            "AE47F80A79537249576AF431B0EA01D3F53D": {
                "t": "Did you just say...{W:250} \"Lady Faratras\"?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "AD00CFC88F28F74E6F396E090ECC5F30468C"
                }
            },
            "925C059214990549707918F9354A5A439F97": {
                "t": "I don't know what you're doing here in the middle of a forest, but I happen to have been looking for you.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "FC2D4B545476444B2B3BED3861C06AD36D5E"
                }
            },
            "7885B591131856442339FF15141DF03704C6": {
                "t": "Listen, Sir...{W:250} Ornières, right?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "014B5F3622D537436E8AE4B669EFFC1E4BFF"
                }
            },
            "ACBB0EFB73126545A35BFB6297071DE9292A": {
                "t": "This was a...{W:250} tough day.{W:250} And I have more pressing matters I need to take care of.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1C29DCFD3522214B2018A21571782C818CCE"
                }
            },
            "6B88DAED9ADE754BCB297266DF6DCDEFBB40": {
                "t": "Why don't you wait for me at Hoikade Castle?{W:250} I will meet with you soon...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3BC3AA511A48E44EAD2B70E58887BC9540F4"
                }
            },
            "300DAAD10527504FAF2AD581AF28EFECD4F0": {
                "t": "Hoikade Castle?{W:250} Sure, but--",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "F62BD4D169E1334794597D14ED8EBE8E2C45"
                }
            },
            "EC01456E1B07A446541883F9A99E3A1E40D7": {
                "t": "Aaargh...!!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "9348917C05AC2846339812B760CF3E840FE3"
                }
            },
            "D28C37A39104C1403A587E2583FA4401CD62": {
                "t": "Nnngh...{W:250} Why...{W:250} why now?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "D5D0D346189836476138EB33ACA097EA428A"
                }
            },
            "6CCA56D56148C145AD98C6E80A5EC923B417": {
                "t": "Milady, this man looks unstable.{W:250} He may as well be an impostor, as I said earlier.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "D3BA8FE42C7392488A69DAA453608DE1A12C"
                }
            },
            "2DEB41F9185F094BE45985B071910EC85272": {
                "t": "You said that the squad was going to be here soon, right?{W:250} We still have to make preparations in time for their arrival.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "F0C90E7B4505C545B489FC19250073EE188D"
                }
            },
            "63F52F0026F66145A84B125560308E39AC5F": {
                "t": "Yes, being delayed here and now may put us in...{W:250} a bad spot.{W:250} We'd better go.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "BC8696BC4C0F6043F5397180216272D840AE"
                }
            },
            "11F99F5D8CCF7543D2483E18C02EC686609F": {
                "t": "Until later, Sir Ornières of the Holy Swords.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D417D5217C8E214B0089497405CBC4E5C029"
                }
            },
            "42EF5FB785F7864F107B700620BC8BEF4969": {
                "t": "Nnngh...{W:250} Wait...!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "6A6A2CE8173E424AB56954E5FE570047EE62"
                }
            }
        }
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}