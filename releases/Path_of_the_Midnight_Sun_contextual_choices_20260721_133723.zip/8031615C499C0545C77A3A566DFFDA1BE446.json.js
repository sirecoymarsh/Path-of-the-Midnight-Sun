GS.dataCache['8031615C499C0545C77A3A566DFFDA1BE446'] = {
    "uid": "8031615C499C0545C77A3A566DFFDA1BE446",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C6-03 Faratras' alone time (POV change)",
        "type": "vn.scene",
        "parentId": "D114372C8BA57244E87B5C53EF9DFA983139",
        "chapterUid": "6C9C582F416E10408F5A6150A01276B7C148",
        "order": 3,
        "localizableStrings": {
            "54CCD8D58D8347457C78D7E5684E70E216FD": {
                "t": "Puff, pant...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F408265B53B8B246AC7863111135608EBB76"
                }
            },
            "D31F6362793129471B284EB3023ADC9AE1B2": {
                "t": "I thought some morning exercise would help distract me from painful thoughts...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F8311AD265A7464AA8293752994849C27D0A"
                }
            },
            "AFA9522B9125124FC77BA9920A3CE595ED82": {
                "t": "... but it's actually... even more exhausting...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C65A1EDD34147345206BECA7C082D1B5B755"
                }
            },
            "5C4C7CB66BDF2044D46B13B6DBA5E6D5CEDF": {
                "t": "Lady Faratras, there's no need for you to follow me up here. You should return to the camp.",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "A55C46F519D5804F2D4808D49C2A8C657350"
                }
            },
            "B14E213149BF844382694E58127BE2599604": {
                "t": "(I'm... actually dying here...)",
                "d": {
                    "eid": "1C956F3F2A246547D42933A841A97DDF5F98"
                }
            },
            "3BBD7DF752F83140CA6869933377ABAB6503": {
                "t": "(Who invented physical exercise?)",
                "d": {
                    "eid": "69B3CDE24C9C9742B88AC700A1CC3319499C"
                }
            },
            "27EBAD2723EFE44AC08A3AD22847B41AC9A3": {
                "t": "(Why can't humans fly?)",
                "d": {
                    "eid": "76B1AF729D95474E842A64D18B63325239FC"
                }
            },
            "C7E98DB81FDE9140E539B12600BB12185185": {
                "t": "Thank you for your concern, sir, but I'm okay... I'm not accustomed to this sort of exercise, that's all.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8083D9830E4114498A4AE996DE5AEF1515DA"
                }
            },
            "9BADD99C434422479E58DC21EFF33587AFCB": {
                "t": "It's rather uncommon for me to be able to walk outside the castle like this. I might as well embrace this opportunity...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "13BBEB698A74734E796A61E129C766A7D705"
                }
            },
            "F9443C7C3D159145B71AF2E4952FF3E9A01B": {
                "t": "Tch! As you wish, Your Highness.",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "158CF8C16F16C44EDD798AD285A876C4AB06"
                }
            },
            "5D8B8E635A456847C79846F556EB8281C7E1": {
                "t": "Is it just me, or was he kind of annoyed just now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0E3A922214E9B348614A71A3B3D5E5192C69"
                }
            },
            "FC38086E7664A3467258A9C6AD79FA2A8C8A": {
                "t": "I followed this Magnolian scout hoping to improve my mood, but Rya really should educate her underlings better.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6DBCC23F5D891143AF5A8C625F1A7E27A8AD"
                }
            },
            "E27EC76180D5774A084B8826755EFAFE3F4A": {
                "t": "Perhaps the scout wasn't mad at me before... He just seems a bit on edge.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "79CB3C963923B846716A15B1A61103397420"
                }
            },
            "A52F17EC51A2464D3B688831A210994309E7": {
                "t": "Oh? And who do we have here?",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "5C1736453A144245598A7318BFE9DF6BBA81"
                }
            },
            "04EDB11F760D854FA798076429CB146541AA": {
                "t": "You're in the middle of the track, little girl, can't you see that?",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "D46728686219754EBC2B86C52CB62222A548"
                }
            },
            "07C35A892BFA5743A129F4854BE67BB24E87": {
                "t": "???",
                "d": {
                    "eid": "2F5E8EF65AB893423F8AF015CE0260D13E16"
                }
            },
            "EB95D36D6C27E4430C5930449C4A129A8D47": {
                "t": "Oh, I'm sorry, but I can't. I'm blind, you know? Eheh.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "10685A4F8EDFB244376920A2E1A60627E7F6"
                }
            },
            "3D4EE7026E751047658992A2CBA48850B100": {
                "t": "So that's why he was acting suspicious. Has this girl been following us?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "842F3F0C784CF54DA338E064589E025445EF"
                }
            },
            "658667A95154B6453C59D7D66508C39F65B0": {
                "t": "I have to say, it's hard to believe that a blind girl would be out here in the middle of nowhere. You were clearly tailing us.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F67DFF4B12B231490749971639EDB1752499"
                }
            },
            "7100DCA860E1C042458B7D605DD68513FCD1": {
                "t": "Poor girl. Being blind is such a disgrace.\nPfft. Now, out of the way!",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "DEA8FFCB1C55844CFA5B7423535502C30AA8"
                }
            },
            "7655047483C69542967BE4D2BF03FC83896C": {
                "t": "Oh, I don't think I can let you pass. I'm really sorry, Mister!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "4E0013B647D9B04759383171690274308072"
                }
            },
            "8F28EC2440917642E339EB39108B9176513C": {
                "t": "Don't mess with me, tiny one. I WILL pass...\nWith or without your permission! ",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "4BF07DDF50E963424148FD430DFA998DF9E9"
                }
            },
            "442F89DA00D0C040D49B0314A0CD6F3492BE": {
                "t": "Wait! What are you--",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "482EE6FD64D6B04E250BBE827DD9C4976B95"
                }
            },
            "5923B835566ED64360395B63D51F4FB68358": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "838570957F5AC04A6B4B7C1650656203C0BF"
                }
            },
            "A4E9A41570510842F52BF076787FD8482DE6": {
                "t": "This scout dispatched by the empress...\nWhat was his name again?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F602907529526544E35B4514022C81B8638F"
                }
            },
            "7720B23C866EB1439719D790C125A05E68E2": {
                "t": "He seems quite accustomed to these strenous walks...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "37BA38D580E2F94831894239F42E7156C827"
                }
            },
            "9CCB41CB663E8943668A5035421FC3585218": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1C97CF37280F0546E44B2ED2F32A0CCEB5C8"
                }
            },
            "28C758E78E57B84B9249845048992E074B9C": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "55FD76181207E44B676ACC8534696362E23F"
                }
            },
            "76610D2883DA744AAF6A7409FAF4B85BD687": {
                "t": "NNNGH!! Gwaah...!",
                "d": {
                    "cid": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "eid": "043C6FC36B174849C9394F027740D8D400E5"
                }
            },
            "B594245A4C87D94D7A294559968AD34FD019": {
                "t": "Dear Gods, you killed him!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "1BA4090A626D8446136A0D96E8A9ED45E64C"
                }
            },
            "08FDD0112AE08449AC4B23455EC4583BECC4": {
                "t": "Who in the world are you!?",
                "d": {
                    "eid": "86D09991235B874BC86A81C97A0D9ECBF40A"
                }
            },
            "2FB578805C50614B7C286CB0957FD2A159EA": {
                "t": "(No questions asked. I must kill her!)",
                "d": {
                    "eid": "F892C1D581F0B74BB08A81917191C4028E43"
                }
            },
            "7B3F830949D2814F2C398875F08977FA2D9E": {
                "t": "I can sense your murderous intent.{W:300} But please, don't be too quick to judge.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0956773E86CC8949A55A18B8784B0C718968"
                }
            },
            "8EFA96FE48826844114A16A43ADF4A31436B": {
                "t": "I'm just a wandering blind girl.{W:300} Nice to meet you!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "FB324DBF8B00A745A25B5186002700BFB505"
                }
            },
            "510EED49947819488F3A43581054E6E7F628": {
                "t": "Are you kidding me!?{W:300} And why did you have to kill him!?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E8A9205D8980344AB36AB74572DB83622729"
                }
            },
            "F0BE90C19BBFE54E5C4B3A9795047BD0BB65": {
                "t": "He was the one who attacked me.{W:300} I just defended myself. ",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7D18D70334EF0546F70A6F472D876A48B445"
                }
            },
            "656524B63189A14ACA88BAC53A79E65ABCC0": {
                "t": "Don't tell me that! You're dangerous.",
                "d": {
                    "eid": "EE9289472C62D74DD66AC70505E728E7CEA5"
                }
            },
            "B37314AF556248407499F4153C74E066DE70": {
                "t": "That's not a good reason to kill someone.",
                "d": {
                    "eid": "71501C836623D047FB2B4AA4C54296DB6172"
                }
            },
            "4426911C616484454A1A1C755486791EA0F0": {
                "t": "I wonder.{W:300} With that statament just then, were you judging me...{W:300} or yourself?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CB035AE102E11140E5695BF100EEB11358D3"
                }
            },
            "4EAE76401898E34D4578CDC17C63F70EFA5D": {
                "t": "What...! Just WHO is this insolent girl!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6902B59E1AB6D6494E190CE25BD85F692B39"
                }
            },
            "5A8CD88B8983554D977B5EE4D826E1158F41": {
                "t": "Wait... Is she somehow aware of what happened in Hoikade?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B4B37E8794CFB94EDB18CCE70E5A1F21AC0E"
                }
            },
            "BADD2BD049E01440149A40D49876645F4AD0": {
                "t": "I don't know what kind of games you're playing, but that scout was a good person.{W:300} You provoked him and...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B137716134B1354C3B1A34528D8B24BBF922"
                }
            },
            "46BBCDF22F4D524D873A64A1A5061455940B": {
                "t": "You're wrong.{W:300} How can you say that?{W:300} Did you know him?{W:300} Do you know me?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "173C27815C2182485B290CF92372C1F1AEC9"
                }
            },
            "9BE232489A39484D3969E33865DED1D4A28F": {
                "t": "How can you say that what you saw from your point of view...{W:300} was the truth?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3CC401F86338A444C659FB27B43199F048BB"
                }
            },
            "789F6DDB17D9224B628B9CD57E25CE4CA420": {
                "t": "You're crazy!{W:300} I can't understand a word of what you're saying!{W:300} But I must stop you.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "93D3C9E73273844282286B6441467612BFFF"
                }
            },
            "7B45D2484F3EF349557BAB12DAE0E2F6F7C4": {
                "t": "Her Light magic is no joke. And she seems to possess some intel on us. A spy, maybe?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5B66AF37734AF64D8C4B6B305B00BAC59251"
                }
            },
            "05941FEB6CEC87444B4A2F9066117C7520E4": {
                "t": "If I don't stop her now, there's the possibility she'll kill the people at the encampment, too...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6784471800AD55471A4B28621D3B004C6321"
                }
            },
            "34A632EF8959C84C1A7B7316A02EE7ED33C7": {
                "t": "... Please, calm down.{W:300}\nI don't have a reason to fight you.{W:300}\nAnd, it looks like we have company.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3CCE390E754175451A5AAAD5DDC1F95FAD27"
                }
            },
            "A1EE2C8D57DB3845F22AB622B44A0E209CBF": {
                "t": "What?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A30B02F3239ED9496A883091E85888CA9476"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Faratras' POV"
                },
                "indent": 0,
                "uid": "046E81D57C93754251182D4917DFEAB19F78",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "0DB97BC16144254BC77BF65096D9B9210BC2"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "NOME GIOCATORE",
                        "index": 149,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2DF616BE1EE4E543DD8B28A16A7AB6970E7C"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "field": 0,
                    "targetVariable": {
                        "name": "POV Main Character",
                        "index": 110,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C0E58D0D26BBE54AEE2BF3848FBC8CE03F14"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B33AD3C059F1A640A04B62C4533B9A3A9CD6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "790B95933951734FEA390BA03DEB5BEE6DAC",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "27CF959402AE8345B69A91929CB65F709E2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1D5E67F3544E0848BE88A763A89E77D3829C",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            55,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "44AAC2976183244A966A3E402E3022556937"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810"
                        ]
                    }
                },
                "indent": 0,
                "uid": "885A44B5194C6245383AF54292BADD1C6EEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AB3CCC5487C134E3C79F1B77C369A8F00C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE"
                        ]
                    }
                },
                "indent": 0,
                "uid": "6729459B2E269444682A3C52C462610E2C3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB34836D6CD0C84EB56A5039FC2A3A6D6002"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "532A709324BC524CFB48A3974ACD90F62E7E",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F37A240A1F082247191A25D2BF826374BEAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2DBBC0B6F680048902BAB038E8650C1EABE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "D069939F154A18455D6A28947B13D3E47D27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "64AF52ED11A5B1474F7BB5B08D1F71227568"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "03E950E82B84F74A14498972537096C40B2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            30,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B5EDE1142E1B54BA1190B0319B828F4CB0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8190E82B144E984082381FF69149D6F74520"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12D0354E57767941996AF9395B60E5C3030B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CA180558874B41463188E1F8D7CB2D937A2C",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "464F09F2746F644E844BA1883C2B8663576C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            2,
                            20,
                            0,
                            0,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CAFBE814AF896474338DC31060424704055"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 150,
                        "y": 150
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "57CD5F23794F8841813A6C0089D1BB00FE0D"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 200,
                        "y": -50
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9136DA418E879448927A765701603548C8E8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "EA22663D8ED5324B4808BD48DF508B557EDD"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "609F5EDA402E274AF5189B77ADCB7A61DE83"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "649F861D83A05343D82BD5C7669B75EC8A79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "43C096828927084E448A29682DF7D68FC558"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B16C62F80DAE749059B055522D216E8ACDC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D5D21545707D94E534B4A719CBD5E670C41"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5923B835566ED64360395B63D51F4FB68358",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line30_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "838570957F5AC04A6B4B7C1650656203C0BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "30F1BEA21983924C13682807C2D08F220184"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAF3226D7CC1D24A66495E20D6011AD6F46A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "54CCD8D58D8347457C78D7E5684E70E216FD",
                        "defaultText": "헉, 헉..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F408265B53B8B246AC7863111135608EBB76",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F1B2BCB2BE362432F3BD056435A74A583CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CCCE6458DFA424BB18837326355122E5EED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D31F6362793129471B284EB3023ADC9AE1B2",
                        "defaultText": "아침 운동을 하면 괴로운 생각을 떨칠 수 있을 줄 알았는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F8311AD265A7464AA8293752994849C27D0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F712B54816C7349037B06D557CFEF8CBEBB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AFA9522B9125124FC77BA9920A3CE595ED82",
                        "defaultText": "...실제로는... 더 지치기만 하잖아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C65A1EDD34147345206BECA7C082D1B5B755",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4DCB3B195EB838405989FC67822F55676CDC"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "63E65FB7641DB84FB61BC056D8FFA03D0A99",
                        "name": "40 - Amaranth Scout"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 7,
                "uid": "4A10C1185A4E7647058A6931EFAE2A5E86BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B99590476FFCE346DB1AD9B55D0AC9EAC3B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "19B54C423A9BC3487648CC801E1209C399E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEC5876A477874420C3AC1F2F5F0CF6E639B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C4C7CB66BDF2044D46B13B6DBA5E6D5CEDF",
                        "defaultText": "파라트라스 님, 여기까지 절 따라오실 필요 없습니다.\n야영지로 돌아가시죠."
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A55C46F519D5804F2D4808D49C2A8C657350",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29F794A99EC74548C18A14620478B43262E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDE2E84D407429412D1AA7251F15191A7C34"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4E9A41570510842F52BF076787FD8482DE6",
                        "defaultText": "여제가 보낸 이 정찰병...\n이름이 뭐였더라?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F602907529526544E35B4514022C81B8638F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C660DF94DB35047E63A58D072AD50549C63"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7720B23C866EB1439719D790C125A05E68E2",
                        "defaultText": "이런 고된 산길에 꽤 익숙해 보이는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "37BA38D580E2F94831894239F42E7156C827",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECEF60D24D87864B5E4A93F39458CAAC9C63"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B14E213149BF844382694E58127BE2599604",
                        "defaultText": "(나... 사실 여기서 죽어가고 있어...)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1C956F3F2A246547D42933A841A97DDF5F98",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3BBD7DF752F83140CA6869933377ABAB6503",
                        "defaultText": "(육체 운동을 발명한 사람은 누구입니까?)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69B3CDE24C9C9742B88AC700A1CC3319499C",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "27EBAD2723EFE44AC08A3AD22847B41AC9A3",
                        "defaultText": "(인간은 왜 날 수 없나요?)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "76B1AF729D95474E842A64D18B63325239FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "fake choice",
                            "fake choice",
                            "fake choice",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF7AFAE4284EC942525AE9450E43D5B90E7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7805BFA0918B0740339B61F139EF102BA552"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fake choice"
                },
                "indent": 0,
                "uid": "7F0937407252D04BD3594EB42848902482A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65703DD797B24747FD09DF365DC4B3410FE0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C7E98DB81FDE9140E539B12600BB12185185",
                        "defaultText": "걱정해 주셔서 감사합니다. 하지만 괜찮아요...\n이런 운동에 익숙하지 않을 뿐이에요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8083D9830E4114498A4AE996DE5AEF1515DA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1609E3AC86E55149BA6AE1F760E174A4D761"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9BADD99C434422479E58DC21EFF33587AFCB",
                        "defaultText": "이렇게 성 밖을 걸을 기회는 좀처럼 없으니까요.\n이 기회를 마음껏 누리고 싶어요..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13BBEB698A74734E796A61E129C766A7D705",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F9E081F1780E946D719CF689E86E0CD0AA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "697F496D6FC992422F7A103713F224F8EECF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4108D08B7CA2D54CAF3AD3539EF294A65F17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9443C7C3D159145B71AF2E4952FF3E9A01B",
                        "defaultText": "쳇! 마음대로 하십시오, 전하."
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "158CF8C16F16C44EDD798AD285A876C4AB06",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ED42952298D9947457A6F3223A42B30A7F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B439B115DF9D64DF39907D60A6AB1E438C1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D8B8E635A456847C79846F556EB8281C7E1",
                        "defaultText": "방금 좀 짜증 낸 것 같은데, 기분 탓인가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0E3A922214E9B348614A71A3B3D5E5192C69",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B2759A85543934BD869CF55339E3A315BDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ED10C17760A544427D49C9C5D904354C2663"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC38086E7664A3467258A9C6AD79FA2A8C8A",
                        "defaultText": "기분을 바꾸려고 이 마그놀리아 정찰병을 따라왔지만,\n리아는 부하들을 좀 더 잘 교육해야 해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6DBCC23F5D891143AF5A8C625F1A7E27A8AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE361DF25356A6420D980341BEDF10BE40DA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D622FB784CEC6742B46A3E2576FDFB169C34"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D6DE8D3978F6734582586CA079B8222BB6AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB537C127D1DA54BAC9A19B35F2EFC2BFA7C"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "A9C50C728F64474DD5386FD4DE64EBEFA944"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "64E32B6D13BDA34FF088FA94687AAC9CE2DC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "F894FB1C2A242244F359DED08A2108D064D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            20,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C97563E67EA284B151AAD74C1DEEA0A30BE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "3F743A0769E1D54D8519D0038EECFA78E714"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "92A19E431BD88747FC994DF5E355C99D0A4D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "458FE1828F35B14F3F2AD398B96B6A1D6EE1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(black screen, time passes)"
                },
                "indent": 0,
                "uid": "5AB2334B770B064C2B48C3118B8BF55B425D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FF4A62AF23CAC54E4758D111AE0E8C18EF0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DF16DDE9FC4F548B49AB465175FD7847780"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B24FAC898DFF9543EA18F2914D84F555EC94"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E27EC76180D5774A084B8826755EFAFE3F4A",
                        "defaultText": "아까 나한테 화가 난 건 아니었나 봐...\n그냥 조금 긴장한 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "79CB3C963923B846716A15B1A61103397420",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "407F32CE30A6C84E1C49BC03AEFFBF7E36BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BC85146829E314A6E99F89517E742D19F28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A889BC25C74F34C099AFE67F5DCB2CC738C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0FEF3724184CD04C229B59A7F55C7865C6C2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A52F17EC51A2464D3B688831A210994309E7",
                        "defaultText": "어라? 여기 누가 있네?"
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5C1736453A144245598A7318BFE9DF6BBA81",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FFCD5165CD33447C4797B227DB954F76FD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1586F5AA7D685544F44994E1C832A6C13E15"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "26A3CAA1871C124E246A0DB8051509852BB5"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 48,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "8EFD7EDE9F01A842B648F807650F0845CC3D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "1F4161924804D240E24B3EA3E009F693C910"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C03AA1D49EAB94450C5BFEB2E7675E0372C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09587E5F4789314AC46ACEC3C3ADB23302B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF9C1B075D33B046046BED24537CBF788927"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18F6C68B19B4074441391621378253BCBCEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "04EDB11F760D854FA798076429CB146541AA",
                        "defaultText": "꼬마야, 길 한가운데 서 있잖아. 안 보여?"
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D46728686219754EBC2B86C52CB62222A548",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E8E7D2D8CCEA440E84850A55CC7738D1796"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Shiori's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "07C35A892BFA5743A129F4854BE67BB24E87",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2F5E8EF65AB893423F8AF015CE0260D13E16",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Shiori"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Shiori's name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "23CA99CC6A01054BB19B61E422F0AA74F7CB"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "4EC6EEF6594447477A8942F27FFC21FEEA72",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Shiori"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Shiori name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B5ACCF0C4FF1F64E6C78E3D5D0C792FA8DE2"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Shiori"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Shiori name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "82CFC5554734384FF948B4C20FC95E152B9F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF5582865ED3754CE6880C64D800C3B80887"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6F47B95518F3234EDA890C164747C07FB97D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9CCB41CB663E8943668A5035421FC3585218",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C97CF37280F0546E44B2ED2F32A0CCEB5C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BC4505D05721C7463F28B1B04B2A0CD79D93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B43290EF287BD54E165A7B05A0EA0335E27D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB95D36D6C27E4430C5930449C4A129A8D47",
                        "defaultText": "아, 미안하지만 안 보여요. 저 장님이거든요? 에헤헤."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "10685A4F8EDFB244376920A2E1A60627E7F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DACDE031FD1F249B82942649891145FB4A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61F7591B51ECC943453A3FB7208FE059963A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3D4EE7026E751047658992A2CBA48850B100",
                        "defaultText": "그래서 저 사람이 수상하게 굴었구나.\n이 아이가 우릴 따라온 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "842F3F0C784CF54DA338E064589E025445EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3932DB42CBE2442874B79E0014815795245"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B662155C2E9D744F365BEAA67A5529348577"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "658667A95154B6453C59D7D66508C39F65B0",
                        "defaultText": "눈먼 아이가 이런 외딴곳에 혼자 있다는 건 믿기 어렵군.\n분명 우리를 미행하고 있었지."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F67DFF4B12B231490749971639EDB1752499",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A91415B8D28434D2B1A7207BB03FDD05256"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1A2A316445CC349425ADDA09922F0147A18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "90F0F9446823874EBB2820A0509E49102501"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1362542921F5241A54BC4651A992C4902AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7100DCA860E1C042458B7D605DD68513FCD1",
                        "defaultText": "불쌍한 것. 눈이 멀었다니 참 딱하군.\n흥. 이제 비켜!"
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DEA8FFCB1C55844CFA5B7423535502C30AA8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9673F6F6671D447875AE86846FFC2AA6719"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94AB505D4408E04A006BBF336AC006F7E843"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19F2398F1D9D52422008C3E926C91E4D3866"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC6D823F36CBF345B80BCBA487997ED5B69E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 21,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7655047483C69542967BE4D2BF03FC83896C",
                        "defaultText": "아, 지나가게 해 드릴 수는 없을 것 같아요.\n정말 미안해요, 아저씨!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4E0013B647D9B04759383171690274308072",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9434D12D4174754EA58B38F733313D5B920A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18DE06B98637F4479A18CBC25465877491BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BDB25D74441B6499D3851572BE888AA8431"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 21,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F28EC2440917642E339EB39108B9176513C",
                        "defaultText": "날 우습게 보지 마라, 꼬맹이. 난 반드시 지나간다...\n네 허락 따위 없어도 말이야!"
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4BF07DDF50E963424148FD430DFA998DF9E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BF1EBEF93212149C3890E06806449AB0003"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A5CD3C3B352843410338B9731325131A7FD8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EAB675EA3B63A04DB04BA9323AE73CDC1A49"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "82BE45EF3581464C8A7ABCE8E710D8EDA476"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0DDABF85722B134A135962599B1DFEEE8671"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "field": 3,
                    "targetVariable": {
                        "name": "COORDINATA X SCELTA",
                        "index": 38,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "55B03BB346D3B74CB27B2AD457B868F77ABE"
            },
            {
                "id": "vn.GetObjectData",
                "params": {
                    "objectType": 4,
                    "number": 0,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "field": 4,
                    "targetVariable": {
                        "name": "COORDINATA Y SCELTA",
                        "index": 39,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "94A257D424D26944208B5B143E2E72BFC0B7"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "COORDINATA X SCELTA",
                        "index": 38,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 2,
                    "source": 0,
                    "sourceValue": 2400,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F572715F9A94774AD98940B50C4C8EDE64D2"
            },
            {
                "id": "vn.MoveCharacter",
                "params": {
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "predefinedPositionId": 0,
                    "duration": 21,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": {
                            "name": "COORDINATA X SCELTA",
                            "index": 38,
                            "scope": 1,
                            "domain": "com.degica.vnm.default",
                            "changed": true
                        },
                        "y": {
                            "name": "COORDINATA Y SCELTA",
                            "index": 39,
                            "scope": 1,
                            "domain": "com.degica.vnm.default",
                            "changed": true
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "ABCDFDD355BC844140497AC252B855E5CD52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D63AB79A6C93D8482F4934B4D83C745D75A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C6672525A8A884A7748C648F92395ECB01E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 21
                },
                "indent": 0,
                "uid": "98FA871B6C0AC14BD818FBE49684B7E88D07"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0AADDED1292AC247962806069A2746F4B992"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "17E0715D7E2F764E931AC621C5D83B1F8CD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "28C758E78E57B84B9249845048992E074B9C",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line31_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "55FD76181207E44B676ACC8534696362E23F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AD4222C27414D449A11BC375AFDD26C01C6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F10209A5A2F394E861ADBF11FAA8827EFE8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4CA50BB902AC3447570AEEA29099C625092D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "442F89DA00D0C040D49B0314A0CD6F3492BE",
                        "defaultText": "잠깐! 무슨 짓을--"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "482EE6FD64D6B04E250BBE827DD9C4976B95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2202BD65C37324E51780697A36707D8A335"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4EA143E3C838740254872C25258607BFDCD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "7274545903EEA241B86A57B9CD33E833E97F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEC8FF411C71E5497B19C5749FF4599272A3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "52427F4C70C6254CCD6BC6B5AC7FD6D55F59"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Light Attack.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1D8C902A563E3543EF3BBDD99A7810840D9F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            2,
                            250,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F31A2E9E7A289248D09991118FE26A3FBD87"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "71A72182228EF2490E9B9CD5D1505414C974"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47A8B99D18FB6947011AB92765A99EAE34E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54377904229B0642FA6B7D936C65892E1EDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BC42E39A179DB4407139EAF59164DC3CD77B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3067FE669040E647D969B567F4B2AA9532BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28717E827790A743E86927C7AF432CFA59BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "EF1E0C4F3732E84BD2591514570854DD696D",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFA362ED250F63442389D7143B406B323D56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "78C3A89212DE4145C5588435879303E85657"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "76610D2883DA744AAF6A7409FAF4B85BD687",
                        "defaultText": "크윽!! 으아악...!"
                    },
                    "position": 0,
                    "characterId": "EF1E0C4F3732E84BD2591514570854DD696D",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "043C6FC36B174849C9394F027740D8D400E5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2203BAD349957441A989E26FA93B6B59052"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85AD92293CB25240DF4B2FE388EF46C2DB13"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "F290188823D4D34D3D39B0C354F8ADA37013"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "01A496FA4DB5654FF6492FC06A45E019C243"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "25EB82F223E7D748595A35834B9AB2DE789A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E810719173B04149C068B828F55440E3C334"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7F246900223BA34CAD8850D2BB6F07B57B41"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51A7BEA880B2574DB79B72E85D4432F825EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE720597566A754E1C7B238275B2E22C73DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B594245A4C87D94D7A294559968AD34FD019",
                        "defaultText": "신들이시여, 죽였잖아요!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-04e2_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1BA4090A626D8446136A0D96E8A9ED45E64C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2E4100B54581540A54BCBA57EF0DA6C6B38"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "08FDD0112AE08449AC4B23455EC4583BECC4",
                        "defaultText": "대체 누구야!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "86D09991235B874BC86A81C97A0D9ECBF40A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2FB578805C50614B7C286CB0957FD2A159EA",
                        "defaultText": "(질문은 없습니다. 그녀를 죽여야 합니다!)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F892C1D581F0B74BB08A81917191C4028E43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "identity",
                            "murder",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "833C5AA87ACCC940EF38900632438C94A0EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1B0A976467C3A843C93AAD4221F840CEF611"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "murder"
                },
                "indent": 0,
                "uid": "D69F8CD33DC9F444D98A1DF64DFA603D6993"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+ cruelty"
                },
                "indent": 0,
                "uid": "1DCB3EAD408DC94CC15A143347DCF273FAE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            4,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D40B1A35A42C74EE05A1B728CB368405267"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EF9A52F4E8F13415F19C0E7AE5E1AD2E40C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B3F830949D2814F2C398875F08977FA2D9E",
                        "defaultText": "당신에게서 살기가 느껴져요.{W:300} 하지만 너무 성급하게 판단하진 마세요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0956773E86CC8949A55A18B8784B0C718968",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "DCB95F12464D734FE778E0E66DD2343A522F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "identity"
                },
                "indent": 0,
                "uid": "5D3AC7625B6EE14F622AF5B15897B178CDAD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64A1A59C628A6844AC5940211A1A18FFF03A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99613F3B58F62446BB8A0C21C9908DCDB0ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EFA96FE48826844114A16A43ADF4A31436B",
                        "defaultText": "저는 그저 떠돌이 장님 소녀예요.{W:300} 만나서 반가워요!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FB324DBF8B00A745A25B5186002700BFB505",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 1"
                },
                "indent": 0,
                "uid": "02A2AA21320A45400B3A3EF145BBEEEB2B47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88C894E2755CA84946786FC2F9E786BDCA62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F84E8AC5803D3462B2AFBF4EA30B83B67C7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "510EED49947819488F3A43581054E6E7F628",
                        "defaultText": "지금 장난해요!?{W:300} 대체 왜 저 사람을 죽인 거죠!?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-04e2_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E8A9205D8980344AB36AB74572DB83622729",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4FD194DF2DD7D245B6383948FB2820F6208E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B1F244A47983844D35847C4919B532AB061"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE8E17FD79EA364C23598C05FCD2A8472525"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9045A40E240EC643206B495644D467B97F47"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F0BE90C19BBFE54E5C4B3A9795047BD0BB65",
                        "defaultText": "먼저 공격한 건 저 사람이에요.{W:300} 전 그저 제 몸을 지켰을 뿐이에요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7D18D70334EF0546F70A6F472D876A48B445",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5B2011C8329464C6B091CF0F9FF2678A587"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "656524B63189A14ACA88BAC53A79E65ABCC0",
                        "defaultText": "그런 변명은 집어치워! 넌 위험해."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EE9289472C62D74DD66AC70505E728E7CEA5",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B37314AF556248407499F4153C74E066DE70",
                        "defaultText": "그게 사람을 죽일 이유는 못 돼."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "71501C836623D047FB2B4AA4C54296DB6172",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "after choice 2",
                            "after choice 2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CC385254AE4D443B11869D20177E3822AB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DB2E0DFA48E473445E2997A39CE8EB6D6B43"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "47B67E117553D349C74849A5C0F4A0BA5D63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            23,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B11D57D5301024A17282C38FE8B1AD7C211"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64B4F9D52291D64A734888429FA24607A972"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76A900825B32F949C749B2B6C2C80392680E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4426911C616484454A1A1C755486791EA0F0",
                        "defaultText": "궁금하네요.{W:300} 방금 그 말로 판단한 건...{W:300} 저인가요, 아니면 당신인가요?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CB035AE102E11140E5695BF100EEB11358D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC51DAC77BAA9943D1882A795697AA67D193"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32C5FD64493A254AB74AC400D5A51C47B89C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4EAE76401898E34D4578CDC17C63F70EFA5D",
                        "defaultText": "뭐라고...! 이 무례한 계집애는 대체 누구야!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6902B59E1AB6D6494E190CE25BD85F692B39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FB8374585A6904943983AF46DA73D685EFA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5A8CD88B8983554D977B5EE4D826E1158F41",
                        "defaultText": "잠깐... 호이카데에서 일어난 일을 알고 있는 건가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4B37E8794CFB94EDB18CCE70E5A1F21AC0E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2C56CBC9A5F674AA16AEC94F6EA004539CB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E82BD881165934EEA98AEE1F7672F96669A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BADD2BD049E01440149A40D49876645F4AD0",
                        "defaultText": "무슨 수작을 부리는지는 모르겠지만,\n그 정찰병은 좋은 사람이었어요.{W:300} 당신이 도발해서..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-04e2_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B137716134B1354C3B1A34528D8B24BBF922",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C90125800F58094E896972C67C028943584F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90C1E8E26DB881446B0AEF117A5EB845D8E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46BBCDF22F4D524D873A64A1A5061455940B",
                        "defaultText": "틀렸어요.{W:300} 어떻게 그렇게 말할 수 있죠?{W:300}\n그 사람을 알았나요?{W:300} 저를 아나요?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "173C27815C2182485B290CF92372C1F1AEC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5845B2928073748274B2889DA1786F07A73"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9BE232489A39484D3969E33865DED1D4A28F",
                        "defaultText": "당신의 관점에서 본 것이...{W:300}\n어떻게 진실이라고 단언할 수 있죠?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3CC401F86338A444C659FB27B43199F048BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EBD21042D76F042D80B2DC7438527DFD0CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13887D405317E24F8E281C666ECE48A5C4E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "789F6DDB17D9224B628B9CD57E25CE4CA420",
                        "defaultText": "미쳤군요!{W:300} 무슨 말인지 하나도 모르겠어요!{W:300}\n하지만 당신을 막아야 해요."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-04e2_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "93D3C9E73273844282286B6441467612BFFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC0B1C6374AC5148105BEAF3F3AC17E1C337"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75955BD66391B24BFF8ACBF1879F6CDB26D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B45D2484F3EF349557BAB12DAE0E2F6F7C4",
                        "defaultText": "저 아이의 빛 마법은 만만치 않아.\n게다가 우리에 관한 정보도 아는 것 같아. 첩자인가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5B66AF37734AF64D8C4B6B305B00BAC59251",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE69F9668CFAC947875944F99F4B3454CAD6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05941FEB6CEC87444B4A2F9066117C7520E4",
                        "defaultText": "지금 막지 않으면 야영지 사람들까지 죽일지도 몰라..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6784471800AD55471A4B28621D3B004C6321",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F585BA823E89A548D819BAA0E81792C85786"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            11,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC39300C131444413D0A31026140B97C3D21"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA3995122D0B6548937B0F83D5D9FF3B14B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "34A632EF8959C84C1A7B7316A02EE7ED33C7",
                        "defaultText": "...진정하세요.{W:300}\n당신과 싸울 이유는 없어요.{W:300}\n그리고 누가 온 것 같네요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C06-04e2_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3CCE390E754175451A5AAAD5DDC1F95FAD27",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "79CF3486128F82466D290DE55083A53898BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFA88CFA64B3234B5F2A7B954D564EE4182E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C2000F6D9635E649E86962767A0E1F6E91E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1EE2C8D57DB3845F22AB622B44A0E209CBF",
                        "defaultText": "뭐라고요?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C06-04e2_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A30B02F3239ED9496A883091E85888CA9476",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B499033C60594845E35B4648BFC5B21345FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3E7671C42D4F784D057B9C27B0FDE1376208"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B85B2E38097E540CD9B78E22715B0403E80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C01BB01593659845425A7D223C04D806482A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "EE1A133339E5C544E6798FA855D9F513F7C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EF8E59B5452974F252A6442868DA7E87AFB"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "20730FA55ACCF44D807B7CF017DE891F759A"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "7412D1F62E8442489558BFF0A2C641F5DFF3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "27092D5A8F09C24A6418B470EBDB51474217"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "906C71BD1C76C6491D880F31363E8E503B5B",
                        "name": "C6-04 MAIN MAP"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CFFCE7DC6CCBB34DBE19A516D88FEF8C5646",
                "expanded": false
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "stringVariables": [
            {
                "name": "Shiori's name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}