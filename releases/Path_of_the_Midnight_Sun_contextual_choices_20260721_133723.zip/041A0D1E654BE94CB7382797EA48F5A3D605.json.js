GS.dataCache['041A0D1E654BE94CB7382797EA48F5A3D605'] = {
    "uid": "041A0D1E654BE94CB7382797EA48F5A3D605",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11B-8c Pre-battle Kabeer",
        "type": "vn.scene",
        "parentId": "04D12A924ED7E240E4793325D061E98BB345",
        "chapterUid": "8A78B92E5A59F446F05823F4DB00C78A28B3",
        "order": 17,
        "localizableStrings": {
            "0E3FFA2A94A2C34EFD8B19E1A9AF098582D6": {
                "t": "Hmph.{W:300} I'm fine now...{W:300} Thanks.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "C65701863C208540868B5CB74CBA4617DD9F"
                }
            },
            "1B6B8923547A874CE80A9873B35F8A1645F2": {
                "t": "Whatever the truth is, we'll deal with it together.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "74CF3A6B8875E34F1289A6D7FC94B0413C5E"
                }
            },
            "45906E6312B4194AA288FD57A146186EC9E8": {
                "t": "We will.",
                "d": {
                    "eid": "5CC8FDAE311640492E4A8E199534DDC84274"
                }
            },
            "99C4D9F8629AE745134BD6914715A5068254": {
                "t": "I will always be there for you.",
                "d": {
                    "eid": "311E7A665C94684A8A6889B88F0814C26488"
                }
            },
            "4FF164B5285E134AF4694240734B80CA48FF": {
                "t": "Okay...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "3C5D7D8D40C6B242D29902524AB716366E6E"
                }
            },
            "6DFE506D933434491269CE997B9101E6EB83": {
                "t": "\"Okay\" indeed!",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "D977615222C01041940BED97E95968B67EF9"
                }
            },
            "2F9410AA38E9974EE75A155406BD783FB6E6": {
                "t": "Uwaaah!{W:300} A-An earthquake!?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "5ED75B5A8CFF6542C91B4562C489AABB6E95"
                }
            },
            "5EC9EC6F6CBE134BE04B06950337BA70968A": {
                "t": "What in the world...!?\nWe're outside!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0DD4B6213B080942CE788F97E32BDFED220A"
                }
            },
            "9FBBA301660DC44ACE18BFE055AA1D8E8E6A": {
                "t": "Tch, what now!?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "893A81CC50669548F76892511BBF3B009755"
                }
            },
            "6D3F4E0869504146B3995E57B731FA6EA9FF": {
                "t": "I'd say that is enough.{W:300} Playtime is over!",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "C8B25ADA510B5445896B797456C8ED642737"
                }
            },
            "05C39070540B91465E182342174FC0CFE4F1": {
                "t": "Kabeer!",
                "d": {
                    "cid": 0,
                    "eid": "C7EDD32393F46047E919B306B7C7E4C57DDC"
                }
            },
            "7EB2A01C50A1E841929A42B83F7CC1AA068E": {
                "t": "Did he just... shift the entire area?\nThis confirms it.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "60676D9F185683487F5BB6D9DC3DACFF8994"
                }
            },
            "FFD279ED53779842E368CB1794A88047198B": {
                "t": "You're the Archdemon.",
                "d": {
                    "cid": 0,
                    "eid": "4779FC261ED61848CE1B14A16DD03B26CF03"
                }
            },
            "BB07CE1974F8B349E35BAB51CE07E3880995": {
                "t": "Is that what they call us superior beings nowadays?",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "94BF5035154AF54F522852E18465D87B89DB"
                }
            },
            "438262CA4BA2A649140B3231624759D05E7F": {
                "t": "Look at that confidence.{W:300} I wonder if you'll keep that cool when we force some information out of you.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "87791B59434502487A0997451E4F6D636083"
                }
            },
            "B6ECFC587F84C644337871627468B109FA83": {
                "t": "Just try it.{W:300} If you have the power, of course.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "0BC8B1B57EA1794FCC6960C72C3267A032CD"
                }
            },
            "4DC9DC1F1BB1D047835900923A1400A9FE17": {
                "t": "What do you mean?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "46EDEA9D3D23F34CE37A81997ECAE1356ED9"
                }
            },
            "2B50FBA31D9C394010597A219DF85381E241": {
                "t": "You are all just pawns to me.{W:300}\nHobbies for my infinite boredom.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "2EDAA18A555F61461168EC38773C43EF548C"
                }
            },
            "BA07416847D96349C678E825CBE9E1FCB05F": {
                "t": "I wanted to help you by leading you here on a whim!{W:300}\nI wanted to see your reactions!",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "48DB5DC25283474DC7992EE3592CB5D0A8B1"
                }
            },
            "D24220D11184D349B50826E74F2500702890": {
                "t": "And look at your faces!{W:300} Especially you, Vassal.{W:300} You're such a spectacle right now.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "A74AB36E2D99454AE03B23F63B770D7B3911"
                }
            },
            "73B2BE1B23B39648987A68980D5041D869E8": {
                "t": "... ... ...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "264B67061A044943F74A3EC412E0C4F4E975"
                }
            },
            "08C05E3C53E4334AC2285D15B93CC047EF1E": {
                "t": "You sick fiend!{W:300} Take that back!",
                "d": {
                    "cid": 0,
                    "eid": "07C9C62840F5B34B1F699294749B34AB191E"
                }
            },
            "0E77E87E3CA5A1439C6B7152465948214561": {
                "t": "Don't you demons feel anything at all?{W:300} How can you leave the world at the mercy of chaos?",
                "d": {
                    "cid": 0,
                    "eid": "C4009DAA56F677421E59F3355C1B6AB362B0"
                }
            },
            "F4BF2D556BD2784EE02969575F7E335CAB87": {
                "t": "I've already told you.{W:300} You cannot question me without proper power.",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "7D47C33944F8E643901ADE8786DF5B3FE0E2"
                }
            },
            "F7A7A06E3FE43547C519ECC9E2C4D48CFD6B": {
                "t": "Or, in other words...{W:300} prove to me that you do possess such strength!{W:300} Quench my thirst for knowledge!",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "62B4800D6BA0C24DEF6991F4292E213696D1"
                }
            },
            "52B7D499152F284EBF58F7B5D9C155268E54": {
                "t": "He's completely insane, just like Tacitus.",
                "d": {
                    "cid": 0,
                    "eid": "7E6450B20000734DD5198652F4CB3AB04A03"
                }
            },
            "75ACDAEE8638654CE68AF121D33FACFD620F": {
                "t": "He's completely insane.{W:300} There's no point in reasoning with him.",
                "d": {
                    "cid": 0,
                    "eid": "E663097B73AC0349990911D6906A28F2C5E7"
                }
            },
            "0C506AC7544C684F126B0245DEED8DFFFC39": {
                "t": "Then we'll accept your gracious offer.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "555C478542B280426D696FC432A3EF45A039"
                }
            },
            "C01C48B06C78914F126A8774A236A7DFD8F7": {
                "t": "We would be the \"pawns\", right?{W:300} I hope you're ready to lose at chess.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "8A63B016714E58499F2B7E382852613683FD"
                }
            },
            "0A350AE42DA7E64CEB8BD497249177141741": {
                "t": "Hah, how entertaining!{W:300}\nI WAS WAITING FOR THIS!",
                "d": {
                    "cid": "5B94A03A39724044404B5838C96979597469",
                    "eid": "E6860ABF13665345A77B69D2138337F7C7BF"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "190A5AE15F32634DB229B5F98ADE01B90AEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C2C7A485EB0574872393DD413B3D73C3EAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "492278C81A43F247C92AB471A3B455C66957"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            6
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "39C222143FD53547BA988B2535EA7A1C5E6D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "DDBF6A0E7129D443683A6C011175CFECB07A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "787416637F7446438359EC918C0FC6E20AEF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "BB87CC5B8A13C148475B18177EC430B0109B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DA85C38B61458249904BFA3477C4131EB3C5",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCB6B6B22495F140741839255CC7338BB42A"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "105A38436875A8410769E297F38B6A382AB9"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "E7CD214579F9304FC16900B5474C14852307"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "7D6854B07EAE2442BC3A333626FD1454E44B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "0E8B77714E18674091382BF1F3FD1D87C7DD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 6,
                "uid": "87D775E28E5581407768592250F7F2CFCB79"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "146BB6EC07A155493B4BA521B58A3C6FEF2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            10,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB450F4094EB4643F11BB614430C2EA1AA6A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            801,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35D7F50B493027496538B608252BB14DB096"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -25,
                        "green": -25,
                        "blue": -25,
                        "grey": 50
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9716DBBE2C0BE34331993A54E6668A7C6A12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA6DC9311D9C16439D5B500802B618AA6C27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62641FA53A41F648897910798E849B825A40"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "CA5F08E07064B744051AD8A73493891B4D52"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "99D8F2CB7AA4D54A738B76589663ED16A466"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "16BE97382216B342961AD9D13B583DF9E550"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "67735D6757EC444C2E5ADEC8DE1FE65CF142"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4196B1F89FAE142A58AF3D6E00D2D6B413E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7857BFE6379434D7A6A8F546710BDB1D0B4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E3FFA2A94A2C34EFD8B19E1A9AF098582D6",
                        "defaultText": "흥.{W:300} 이제 괜찮아...{W:300} 고마워."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C11B-8b_line59.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C65701863C208540868B5CB74CBA4617DD9F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8133B3E76FE09040188B74B49D04FB1ACA61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3CA43DE103B28841CB5A703960B92215D7E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4477B2682B9C604C6A6AC9B5BA94C6438C1D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B6B8923547A874CE80A9873B35F8A1645F2",
                        "defaultText": "진실이 무엇이든 함께 맞서면 돼."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C11B-8b_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "74CF3A6B8875E34F1289A6D7FC94B0413C5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "91AD32884CCBF5411A9B27C80CEB9697773A"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "45906E6312B4194AA288FD57A146186EC9E8",
                        "defaultText": "그래, 함께 맞서자."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5CC8FDAE311640492E4A8E199534DDC84274",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "99C4D9F8629AE745134BD6914715A5068254",
                        "defaultText": "언제나 네 곁에 있을게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "311E7A665C94684A8A6889B88F0814C26488",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "final",
                            "final",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "593420911AB76349AD8949B0D4F6A6776988"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "25260B5969F83340F16B8525ABD498BA2169"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "final"
                },
                "indent": 0,
                "uid": "BED3B5A00EA5174AF19BA387B92C75B95967"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15DDE1EC8C9DF74CE55A413545DB3431CFA4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FF164B5285E134AF4694240734B80CA48FF",
                        "defaultText": "알았어..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C11B-8b_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3C5D7D8D40C6B242D29902524AB716366E6E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C4E90450E3B654A2E6866B1C9C84CAB8A40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "418879B44D41F042E7194045AC59F0DD2946"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE824D8279EC024343788CB51B456E3308B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57E54E0B8756D244488B4CC9EC5916AA701A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6DFE506D933434491269CE997B9101E6EB83",
                        "defaultText": "\"알았어\"라니, 참 좋군!"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line64.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D977615222C01041940BED97E95968B67EF9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A498CAE260C9B343D87A99356BEECD2C8950"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4729FB3F829AA94E43697F639A7700747134"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "11EB73A88E766148109990C9E8F41849E268"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "terrain morphs, to desert"
                },
                "indent": 0,
                "uid": "649161F88AB08741826ACA87380C65C2ADBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D844193E303B9547567A3A263E191EB88240"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AF7F9D911A91844A6388C386FBBE9A73DE9"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "MUSICATK_KAB2.ogg",
                        "volume": 100,
                        "playbackRate": "122"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C817C41B2AFB334F1D4B8BC10F5AAB0D1492"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 15,
                        "x": 20
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "F81D943E22D347495F4A2418B090F02A81B7",
                "expanded": false
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "MUSICATK_KAB1.ogg",
                        "volume": 100,
                        "playbackRate": "106"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B7A198D2478AE34C385A6494B339C78545E2"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 15,
                        "x": 20
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "5D2227418254F8451E48FF94BBD84B9D6163",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "scene"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 13,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 48,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "10.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 0,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Desert background NIGHT.png",
                        "folderPath": "Graphics/Backgrounds/MIDBAR",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "38D9A7C94675634DB96B66D709EB3275E0CB",
                "expanded": false
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0517C28E5A458845EF898FA3532DF686A7B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CB714D94714A504FBA8BF0D8BC0540C586A7",
                    "parameters": {
                        "values": [
                            0,
                            1000,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3DA911F99C1117428308BE23063F1FFB0033"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -9,
                        "green": -9,
                        "blue": 4,
                        "grey": 50
                    },
                    "duration": 60,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E87C0ACB468A7846954AB559A58B914974D6"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "MUSICATK_KAB2.ogg",
                        "volume": 100,
                        "playbackRate": "96"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9C0533D58B38E34D6569FAE0B9DFD874F1D6"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 15,
                        "x": 20
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "68F7190614B799414F1B52F71AF3A1EC1DEC",
                "expanded": false
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "MUSICATK_KAB1.ogg",
                        "volume": 100,
                        "playbackRate": "90"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B5820A0356E2024A7418A5D48AF2DF92BDE9"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 15,
                        "x": 20
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "E3CF28B22F4877437C196854600545C1D9DB",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "10ED308233D877446F4AE0A196BAFFDF882A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "A6F443D716DE644A021883441F2AF71A9FA8"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "05509A981CCA15429A5BE936D5FDFBA56A9A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "96D50B9682474847C63804E5EB7080CF2B76"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "053DF6124B2D1541E168DB566855BCD860EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A9DE9C828407745317800D7607977FA4B73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "969492B479221249E539F1C29C7E40250B3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F87B966A05119345522BB524F3653196B32F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2F9410AA38E9974EE75A155406BD783FB6E6",
                        "defaultText": "우와아악!{W:300} 지, 지진이야!?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C11B-8b_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5ED75B5A8CFF6542C91B4562C489AABB6E95",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1AEAC0C90A4014101498A691601E9C959F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8748796213AC994CF57A1C728E6715243998"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5EC9EC6F6CBE134BE04B06950337BA70968A",
                        "defaultText": "대체 무슨...!?\n밖으로 나왔어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0DD4B6213B080942CE788F97E32BDFED220A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "21369DE98793A4408589C67082A2A3F65976"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F62741A2412B747343BDDC5591069A61610"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "4C3658BF2378894B251938279E937128438E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "319370F22DFB734C538B28B8FE18956DA281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "669DD3371030C843095B5345B324C624634E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53AB2D4341B4F8469B0984D70774CE074208"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9FBBA301660DC44ACE18BFE055AA1D8E8E6A",
                        "defaultText": "쳇, 이번엔 또 뭐야!?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C11B-8b_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "893A81CC50669548F76892511BBF3B009755",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "631FFEC450F4B44298499AC0FD302104ECB8"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4999,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1450,
                        "y": 576,
                        "zoom": {
                            "x": 1.7,
                            "y": 1.7,
                            "d": 1.7
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "CFBBE2144FA901498189DCC13FBB0BE4933F",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.6,
                    "idleIntensity": 0.6,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "7F20BE9822F0434EF69AAB80921B0A48B4E8"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "PARAM_WINGS_AUREOLA_ON_OFF",
                        "value": "0"
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "592D924120EDB742252B447413DE052F5379"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "7F1CB8932817D345649A0435C847B5BB3AF9"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -980,
                        "y": 576,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 14.399999999999999,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BD48E25F9001764D7A5BCC10609BADF32437"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E62BB8F0F35164C5E6BFF81B4AE5732C7DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6D3F4E0869504146B3995E57B731FA6EA9FF",
                        "defaultText": "그 정도면 충분하군.{W:300} 놀이 시간은 끝이다!"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C8B25ADA510B5445896B797456C8ED642737",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "740543545F512842084858F7779ECB3B4A73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            9,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "01354BF86AA4D24BAE7A253723C733B8D070"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            15,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06A1F671727374472F78BC92DBFBAE324283"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C451FEF9734F66493F99C1470AC8A30B1626"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05C39070540B91465E182342174FC0CFE4F1",
                        "defaultText": "카비르!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line68.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C7EDD32393F46047E919B306B7C7E4C57DDC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2641238D5415B9461639DB11D315ACEFB8D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FC1BCE62EB5C644989B792489250DB5B03B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7EB2A01C50A1E841929A42B83F7CC1AA068E",
                        "defaultText": "방금... 이 일대 전체를 옮긴 건가?\n이걸로 확실해졌어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "60676D9F185683487F5BB6D9DC3DACFF8994",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "890954468641C5433F9AC803DA0F7324D409"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91894A59517CC2456F8BFDD734C9DA6D924B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFD279ED53779842E368CB1794A88047198B",
                        "defaultText": "네가 대악마구나."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line71.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4779FC261ED61848CE1B14A16DD03B26CF03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBDD019C0FC55943D079F693A3837BD8126E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6170973F1B8F2248369A4598F2DBBF161CB2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB07CE1974F8B349E35BAB51CE07E3880995",
                        "defaultText": "요즘은 우리 같은 우월한 존재를 그렇게 부르나?"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line72.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "94BF5035154AF54F522852E18465D87B89DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0C8C3B2DB5344C8F7A4163D9A673175C90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1E26A001F1956402989D4E1D627AFD02959"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "438262CA4BA2A649140B3231624759D05E7F",
                        "defaultText": "자신만만하네.{W:300} 정보를 토해내게 해도 그 여유가 남을지 궁금한걸."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C11B-8b_line73.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "87791B59434502487A0997451E4F6D636083",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7161F1080C8114C4E1A42B4268C5A97706F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E1B5C561FC7044A05891E14B19B8D942AD8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B6ECFC587F84C644337871627468B109FA83",
                        "defaultText": "해 보아라.{W:300} 물론 그럴 힘이 있다면 말이지."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line74.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0BC8B1B57EA1794FCC6960C72C3267A032CD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6CDFB5F319806648BB49E386BE07FD5029C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "258D697381D5C146AC5BD3B27741D2C7F804"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4DC9DC1F1BB1D047835900923A1400A9FE17",
                        "defaultText": "무슨 뜻이야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C11B-8b_line75.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "46EDEA9D3D23F34CE37A81997ECAE1356ED9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F373024B485C014E8D683A178F07D22AB4E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AFB641F5ACB6049B75BC0F60B360B82F484"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B50FBA31D9C394010597A219DF85381E241",
                        "defaultText": "너희는 내게 한낱 장기말일 뿐이다.{W:300}\n끝없는 무료함을 달래는 취미지."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line76.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2EDAA18A555F61461168EC38773C43EF548C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5648BC7B730A80402378EC3499DFC8B6C098"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BA07416847D96349C678E825CBE9E1FCB05F",
                        "defaultText": "변덕으로 너희를 이곳까지 인도해 도와주고 싶었다!{W:300}\n너희 반응을 보고 싶었거든!"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line77.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "48DB5DC25283474DC7992EE3592CB5D0A8B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4F6FF526D4FD344405A0DF24EE2FBEF245F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D24220D11184D349B50826E74F2500702890",
                        "defaultText": "그 얼굴들을 보아라!{W:300} 특히 너, 그릇이여.{W:300} 지금 정말 볼만하구나."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line78.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A74AB36E2D99454AE03B23F63B770D7B3911",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00F2B25548A952474A796485D01488A6811A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B121674D56B811498D79EF030E8FB1EB90DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73B2BE1B23B39648987A68980D5041D869E8",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "264B67061A044943F74A3EC412E0C4F4E975",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17392F7035ECC5497D6B2FE59734D153F7A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D3638B044237941994A189133D9C4C4D122"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08C05E3C53E4334AC2285D15B93CC047EF1E",
                        "defaultText": "이 역겨운 악마!{W:300} 그 말 취소해!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line80.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "07C9C62840F5B34B1F699294749B34AB191E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FA810C0007A4342A28B13C8065A60C8FFC8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E77E87E3CA5A1439C6B7152465948214561",
                        "defaultText": "너희 악마는 아무것도 느끼지 못해?{W:300} 어떻게 세상을 혼돈에 내맡길 수 있지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line81.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C4009DAA56F677421E59F3355C1B6AB362B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED541F6679B6F14DBE7808E96E98E9D3A7D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3088D2324285B24A35084B882D054AAEAF15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4BF2D556BD2784EE02969575F7E335CAB87",
                        "defaultText": "이미 말했을 텐데.{W:300} 합당한 힘 없이는 내게 질문할 수 없다."
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line82.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7D47C33944F8E643901ADE8786DF5B3FE0E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC74878132D73747232ABB343C1744F81416"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7A7A06E3FE43547C519ECC9E2C4D48CFD6B",
                        "defaultText": "다시 말해...{W:300} 그 힘이 있음을 증명해라!{W:300} 내 지식의 갈증을 풀어 다오!"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line83.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "62B4800D6BA0C24DEF6991F4292E213696D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A385421E8506A947572BD117BA9775430F7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40D73D986D72C046F52955883A27A5FF2600"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DAA47BBD7175F84CA1787C81023FA6B2BACD"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if tacitus first"
                },
                "indent": 1,
                "uid": "0F745CD74C1E054631891D81D3AEFDF95261",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "52B7D499152F284EBF58F7B5D9C155268E54",
                        "defaultText": "타키투스처럼 완전히 미쳤어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line84.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "7E6450B20000734DD5198652F4CB3AB04A03",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "32A5C2044D1415449D8BDBF770479AEA2397"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "0C2A60449CCAC84F9A6826A4AADFB84C6919",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75ACDAEE8638654CE68AF121D33FACFD620F",
                        "defaultText": "완전히 미쳤군.{W:300} 대화로 풀 수 있는 상대가 아니야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C11B-8b_line85.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "E663097B73AC0349990911D6906A28F2C5E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5D171F54A57C741DD1973B882E379CF0282"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3B66EF389844D248397B57F58CDB28A12776"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C506AC7544C684F126B0245DEED8DFFFC39",
                        "defaultText": "그럼 네 관대한 제안을 받아들이지."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C11B-8b_line86.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "555C478542B280426D696FC432A3EF45A039",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "718DB15C16C3F74B8B197931B33C049203B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C01C48B06C78914F126A8774A236A7DFD8F7",
                        "defaultText": "우리가 \"장기말\"이라 했지?{W:300} 체스에서 질 준비나 해 둬."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C11B-8b_line87.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8A63B016714E58499F2B7E382852613683FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6541AF9F8C5EB341243ADA50460DD8206A45"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D6486957693A8444C89DDD7F37700190FBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5B94A03A39724044404B5838C96979597469",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C171553F83D465420F48C5E1B9566975E1ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A350AE42DA7E64CEB8BD497249177141741",
                        "defaultText": "하, 정말 재미있군!{W:300}\n이 순간을 기다렸다!"
                    },
                    "position": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Kabeer",
                        "name": "C11B-8b_line88.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E6860ABF13665345A77B69D2138337F7C7BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CAA109AD7B3F964E3119ECE18CB3DD8DA96C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7745146131A41438F2BD0F76E770F8456FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7BFCACE28622534C3F586CB3C67E4A0589E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "76EE00CA8576914A8C6B3474F9FF23055DE2"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "model": {
                        "name": "KabeerArchdemonBattleModel.model.live2d",
                        "folderPath": "Live2D/Z1 - Enemies",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1450,
                        "y": 576,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 14.399999999999999,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B0B934DD876956495B089EF31122BDDC2A27"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    }
                },
                "indent": 0,
                "uid": "5808FE9B6FE98844940AEF2885382201873D",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCB9EA004553F8412E689A48296A74EB75FE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "1DBD1E99521C6149363B59D53B15AF256EF4"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5AC2DBA45D4B804F9D5A3A55E7A8142B41BF",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "E2CD45A0329B684FEE4A8391BDDACE4A6A53",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3D6CB73F55ABD74D909B8077E4534CDEBDE5",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4EFEDD0012D2C243767867A15075A57C3151"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Tacitus?",
                        "index": 230,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B6F839AB5E7523455F1A3912CE45332B3783"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Salute MAX",
                        "type": 0,
                        "value": 120
                    },
                    "numberValue": 77000,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "48F3CFC569C2A141BB5A9098ADAA1989A59D"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Salute Attuale",
                        "type": 0,
                        "value": 120
                    },
                    "numberValue": 77000,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "925810067D68344EB47869B5BA51AA6B4830"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Salute Base",
                        "type": 0,
                        "value": 120
                    },
                    "numberValue": 77000,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "F3FCB8CB290E45491A88E8F5FB16AA1C9459"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Attacco",
                        "type": 0,
                        "value": 40
                    },
                    "numberValue": 435,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "248A8AFD3DFA61402C4987E3D89D4ABE9594"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Attacco base",
                        "type": 0,
                        "value": 40
                    },
                    "numberValue": 435,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "30927E89776AD244231B6975EF5198E12FBE"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Difesa",
                        "type": 0,
                        "value": 25
                    },
                    "numberValue": 470,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "4055B41A43A7F745DD9A6F07AC94C3763028"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Difesa base",
                        "type": 0,
                        "value": 25
                    },
                    "numberValue": 470,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "36438775665DA74C79698BF66FE086E5EB5A"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Velocità",
                        "type": 0,
                        "value": 46
                    },
                    "numberValue": 690,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "FAB462693CFAB64E5F3B9247620A218A5145"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "5B94A03A39724044404B5838C96979597469",
                    "param": {
                        "name": "Velocità base",
                        "type": 0,
                        "value": 46
                    },
                    "numberValue": 690,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "96C2E22017AA23473A6BF1564BC55C102DD1"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "kabeer lv",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 77,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A79BAE4D382369472439B552E2A47FF2D3BF"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "E5A7ABA34A2D4545D54808120BB697C63728"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "kabeer lv",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 70,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "403C92501562C8441D9B65066E76995C7F27"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "931ECB8A6A4C6641284A44917D705AC9FFF5"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F448382058D6754204190A083C7323FA2E7E",
                        "name": "34 - Kabeer (Boss)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "02716EB664D1E747148A2B748253E88A5033"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B0A093064365624F5828CCD7BAD7C6708EAB",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F1EE3BC64F560497C484654B04285BB5EFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            0,
                            "5B94A03A39724044404B5838C96979597469",
                            {
                                "name": "kabeer lv",
                                "index": 0,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            2,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "053DA21B6B9D6741B228A582A4B6BFF4F222",
                            "Graphics/Avey's Battle Backgrounds/Desert night.jpg",
                            "777A885942E0574F9C3A97C2619809698C64",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "83CC42A17CEC55491B1A7931A36981D84132"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "battle"
                },
                "indent": 0,
                "uid": "39A609D12FE8C84FF52AFA6251336DFC21F0",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "053DA21B6B9D6741B228A582A4B6BFF4F222",
                        "name": "C11B-9 VS Kabeer (Archdemon BOSS)"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D4CE940A547755449A98D6682196AFD4AF5B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "F8BB859176FFB343B29ACB710A9563357896"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "A94400D6222C9143363B2D0439F9B7A8A094"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "EC938D9412EDA04326182E21E5F3493F4D71"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the battle"
                },
                "indent": 0,
                "uid": "D3267EDD7D02E443A79A4191BEA846FC6F2C",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "613C20062C176448F3986601492C17E91ECC",
                        "name": "C11B-10 Post Battle"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E64B8BFB803E6240E91A94F132A6BBBC9512",
                "expanded": false
            }
        ],
        "livePreviewDisabled": false,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "kabeer lv",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}