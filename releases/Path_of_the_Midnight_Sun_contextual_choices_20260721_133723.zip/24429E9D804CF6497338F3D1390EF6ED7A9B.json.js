GS.dataCache['24429E9D804CF6497338F3D1390EF6ED7A9B'] = {
    "uid": "24429E9D804CF6497338F3D1390EF6ED7A9B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C13-2 Meet the Demon the sequel",
        "type": "vn.scene",
        "parentId": "6C71761C2410664EDB6BA5141884A87C6D4F",
        "chapterUid": "308CB00B9377A744EF192A255CFEC62F6D2E",
        "order": 2,
        "localizableStrings": {
            "AACEC6A40090F147C489EE25898F58B78B01": {
                "t": "Can you sense it too? We are already surrounded by very powerful monsters...",
                "d": {
                    "cid": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "eid": "68BE40AA3908E4434479661423F223EDBE3B"
                }
            },
            "FA4FC34533A6E64BAD9999A43BF4B8291166": {
                "t": "And this despite sealing away the Mana Scourge. It really shows how influential Elias' power is.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "A46B3F6E366F9247AD68BD58A83350FE86AD"
                }
            },
            "D55AB3FF41899542F46B8344C36C7D3FF6B4": {
                "t": "I wonder where he could be hiding. Keep your eyes open, everyone--",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0DFD9A9A5EC2B342E019D26309D3FDF1AAEF"
                }
            },
            "4189BE1D63FDA743023993168613D330657D": {
                "t": "Whoa, what do you think you're doing, buddy?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "B2899BE2757F56492A48DBE33A92BBA2AEC5"
                }
            },
            "EFDC69A394EA054C4E3944368283EF5D223D": {
                "t": "Nice parry, for an insect.",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "9DB729DD66758143F2384190B17991862853"
                }
            },
            "163911E6787CC7422D2956D762E0623BC9FE": {
                "t": "He... he's here already!?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E1FACCCA512AB74E8E7AD7B4DD0A42365A62"
                }
            },
            "C216CBC7569D7745416BDA67CA1B3F44D879": {
                "t": "I got distracted! Thank Valonja, Cristoph saved me...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2AC729243F06E8455598FFA4987AB6F878B7"
                }
            },
            "D1DB3FE29D10F94EDC3ACCA7F591F84CD936": {
                "t": "HAHAH! What? You really think you can take me on?",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "564B4B388EC3424F159887976F87A5D1B68A"
                }
            },
            "767E44A74C85D34158390D925DD8C2C0F3E3": {
                "t": "What do you think we came here for? Deduction has never been your strong point.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "E0EB7CB57164294707885492D490897A3F40"
                }
            },
            "E370530172B1214AC61A9F2465CEDFD2D030": {
                "t": "FOOLS! Your words mean nothing to me.",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "A2FD8F5E2BADB748833B4AC6A4DC92474A0D"
                }
            },
            "AB1542897D87D64404083721C875AD386C48": {
                "t": "Your feelings, your MALICE shall speak the truth about you!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "5A30BE5E61F6F841BF6972D793D6469FC5B3"
                }
            },
            "7B675AAF4B14C242A08B5FD35BFAB9378971": {
                "t": "He can sense {SP:1}{C:1}our malice{C:0} now... That must be how he found us in the first place.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C3B4A4006138384EC03A5FA83B0CEC9237B6"
                }
            },
            "B1138F6668D99346AB184353D80CE9DCEDF7": {
                "t": "Don't be ridiculous. It is exactly because you have that power, that you should've realized you're in danger.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "E40A213A4E79C344118B55137C5BD3073824"
                }
            },
            "94425139777FD04A916BFB8585D580D5A806": {
                "t": "Me? IN DANGER? HAHA!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "939ED6CC010A044A0F796922EEB16F538747"
                }
            },
            "5673B9A5168F46408379C543866F8D58FFC4": {
                "t": "I see that since we parted, you've applied for the role of comedian, Vassal.",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "C2A846856230714E4D7AB41909B294562199"
                }
            },
            "6C666ADA14DC9949044B9A674F051FE2A1F0": {
                "t": "I can sense your insecurity. After all, even you know you can't defeat an IMMORTAL being!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "6A87D3FD4302E64AE5780C16CAA9529A11D0"
                }
            },
            "4165E21E32D1324D2D2AD348875781552C71": {
                "t": "If He's really sensing our malice right now... Then...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D449A433608ED54EA279A4126C41229FAC11"
                }
            },
            "AE015E6328F8014B5B5B1657F4194E14D111": {
                "t": "Y-You're wrong!",
                "d": {
                    "eid": "B8998E1A40D346454F29A1E56A09483B1E13"
                }
            },
            "9902DBC3745EA74E2A1913D8EAF131BEA3AF": {
                "t": "You don't know how to use that power properly!",
                "d": {
                    "eid": "D1C50A30013DA645B989CB47585763A5F8CE"
                }
            },
            "50FE8DC870ABF1443259AE06567BA9C5366F": {
                "t": "What!? You DARE contradict the King of this world!?",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "280A62E87953684A51295C27138547584014"
                }
            },
            "FC5F21584033554E8D0866A1F953ECE87A19": {
                "t": "Oh, yes! Because the higher the pedestal, the more you'll hurt yourself when you fall, Demon King!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D18EE5B72F1D16411A4A52A17DFA467BA449"
                }
            },
            "AF5572EA1101D744177B622855EDD5509149": {
                "t": "Even YOU can be wrong!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2671A2B27A9E074AEA6A51004C4AA7C21095"
                }
            },
            "464E6BB7583308487B8847F5BFC782906A53": {
                "t": "Whoa, Shiori! Quite brave of you to be provoking Him like that!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "5D89135346FE9546C01B187808D40A22FD15"
                }
            },
            "E21DCC215CEB0644DC5B4E31145889C67DE6": {
                "t": "HAHA! Interesting.\nYou want to teach ME about how to use MY power?",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "4425286275512148E43B0C10CABA0AAB303D"
                }
            },
            "EA8E01E9519C2245E128D8871710E089FA1E": {
                "t": "Yet another FOOL who has lost their mind along the way!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "85B25E7B788F9744A989F12383600A599728"
                }
            },
            "91FDCAE74B0899400219574492A4D17A3E14": {
                "t": "I assure you that I'm fine. In fact, I'm not the one who turned into a monster, right... {SP:1}{C:1}Elias{C:0}?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "32AE639B6992E4469C39DEA64F4C389D740C"
                }
            },
            "D5A4AE504492564AFE4B0A39BB0F565B4C3B": {
                "t": "You... You've been in the lab!?",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "C492B0D36B8B6647B359E2565771531AD872"
                }
            },
            "B8E49B9A63CDE44FD6780E68113EBC30EE08": {
                "t": "How wonderful. We finally see a crack in that arrogance of yours.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "1E024B188ABF24463A3A01776694EFD11945"
                }
            },
            "7C5F6CC55D46C148EF49BB67D9A018103DE2": {
                "t": "What's the matter? You don't want others to find out you had a crush on my grandmother?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "E87B187B9D08154D7659E3349488E028A98C"
                }
            },
            "E7591A079076334FCC39F632DE76D9A965C3": {
                "t": "I can't wait to BURY THOSE MEMORIES... along with your useless CORPSES!!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "A69F4E839B3943476618F509E3A9299FB7CE"
                }
            },
            "26B251772D5E144DA118A8363AB668E34DC7": {
                "t": "Haha... HAHAHA!! I'LL ENJOY SEEING YOU DIE AN AGONIZING DEATH!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "B1B3551E7662554E49294E3543F012EA54BF"
                }
            },
            "E174AF2008369146E82B48A42792D3D63413": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "6226B4A74CEEF64ED839C9B248F17D840A17"
                }
            },
            "14B142F68D77D34ED41B6304C75909DBB109": {
                "t": "Hey.",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "7B41BBED9D3F8249BD4A3A94DDE1A587FE8E"
                }
            },
            "3CB76AA1310A01484D4B3DE62CB563A824C9": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C0937CAC835C7348FE0B3AC3B10B7C05C44B"
                }
            },
            "A4D494596148714B0F69B6549DDB610CD7E4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B2A0964B895F6546B52A7A0675CD6AD2104D"
                }
            },
            "712280A718783646451AAC64EBD79D2C2CDC": {
                "t": "Who was it that led you there...? Kabeer, wasn't it? Damn it!",
                "d": {
                    "cid": "E70872A1280ED143397963774B6B7627406C",
                    "eid": "8F54108D8616C8418C288B553FC56A80597C"
                }
            },
            "F55C22C970F9B7421D995A8621BE05CF4D21": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "B21E793181F0A34DF05AF73785561ABCD9AB"
                }
            },
            "ABF7B6442314C345F12AB3E1E3E084523753": {
                "t": "That... That seems to be it!\nHe's furious!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8B30B11D382C67493799B679D8A74B13D835"
                }
            },
            "A7DB70856DD6D0494B6A5CB1D13CB419A0AD": {
                "t": "Monsters are charging toward us! They are incredibly strong and seem to have been summoned out of their natural habitat!",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "6CB06FA554448547CA9BA028CB12A912EA8C"
                }
            },
            "4A7562FF0223504DAD0883662176F7758020": {
                "t": "We have faced far worse, haven't we? It is time to bring forth a new day!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "561BB95D78154746915A52E8A3DE0576DB4D"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "096803021381934E22593586FA69E48CE539"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "491D626C40FA144C1B4832E147AEC0586E74",
                    "parameters": {
                        "values": [
                            1,
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "E47021D35C450742612917E6A2BACFA863BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EBBBD21C835A8549AB794FB7C1212E74CB9E",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27EECAA07001A140957888270B71698C0DD0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "ED6BF7E01B34D649912AF8507A86447A1B35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F58F57B646C7C842A2594FB31CBE688B38A8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "833C2BC4118E3544765B8B75C16E74EC1A22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CA180558874B41463188E1F8D7CB2D937A2C",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "414E939A7BFE4844AF4A6781340679A31715"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "869F3BF078BBE249BC191A7541E46F6324EF"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3F35249C0BBCD240A47B353386E1244ED457"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "FA4E5D8415E4A2498B393F794BE610B1E9E5"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "F3823FD62416494D4B19AC16A32B0551CD5B",
                        "name": "91 - Ornieres Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "904EDCD768CCF94324695AA699D9BB7BA220"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "4558B5BA3CE7424A494B2743F9AAADAF5E35"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "F730815538AE0245F6898264E8AF6F4F4AEE"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "model": {
                        "name": "Demon King.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 802,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -276,
                        "y": -24,
                        "zoom": {
                            "x": 1.8,
                            "y": 1.8,
                            "d": 1.8
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "5BD33106421C834C01584FF27CE5715DAE5C",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.75,
                    "idleIntensity": 0.65,
                    "lipSyncSensitivity": 1.05,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "829296D73EE5C2403A28FEC55D8A2A7A36A5",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "67C5FD664070D34ACC1AD9033CBCCF888F17"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "5A2ADA396019254CBA8BE8862AFCDF545429"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Crossed_Arms.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "99F968EA5AFBF244B87BD8A6110C5C96C79A"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "04CA9C9A2168B746497A0B0497A3DFC80685"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            15,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "895B1A190D024440893B8A63A1ACF44906DF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "FB4D568E6448644F73683FB7D35CB0C28277"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7709FE212162654D534AEE0968251C75F2F8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "C948CEAB8A5E774E6B1864C83DE3E35B3479"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3E5325A061867842732A018150A352CF5A79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "853CD3A24EF0184AA128622751603D6D795F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB68A0F41E1F26455C7AC7F9B41E697F32F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4098FB51D9162421F1BD7D2B514FF37B8F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AACEC6A40090F147C489EE25898F58B78B01",
                        "defaultText": "너도 느껴져? 벌써 아주 강력한 괴물들에게 포위됐어..."
                    },
                    "position": 0,
                    "characterId": "782BEB6542BA954DC7881AC8DA422E2960E7",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "68BE40AA3908E4434479661423F223EDBE3B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F92CC0193137E346EA096624CBB81F6C415D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5B686341B91F1481649EB3148ADF4DFF041"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C3E49E877CF2D8417789A482929D09FD536E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E174AF2008369146E82B48A42792D3D63413",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line32_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6226B4A74CEEF64ED839C9B248F17D840A17",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C1DE7F396B0DD64A034A9484BD0E2B4D3B98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E204C6595A374441DF6BE3A219990025E6C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA4FC34533A6E64BAD9999A43BF4B8291166",
                        "defaultText": "마나 재앙을 봉인했는데도 이 정도라니.\n엘리아스의 힘이 얼마나 막대한 영향을 미치는지 알 수 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A46B3F6E366F9247AD68BD58A83350FE86AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81CB0C2F4DEE18415638C7B7659F66E01DFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A193CC4B01C9D848173875F71DFF7FA690D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D55AB3FF41899542F46B8344C36C7D3FF6B4",
                        "defaultText": "어디 숨어 있는 걸까. 모두 눈을 크게 뜨고--"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0DFD9A9A5EC2B342E019D26309D3FDF1AAEF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EA60B183D4541472748DAC6887991CF0596"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "506CB3A33CB0014C0B4AA5E7DADD88C5C412"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "782BEB6542BA954DC7881AC8DA422E2960E7",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "774D71577897C44352888B43304196D90DD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CD72EC98993F8487B493BD68C3B6FEF38F7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "615D9F455430E44E2A9ACE45B7795A1EE07E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EA600EDE3092354D9E685293CBC22BD61749"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D64FCB0366B294BCE4A2E678E6FCA46BCC4"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "35EFBA647F488249A42A6AE2FFF33456A54D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8AD880FC6428414D816B2EE4CF44FE98C4BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "E70872A1280ED143397963774B6B7627406C",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "09DA0D6883C3E24669691C058749E41BBDD2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "14B142F68D77D34ED41B6304C75909DBB109",
                        "defaultText": "이봐."
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B41BBED9D3F8249BD4A3A94DDE1A587FE8E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D95ADF0898D614D4C1AC870044AA7DC5655"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "F3BF8D486E2BF545B86A68B8DF28A5375F6A"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D2B86AF74C068547471ACA78F546981B12CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5974F32A7B217146275B7AE57D16271FC6A2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "99B5B64C351AF640A54B6AC3D2D2465B8FD4"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Hit sounds",
                        "name": "Hit Phy Crit.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0C5E6D98358EC7460A7B83C0DB8ED8D30A68"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "CEA2E9205B387849317A3E268A205FDBFABE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            250,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0B8364A350D01474C5A0B174EB6ACE5562C"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2A118937083E954E0A7B5AB69C872A434618"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "98CE8244255EC549E73AEF710F14BB67762E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "GEN_BLADE.ogg",
                        "volume": 100,
                        "playbackRate": 80
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "08ABB1168A314247236B59516C8FC96885C8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "2AC478D8408D87472129E26281F666A55E64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C61420F923D9664ACB98D6E2367486CEBCFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C9D79F93DDA9146D21B1B02F6737D03471F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4189BE1D63FDA743023993168613D330657D",
                        "defaultText": "이런, 뭐 하는 거야, 친구?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2899BE2757F56492A48DBE33A92BBA2AEC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B59E7D068FC75543F4399EE90BBE754911F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8349FC6855A99545595A0AB34081A284E389"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "model": {
                        "name": "Demon King.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -100,
                        "y": 135,
                        "zoom": {
                            "x": 1.05,
                            "y": 1.05,
                            "d": 1.05
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "32653CFE1F12D84B494B3636D14EAEE5ADD0",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "E70872A1280ED143397963774B6B7627406C",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0377900B4DD8D04ABA6B3414DE28BB9BFB4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            801,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6DF35C66F79254FB7788C77A4D57B1EE95F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "783F714A34235643187BAD28392F7AD8760A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4ADC5DFB23BC164A9C3844052F05D4367FF3"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.75,
                    "idleIntensity": 0.65,
                    "lipSyncSensitivity": 1.05,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0,
                        "eyeBlink.enabled": 0,
                        "eyeBlink.interval": 1,
                        "eyeBlink.closedMotionTime": 1,
                        "eyeBlink.closingMotionTime": 1,
                        "eyeBlink.openingMotionTime": 1
                    }
                },
                "indent": 0,
                "uid": "D87CBCFF0EDEC642B14951A91744CF659E12",
                "expanded": false
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "62E2BFB714FDD345DA78DAB4C3AB92403638"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "65B741FD7368164EF27879A2334CE888A2CA"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Crossed_Arms.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF0842F83AA24548B57AC0B86CDBF569EA94"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9FA90C3D76E11146AA085754433507D6719C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 39,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8238B3B93D9A4141FE3AAE9568D2185EE720"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "C7247F853E77D34F1E39100409D3CC3BC02B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "out of black screen, now"
                },
                "indent": 0,
                "uid": "0FA8F5536A03474EC16AB916EE19FCE486D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "384D91AD10EBA34C5C0AA251CE2404F9EDFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FE7521BF29A7B2413929B6F50A4BF3A8190B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3CB76AA1310A01484D4B3DE62CB563A824C9",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "E3-Hellios_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0937CAC835C7348FE0B3AC3B10B7C05C44B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EECAFE8E2CE443416499C262FE8450C0A5C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F06F872A46C0E749AC188D82A8A2960798C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EFDC69A394EA054C4E3944368283EF5D223D",
                        "defaultText": "벌레치고는 제법 막았군."
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DB729DD66758143F2384190B17991862853",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3C1B2908C77954D4A9880127E5ED0139EFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "284D50795B22F041A74B9C787662EAC6C5B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "163911E6787CC7422D2956D762E0623BC9FE",
                        "defaultText": "벌써... 벌써 여기 온 거야!?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E1FACCCA512AB74E8E7AD7B4DD0A42365A62",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79A0988A7A6368408E6B8EE98A789E33DD39"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8642E4489EF26454A6893D5FAEA4ECB9307"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C216CBC7569D7745416BDA67CA1B3F44D879",
                        "defaultText": "한눈을 팔았어! 발론자 님 덕분에 크리스토프가 구해 줬네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2AC729243F06E8455598FFA4987AB6F878B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10FF09D3729B25495D7B3F6236B7C49AA788"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Unsheathe Sword.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "405447B9536C5643076BE22151C1B862339A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "09A7B388653E744E5C290C8704BC8BCB0025"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Look_Down.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8289906D5EC5A547A54B3FF7E77153E1B67D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "(everyone unsheates their weapons)"
                },
                "indent": 0,
                "uid": "AEDEF19972C97142A72BF221295063204ED8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1023739E8B17314CB63B2A445F710C6D0941"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D1DB3FE29D10F94EDC3ACCA7F591F84CD936",
                        "defaultText": "하하하! 뭐냐? 정말 나를 상대할 수 있다고 생각하나?"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "564B4B388EC3424F159887976F87A5D1B68A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4AC81D8D098FC34C1099E978D312784D76BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89335C372AFEF2477678E5B765E616E1141B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD3E8BEB67AC9346B94A8C978CE65E83D2F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "767E44A74C85D34158390D925DD8C2C0F3E3",
                        "defaultText": "우리가 왜 여기 왔다고 생각해? 추리는 원래 네 장기가 아니었지."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0EB7CB57164294707885492D490897A3F40",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28AF08DA4CDDF846582B7FB1CA79E0C186D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "425D3DB48910A34A917BE7479C7A09ECBFEF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E370530172B1214AC61A9F2465CEDFD2D030",
                        "defaultText": "어리석은 것들! 너희의 말 따위는 내게 아무 의미도 없다."
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A2FD8F5E2BADB748833B4AC6A4DC92474A0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F3FF0713926054DF589D034942A77B78A64"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AB1542897D87D64404083721C875AD386C48",
                        "defaultText": "너희 감정과 악의가 너희의 진실을 말해 줄 테니까!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5A30BE5E61F6F841BF6972D793D6469FC5B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A068489D32B41749F078DD832A2B2D3E0ACD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E7AB97189C05743AD9895D55A7870C7786D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7B675AAF4B14C242A08B5FD35BFAB9378971",
                        "defaultText": "이제 {SP:1}{C:1}우리의 악의{C:0}를 감지할 수 있나 봐...\n애초에 우릴 찾아낸 방법도 그거겠지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C3B4A4006138384EC03A5FA83B0CEC9237B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65D6951F5CCBF34AA8585E936935CA943FF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DD3E656350DE84B0B1A7DC0536E119DB6ED"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "087D750812F3514A71499079B095225B9D75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F16E4FFB10ABE3441389BFF74E65C0E1F696"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEF028D71C9BE641E32AD9009C62DEF4F4EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B43AC9A144F58643997A283665E94FBF3DD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1138F6668D99346AB184353D80CE9DCEDF7",
                        "defaultText": "웃기지 마. 바로 그 힘이 있으니 네가 위험하다는 걸 알아차렸어야지."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E40A213A4E79C344118B55137C5BD3073824",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0658312B8C73A748B4686111807C33F9AD51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E21246F1378235480018A1330774F399818D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4D494596148714B0F69B6549DDB610CD7E4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "E3-Hellios_line34_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2A0964B895F6546B52A7A0675CD6AD2104D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FB4AD5377C8C214830782833C7A645D603B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B3725F821CFF0427E0859A209E40A4DF11F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94425139777FD04A916BFB8585D580D5A806",
                        "defaultText": "내가? 위험하다고? 하하!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "939ED6CC010A044A0F796922EEB16F538747",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06D2C0102D7F1844B23ACF0720D435850DFC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5673B9A5168F46408379C543866F8D58FFC4",
                        "defaultText": "헤어진 사이 희극인 역할에 지원했나 보군, 그릇."
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C2A846856230714E4D7AB41909B294562199",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C3F377E1CDFD54C808893592D5A2679B349"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C666ADA14DC9949044B9A674F051FE2A1F0",
                        "defaultText": "네 불안감이 느껴진다. 너조차 불멸의 존재를 이길 수 없다는 걸 알고 있으니까!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6A87D3FD4302E64AE5780C16CAA9529A11D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4734B9B08B56B6430E7ACC6227E8FD3F7A18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB24BCB2687D21444C887E137C7D731EF008"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4165E21E32D1324D2D2AD348875781552C71",
                        "defaultText": "정말 지금 우리의 악의를 느끼고 있다면... 그렇다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D449A433608ED54EA279A4126C41229FAC11",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "765547AF4DD5B24ABC4B30E7970A8861B572"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "AE015E6328F8014B5B5B1657F4194E14D111",
                        "defaultText": "네, 네가 틀렸어!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B8998E1A40D346454F29A1E56A09483B1E13",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "9902DBC3745EA74E2A1913D8EAF131BEA3AF",
                        "defaultText": "그 힘을 제대로 다룰 줄도 모르잖아!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1C50A30013DA645B989CB47585763A5F8CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "insecure",
                            "secure",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "C2B0E8DA1E9B644DED5BAFD9131845D83551"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D887E18013FC484466687747E908C72A3443"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "secure"
                },
                "indent": 0,
                "uid": "A52D3DA38A57B44C7E7AF316B9D57C7090A9"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++sanity"
                },
                "indent": 0,
                "uid": "B237D3030398A140B26B1947DF61A3F3905E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED0CF5B51E44A7448C7A0AF0A68969980F31"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "03_Angry.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9571259C499D954A065A4586F5888B3FC44B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1E6536835E894447C459A822376A263643BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50FE8DC870ABF1443259AE06567BA9C5366F",
                        "defaultText": "뭐라고!? 감히 이 세계의 왕에게 반박하는 것이냐!?"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "280A62E87953684A51295C27138547584014",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "434538816F22664E5A6A4304CFE99D4AF9FD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37DA54FC4FA8164D1E0BB3562F3F25187A33"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC5F21584033554E8D0866A1F953ECE87A19",
                        "defaultText": "그래! 높은 곳에 올라갈수록 떨어질 때 더 아픈 법이거든, 마왕!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D18EE5B72F1D16411A4A52A17DFA467BA449",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4BF7A88B7D57F4444D8884E36682DA20F3A2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AF5572EA1101D744177B622855EDD5509149",
                        "defaultText": "너도 틀릴 수 있어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2671A2B27A9E074AEA6A51004C4AA7C21095",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B29AFDD275636477F381397DA02A36C9B2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            8,
                            10,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AD091508A1C1347E8787C4323BB3A501F4E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "insecure"
                },
                "indent": 0,
                "uid": "7001D7B574E6864E511B8C960686863042FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "884F1AC789A31549791BCD66B4E09327F550"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D5E5AC94339F24D878AED25E35931B1E146"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A27366C158BA05409B284CF117F8F9C2EC1F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "464E6BB7583308487B8847F5BFC782906A53",
                        "defaultText": "이런, 시오리! 그렇게 그분을 도발하다니 꽤 대담한데!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5D89135346FE9546C01B187808D40A22FD15",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6222FCFA9EDC6741C30937A7997057E7FF18"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDD5102232E8D2478B6B2A749B5018D640D7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 2,
                "uid": "4E72234D72BC6644473907516EC27745A63E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Look_Down.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "11BF4AF56ECB2245646A3AB1F30065867356"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8664601708A46463E1B73E5862411BF7492"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0BC2F80549279421C9B5A53736683CC5E3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E4D14B66D04664F7C78BE93D60FD8B2D01F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E21DCC215CEB0644DC5B4E31145889C67DE6",
                        "defaultText": "하하! 재미있군.\n내 힘을 쓰는 법을 감히 나에게 가르치려는 것이냐?"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4425286275512148E43B0C10CABA0AAB303D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F4634E09B60C640BC7B0CF61A84EFA6C64F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EA8E01E9519C2245E128D8871710E089FA1E",
                        "defaultText": "오는 길에 정신까지 잃은 또 하나의 바보로군!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "85B25E7B788F9744A989F12383600A599728",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CFF48CF2B75084196193C52FAD083382607"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A104189D8D4DF2467A5B94A756BBC7504DA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "91FDCAE74B0899400219574492A4D17A3E14",
                        "defaultText": "난 멀쩡하다고 장담할게. 오히려 괴물이 된 건 내가 아니잖아...\n그렇지, {SP:1}{C:1}엘리아스{C:0}?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "32AE639B6992E4469C39DEA64F4C389D740C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C483B0A7F1132476739CF698203CD64ED02"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "03_Angry.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2333598A456B774EFC0990B8FF9A03D96BE7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "CAB42E6631FF5540E65B3CB1CE19CEC4F098"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "07_Idle_Arms.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3FC9841E5B0E75455E88C695D1C68B5A7DDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A98D8231F2F3344311A4E3857C0F8359C0D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D5A4AE504492564AFE4B0A39BB0F565B4C3B",
                        "defaultText": "너... 연구소에 갔었나!?"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C492B0D36B8B6647B359E2565771531AD872",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7CDBC918E1F854ABB2B7A9506917E6D4595"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "712280A718783646451AAC64EBD79D2C2CDC",
                        "defaultText": "누가 너희를 그곳으로 이끌었지...? 카비르였나? 제기랄!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8F54108D8616C8418C288B553FC56A80597C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E20603A5A11984871187A014D28074E425A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "027737811A39C84A38299DD6B175A4AED61F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "D6BF04A7437BE946D80AF595FFE8B0FDF8E8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "20CCB0257B8DA545050859C66462B9D4F53B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1A410566F3F91482709829593DD220840EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8E49B9A63CDE44FD6780E68113EBC30EE08",
                        "defaultText": "아주 좋군. 드디어 그 오만함에 금이 가는 모습이 보이네."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1E024B188ABF24463A3A01776694EFD11945",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "989007F063BE5241BD486B1162EE9011359B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE4785318B9D394BF18937116849897BFA7C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "4D6BDD406BF2014FA22A0942A5D2D968051C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB4FF356229DE140A888A0B4745B9D2277BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7CA23717A53864F3878FE78F28E7D9E6688"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C5F6CC55D46C148EF49BB67D9A018103DE2",
                        "defaultText": "왜 그래? 네가 우리 할머니를 짝사랑했다는 걸 남들이 알게 되는 게 싫어?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E87B187B9D08154D7659E3349488E028A98C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEB912E21B186444AD487F07A56C22C6C2D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0169B2A86797454E6E49AD16D94B47D72586"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "02_Sorrow.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7B5F350338B8F34A6109CA07ED0CC51AAB0F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "8DE7A74052BBC845C05825789041D6CAD0EA"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Crossed_Arms.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2434066A61E2C5431758B6E01258FB775BB2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "A736F7B983283144922B26B35AD275EB6FFA"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B95D5A250B91714079996DB25397DB86F783"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F3CB408910C024E696B04E2007920EFD080"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "59F67AE4185CA84D7F4AA8331C4EB0781D69"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "D21EBA508B9ED143971AC6762111BEC6F2D9"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "he closes his eyes\nscreen shakes\nthunder VFX"
                },
                "indent": 0,
                "uid": "A78EED372CC38041A659B979125E0A079D2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C7D9E0650B9344A7F2B6AE73D228C96CD1B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "36BB626674F5014DEA98B6F7EF2940B19A63"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F55C22C970F9B7421D995A8621BE05CF4D21",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "E3-Hellios_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B21E793181F0A34DF05AF73785561ABCD9AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2551F9734ED153427C3926F89EA6280EF1CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "44F4B3514F9949407D4B92617E10475CE94E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7591A079076334FCC39F632DE76D9A965C3",
                        "defaultText": "그 기억들을 너희 쓸모없는 시체와 함께 묻어 버릴 날이 기다려지는구나!!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A69F4E839B3943476618F509E3A9299FB7CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "208632B67D67114501788548BFB3529D7C1B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26B251772D5E144DA118A8363AB668E34DC7",
                        "defaultText": "하하... 하하하!! 고통스럽게 죽어 가는 모습을 즐겁게 지켜봐 주마!"
                    },
                    "position": 0,
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B1B3551E7662554E49294E3543F012EA54BF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8D6A804103798459E580809C4FA70C0AA5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A5645D71DB210420F6837F39F19630D73A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ABF7B6442314C345F12AB3E1E3E084523753",
                        "defaultText": "저게... 저게 맞나 봐!\n완전히 분노했어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8B30B11D382C67493799B679D8A74B13D835",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3535415775BEC44BFC0B1A1000334953436B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDC536636745154CBF59C5B1F132185C3E81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3154F751864DA3492818C619C1DFEC188D81"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "E12F74CB49E2434B7F8AD3F2D9026C16CF4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FF96F693166944B3D8993C2F278FB3772B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B176F3B8E0BB440CE88D9D7321391081B95"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "337C8087058F084D27086DB2D423A9680F50"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A7DB70856DD6D0494B6A5CB1D13CB419A0AD",
                        "defaultText": "괴물들이 돌진해 와! 엄청나게 강한 데다\n원래 서식지에서 강제로 소환된 것 같아!"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6CB06FA554448547CA9BA028CB12A912EA8C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0ACBF8C52D8C3943B56B067382C8811721BD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72D9E1D24432C840036B5674C76BE6BC311B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74D78D5F1A374644534A3A554BBD1CE445E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4A7562FF0223504DAD0883662176F7758020",
                        "defaultText": "우린 훨씬 더한 것도 상대했잖아? 새로운 날을 열 시간이야!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "561BB95D78154746915A52E8A3DE0576DB4D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3C45DB7E85D5334F6599709652D01A874B38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F7ADE593C8F4241112BB5C88155E2F533B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5E0810B3152A7349EF59D1A51B32E3672B2C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DCF92776DF65942D908E719C7698A9891F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C98E82F84F43644240083231DF79CC6572DF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "E3E2DA1F4B5235496909DAF15298604F2F41"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A4ED4890843D524A996963B24BC2EE952FAC",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "5C630F9D25B00745059AF02910AF2107763A",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "E70872A1280ED143397963774B6B7627406C",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BFB98C8921C5F2405138888460DC222CD79C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "1B1B3ADC1A6E634AA32BE7E57900EA932256"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "5DC8F3D11E4DE641283899D5F37DF2FC6B2C",
                        "name": "C9-03 Enemy Balance 10"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDBFEF4A5329F64B3928F1C55334130F9984"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "AB9888C61A474143AB49A232F0D529FA9A24",
                        "name": "20 - Butcherfly"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "9C36972D763B1344767963F83E9087712525"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "04597BFB95A2B845E33AD1C564BAA1912D87",
                        "name": "23 - Samuwraith"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "270D2F5C05362649DF495FE5418978DDC5EA"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "9B685B678F7C94447E6945168851D664456C",
                        "name": "25 - Mothremble"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "0AD0F43A19DD37457B488282D865695F78AA"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "BE8FEB23762F274BE39BD2F969C49EAC9E94",
                        "name": "27 - Abomander"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "6231944F1D661643346967B38FB017140B8F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "187EA2B18738A841278BA6E816F80AD12156",
                        "name": "28 - Lavamander"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "C822933F73F0D14AFF99C5D8416E02CAB490"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "705077A82023E24D6849A4704A0CD0BDFDC8",
                        "name": "29 - Ferynx"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "19CD9BA14F431744C628634642043A55E15F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "A26B351E8D1BF342E26BCDC07FDA7A54313E",
                        "name": "30 - Tyrantelope"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "D94713CA172CE34EFF298443E259F1C2A7DE"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "61FEA9643CBE8349FF4865E48D57E49F8E54",
                        "name": "31 - Snactus"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 3,
                "uid": "F213F0491D17B2472568C6846C2A06028D0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            5,
                            4,
                            5,
                            0,
                            "7A355CC4571D244BDE3BB44245333B13A1B3",
                            81,
                            1,
                            "88075A6B6877024416186979A1BE9764CAE3",
                            81,
                            2,
                            "D5C8F8BC74F61549AA6BEC88E2AC17317B8E",
                            82,
                            3,
                            "9863BF1158874747FB089B6376EEE70AB666",
                            80,
                            4,
                            "2087411254E9D74AF859B9A70FA7C7A0413C",
                            81,
                            6,
                            "753BF5022BBCD6434D383CA7820EDBB0862E",
                            81,
                            1,
                            "D5C8F8BC74F61549AA6BEC88E2AC17317B8E",
                            82,
                            3,
                            "446BDA625C6A274DC46B3EB7BA3F442E58D9",
                            81,
                            6,
                            "A72EB1E0432086453B182A04C5BAED5666F7",
                            82,
                            5,
                            "560F192E55CEB64A8C69B12083CF1CFE8E4D",
                            81,
                            4,
                            "88075A6B6877024416186979A1BE9764CAE3",
                            80,
                            5,
                            "982FB3AC883A434A0A6B4B8078DC3E7685C9",
                            81,
                            6,
                            "D5C8F8BC74F61549AA6BEC88E2AC17317B8E",
                            82,
                            1,
                            "5BFB10278C53C7470E69D7E1340776D8EA32",
                            82,
                            2,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "D6F767E57EBE46449E895730A110B50B6065",
                            "Graphics/Avey's Battle Backgrounds/Mountain Area.jpg",
                            "0FD411125122A54DDE78A734298726B33206",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F151EF37439515423B6A8457C8B83ACDB41E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "battle"
                },
                "indent": 0,
                "uid": "4CF0CFF69A62B34FED488C25275F45245290",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "D6F767E57EBE46449E895730A110B50B6065",
                        "name": "NORMAL BATTLE"
                    },
                    "savePrevious": 1,
                    "erasePictures": 0,
                    "eraseTexts": 0,
                    "eraseVideos": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "77BC0EC98D4E194773485B77821847211DC8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "EFB45B7A749B234C493A3B34B0A277256150"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "3CA5F3856580D441608BF7F14A1ADBFCCC17"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "F7010882067C194F5C799C186E528EB4D049"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "after the battle"
                },
                "indent": 0,
                "uid": "4C01E7F26B8D58460E2902B5E714EFF2786D",
                "expanded": true
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "9C2AAB34638AA343094A4C85D6235A874CAF",
                        "name": "C13-3 Second wave"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "01B173F565EE7843E748C66012746715A220",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}