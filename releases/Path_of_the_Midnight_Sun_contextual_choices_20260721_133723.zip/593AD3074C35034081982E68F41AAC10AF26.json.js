GS.dataCache['593AD3074C35034081982E68F41AAC10AF26'] = {
    "uid": "593AD3074C35034081982E68F41AAC10AF26",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C5-02b P1 Poledro & Andre",
        "type": "vn.scene",
        "parentId": "E9BE949B5EB61747871AB1426EB89AB12953",
        "chapterUid": "27B6E8FB2921364C12682182E915B49DA958",
        "order": 0,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "duration": 21,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "6A96C2128013104FED5B752934C4221756B8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "494C253608A281446D4A56F01E8920998E74",
                        "defaultText": "폴레드로"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4D4C4BA381C081441B18B8E88DFD776C2DDD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2D378EB09B50344022AA44826BC8F04A4F9"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Poledro"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Testo Multiuso 1",
                        "index": 1,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "05B347D95854294523793C72E3334D4738B6"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "551D06253932384B9828CCD4F09678129DF7",
                        "name": "33 - Andre"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "9F426D10470CA449F65ACEC714D0AF8DC3F1"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "CA2D3D27011EA84A95598F5399BCB4D66C85",
                        "name": "34 - Poledro"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "38AFE192245C84410E898CD2F2509A7AF113"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "74B151978A5353493C1A65288D2CEE58A253"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "BE54884499BA094C6B3B4AA2B8F1EC9E2AF3",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "65BE32B3829EF74A6C8ACE126BAF0FC36B1C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C4C934E09DC5984D3A59F927AFEA4B44CE9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 2,
                "uid": "DB8EED7071F0904DB3683DD46FC082E907CE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "A77F29FB1BE9444EFB4B5255645931A0FA80"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "model": {
                        "name": "Andre.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 668,
                        "y": 176,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 1,
                "uid": "5B48A6984BC49944407A0AE19FF9B10AA751",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "model": {
                        "name": "Poledro.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -226,
                        "y": 35,
                        "zoom": {
                            "x": 1.75,
                            "y": 1.75,
                            "d": 1.75
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 1,
                "uid": "0202EBF521230643AF59BEA3A5EE1878E73A",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.7,
                    "idleIntensity": 0.6,
                    "lipSyncSensitivity": 0.85,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 1,
                "uid": "1EC82C1062EF3849929A48440655238BF54B"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F68FA5188267534EED8B4293AEFDEB0BDA22"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FA11ADE12161434EC87A0EA71117C915C336"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 1,
                "uid": "935639C87A3C524FC48A5B97732D6E35BA12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F3BAE5D553A8B246633B96719F8ED4A8D09C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4BE38B944B07D148DF69CB42BE3D9E2CFC90"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7CB59B960CCB3144EF78BD18DF9000CF2C1C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "FAA6D899838D684C3E5AA8E2EC8F03283D50"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time",
                    "target": "activeContext"
                },
                "indent": 2,
                "uid": "58E209F30DD31049F98AAD964076B0352752"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "4EB63A79039BA0497B6A89D4530C042AA390"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "last time",
                    "target": "activeContext"
                },
                "indent": 2,
                "uid": "69F0749D62AF8749A029EA5262538ACCFEE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "80F11C5D586A0947576B9D61ABD128CB0F09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E019120338A91446A381651D7A9931DC3C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E92C4B445962B543320A01515B1EFBCA066D",
                        "defaultText": "어? 리아와 여제가 말하던 가신들이 저 사람들인가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7887708B0F82364A986A3913D51C7174F639",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9DCE042A7811404ADA1B11E359F662ABF569"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F21525298D68814A31882BE18902F8F374D2",
                        "defaultText": "이름이... 기억이 맞다면 폴레드로와 안드레였지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5DF6B5F29AC8224E03891FC48EAA587A37F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "309C1F8A7D02D84B8E08D5A8C1BAD4C6818D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "05F140E6435DE549B1899D58E3BC02C8E010"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "564C7B140F165841E08AD5B1F4EF8795E0E9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "BBAAF1115B1C54471F798214DE414E61F9F7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Talking in message box"
                },
                "indent": 0,
                "uid": "953D55CE9577C347C94B6BB2BBE1FE61E564",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7CB59B960CCB3144EF78BD18DF9000CF2C1C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6BE6C2886E40B647284BFCE68AE3A465F1ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62F4E69E33E6264CF84ABE319F4F93EF352A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7D71BF2349A274DCE7815B5F579AB600157"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A9EF35D345A214431C98AEA6169343CE9658"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "53E51EE77B34204638593F96D940C9C0179E",
                        "defaultText": "호이카데의 공주라...{W:300} 정말 장관이지 않느냐?"
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "43011EEC2412854C127A2DB2DB92187DDE0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C925CC9E196BF44BFD2B321113999EBC9E4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "194149AC7948F74F662A8696334C4906D141"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFC346685722D74E649AE614B159B8BB21CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4E062279F6C6045BA1B15B7296792F778F5",
                        "defaultText": "맞아요, 폴레드로 스승님!{W:300} 아까 살짝 봤는데,\n정말, 정말 섹시--"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3C92513A38019444D559BA67D0A56DCE193F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0472E4611B8464B082B90504936A043F6FC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "448EDD1B18F08649D71B8E19727AD0A6A73D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50F7BBCF782F714DCC19F906220CBDE3971E",
                        "defaultText": "자자, 어린 안드레야. 그런 부적절한 말을 입에 담으면 안 되지."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "E403F2AA437B7443818B90012A174BD8BFB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA36F3BC4E50364E0C7A55C8271C6EC5F247"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD48A7C29CCD80477B8B1F6694407C572281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E95CF0665C5A749E9286335A6ABBDFF31E8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "197AA4E47364594AB37B7076F08C1E104E30",
                        "defaultText": "네 말이 맞더라도 말이다."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "710AAE968B48054DC06BC893AFE831E110B0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F863B3937160284AFC499DD87298287BE6C5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "068213296B62C842B549A5F20F0420CA9841",
                        "defaultText": "그래, 확실히 섹시하긴 하지."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "ED99F485435C984B9F686C81AAB1337988FC",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0462CD553F72F6465F485A61D369562E4791",
                        "defaultText": "실례합니다, 리아 공주님의 가신들입니까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B7AF7421927BC54E2E1B2FF56ED1C9516044",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "hot",
                            "modest",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0983E5276C0B8415548C5A4B7D62EFEF918"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3117CCE914BB98486D6A74749E2CD5A0C8AB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "hot"
                },
                "indent": 0,
                "uid": "0887E004626583475859B458DC3C583A9C42"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "hot?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "145C689B62CFB8486779F6967440634D25AC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff with Faratras, invisible increase"
                },
                "indent": 0,
                "uid": "8008FF530C1F91462A1809D61D7616E2CE12",
                "expanded": true
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Ornières x Faratras",
                        "index": 401,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 4,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "46E643BD8B650743CF3AAC48424883E7BE3D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "modest"
                },
                "indent": 0,
                "uid": "8EF5B3B44A3593465458BC93001869456996"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C123158B2A1D454F6C1BD708EB81EBCCDFA0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4DF6B8478F462420C3961A6DB74FF4E89EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "392BAE1255A6C843DE291D177D246C3824CC",
                        "defaultText": "오-오!{W:300} 옳은 말씀이세요."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "E3-Poledro_line4_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "965D4C945624614B882BD239ABA24CC2CB0C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BAEF8C8980A7A343D21B36E3EECFA7FE9B65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B25F526A1993C147257A30F46509714695B7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 78
                },
                "indent": 0,
                "uid": "EEE9811F63670549FF39AAA7DF991816C2A0"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "model": {
                        "name": "Andre.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 668,
                        "y": 176,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "40480C2F7849C94CF249C265FB932F32B699",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "model": {
                        "name": "Poledro.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -226,
                        "y": 35,
                        "zoom": {
                            "x": 1.75,
                            "y": 1.75,
                            "d": 1.75
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 42,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "7E22C0300C6B064E5479A4E59FF0C373D17B",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.7,
                    "idleIntensity": 0.6,
                    "lipSyncSensitivity": 0.85,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "C950BA3063F39841F43AE531E28C3FF1AEFF"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B2107C306A6CA448293AE1E3F20DD5C006DA"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -15,
                        "green": -15,
                        "blue": -15,
                        "grey": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "159C2D305C64E1461D68C8B4671ECD5232D7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "ADD152387BC13743FA2934A2772880DF7FF1"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Andre and Poledro get closer"
                },
                "indent": 0,
                "uid": "C9EF3E425D04E240387852826DFA9E7ED38D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "72FBBDAD4FBBD84C1438A679112387AD3A49"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "98342BC35D415145C76989D171ED0C2A0D2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7228A428F8B8741586ADCB517CE8CA5972E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "355A84A242F251425A1AF496BE6FA9E5EBE1",
                        "defaultText": "아! 당신은...{W:300} 리아 공주님과 친구인 기사님!{W:300}\n경...{W:300} 오르니...{W:300} 음란니...?"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ACFF7C348A9567439179E8C7FFCA51849773",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40634BA12B8E044AFC7A82025F2AA0941E9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBDAE78F86EEE34CBC1AE9775FC0C88A9699"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9F6BCEC949FFD843D66A7CB3A202A759E369"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3EDFF6E656AD247C13B1147BBD7F32EBB6F",
                        "defaultText": "제대로 말하거라, 제자야.{W:300} 공주님의 지인을 존중해야지."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "2D4E152C8C3175467A68854760724A7C352D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "846C74E358972248DA38711576C0D313DE04"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "861F72DF3D8E1341A68969D48D628621D2FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4BF4FC2F7DE613477339FE150993C8A56E04",
                        "defaultText": "이 친절한 신사분은 음란니에르 경이시다."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "F548970F147B3243AB4B0DA27FFC2F525340"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43B4649C815B744CC72A96A83EA0B18CC13F"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0488BEB41841054E60194425FAB8E6A4A86E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "46A4CA7E649C674ECD2885F6BE8BC0937F9F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FA021C220607248942B1FE472582FB99958",
                        "defaultText": "... ... ...{W:300} 오르니에르 경입니다!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CC62E24D08CD5747136BF7373FA9BC571D76",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "328E0DE2785852426C18B241703279AE5C05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6246606606CBE84E3B697403DE208BB1491D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C9885E08A7772450478958428E4650B568A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9039D1D7A9EE948970928B8AD2553EFA227",
                        "defaultText": "우웃 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "046C1B7B659E9246523B92A86F5816E82A0D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3BDE5FB87EF35648611B674485AF3CB5F7AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EFBFF526FCF724B3F3ADB03953395531AC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79F85F7511EF27490608B9A9345A5CC6965D",
                        "defaultText": "넌 왜 그렇게 즐거워 보이는 거야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2BFC3A3422C61544F488DB9270DE2CB3C457",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B68C22555CE734A3B9BD5311D151C74C5EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB722EB0823A41451858B4372DF428FE6900"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D27D3E67693E2943502B4CA3F72FAF65EAE3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E6856B4345AF74F4E7AC431DC56F5B5C215"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F6140062F0C944876793215D6B9F8F0D9B3",
                        "defaultText": "오호호!{W:300} 미안하오.{W:300} 그저 순진한 실수였소."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "68AEAA5D93B958497D18E3F35DA7E6C8F9A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E78D010E54A8F34ADC181B0141D508F036FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD674854934959436029DBB5FBA1BA5D43A0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08F6EDB283981546E28985B129C97052AD20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "40EBA1D54B5842492B1BF5598401440F3388",
                        "defaultText": "폴레드로 스승님은 제가 아는 가장 순진한 분이에요!{W:300}\n제게 모든 걸 가르쳐 주셨죠!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A309217F8ECA6246C6095EF66A1349C018F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F39966067E85E74C863BFBD1F681CD102A9B"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "hot?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "51490AA73C0152449B6890B79F153155F2CE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "36F31CCC379C384C5D19C1C8A5DD901C13B7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3686BCDA3277054629480154FBE90C3B6A47",
                        "defaultText": "이 아이의 앞날이 걱정되는데..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1AE2BA9E5DFE94423118D2C1D98794027EF3",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "A7297E814A34A64DF84A2781EA20F5A7D924"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CEDF72784E3C254FB48B70F6083FA390E330"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DAA320E4745D64B1D2840B97ED1D182F9A4",
                        "defaultText": "알겠죠?{W:300} 방금 그릇이--라고 하셨잖아요."
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1F538AE042483844BF599DD719B347ECFA2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7CE053C82E39D6417538D1A99FA0AE6D3D16"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "51B21C0369D6B4428A88AC02AB2DE6EEAE2E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "528D0CD2270EC740459B9E76A894A4C7B139",
                        "defaultText": "뭐, 내가 한 말을 부정할 수는 없지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D9F3EDE22DAEF74302986D64180622DDA059",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FA577A721E3E1493A885F8285ED5545ECFB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85333AB42248A34CE7881BA232557ED692AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2FA396827F7F74CBA6966C1CFB9541D65A9",
                        "defaultText": "흠흠, 아무튼..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9EC367423D32E0447F1B14C2AB057413CEC0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "07EE5C7978E80245FC4BAA333AC40B09484C"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "AF4813E22F23814A0F78689811698A340893",
                        "defaultText": "훔쳐보는 것도 준비의 일부인가요?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D1E77A0F8FCE4842EF393EE4D898E450C6F4",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "295F4FAC839B9247389903F979334E07F94D",
                        "defaultText": "전투 준비 중입니까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F775041C6B2BB042BB795F47E8C6EB41FAFB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "what",
                            "what",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A8E621E243CE5443F8BD07263E0288A9A8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A85C44F229BB5742374A17F2B218BD64623C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "what"
                },
                "indent": 0,
                "uid": "09783DDC5065F545DF98BCE37DC4CDD43709"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB2D32002F67054A853BF2A6A04369352E79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "834435911960244D461A9D59A7EB8900F4E0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C400D51F7834F7461B2B00697C5C55AE026D",
                        "defaultText": "음, 그렇소. 아주 날카로운 관찰이군! 우린 전투를 준비하고 있었소."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "D9DB7DE94EF6104E11899A4804D4F02EFBBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9906BA6C99CC394BD56A3FB9A8BF42EF8443"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "351091BE37CB674F7C8AF7B54C2DA96ADD02"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "348EDA386FCFD540B33A6C233FB89C9DA5C5",
                        "defaultText": "그릇의...{W:300} 그, ‘매력’을 논하는 게\n어떻게 전투 준비인지 모르겠는데요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2BF48F4D56B0F44F461A42B295D9968BD554",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27F4E0348E56334C4268C1C7774940ED59A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "1614285E3F9135427F881B08A020C768A0FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C479FE22391BA44F5058F523629F8E3C1184"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6E0F97835CDFC54B007A9792A057446E3375",
                        "defaultText": "우-우리는...{W:300} 그게...{W:300}\n정신 지배 주문에 걸린 척하고 있었소!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D6CD877743A1E14E456A7C483761D7C99ECF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FEEFEC411090B5450C899B75ACE0DEB5FBE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBE4F80A41AC62495C8B77B54FF64FADFEFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7576B34B25A6D14CF779AAC12ED1867B88E5",
                        "defaultText": "하아, 피비 여제의 계획 말이죠?{W:300} 정말 기발해요!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ED4324132905914EEC7B34C779E669D921BE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75BC71A7118759421F6A04F7632BAB8F93B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6876A63374846496239A1746AAC0C1BD5DF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0675C00D50F44F375A97D4FF2E3A53199D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36F2C9C6864CC6447B3BB9773C6014D27911",
                        "defaultText": "그렇지.{W:300} 여제와 그 동생 리아 공주님은 모두 자연의 경이로다."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "83AEA5BA422BB24EC06A06C3D50A8B27390F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A8DA0057CD7C040985BAB474B32F984DD17"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "hot?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5068C7EC253D3642D4186A47B8E1630B4361"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6085533D0948D3488C693826D25D6B237292"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58BF53583B7F5048017968C32552B9E38B8F",
                        "defaultText": "무슨 말인지 확실히 알겠네요. 헤헤."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "068E4A650133334C1B19939244D2FC3FC437",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B1C081CD2D114349800AD2480C3E54F41F17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "800D4B7C5A8EC14F4F3B321879EA2F1C7FB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0467775C67393549648A3697C9B628FEF863"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F2F2C75930E5574F778B0C28E7760603DC82",
                        "defaultText": "이분은 우리 편이에요!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "8110A7A52DEF644C536A9640A7A2791CE4CD",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "678CA3588A1A114A881AD3220AFE82EAD132"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "491450AD041A47487F5879067CA93D0CBF86"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E08B4BF19D1B24FF268D178B96718C500C7",
                        "defaultText": "여러 의미로 그런 것 같네. 하아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "52352CC202D74544D61BAA241D34E5936643",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "551B083F1DDE784D875903F44FAE33EA34D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C415F65929C74AC5190E53A5DBF36C9F67"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "CFCFC1AB88F71340D519785227F5B5CCA77A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76D7E4FD1B796149E69AA3E1C19C6EE5A67D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE56999049406143872AA053E1F889C6DF3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B03726D2461864E464BC9985EF514CE64B9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time"
                },
                "indent": 0,
                "uid": "DB141A680041E742498A5A88881006D30249"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9253F2A8DD21642DE6A767459829EF5FDCE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB1C5F643A0A4045D40AD2511146202EB282",
                        "defaultText": "그런데 리아 님이 아이스크림을 약속하셨어요!{W:300}\n가지고 계세요?"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C839D1702F86B3415D7A3EA97C7C70694799",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2164FE7D25DFE446380AAB6137F058C0E0C7"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if ice cream is in the inventory"
                },
                "indent": 0,
                "uid": "0EEDAD176D141242D43BE5184BA1029DFF4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C07D8F0E5479A84D62189F80C3ECBAC30C70",
                    "parameters": {
                        "values": [
                            "EBA214B73A7445455719E0E9E91057954732"
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3685BF2325B4546D088E918CFDB3DFDE7E9"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "591391541639C34E1D894B59E10343617C87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A39C5BF9482D684B013AFC71486FA1F36999"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "811E4C7C4916D149452819D97ED9F83ECFE0",
                        "defaultText": "그래, 여기 있어.{W:300} 그런데 왜 특별히 부탁한 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "FF250D2C297D614B858B0A633391C67154F7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8FF308602C8B864DCD6A3A19A15802B50F11"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "C7C5B3AB38E98142E92835F3451E27A25747"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1450266D168EE64C2A2B47659013ACD5C338"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E5F2A42F8B597640F81B4106BBCD891131F1",
                        "defaultText": "갓 만든 아이스크림이다!{W:300}\n최고예요, 오르니에르...{W:300} 경!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "A1D179F681B1C6454A7B28370345BDF5C3D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8476C92129284841F52BDD0181512E3346EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6B19669453C5C549A95BA3368A91CE7AC3F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E3F0B0167E123408D0AAA1263AE3D01AE3E",
                        "defaultText": "이름을 기억하려고 애쓴 게 뻔히 보이네!{W:300}\n아이스크림이 정말 중요한가 봐."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0ED64DF01D76B244F27A9E26715394AF921B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B629CAA958A5564CBA0AC03783C8EA0505A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "402BE0006D6D2446AA6B26818C0A505554CA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4333927768EF07413E6A94625B5DAD609F35",
                        "defaultText": "아무튼 어린 안드레는 불과 번개 주문을 전문으로 하는 재능 있는 마법사요."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "3F3266B11B70914E824878E28F10F2E885EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "FC5EA31E1D3D5148D77BAE0439F115C368AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B66784232FB6E946D2293D75BB8AE1F511EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "05C15EF9983D254E5C58C16453E30DC7A639",
                        "defaultText": "아이스크림은 체온을 낮춰서 몸이 과열되는 걸 막아 줘요!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "F50C7873110A4541942A0F85229765BFE9B1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4C69F02379C6C74B502A083438BE209E3B63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E16AF4894349A24A381B4A569DB1BDC50ADA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5075E9820A4A764A1F384E87059FC8188DE4",
                        "defaultText": "그게...{W:300} 정말 말이 되는 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "282FA6C05997C34B1578995772318D59A3E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8A2362B04534C44C4E5B8041090A0A5084BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F1C312167DB760467A0BD728CB22F7A08D28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "76ACDB2641B8E740DE888857B55BAA9B3F32"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E0A7C496705574B1718A0966159417B41A5",
                        "defaultText": "우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "74759881855D79494D18AA788782F3B203AB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "61F439D1405BF94A7009B4A446B28833EE1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C1371F652DC2784D6618D205326C7FA1DD46"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0DDBC27E646695471499E26095657D98684F",
                        "defaultText": "네가 그렇다면 그런 거겠지."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "71DF038D4283824C8A494E57ECCDBC3F3099",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "631104A0828BA243913A1325D662DE21AFE3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7EAE1D923D5A774E5A5801A4FDAA4337EDF0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B8CC1CF90A7334C0E3A04F38D31ECE7CAC9",
                        "defaultText": "이 강아지 정말 귀여워요!{W:300}\n나랑 아이스크림 나눠 먹을래?"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "60F3612E5A680247BF9AE663B7E66C2923EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DFC5AFCD910DC54FC71AB1E936683B2DFB36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "D3CB07E14F399748EB6B9D355D56895D9AAD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5AA28CF582887547047A080288A15CB9B371"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4BE45C606A5384E03580550CDDBF10CD51C",
                        "defaultText": "우우우우우우우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "815F9CAF4F85C340FA584E86ECE48411F32F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "2E4953E687DEA24606787C315F40797F5801"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "4C83676B1F48C140652886C3F6FEC07567B9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "9E6BBFCE48A0F4462E2B2062E2BAFF455D8B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "E47A0758455C954D4828E90508F987EA1157"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "16BEA919453249461948D4029C18A41D46B5",
                    "parameters": {
                        "values": [
                            "EBA214B73A7445455719E0E9E91057954732",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "7D8AB6EE9DA37440CC784E123C3CB3A67795"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "7D3C8A620BC3B445FE38AB86D6913118B156"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "06BB64942A85124BBB8BD0217BA4E0204017",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "8C232FFE53256541B3285098A4EFA433C18E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6BE7CB0F6E432349354986D5355474CF1016",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "E09CFA4D72B0A449592B16A8786CC2BA4454"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "B87AD6F87F8531439D2B20C5A73C41D52401"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "22D7CA523D0888482638BD27B041D7012D29"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5238FFEA091A6340A11BD0B2CF5652C6417B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "48E5D41638DAD549E72BE386A3AE1AC2CE44",
                        "defaultText": "이런.{W:300} 루코스는 이 말을 기다리고 있었구나."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "967F0EA06486504BDF2B2C213926D5BD9E13",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "44B8FA358590C84EFC486AC8A35E7E1FE99E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "7F86CD4952BBF043DA897EA363A3D4099216"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "9543543D204C534F49491DE79E1984EF8718"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E4E58714F23C54A272A7D369C852B397937",
                        "defaultText": "오호호호!{W:300} 젊음이란 참으로 멋지구나."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "32C1777661FF454A08794505671452102135"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F274D5CA43D7B84A4C2A29E5972E7BF85F83"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3582D5345660864723480454D752896EF675"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0AA6B9BC00C3864BED9B096266491781012F",
                        "defaultText": "그런 것 같네요.{W:300} 아무튼 저는 전투를 준비해야 합니다."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "1C50C0D249C0234A192B6B0207B0E5C859DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B730042A7F05E746AC59C177D314ADB47F5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "712422546D85B444901B0E934F61D4D191E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7A95BEE564811745DC897C22DB08C95E09D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6E17CF6340C664EC03B0F77B7EEF27A6457",
                        "defaultText": "그...{W:300} ‘준비’가 잘되길 바라오, 경."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "A6D8070D8C6FC34CB0687C03EB9EBEC2DF71"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "27D9AEAB9BD8A8495D79DE34A46941E0ADF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "854780763DD3A542D33A6506CE00163D11A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A1A82AC8414E24ED38891C5861BBD4BFA16",
                        "defaultText": "정말...{W:300} 진지하게 ‘준비’할 겁니다, 폴레드로 씨."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "3769AEDF35BBD34BBE3B0004F759C50E7185",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "75047E8F28DD054B991914E3462434B14E23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "5CE910436113F84F1D1B347807DE0D4E2676"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "C32A993876634844F22AD739A0DD333E2D15"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB853BAE3862A845807A1AD719BEC208AE5F",
                        "defaultText": "오호호!{W:300} 의심할 여지가 없지."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "60C4970C7B85F747A79BCF61A2D599EF04BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "D7CA15741481D24C048910778DC9F240E83A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "EBB9DBC810CCB14A27692395DEE53E8A7E61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "ECBD22801082D845BD9B87263D785304B18A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "225748AF29ABC740B4183AA302485F596209"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "3D0D13EA25D2674DC9990C90866D8F2EB06A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "BB1C08930EA5014D2D6BE5D7FA7BDA4C43D8",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "D67E5F427113F148B82A3ED562E17D08B8E1"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 3",
                        "index": 162,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "250C8DA520F40643BB795EE31F656C49B81D"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "337DC5776247524177087F56E6673DF97E8C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if ice cream is NOT in the inventory"
                },
                "indent": 1,
                "uid": "8337C07D72A225476358CC713F77A2B59F46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B5DDEB7F70B6234C7E18E36502E66080C177"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE3269B55FEA1542A8187566591EB68BEE6D",
                        "defaultText": "아, 아직 없어요.{W:300} 저...{W:300} 아직 만들어야 해요."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "6B8DA0CC5F8A454D888996550C88986D08CC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "544DB82D527AD2455318ED398C5048E48FB3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "82FD337F818AB447D61A3858EC38185896E2",
                        "defaultText": "곧 가져다줄게...{W:300} 아마도.{W:300}\n만드는 법부터 알아내야 하거든."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "D8BF4A3E66C3D44FD52958D5AF4158C18C38",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DB4366AD02F017473E79F372965935E0FA3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "53BBC04B64CA044D1D08868271D57ECCEDE4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "864416960A3A24410C483626049B65B97625",
                        "defaultText": "놀랍게도 그 아이스크림 역시 우리의...{W:300} 전투 준비 중 하나요."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "E7B71969449F514AB86B4236604B0975AA77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0FD2D6C88A5506418798C331F0DA19DA8774"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "010DD7945464E549618A62368F9941CE7659"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC89EFF57EDEA54C961BAC460C1E872A0FCB",
                        "defaultText": "아까 ‘정신 지배당한 척한 대화’처럼 말이죠?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line54.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "C9B0D5F74DAD95430A8A4FE9608FB193535D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F36234997E6B8545DE7A5E4469D0BE674F92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            5
                        ]
                    }
                },
                "indent": 1,
                "uid": "6290B37B765AB74E2D8A61443DFCFE9EF44E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BBD72B94452D4843C10B3D752CF56BF0E409"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FFA47378BB50640885827933D1E0785E715",
                        "defaultText": "잘 아는군."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Poledro",
                        "name": "C05-02b_line55.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "expanded": true,
                "uid": "65E3515D720734436B7B26B220EFE3658775"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3EA475D70685C741C93881070A1B12F64D4A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            5
                        ]
                    }
                },
                "indent": 1,
                "uid": "2C7C0DB231F773414F9AA0C128AB89E6839B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "467FDFD68879E240951ADF9891F448096CA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61B79D1A63122340513836917ACAF3FCD5E2",
                        "defaultText": "이분은 잘 아시네요, 스승님."
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Andre",
                        "name": "C05-02b_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "04ED6A475C61014FE488EBD7BD6424780292",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "7C1CB28C4307E84BE73956679D6E2B00726D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "F64F7C1E3E619549D62B07E7D6D01C6C2B08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "26352FC040566442D59B02F5744B3541049A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 1,
                "uid": "2B532A7257F81340498A47F3E08BA939C38D"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "4EC52154027384467868C142A1EA822786B1"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "94D49EB66B81424C60582A944A4AE3E593F4"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of talk",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "26F7C3CC28992548468A93C786E2D4B68B33"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "last time"
                },
                "indent": 0,
                "uid": "F234EA781C4F98443658B7B8E284B66829EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C1E98F5996FA96469D5A5F4288B61F15B8A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18A572A13C3A6341623AD6F97C3B83F5A693"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B1A6BF7173E493477F4AE038A8F9BC05D858",
                        "defaultText": "열정은 고맙네, 젊은이. 하지만 이제 야영지로 돌아가는 게 좋겠어."
                    },
                    "position": 0,
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DFFF7F23285351443989AE03FFDFB97DEF93",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D23EED9633255441D5B4E66C0CB8C0F7202"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F9B0D083750F944813AE3120873B765D210"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A077649913BC047112A5C19CB35D547E929"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "402FEE955D46B944759B15A6F1B8B990B391",
                        "defaultText": "그리고 아이스크림 고마워요! 맛있었어요!"
                    },
                    "position": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4A18CBF9624F2242ED79A756DE6096BCC52B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "32BB9C8C434E334DF04913F14FD983A24027"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "747D016243E158490D4963E671036901EFA4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "742D3B0584F7254E78189508A351CB0F4A70"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D44417CD5D6977435349B6F1CF6C400779B6"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "AEC647753BCFA6451A2A9EC86F5A67BA32B2"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of talk 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "E01F588360730847EE5860E03B89A94C844F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of talk"
                },
                "indent": 0,
                "uid": "C1707C723EB4C5428D284B18AD3EA2AA7322"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DFF791D58644644FD49BD026F11B8431B23D"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9343A3EC4C67734AB6398EA7804EEC7F84A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1148036754E2994C210B6749EEFEAC16E090",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4A121F0162103741D9283DD7C55696C1A94C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of talk 2"
                },
                "indent": 0,
                "uid": "AB74B2AE7B95B54A9138E9F6C35C1A34F3BD"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "model": {
                        "name": "Andre.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1231,
                        "y": 294,
                        "zoom": {
                            "x": 0.46,
                            "y": 0.46,
                            "d": 0.46
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 21,
                    "waitForCompletion": 1,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "D71B53632975A64E803B6D57C4584E073B7F",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "7285F1B9214BF643D3982457FE50A883F047"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F83FB82441FFF043885A98D59678155BCE7A"
            }
        ],
        "localizableStrings": {
            "E92C4B445962B543320A01515B1EFBCA066D": {
                "t": "Oh? Are those the retainers that Rya and the empress were talking about?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7887708B0F82364A986A3913D51C7174F639"
                }
            },
            "F21525298D68814A31882BE18902F8F374D2": {
                "t": "Their names were... Poledro and Andre, if I'm not mistaken.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5DF6B5F29AC8224E03891FC48EAA587A37F7"
                }
            },
            "53E51EE77B34204638593F96D940C9C0179E": {
                "t": "The Hoikadian princess...{W:300} quite the spectacle, isn't she?",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "43011EEC2412854C127A2DB2DB92187DDE0C"
                }
            },
            "D4E062279F6C6045BA1B15B7296792F778F5": {
                "t": "You're right, Master Poledro!{W:300} I caught a glimpse of her earlier. She's so, so hot--",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "3C92513A38019444D559BA67D0A56DCE193F"
                }
            },
            "068213296B62C842B549A5F20F0420CA9841": {
                "t": "Yes, she's indeed hot.",
                "d": {
                    "eid": "ED99F485435C984B9F686C81AAB1337988FC"
                }
            },
            "0462CD553F72F6465F485A61D369562E4791": {
                "t": "Excuse me, are you Rya's retainers?",
                "d": {
                    "eid": "B7AF7421927BC54E2E1B2FF56ED1C9516044"
                }
            },
            "7FA021C220607248942B1FE472582FB99958": {
                "t": "... ... ...{W:300} It's Sir Ornières!",
                "d": {
                    "cid": 0,
                    "eid": "CC62E24D08CD5747136BF7373FA9BC571D76"
                }
            },
            "F9039D1D7A9EE948970928B8AD2553EFA227": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "046C1B7B659E9246523B92A86F5816E82A0D"
                }
            },
            "79F85F7511EF27490608B9A9345A5CC6965D": {
                "t": "Why do you look so amused, you?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2BFC3A3422C61544F488DB9270DE2CB3C457"
                }
            },
            "3686BCDA3277054629480154FBE90C3B6A47": {
                "t": "I'm worried for this boy's future...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1AE2BA9E5DFE94423118D2C1D98794027EF3"
                }
            },
            "528D0CD2270EC740459B9E76A894A4C7B139": {
                "t": "Well, I can't deny what I said.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D9F3EDE22DAEF74302986D64180622DDA059"
                }
            },
            "AF4813E22F23814A0F78689811698A340893": {
                "t": "Is peeking part of your preparations?",
                "d": {
                    "eid": "D1E77A0F8FCE4842EF393EE4D898E450C6F4"
                }
            },
            "295F4FAC839B9247389903F979334E07F94D": {
                "t": "Are you preparing for combat?",
                "d": {
                    "eid": "F775041C6B2BB042BB795F47E8C6EB41FAFB"
                }
            },
            "1E08B4BF19D1B24FF268D178B96718C500C7": {
                "t": "In more than one sense, right? Sigh.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "52352CC202D74544D61BAA241D34E5936643"
                }
            },
            "7E3F0B0167E123408D0AAA1263AE3D01AE3E": {
                "t": "That obviously took effort to remember my name!{W:300} The ice cream must really mean a lot to him.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0ED64DF01D76B244F27A9E26715394AF921B"
                }
            },
            "1E0A7C496705574B1718A0966159417B41A5": {
                "t": "Woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "74759881855D79494D18AA788782F3B203AB"
                }
            },
            "D4BE45C606A5384E03580550CDDBF10CD51C": {
                "t": "WOOOOOOOOOOOT!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "815F9CAF4F85C340FA584E86ECE48411F32F"
                }
            },
            "494C253608A281446D4A56F01E8920998E74": {
                "t": "Poledro",
                "d": {
                    "eid": "4D4C4BA381C081441B18B8E88DFD776C2DDD"
                }
            },
            "50F7BBCF782F714DCC19F906220CBDE3971E": {
                "t": "Now, now, young Andre. You needn't indulge in such improper language.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "E403F2AA437B7443818B90012A174BD8BFB3"
                }
            },
            "197AA4E47364594AB37B7076F08C1E104E30": {
                "t": "Even if you're right.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "710AAE968B48054DC06BC893AFE831E110B0"
                }
            },
            "392BAE1255A6C843DE291D177D246C3824CC": {
                "t": "Oh-oh!{W:300} Well said.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "965D4C945624614B882BD239ABA24CC2CB0C"
                }
            },
            "355A84A242F251425A1AF496BE6FA9E5EBE1": {
                "t": "AH! You're...{W:300} the knight who's friends with Princess Rya!{W:300}\nSir...{W:300} Orni...{W:300} Horny...?",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "ACFF7C348A9567439179E8C7FFCA51849773"
                }
            },
            "F3EDFF6E656AD247C13B1147BBD7F32EBB6F": {
                "t": "Say it right, my pupil.{W:300} You need to respect the princess' acquaintances.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "2D4E152C8C3175467A68854760724A7C352D"
                }
            },
            "4BF4FC2F7DE613477339FE150993C8A56E04": {
                "t": "This kind gentleman is Sir Hornyerez.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "F548970F147B3243AB4B0DA27FFC2F525340"
                }
            },
            "1F6140062F0C944876793215D6B9F8F0D9B3": {
                "t": "Ohohoh!{W:300} My apologies.{W:300} It was nothing but an innocent mistake.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "68AEAA5D93B958497D18E3F35DA7E6C8F9A9"
                }
            },
            "40EBA1D54B5842492B1BF5598401440F3388": {
                "t": "Master Poledro is the most innocent person I know!{W:300}\nHe taught me everything!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "A309217F8ECA6246C6095EF66A1349C018F1"
                }
            },
            "3DAA320E4745D64B1D2840B97ED1D182F9A4": {
                "t": "You get it right?{W:300} You just said that the Vassal was--",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "1F538AE042483844BF599DD719B347ECFA2F"
                }
            },
            "B2FA396827F7F74CBA6966C1CFB9541D65A9": {
                "t": "Ahem, in any case...",
                "d": {
                    "cid": 0,
                    "eid": "9EC367423D32E0447F1B14C2AB057413CEC0"
                }
            },
            "C400D51F7834F7461B2B00697C5C55AE026D": {
                "t": "Mmmh yes, a most astute observation! We're getting ready for the battle.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "D9DB7DE94EF6104E11899A4804D4F02EFBBD"
                }
            },
            "348EDA386FCFD540B33A6C233FB89C9DA5C5": {
                "t": "I can't see how talking about the Vassal's...{W:300} er, 'qualities' can be considered battle preparation.",
                "d": {
                    "cid": 0,
                    "eid": "2BF48F4D56B0F44F461A42B295D9968BD554"
                }
            },
            "6E0F97835CDFC54B007A9792A057446E3375": {
                "t": "We...{W:300} umh...{W:300} were pretending to be under the influence of a mind-controlling spell!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "D6CD877743A1E14E456A7C483761D7C99ECF"
                }
            },
            "7576B34B25A6D14CF779AAC12ED1867B88E5": {
                "t": "Haaah, that was part of Empress Phoebe's plan, right?{W:300} Truly brilliant!",
                "d": {
                    "cid": 0,
                    "eid": "ED4324132905914EEC7B34C779E669D921BE"
                }
            },
            "36F2C9C6864CC6447B3BB9773C6014D27911": {
                "t": "Indeed.{W:300} Both the empress and her sister, Princess Rya, are wonders of nature.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "83AEA5BA422BB24EC06A06C3D50A8B27390F"
                }
            },
            "58BF53583B7F5048017968C32552B9E38B8F": {
                "t": "I definitely know what you're talking about, hehe.",
                "d": {
                    "cid": 0,
                    "eid": "068E4A650133334C1B19939244D2FC3FC437"
                }
            },
            "F2F2C75930E5574F778B0C28E7760603DC82": {
                "t": "This man's one of us!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "8110A7A52DEF644C536A9640A7A2791CE4CD"
                }
            },
            "BB1C5F643A0A4045D40AD2511146202EB282": {
                "t": "By the way, Lady Rya promised me some ice cream!{W:300} Do you have it with you?",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "C839D1702F86B3415D7A3EA97C7C70694799"
                }
            },
            "811E4C7C4916D149452819D97ED9F83ECFE0": {
                "t": "Yes, here it is.{W:300} Why the special request, though?",
                "d": {
                    "cid": 0,
                    "eid": "FF250D2C297D614B858B0A633391C67154F7"
                }
            },
            "E5F2A42F8B597640F81B4106BBCD891131F1": {
                "t": "Freshly made ice cream!?{W:300} You're the best, Sir...{W:300} Ornières!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "A1D179F681B1C6454A7B28370345BDF5C3D1"
                }
            },
            "4333927768EF07413E6A94625B5DAD609F35": {
                "t": "Anyway, young Andre here is a talented mage who specializes in fire and thunder spells.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "3F3266B11B70914E824878E28F10F2E885EB"
                }
            },
            "05C15EF9983D254E5C58C16453E30DC7A639": {
                "t": "And ice cream helps me lower my body temperature, preventing me from overheating!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "F50C7873110A4541942A0F85229765BFE9B1"
                }
            },
            "5075E9820A4A764A1F384E87059FC8188DE4": {
                "t": "Does...{W:300} that even make any sense?",
                "d": {
                    "cid": 0,
                    "eid": "282FA6C05997C34B1578995772318D59A3E2"
                }
            },
            "0DDBC27E646695471499E26095657D98684F": {
                "t": "If you say so.",
                "d": {
                    "cid": 0,
                    "eid": "71DF038D4283824C8A494E57ECCDBC3F3099"
                }
            },
            "4B8CC1CF90A7334C0E3A04F38D31ECE7CAC9": {
                "t": "This puppy is so cute!{W:300} Wanna share some ice cream with me?",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "60F3612E5A680247BF9AE663B7E66C2923EF"
                }
            },
            "48E5D41638DAD549E72BE386A3AE1AC2CE44": {
                "t": "Oh boy.{W:300} Luckos was totally waiting for that.",
                "d": {
                    "cid": 0,
                    "eid": "967F0EA06486504BDF2B2C213926D5BD9E13"
                }
            },
            "2E4E58714F23C54A272A7D369C852B397937": {
                "t": "Ohohohoh!{W:300} Youth is so splendid.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "32C1777661FF454A08794505671452102135"
                }
            },
            "0AA6B9BC00C3864BED9B096266491781012F": {
                "t": "I suppose so, yes.{W:300} Anyway, I need to prepare for combat.",
                "d": {
                    "cid": 0,
                    "eid": "1C50C0D249C0234A192B6B0207B0E5C859DB"
                }
            },
            "F6E17CF6340C664EC03B0F77B7EEF27A6457": {
                "t": "Good luck with your...{W:300} 'preparations', Sir.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "A6D8070D8C6FC34CB0687C03EB9EBEC2DF71"
                }
            },
            "9A1A82AC8414E24ED38891C5861BBD4BFA16": {
                "t": "They're...{W:300} going to be serious 'preparations', Mister Poledro.",
                "d": {
                    "cid": 0,
                    "eid": "3769AEDF35BBD34BBE3B0004F759C50E7185"
                }
            },
            "BB853BAE3862A845807A1AD719BEC208AE5F": {
                "t": "Ohohoh!{W:300} No doubts about it.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "60C4970C7B85F747A79BCF61A2D599EF04BE"
                }
            },
            "DE3269B55FEA1542A8187566591EB68BEE6D": {
                "t": "Oh, not yet.{W:300} I...{W:300} still need to make it.",
                "d": {
                    "cid": 0,
                    "eid": "6B8DA0CC5F8A454D888996550C88986D08CC"
                }
            },
            "82FD337F818AB447D61A3858EC38185896E2": {
                "t": "I'll bring it to you soon...{W:300} er, hopefully.{W:300} I still need to figure out how to make it.",
                "d": {
                    "cid": 0,
                    "eid": "D8BF4A3E66C3D44FD52958D5AF4158C18C38"
                }
            },
            "864416960A3A24410C483626049B65B97625": {
                "t": "Surprisingly, that ice cream is also part of our...{W:300} battle preparations.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "E7B71969449F514AB86B4236604B0975AA77"
                }
            },
            "FC89EFF57EDEA54C961BAC460C1E872A0FCB": {
                "t": "Just like the 'mind-controlled talk' from earlier, right?",
                "d": {
                    "cid": 0,
                    "eid": "C9B0D5F74DAD95430A8A4FE9608FB193535D"
                }
            },
            "3FFA47378BB50640885827933D1E0785E715": {
                "t": "You get it.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "65E3515D720734436B7B26B220EFE3658775"
                }
            },
            "61B79D1A63122340513836917ACAF3FCD5E2": {
                "t": "He gets it, Master.",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "04ED6A475C61014FE488EBD7BD6424780292"
                }
            },
            "B1A6BF7173E493477F4AE038A8F9BC05D858": {
                "t": "I appreciate the enthusiasm, young'un, but you should probably return to the camp now.",
                "d": {
                    "cid": "4A33BAC618CB3348AE0BF2569A26E71F74ED",
                    "eid": "DFFF7F23285351443989AE03FFDFB97DEF93"
                }
            },
            "402FEE955D46B944759B15A6F1B8B990B391": {
                "t": "And thanks for the ice cream! It was yummy!",
                "d": {
                    "cid": "A12C14C68AC92343D81BAC7620AFFDEF95D8",
                    "eid": "4A18CBF9624F2242ED79A756DE6096BCC52B"
                }
            }
        },
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "hot?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "read?",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}