GS.dataCache['E559F0615E656047C548C9E6391CEF48D99B'] = {
    "uid": "E559F0615E656047C548C9E6391CEF48D99B",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C2-02c P2 Lyvonis",
        "type": "vn.scene",
        "parentId": "4128727E2334D249A98803B18CC6BDB0D6FD",
        "chapterUid": "821526CB730C524E8E8AE3E37167B67D0B30",
        "order": 1,
        "localizableStrings": {
            "CF5845CF70D1C9407E587371C526724B105F": {
                "t": "I wasn't expecting to see you here, Lyvonis.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "AEDC08A520B6C64AE06BAB61DADF311FFC22"
                }
            },
            "F4A351DA2E9344436E8BF8637455B4BB59C7": {
                "t": "I know you don't really care about me. So let's get this pleasantry over with.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "C48CB8646588C4463D5BD7788B9A6626390D"
                }
            },
            "140CA60E2348634F9F488EA2C659EBBEE537": {
                "t": "What do you need?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "981A0C7A56D5F849574A45C796F4B006F534"
                }
            },
            "969A59D379951541811B37288693E962EA90": {
                "t": "I just wanted to talk...",
                "d": {
                    "eid": "1CDDFC5A374D154EB27A43576A023D202442"
                }
            },
            "2B46F8FF90337241FD1929C2CD013FE18C66": {
                "t": "Oh, yes. Cry more.",
                "d": {
                    "eid": "3ADC199B7E8412418F2BECD43F14C9FA38E3"
                }
            },
            "DEB54F7D25ABE14C7E1B9F556E622FCF0C89": {
                "t": "Why would I believe you?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "7C64928D9C21F449F68AA589F13CAA1B9CEF"
                }
            },
            "C9D1C8AC13D2C44FD51A7311273D29729ECB": {
                "t": "I mean, is it always necessary to assume that I have an ulterior motive with you?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "0CD879105951E94AF58BD4510CA480D62C71"
                }
            },
            "A47B3079043AD540AF596CF7752AFE24F6F8": {
                "t": "Are you done making fun of me?",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "C9F5329166F4424DE51A13E3D74837605B3D"
                }
            },
            "0C050DD1747E5949EA9982D7E782DFA86E2B": {
                "t": "Actually, you're the one asking for it.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EA93537C26FEE445458A1970C2137D93308E"
                }
            },
            "90FDBABD6C56174B22991F6634FF24976A47": {
                "t": "If you weren't always that passive-aggressive towards me, I wouldn't need to constantly defend myself.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "5320CB8E8F41124EBE686755C79166BA6500"
                }
            },
            "BE25D62311134941CC4876F37C29B37216BB": {
                "t": "Tch... Think what you want.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "4418C1332478024A1F4B1B0687B3765903D8"
                }
            },
            "97B0E5C96E079548D39B29B8FF10231CF350": {
                "t": "Don't worry... I will.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CB6635B7747B11465A3AA654E01D985CB675"
                }
            },
            "FC1358079AF7984CA26AC70141AB4BF67AE7": {
                "t": "In any case, we don't have anything to talk about.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "22B0B52C01FBE541F88BC0D59908903DDA5A"
                }
            },
            "C262DD6917260747DF994F840C269B69CBF0": {
                "t": "If you're curious to know what I'm doing here, I'm... {SP:2}{C:1}on guard duty{C:0}.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "0E32FC506A8C264D7C08CF43D325635A9A3C"
                }
            },
            "1134C5B22C63864416199C214AAACEF76075": {
                "t": "What? That's William and Sabrina's job.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "96CEDD8C504E134B592B41312D2F3CAEF3B7"
                }
            },
            "2D66B4513611D14B481956A22105ECD55DBF": {
                "t": "Master Alvano called them to the training grounds.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "4A2AA3862EA79843675B9EC46AA486A8BA7C"
                }
            },
            "598728512EB7484AD848A78415833C399D42": {
                "t": "Huh, that's news to me.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F23537313204A64F4D09F7C4E12E73D2D92B"
                }
            },
            "3BA2DC1466071345F94BE3231C5F0381ABE2": {
                "t": "Hah! You should see your face. It seems that I finally knew something that even you weren't aware of.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "E8D9FCE556B8C74CB3299702998530EE14AF"
                }
            },
            "D25C49F56255E547C828DA143C7C716BADEE": {
                "t": "Master Alvano isn't required to tell me all of his intentions.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "996640250BA514465A890E559BAA669E3980"
                }
            },
            "37DC794F66FAD441BC4A17E8D5DD3F52C340": {
                "t": "Knowing him, he might want to teach magic to the soldiers as well. It'd be interesting if our soldiers became like the Holy Knights of Pylum.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "826F692117F5464CAF4BDB29D1C9ACBF5266"
                }
            },
            "2191A47F6E34654B7729C586E6E9C66E3F5A": {
                "t": "Beats me.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "D2723841759991449A497428144A0805A62A"
                }
            },
            "D3F6AE0279A8D446A23BC042F186679DBC95": {
                "t": "Now, leave me alone. I'm working here.",
                "d": {
                    "cid": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eid": "5F1582A72A72A54FF62B1730A6DB8480A7D2"
                }
            },
            "36D9E70B13DAC240D629CF49E7FE1905109B": {
                "t": "I'm busy too, you know.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "CDF2DB95371B6849961AEC3405399509E4C8"
                }
            },
            "62002DE493D5F24852681DD7CD36B10B40BC": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E27955040A50914B745A6C3399A39E320998"
                }
            },
            "A4CEFED24F3D824DBE7A2954AAFDD6B6D728": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "37892C784FAE53474F3BD4675009DC22B028"
                }
            },
            "37D31C5E6AA3B64449984F96BB95928B1F15": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9397AFAB12209844EC6AE688FF708E7AF3DB"
                }
            },
            "C60938730B6742440E0B5DE4300796C5B5C2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D4A6F2C0980763437F4AFD139148C29B70D6"
                }
            },
            "AECE734C4ECD094A93493AE1C9B6065CCB26": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "4F0E22818C4C164CB149C143B87E88FE018B"
                }
            },
            "CCE2F88D86E0C1450E5A25E032B22BC83EA9": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1A69B3AF49FA94404E3ADEE574F72BD69BAC"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43C094F95D0D934243790924A8542529E9A4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5BC3F1D892067148687B82694FEDD230DDF1"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 299,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 1,
                "uid": "28ACEBE69823C5415319B152414079E9DCB9",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 1,
                "uid": "8A35DEC41B6E0849693A11C39FD50595ABEA"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "6EA86EB744418045508911A6886F3BF6A4FC"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "jump second time",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "4DECD7BD8A87D441D53BF0C1159C3D2C74A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A2753203AC51148B85944720E25643D58BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF5845CF70D1C9407E587371C526724B105F",
                        "defaultText": "여기서 널 볼 줄은 몰랐네, 리보니스."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "AEDC08A520B6C64AE06BAB61DADF311FFC22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "24A13B2A89431442628A06C3D36196E29841"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "model": {
                        "name": "Lyvonis.model.live2d",
                        "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 299,
                        "y": 146,
                        "zoom": {
                            "x": 1.5,
                            "y": 1.5,
                            "d": 1.5
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "DFED6FBA33D21949142986F4ADEB0746D1BD",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.5,
                    "idleIntensity": 0.5,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "25EF6C878AFCF344D729B1755DC2D2DB4C89"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "loop": 1,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Lyvonis.model.live2d",
                            "folderPath": "Live2D/Z2 - NPCs/Hoikade",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "normal.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDE6F9197190D648FB98534196AF4AAC3DDF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "E10D508828BE32461518DD975FBCDC60A535"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "99A725F701DE544CE158EE3290D15945FC9C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "62002DE493D5F24852681DD7CD36B10B40BC",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E27955040A50914B745A6C3399A39E320998",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "00ED68CA1AE4C3417E9868167B5716ED6FA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ADADE977CFEC140555A7A12F78DCA361FDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F4A351DA2E9344436E8BF8637455B4BB59C7",
                        "defaultText": "네가 나한테 관심도 없는 건 알아.\n그러니 형식적인 인사는 빨리 끝내자."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "C48CB8646588C4463D5BD7788B9A6626390D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30442F084A1D844ED96965D6569DC913B71A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F46E7548939264E7F7AB9C4A121600A57F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "140CA60E2348634F9F488EA2C659EBBEE537",
                        "defaultText": "뭐가 필요해?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "981A0C7A56D5F849574A45C796F4B006F534"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E7F3E2F5F76854FD56A27675D1C8DA44508"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "969A59D379951541811B37288693E962EA90",
                        "defaultText": "그냥 이야기하고 싶었어..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1CDDFC5A374D154EB27A43576A023D202442",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2B46F8FF90337241FD1929C2CD013FE18C66",
                        "defaultText": "그래, 더 징징대 봐."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3ADC199B7E8412418F2BECD43F14C9FA38E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "talk",
                            "cry",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2AC3AEE7393D2543958B5A569F499F73CF03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D6247C307A8C78476F49BF63830DFCC5D3A0"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "talk"
                },
                "indent": 0,
                "uid": "5B031BE000FBF84BB13AA1F2D8450E5E9F9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB0D5E69615FE249056AC794ECAF9BC6EAFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B26D66D045DDB344E1683962706DBE3074ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DEB54F7D25ABE14C7E1B9F556E622FCF0C89",
                        "defaultText": "내가 널 왜 믿어야 하지?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "7C64928D9C21F449F68AA589F13CAA1B9CEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0ACB9AC02905F2451148A60712F8F4498ADE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71E8BB359D5615490B7B871636FA9D299224"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9D1C8AC13D2C44FD51A7311273D29729ECB",
                        "defaultText": "그러니까, 내가 널 대할 때마다 속셈이 있다고\n생각해야만 하는 거야?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0CD879105951E94AF58BD4510CA480D62C71",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDFC6BBC54EC034DBD19AFE79329F0578970"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "02E0ACA13AD6E84B2C19B4C1DE532CF0AA7A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "cry"
                },
                "indent": 0,
                "uid": "BC64B7E33678254BBC3A2AB125096F1946A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            8,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA6825110D8DA3483068FFE38336858E9F4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "2018256F5676614C8298992295EE226BBA00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8FB55AE679DC274B8019EC1971A994F53CE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4CEFED24F3D824DBE7A2954AAFDD6B6D728",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "37892C784FAE53474F3BD4675009DC22B028",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9C510FA369E4E14AC92B7FA40B31B285E321"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51A5E1913C55F844642A1404B921C848AC1D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A47B3079043AD540AF596CF7752AFE24F6F8",
                        "defaultText": "날 놀리는 건 이제 끝났어?"
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "C9F5329166F4424DE51A13E3D74837605B3D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40D03F2868F5764146085EA318F87BC082D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6890EFF16EF6C944F93AEEF97C08FC4F4A08"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C050DD1747E5949EA9982D7E782DFA86E2B",
                        "defaultText": "사실 자초한 건 너야."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "EA93537C26FEE445458A1970C2137D93308E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C4B340C4969C748D57A81A43020C3CEC926"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "90FDBABD6C56174B22991F6634FF24976A47",
                        "defaultText": "네가 늘 그런 식으로 빈정대지 않았다면\n나도 계속 방어적으로 나올 필요가 없었어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "5320CB8E8F41124EBE686755C79166BA6500"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E2E24CB42BC664A8E6BDEC7C82A29E97B0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8ABC3AEE4F4D344ECF792365BD4845EF9F25"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37D31C5E6AA3B64449984F96BB95928B1F15",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9397AFAB12209844EC6AE688FF708E7AF3DB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7698091322A116460168D0B6ACB4C608EAD6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB801F98785D3346806BA18270A997CBF86C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE25D62311134941CC4876F37C29B37216BB",
                        "defaultText": "칫... 마음대로 생각해."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "4418C1332478024A1F4B1B0687B3765903D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E105A1C421B55490208C179F64DE51ED1CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9641EE522F1AD64B2A1A7411679B17AD3DDF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97B0E5C96E079548D39B29B8FF10231CF350",
                        "defaultText": "걱정 마... 그럴 테니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "CB6635B7747B11465A3AA654E01D985CB675"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56C1286A5CE3E348729B3F3759322B1D1787"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "165E206B6D6D8144AB6986F603EFC5C76928"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFED6B4E4A919148DB6A8AE80B61C6F001DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A57D01AE4A649841E83ABCC2CFB10C59885D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC1358079AF7984CA26AC70141AB4BF67AE7",
                        "defaultText": "어쨌든 우리 사이에 할 이야기는 없어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "22B0B52C01FBE541F88BC0D59908903DDA5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "220EB5614A1D594AC80873F5B7CCBC45DEA5"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "jump second time"
                },
                "indent": 0,
                "uid": "B936BC517CE16641D59AA807ECC162FBFEBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69B9F4C25EBCF847646AB2D07965104089EC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C262DD6917260747DF994F840C269B69CBF0",
                        "defaultText": "내가 여기서 뭘 하는지 궁금하다면...\n{SP:2}{C:1}경비 근무{C:0} 중이야."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "0E32FC506A8C264D7C08CF43D325635A9A3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DB251787B8B5641317B15B2F27C09BFD2C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3CB588006C2E464DB758A3387072D181092D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C60938730B6742440E0B5DE4300796C5B5C2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4A6F2C0980763437F4AFD139148C29B70D6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C8A80F294A26924E649B0B41FB559C3561FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "751758CA0D4C4146B909216314385C764C6A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1134C5B22C63864416199C214AAACEF76075",
                        "defaultText": "뭐? 그건 윌리엄과 사브리나가 맡은 일이잖아."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "96CEDD8C504E134B592B41312D2F3CAEF3B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF106F5013EDF84B9A49BC5502FAC6E1B37C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC9B9E0D10C354432B79A7211D1933D32BA2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D66B4513611D14B481956A22105ECD55DBF",
                        "defaultText": "알바노 스승님이 둘을 훈련장으로 부르셨어."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "4A2AA3862EA79843675B9EC46AA486A8BA7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A014D3176916A14DB48B8F97AE40E5D02916"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6C4F73594655B5402A2B08C484AA28938715"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6BB659387D08D44373090C113AB0D6FC7956"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "598728512EB7484AD848A78415833C399D42",
                        "defaultText": "흠, 처음 듣는 소식이네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F23537313204A64F4D09F7C4E12E73D2D92B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B5EBB8BE4FC8C4411A392A67C4BE408C5485"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "DE0FD8EA479F3243404B51D771576EFA3A2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "919A1BBD492C48467F09A92536AFAEE41087"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AECE734C4ECD094A93493AE1C9B6065CCB26",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line11_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4F0E22818C4C164CB149C143B87E88FE018B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "D29CCD80631AD14AFE595D496774B194AED2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EEF78CA14D1E6140745AD1A6BAE3FF4271F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BA2DC1466071345F94BE3231C5F0381ABE2",
                        "defaultText": "하! 네 표정 좀 봐.\n마침내 나만 알고 넌 모르는 게 생겼군."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "E8D9FCE556B8C74CB3299702998530EE14AF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0A7060378B4AB2453548D8039605AA042A27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "AFFECBFF6C7FF04E653BBAE38FE1EF157B84"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D25C49F56255E547C828DA143C7C716BADEE",
                        "defaultText": "알바노 스승님이 모든 계획을 내게 알려 줄 의무는 없어."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "996640250BA514465A890E559BAA669E3980",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "A89A84BB67C6D14AD178FBF72F604AC13EA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F843D7758642464DCE6AB9373474109261BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37DC794F66FAD441BC4A17E8D5DD3F52C340",
                        "defaultText": "스승님 성격이라면 병사들에게도 마법을 가르치려는 걸지 몰라.\n우리 병사들이 파일럼 성기사단처럼 된다면 흥미롭겠네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "826F692117F5464CAF4BDB29D1C9ACBF5266",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A6B930681FD5414428084684CBBFD148B62E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C3C8CE423E28042641A27475D4E00BB4C6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FCD0B40E8C1E9449712BFF884101FE9BAD9B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2191A47F6E34654B7729C586E6E9C66E3F5A",
                        "defaultText": "나야 모르지."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "D2723841759991449A497428144A0805A62A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2ADEEC2003A37409119F5C628E079698F8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DCCAEE35300CB14D192864A5B60FE1496FE6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CCE2F88D86E0C1450E5A25E032B22BC83EA9",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Lyvonis",
                        "name": "E3-Lyvonis_line15_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A69B3AF49FA94404E3ADEE574F72BD69BAC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E9254BBC730B3245E27A42A4B80C8089152E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AA4FDFF627F24400B8B4625518E86B49DC6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D3F6AE0279A8D446A23BC042F186679DBC95",
                        "defaultText": "이제 혼자 있게 해 줘. 일하는 중이니까."
                    },
                    "position": 0,
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "5F1582A72A72A54FF62B1730A6DB8480A7D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3523E772AE1904100192E75A2DE657D56B1"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A45ADB5D8A83054EB82BDBC54819BE50F303"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "5B58AA2D190E5649BF4950710C05612D3C93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36D9E70B13DAC240D629CF49E7FE1905109B",
                        "defaultText": "나도 바쁘거든."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CDF2DB95371B6849961AEC3405399509E4C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "19F9DC7A38CC13441529F4278263C00788AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5BF72DB77FD1742E05AFAD8A8CA63170A99"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1D8B3F6755F4C8473B4AFA319A6EB952A9D2",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "CF48A26E1865224C714AC0E5DDD0997F09B9"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "51AA1E4F17EAE74A1A08CDA2C70DE1A10A13"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}