GS.dataCache['621190BC84D396457D9B55771FC5C64B94A7'] = {
    "uid": "621190BC84D396457D9B55771FC5C64B94A7",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C9-04 Arrival at the shrine",
        "type": "vn.scene",
        "parentId": "C101743084EC83479F0BEBF6C0326A79803A",
        "chapterUid": "B73FC0E12D36244CA65A5C38B3C3733E5786",
        "order": 3,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A339F1F77D105437D484ED486C008B39739"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "59714350694F014C9598F1B6C72276BBDC0C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "E77C24C81793C649597AC7F2F527C25F0C9F"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "C766BB703499C8497E1B0D0393168B8511AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            0,
                            0,
                            0,
                            0,
                            50,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C677A9553CD571492B18DB1945AC5D383FB0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            1,
                            2,
                            0,
                            2,
                            0,
                            0,
                            801,
                            -150,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "468BC3755228E64C4E29DC269FC92C3F5004"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA1270D416CE524F1A28D638084823103B43"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E735742544128410458F17599C17AE9FA78"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "65FAC73C69641040F6188202D08E49CA7F5C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "49353D0E522376439F49BDF6687C28FECFF7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "B73FBC0C3B46784E952A7BA76DAA7F608900"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            20,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "332D81089C1B7543CC8902A10FEC3243BEB9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "0A156CCC32459443E07B3338D3B5E240D924"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9072861D467FC34D97585E74C028B100E0E7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2FE6A3BC4E4134422029606208F7D3867EBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1CA24F0A0585F647D519EBA7C3B0A996E531"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E1F31C467728284A9748C8F6B07727D5A873"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBBF801252686748E6695518765EA100EAE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6CF68A501705542D529ADE161008D1845E8",
                        "defaultText": "드디어 도착했어... 으윽, 마나 재앙은 여전히 강렬하네."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B32899E721FB05488C6808E8E4F9EDC264CF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE4203851775024090792AB3AF9C6144B43C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51ACF3CA6DB1D4404F881EA410C5C865446E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F991DFD15803F24CD01BD7F181F443354482",
                        "defaultText": "하지만 곧... 곧 이 모든 고통이 끝날 거야."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FEBF29D4865F3545AE4B11B3006200AF9C36",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6ADBFFCD12B3A24F5B7A49C25FC4636B0A2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45DEDF0E31BDC34668199312128A14251C68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57A5A27C765C60457139B478816BD8E6983D",
                        "defaultText": "다른 사람들과 상의했어. 혹시 나타날지 모를 괴물에게서\n입구를 지키려고 모두 밖에 남았어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0884AD4D7511E14143289DA75CBC885D8C2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "674F444D8E2F2749631A7547195D0F6E5E39"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10F00B6C388E9245002BE5C8BA73F81B0C8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CBAD3E69136BB748CF38F0357C010680D2CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2D6E728218A144CB24BA2960E473D75476B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4D373ED554BF91434678E033B134B99FF4AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "742644A00DCDA14CA068BC2399FC154343DF",
                        "defaultText": "좋아, 그럼 방해받지 않고 그릇 계승 의식에 집중할 수 있겠네.\n잠깐만 기다려 줘."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A18BB531201492458659AAB6E9DC2F7F1D6D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0E11058205D9340E678AD56287B5EED5032"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35D567AD4A9C15482B28EBC172A1ABE78B5F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;\nshiori reappears in the middle of the scene, focused (Hellios is in the minimug, implying he's behind Faratras now)\nFlash of light\nreopen"
                },
                "indent": 0,
                "uid": "F9581FF47C4E124CD72A5F95643715ED13BC",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "D1B90C2A5B6372485E2A33A63C65D270D352"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F8C308F248A2834EB858E1456F6DF5B4FFAF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "E85D6AC372F097462768FA782463FF06223B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "443965FA59D8F5410F0A91532E0103184B0F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "70E767C76938154B8E39B6485C4473C95973"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            701,
                            300,
                            419,
                            -82,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8708A9ED50A462421548ECC017FFD5105880"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CE0456631313243A07AF8015FB1EBAA5964"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            23,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8AB144CE45740840A67B7883325311B275FD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "63555615768F8749898872F66C1F773658AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F97084CE279F7741DF3BD9822D2F7E713E4F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "22FA5BE604599440E9487187330C9A18C5A8"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BFCFC21B7B03544EFC287723FBE4E35BCFE9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 126
                },
                "indent": 0,
                "uid": "73CF6AF60B330846BE7A711250FBF58C4E3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2FAE998B36115144A349A7A18845A1810E36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45B7EEF725A51041C6497486325A621851AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D1E43DD40527141F11A0D541C9CAD9F8ABB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A9F2958C5B239647183A75629CE7ABDCE5AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "06238F1D7BF48248EC28F2146756D8B603D6",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8A7F8DF035434845FB1AD628757D5182BBAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FD7B746734A2349FD69E456081490D3A421"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDD26C85394A7043E269E4A96C68564C0DA1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 126
                },
                "indent": 0,
                "uid": "65F68780176D5647233AA8D9C376F1EB34AD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34115CD313254542C01B2F53E7AAE5F68C18"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "0B01AAAD160B354E6C1859D29F434B1EED0A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "296A5E6689BF8940B9194C495E95C2861E4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A844D2746C9F044728992267859B5720971"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "94DE9DF246425344DF9B9031B7F19BDBD6E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7869E1D2852151451B1AD677F3B5E9FB0E8F",
                        "defaultText": "...얼마나 걸리지?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "91C15429495799497D3BC6A4050F9FB0BF21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "634A00BD5D15314CE128A9043439E4F5362A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9371A524CD11842D58BE9D37F38B3B291B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B9608829A5A0744B31A6818AEC2349D29EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FF8D9AC265D6E54D254AB1F980728303B396"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E9AA2E687CDCD346ED8AB752BE30E7121FAE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line28_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DF8FFF5A18817248735BB951F7F49D82ADC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "839028C96F653848249AA3F50958224936ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE9A847E7909C14BDD6B80061FDFC6FAB961"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D73348D420D834538792A05B0216676CBB3",
                        "defaultText": "쉿! 방해하지 말자.\n어쨌든 “잠깐”이면 된다고 했잖아."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FAF87D988D33044FBE5AC924FA7488745B74",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "341D6DFE3E956742B3382FD1A8ACF8406A63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A821E7117632E04CB32881A1A0E68D222F13"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "281CB04F4CF9914CB10B407900045BC62598"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29AB32A18A04B24ACA8ACA3473B6882EB72D",
                        "defaultText": "그, 그래. 미안해."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D4D8551042EB3744E50A3CF56C240502083F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BAEFC8286586F24897291D96FE77725F0E59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E15292ED0B0E8549E64BA6A6FB5647364B93"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 126
                },
                "indent": 0,
                "uid": "BDB304B97F18A745D67A3C67CB5E33031411"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD0C080A30C8F1413899A1C9F37FE78BB7B4"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Candelabra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "76BE384F87945449197908C43A5E7CFE7979"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            5,
                            250,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1000CCCC47D3F1434038C0662B8A6BD57F7F"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1401,
                    "viewport": {
                        "type": "scene"
                    },
                    "animationId": "8D6C237A878B664C8999DAD7B82690AE1F28",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 1399,
                    "duration": 12,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 765,
                        "y": 500,
                        "angle": 0,
                        "zoom": 0,
                        "horizontalFlip": false,
                        "data": {
                            "x": 388,
                            "y": 264,
                            "zoom": 0.69,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 265.85,
                            "height": 319.8
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B909E36F83F60646F079F6952C702F6DD517",
                "expanded": false
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1401,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -74,
                        "green": 13,
                        "blue": 79,
                        "grey": 255
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E61E194D295B38459E48199453335B046380"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1401,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 140,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5D628A099A9E944AA49950F4502734F93919"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E14045584533B343C36860E015F857E2A910"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D9435E3942A5A44DE81978197A1A8099EE32"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "33EEF7910DBAB9477B0B92806FF67FD39432"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;\nFlash of light\nwait\nScourge mist disappears\nreopen"
                },
                "indent": 0,
                "uid": "248FFE4A3ABB51435B788F1103B95FC52E2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B0AA6272773717421D49B8464E428C6EBA19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4138B375F78214EDC38B369A4CE83E6D053"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE6480975C4B964C657BB2444D8FDA714F07"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F5B494C1649074EB72A1AF60356BBC72785",
                        "defaultText": "정말 엄청난 힘이야...!\n주변의 마나 재앙마저 걷혔어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7F186CB878F9C14A4738AB818E11FF8F47C9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D94856E39CA68418618A9C77BED65AD14D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36D1E38D1EF9A74BAB19C9D0D6A839DA7E1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA04F806358DD84C2B894622B2477B280B51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E23B3780A41A84D3569ABF061E0C202BAB4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9AF36908420F6348A05B488875DAEEBED3D4",
                        "defaultText": "...! 뭔가 잘못됐어!"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FA4D8AA466825249520873B7822C278FA4A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "086DB7406ED8D3469F0A27E54ACEEF4362A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CECC8376A39C6450F0A545807EAC9AE8681"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60D5BDFA7E24A345D65BBCE5A46F06A0E398",
                        "defaultText": "뭐라고...?!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4DF0ECD4422CB04F6F69FDA9124DD365C9E3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "569080C64BE325429A4A32D745EDBD74A429"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "F3BF8D486E2BF545B86A68B8DF28A5375F6A"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "44B2CB274A13A042307910505DBFD6AD0B64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "10339396977AD04C762A08B9BA101F7C5169"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E90077215B41D3474A6AE5D723FCC0F201D6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "66977B503EEF964AA46A13C4E1E2B88A14B2",
                        "defaultText": "조심해, 시오리!"
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "307268FE5A30174FA938A3434E0B6D170199",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "09BCAA6B366D18479C3BAC53224A9B1F3A1B"
            },
            {
                "id": "vn.L2DMove",
                "params": {
                    "predefinedPositionId": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "model": {
                        "name": "Hellios Overworld.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": -1500,
                        "y": 540,
                        "zoom": {
                            "x": 1,
                            "y": 1,
                            "d": 1
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 9,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1E58705E4566974BEE3ABB59D445E11B145B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "1998131E73E8824D178A4715BCFBADCAEFBA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.02
                },
                "indent": 0,
                "uid": "EE75E9BB624A524D9E8836287E04198D8416"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "603112F1739345415739AA990B2B70000A44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A43BF7E188E63418F88F701A5F6EE8A2F0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B09D1E216D2164421F5B16E3C26699677CB5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "E65C92BF25793348099AE213FD21141FEAA2"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Exploration",
                        "name": "Bed Drop 2.ogg",
                        "volume": 100,
                        "playbackRate": 117
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "604F294F2B0B624BB848C300D1D1E8B8791D"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "977E33B98726954969496D042EFB4B6CC0B7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "C95693E75D747842AE7AB539F3BC6FF3BEA5"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 18,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8CF83F5F2655E34EC85994C0849B759A7A69"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "SQUINK_DEMON.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "535CD1F2029844418E4A47D227AEEF8C6257"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "31225F17911D124967886596BFB37973C668"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Enemy attacks sounds",
                        "name": "Generic Enemy Claw.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0DEEA7DD6EE9294DCE1BE786074CAD0D5654"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "937CD6E8187BB74A1C88EC5532532600F95C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            4,
                            300,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "59D8EC3435150947488965D29BF78F8458F8"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;\nShiori disappears immediately, sound of her and Hellios falling to the ground\nSquink sound\nreopen"
                },
                "indent": 0,
                "uid": "A341956214F3984D0C4A3873BC619F78AD85",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 102
                },
                "indent": 0,
                "uid": "3B69A4821E20244EF34A64C6AC42ED112747"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1A3FBE196E7305438F6A4D85B2E4B5C310B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE7FFFC21062244F6C6A3177F21FE7629D00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F82829A8339554602290CC8C7907F647AAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25851C8C725EA5490E0B1B80CD09EC56ADAE",
                        "defaultText": "스퀸크가 여기서 뭘 하는 거지!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D8833181673C024FBC8982D41F6570925BF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47666F465415B24EAD0BFA88A8D4C35C0C18"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4EA7AEA8E3AD54F6C7B48C87A9CE2194401"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F1A2D9A55453B749852A3147A271229A00E5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1AC94A314D0CB841A20BAE77046EFB8CAE50",
                        "defaultText": "사라져라! OBLUMBRA!!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E02A74DC7367A2453F5BFC38DC0058C8C08E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2C20792480E314EE67A6572CFE7EDEEE177"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A72F8963315EB044AD78FA05C1C9F187CE9C"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;\nOblumbra sound\nreopen"
                },
                "indent": 0,
                "uid": "D948F5C757690940F72B28B11FC94212801F",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "D1B0DAEC5DE36147DB3879F491F4D71AAE44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            600,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E24E61BD88F0D545AF39DAF947DC57B25458"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Faratras Oblumbra release.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9AEBF5571CFD204B0B88ADE734198FB737D5"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9000,
                    "viewport": {
                        "type": "scene"
                    },
                    "animationId": "0219CC78811DB148C3193DC3C51CCBA64EAE",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 2200,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": -161,
                        "y": -14,
                        "angle": 0,
                        "zoom": 3,
                        "horizontalFlip": false,
                        "data": {
                            "x": -75,
                            "y": 147,
                            "zoom": 3.3,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 991.8,
                            "height": 771.4
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "436D155562C4234FE36AE8837EA1F3A0B43B",
                "expanded": false
            },
            {
                "id": "gs.PictureEffect",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9000,
                    "duration": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 15,
                        "speed": 20,
                        "orientation": 2
                    },
                    "waitForCompletion": 0,
                    "type": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "74E4E9705FD752400E894CE5F154F5B922A0"
            },
            {
                "id": "gs.TintPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9000,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -27,
                        "green": -131,
                        "blue": -42,
                        "grey": 120
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1345236357935546101B3F52A6CAB5622480"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "10981091381165451378E1D40D25F3DFB6CF"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "42CEC3D80EA0E74C2D187EE68C9619DBAD37"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "4553CD136F28C6485F2AB081A2794C236B80"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 9000,
                    "duration": 15,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F283CAAD0057E8404C3981731D4D04EEB203"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "61B2C945628EF3448A3B132030B7BDC19AE3"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 66,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C7706BEE075D6542EA695288A02E3E419A5B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "DCC543A76C324641F4381CF46DB3F20AAE3E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF908EF9834986418A7AF4B24B8476203335"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "8F6FD5E14AED84480F38DC195C28F8B945DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A2C939E7024881491639C9D1D15F97EFCE82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F911627F8054B343A90ADDC24EA00560050B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1A55041300B7F249DE6ADA6927BB079F67E6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1B9BB454225C7049C1995EB4387FBB23FA63",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line30_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2FB5FE235927864DCF7B464638D6A32E1048",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BEECB8743A6584420C493F220711702F21A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AE5E2BA4FDAF346183AB705AAD736C16354"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58D4F36450AB8447612BAA6446C1AC3E9B89",
                        "defaultText": "괜찮아?"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA8E1D85661A6244220BFC276A62845DD804",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75D76C019F6AD849ED484291172E1161974B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DB2CDEC354069646936B3126CD5DE8C8245C"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "83E80D3432BA62428F889E83B59F521785B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4539F564056DC249DE7A3A69E68B05FFA9D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7142489609F1B045C079B7B135DB6A55B9AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57007385166CB148F32B34B4CE680FC356FD",
                        "defaultText": "으, 응... 너와 헬리오스 덕분에."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ABB10D3C78C3364F48084FA6076B6E926932",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C21376F98117B348D6786C57A9ACDA842B17"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A2925347A829148C69A4774D04077C2BABD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CACA77D96F49C84CD84BFF5374DE037E2A07",
                        "defaultText": "그런데 아까 그 스퀸크는 감지하지 못했어. 이상하네..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4AA73667115C934F557932125CFBB8D9C672",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E47BD4EF771F1845C05A0AD243BFB10F36A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43A9189D14D1B74DA579FEA67157C7DE3191"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2E9BF58502E7841AB588C76C9370BD23599"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "55C1B0CE66E2C549EA1AC2206691537562BF",
                        "defaultText": "그릇 계승 의식에 너무 집중해서 그랬을 거야.\n그러고 보니..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE06E97B3847954E137B34F9EE8FB275C47D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5C928D67BA40042211BB8660A8A7830D497"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EAE41408733184E8139C081DFAF1160D126"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F6EE08E6368D8344AF795890DF56D27FF08E",
                        "defaultText": "우리가 받침대 위에 바로 떨어졌어.\n이 때문에 의식에 문제가 생기지는 않았으면 좋겠는데."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8F903DEF1232F346675A9D428FABD05320A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EC480764D5D484CD4588F0541A6B019E5AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3EB261D97A0B9647752AD297337A6F850DB8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E9D0CF9655CEB5417F88D5A7DC948E0989ED",
                        "defaultText": "아니... 괜찮아. 오히려 준비가 끝난 것 같아!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C33FF32D68A6A14DB708FD53E174BACC2F1B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43B5C1F8561AB74D602826A813F9A268C7C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "997C4ADB382C054C290B725413295B4A1D2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5802F63D5D95934AF2491121A7C79DA2EC7B",
                        "defaultText": "이제 파라트라스가 받침대 한가운데에 서기만 하면 돼."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B256F8325153643B9481B53B8BAFE2ABF7C",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "final choice"
                },
                "indent": 0,
                "uid": "7D44E8F48A6227448F9A7E05F42EB4501036"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "722433657D01214CDA5977C76BB4F8539992"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E850D03C33F3294EB82B84564CB1DF2B68D1",
                        "defaultText": "알겠어. 준비됐어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "162D69DA92A4C1441758F3A6EA25D59BC8B6",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "second option seen?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "735405385B64664CC959C12779EABA053F85"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "56190C6E0AF10141145ACD12CC20BED0ABE8",
                        "defaultText": "잠깐만 시간을 줘..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "F887938D4EA8A845758BF1E375A64FD00A5A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "ready",
                            "not ready",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 1,
                "uid": "1949AD4F88CA264B0989BE62D86C18A44B3A"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "5BB7D74237B8A54F4209ABF0C7A201CE685C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "ready",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 1,
                "uid": "B03F27DA14E101437C9BFD90E7BEFC05C638"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "030F2534704D4847D759E42653D521AB588F"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "ready"
                },
                "indent": 0,
                "uid": "DEAF34FE78B4324AA04970E219D292BD0684"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "06BC782A2990584C890BBF98C51E5C21E039"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1478209E16C2994D0D7AF9947724343DFDB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "04BD94CC00891745525961C4A9D5C874EDE3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9B6F1846FC4B64642583274D846BD0AE521",
                        "defaultText": "좋아, 헤헤! 거기서 몇 분만 서 있으면 돼."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7EF034FE19DC77400B492F11E1F07DF20CA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3476BC1A97F4C845A64B5A9397461F69D66F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF94B52C102756432D185FB566835B56BE83"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "9B78DD670735624B008A01C381678CD8372C"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not ready"
                },
                "indent": 0,
                "uid": "0D32E7D07B465040193BC597E0AB0C283C99"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A592B4D838EE348A94AA9925511F9C8E7C4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "528A71137C8F1645A34AC8A67342CC7CC441",
                        "defaultText": "무슨 문제라도 있어, 파라트라스?\n언제까지 괴물들이 들어오지 못하게 막을 수 있을지 몰라..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "969577D02C06D847AD58692882F8712E9A03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE32D5EB25E0324938385E908271C35EBE28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "236841026E1A6541651857C57165B79935DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D904A174708124CB36A9CC412F79882E2D2",
                        "defaultText": "저 사람 말이 맞아. 여기까지 와 놓고 이제 망설이는 거야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "59034B2E3FC14442918945E53EAACC7D63C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C93C7AEC57DF5247FA19C5B6AAF8FC6E547C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5AE6430A0DAAC24C5E5A01C7FA049A4A2D17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "31F661F41F3E924D201B43902F2EE8E87F9A",
                        "defaultText": "그릇이 운명과 마주할 시간이야!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "855C1CA835FAC54C9E3A537759BC091E4319",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "second option seen?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "435C9E401E3851429A885B01C9B93AAC7BF7"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "final choice",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "2E8282510380C141423B80A809967033B779"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after final choice"
                },
                "indent": 0,
                "uid": "219654D756B8A34C965961586AD9A98EFD38"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "zoom on shrine pedestal"
                },
                "indent": 0,
                "uid": "87018BEC09329142F838D7C742D36014AF2A",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 39
                },
                "indent": 0,
                "uid": "5F0B92622E3FD54B09490F9396C39434D480"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 12,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BE7B2E6D719C524E1F394DA13478ED7EEE11"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 84,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 180,
                        "y": 180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "26D49D7A3AE6824B3C3A3F674B57E2410C9A"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 84,
                    "waitForCompletion": 0,
                    "position": {
                        "x": -40,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "A358A2193AB1E94782580BC6E29B3D4A0C07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "4B8E9FF0167D914046390F75687D84636674",
                    "parameters": {
                        "values": [
                            6,
                            1400,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FC9196E0B46C242363BA53648E5E2FF7622"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "CBE0ADA2817BE54D8B18ABC7BB4C7240B9FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BCFEC11434F7C0470F99FC68585483BCC01A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12E9DDB5565E3245AD2A7911EEAB08385802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "282765012213A846626AA0B01B96BDC0A0AA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1A9DAA9701EC0487C8B9201F3CB0BBB1AD3",
                        "defaultText": "여기에... 서면 되는 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1F028D7166BE7744FF8A80F3D9F27603D234",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4430C3BE49EC074BF68B17C2DA501344D1AF"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Candelabra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8026E41A8625A3471F386C34E1E61413D973"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            5,
                            250,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "96F762383F7D824A9829DFB5036E84CB8734"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "845E71311DC9784D468A3B9330861DB41DCE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "643EBE2F70E5534B457BFDB528D448B7192D",
                        "defaultText": "뭔가... 마음이 편안해져. 안에서 새로운 힘이 솟구치는 게 느껴져.\n이게 그릇 계승 의식의 힘이구나..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E9DB37660355644A234AF386D294EBE8B3FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C62B0ACF5B55854356388E23AEFDA6D72778"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BA157EA14936B44717181A94B476BBB00E3C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "770954F05AC8D1445B7AA718D7420AEBAB61",
                        "defaultText": "꼴 좋다, 마왕! 우리가 이겼어!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7E749CE20DB6142D31AC309C4FB8A277D5D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D86AA97B7A2A834BB6685DE865EF34B14EC3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39C1497E579EB443A21AE701418B6B4F9B9C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "F75C2ED83D69F54D16699B313F225A5C8819"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            300,
                            435,
                            -82,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE515A0A404C4945772B68171086A9E98D25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F954C67490E9C54CE94BDF245FE8220EE2CA",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "457050BE0A8DE34A951A0520523B3DEFEB30"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "8BC7871364242849216A21B0EDE37BB3037F"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "22AE4CA748A7F04DB66A9E129FC5C0469013"
            },
            {
                "id": "gs.BlendPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 96,
                    "waitForCompletion": 0,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "E07035C797D677490C8920A24282AAB40ADB"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 84,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "AA5FE2FF31CFA24C15290034036247BB47D4"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 84,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "50883571129E2546BE78EE9984484505D254"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "01F42960327844425C4BDB34E0C2D6D1B275"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3028EB2E9D5D744588292118704FD0D5DC2F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D75D5E5578EE674EB83A8551C67922096750"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D0D8DB4182A27447847A14E6D7B59BE2DD7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E5B1CA954C9B74D6B3AD6321814AACDABAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "47C689226244454581491F330A0B0F92A88D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21E056E56792204C65096E372F9097E805BB",
                        "defaultText": "시오리, 계속 마음에 걸리는 게 있어..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5929A776160CC747062BAE485D04E35F9FED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25BB09961003E64E674BB7A87DCC94C8D5E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F15D662F1085834B931982C5D3B02581B6B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F9C9B4C17FDCB4400C6BE958704EFFEFBE43",
                        "defaultText": "맞혀 볼게. 내 눈에 보이지 않는 괴물이\n또 나타날까 봐 걱정되는 거지?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "61BE28631F2FC341346BA612899AB1BF353F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1A7F1456DD16347BC199F0613F571EBE5F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C0D64A4C80A0634C325BD8086100326ACA2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99D4BBBA20D6A84F7B6A63B67A32D4F0F223",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "E3-Hellios_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "46EF32393226B045EA5884D586578DC1DF7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "18343C0C8CC4A1480E2819275802090C6B08"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "897832D344BBA647818BBCC9006FACDECAB8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CED51207540FF246899AB15140F0B581E5B3",
                        "defaultText": "맞아. 그리고 그뿐만이 아니야..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D3F70415477D6416F4B7391FF89C2D874B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8FBFE62287656462C9820120DAF1CE49C8D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "49F2EC42786DA54EFE69AAF19731106CD6C7",
                        "defaultText": "사령관 말이야. 믿을 수 없어."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6DBC50146DC6E544F76868F7FB20FEDC0AA8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F09889976821F94EA73A48A91A0265E41C97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "3452456F5510084491488514A65A5FA7F064"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BE008458B6115462C493150D1E077E36777"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AE051B9C3BBAF54A788A2454F52FEC56CCDC",
                        "defaultText": "나도 같은 생각이야. 지금이 가장 중요한 순간이고\n파라트라스가 방해받아서는 안 돼."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "42BB99144869B541258AECF75FA67E0E3CBC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23ACF6107CAA9248E049D5F5F41E1EDC08F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AFCB1ADB8F52E140285B2107B1CAA00035B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F60812DF1B06B04F5E4829A98A7930BA8700",
                        "defaultText": "사이 사령관은 내가 어떻게든 맡을게...\n너는 다른 사람들과 주변을 정찰하며 방해 요소를 찾아 줘."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B297D4AE7D04374B767B30F1EFFD9F25D7B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F35DF8CD6391134988694D54E8EF1C948A69"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0CBB47A67855C8445D4BEB94C464BB8EC964"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "255FF3968EED924DD04BF917F0996DF79FFF",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line28_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C98066004F6689499669F38112996D6736B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F89FED7B489F044C5488C0D80D89603ED6ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D10646001BFB484967185E948885D7806989"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A92A45599B7BA544B87841E887C3330CF062"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC7D23AC2205D645B37919E8710259A377A5",
                        "defaultText": "계획은 정해졌네. 조심해, 헬리오스."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "01BC26DA2B8120448E3A2286257C356400CB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E58CA3BB54A10442E24937832C50153F9F38"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "574346864C74484B043821451BA3E20A53D6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "8776ED832BB4F746B1587FF4C9B14BD48325"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5000,
                            900,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35CD259C5C34E14BAD2BD442D82FDAA4F7EF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "91C3C7228EE257445D088D1788DBA75E11D5"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "796762B26CED234F00488C932F560DBCA750"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "83D1BAC282823449595B3E93BC6267FFD988"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "FEBAA0052135314A2F0A67E898739B2A2710",
                        "name": "C9-05 Conclusion (Map & VN events)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1574AA0D9BE27244EC29B7715C0CDEA9610F",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "localizableStrings": {
            "C6CF68A501705542D529ADE161008D1845E8": {
                "t": "We're finally here... Ugh, the Mana Scourge is as intense as ever.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "B32899E721FB05488C6808E8E4F9EDC264CF"
                }
            },
            "F991DFD15803F24CD01BD7F181F443354482": {
                "t": "But soon... Soon, all this suffering will end.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FEBF29D4865F3545AE4B11B3006200AF9C36"
                }
            },
            "57A5A27C765C60457139B478816BD8E6983D": {
                "t": "I discussed the matter with the others. They're staying outside to protect the entrances from any possible monsters.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "0884AD4D7511E14143289DA75CBC885D8C2B"
                }
            },
            "742644A00DCDA14CA068BC2399FC154343DF": {
                "t": "Great, then I can focus on the Vassalage without any distraction. Just give me a moment.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A18BB531201492458659AAB6E9DC2F7F1D6D"
                }
            },
            "7869E1D2852151451B1AD677F3B5E9FB0E8F": {
                "t": "... How long will it take?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "91C15429495799497D3BC6A4050F9FB0BF21"
                }
            },
            "2D73348D420D834538792A05B0216676CBB3": {
                "t": "Shhhh! Let's not distract her.\nShe said it'll take just \"a moment\" either way.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "FAF87D988D33044FBE5AC924FA7488745B74"
                }
            },
            "29AB32A18A04B24ACA8ACA3473B6882EB72D": {
                "t": "R-Right, I'm sorry.",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "D4D8551042EB3744E50A3CF56C240502083F"
                }
            },
            "1F5B494C1649074EB72A1AF60356BBC72785": {
                "t": "What incredible power...! Even the Mana Scourge in the area has been dispelled...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "7F186CB878F9C14A4738AB818E11FF8F47C9"
                }
            },
            "9AF36908420F6348A05B488875DAEEBED3D4": {
                "t": "...! Something isn't right!",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "FA4D8AA466825249520873B7822C278FA4A8"
                }
            },
            "60D5BDFA7E24A345D65BBCE5A46F06A0E398": {
                "t": "What...?!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "4DF0ECD4422CB04F6F69FDA9124DD365C9E3"
                }
            },
            "66977B503EEF964AA46A13C4E1E2B88A14B2": {
                "t": "WATCH OUT, SHIORI!",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "307268FE5A30174FA938A3434E0B6D170199"
                }
            },
            "25851C8C725EA5490E0B1B80CD09EC56ADAE": {
                "t": "What's a squink doing here!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D8833181673C024FBC8982D41F6570925BF3"
                }
            },
            "1AC94A314D0CB841A20BAE77046EFB8CAE50": {
                "t": "Begone! OBLUMBRA!!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "E02A74DC7367A2453F5BFC38DC0058C8C08E"
                }
            },
            "58D4F36450AB8447612BAA6446C1AC3E9B89": {
                "t": "Are you all right?",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "DA8E1D85661A6244220BFC276A62845DD804"
                }
            },
            "57007385166CB148F32B34B4CE680FC356FD": {
                "t": "Y-Yes... thanks to you and Hellios.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "ABB10D3C78C3364F48084FA6076B6E926932"
                }
            },
            "55C1B0CE66E2C549EA1AC2206691537562BF": {
                "t": "It must be because you were so focused on the Vassalage. Speaking of which...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "FE06E97B3847954E137B34F9EE8FB275C47D"
                }
            },
            "F6EE08E6368D8344AF795890DF56D27FF08E": {
                "t": "We fell right on the pedestal. I hope this didn't compromise the ritual in any way.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "8F903DEF1232F346675A9D428FABD05320A8"
                }
            },
            "E9D0CF9655CEB5417F88D5A7DC948E0989ED": {
                "t": "No... No, it didn't. In fact, I think it's ready!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "C33FF32D68A6A14DB708FD53E174BACC2F1B"
                }
            },
            "E850D03C33F3294EB82B84564CB1DF2B68D1": {
                "t": "Understood. I'm ready.",
                "d": {
                    "eid": "162D69DA92A4C1441758F3A6EA25D59BC8B6"
                }
            },
            "56190C6E0AF10141145ACD12CC20BED0ABE8": {
                "t": "I need a moment...",
                "d": {
                    "eid": "F887938D4EA8A845758BF1E375A64FD00A5A"
                }
            },
            "F9B6F1846FC4B64642583274D846BD0AE521": {
                "t": "Very well, teh heh! You just need to stand there for a couple minutes.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "7EF034FE19DC77400B492F11E1F07DF20CA6"
                }
            },
            "528A71137C8F1645A34AC8A67342CC7CC441": {
                "t": "Is something wrong, Faratras? I don't know how long we can keep the monsters out of this area...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "969577D02C06D847AD58692882F8712E9A03"
                }
            },
            "5D904A174708124CB36A9CC412F79882E2D2": {
                "t": "He's right. I've come this far, and now I hesitate?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "59034B2E3FC14442918945E53EAACC7D63C8"
                }
            },
            "31F661F41F3E924D201B43902F2EE8E87F9A": {
                "t": "It's time for the Vassal to meet her destiny!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "855C1CA835FAC54C9E3A537759BC091E4319"
                }
            },
            "A1A9DAA9701EC0487C8B9201F3CB0BBB1AD3": {
                "t": "I need to stand... here, right?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1F028D7166BE7744FF8A80F3D9F27603D234"
                }
            },
            "643EBE2F70E5534B457BFDB528D448B7192D": {
                "t": "It's kind of... soothing. I feel newfound energy surging from within. So this is the power of the Vassalage...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E9DB37660355644A234AF386D294EBE8B3FF"
                }
            },
            "770954F05AC8D1445B7AA718D7420AEBAB61": {
                "t": "Serves you right, Demon King! This is our victory!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E7E749CE20DB6142D31AC309C4FB8A277D5D"
                }
            },
            "21E056E56792204C65096E372F9097E805BB": {
                "t": "Shiori, there's something that has been bothering me...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "5929A776160CC747062BAE485D04E35F9FED"
                }
            },
            "F9C9B4C17FDCB4400C6BE958704EFFEFBE43": {
                "t": "Let me guess. You're afraid that more monsters that are invisible to my sight may appear, right?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "61BE28631F2FC341346BA612899AB1BF353F"
                }
            },
            "CED51207540FF246899AB15140F0B581E5B3": {
                "t": "Yes. And not only that...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "4D3F70415477D6416F4B7391FF89C2D874B8"
                }
            },
            "AE051B9C3BBAF54A788A2454F52FEC56CCDC": {
                "t": "I feel the same. This is the most delicate moment, and Faratras must not be interrupted.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "42BB99144869B541258AECF75FA67E0E3CBC"
                }
            },
            "F60812DF1B06B04F5E4829A98A7930BA8700": {
                "t": "I'll take care of Commander Saai... somehow. You scout the area with the others for any possible nuisances.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "B297D4AE7D04374B767B30F1EFFD9F25D7B7"
                }
            },
            "EC7D23AC2205D645B37919E8710259A377A5": {
                "t": "We've got a plan. Be careful, Hellios.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "01BC26DA2B8120448E3A2286257C356400CB"
                }
            },
            "06238F1D7BF48248EC28F2146756D8B603D6": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "8A7F8DF035434845FB1AD628757D5182BBAE"
                }
            },
            "E9AA2E687CDCD346ED8AB752BE30E7121FAE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "DF8FFF5A18817248735BB951F7F49D82ADC9"
                }
            },
            "1B9BB454225C7049C1995EB4387FBB23FA63": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2FB5FE235927864DCF7B464638D6A32E1048"
                }
            },
            "CACA77D96F49C84CD84BFF5374DE037E2A07": {
                "t": "However, I couldn't sense that squink from earlier. How strange...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4AA73667115C934F557932125CFBB8D9C672"
                }
            },
            "5802F63D5D95934AF2491121A7C79DA2EC7B": {
                "t": "Now Faratras just needs to stand at the center of the pedestal.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "4B256F8325153643B9481B53B8BAFE2ABF7C"
                }
            },
            "99D4BBBA20D6A84F7B6A63B67A32D4F0F223": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "46EF32393226B045EA5884D586578DC1DF7B"
                }
            },
            "49F2EC42786DA54EFE69AAF19731106CD6C7": {
                "t": "The Commander. I don't trust him.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "6DBC50146DC6E544F76868F7FB20FEDC0AA8"
                }
            },
            "255FF3968EED924DD04BF917F0996DF79FFF": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C98066004F6689499669F38112996D6736B9"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "second option seen?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}