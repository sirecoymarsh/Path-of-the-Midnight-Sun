GS.dataCache['E63625077CDA8249D38BEEE8C9AB35560CB9'] = {
    "uid": "E63625077CDA8249D38BEEE8C9AB35560CB9",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C13-1b (Talk) Nini",
        "type": "vn.scene",
        "parentId": "2300F6BD2F7CD6418E4BA4F2F3DD3C866065",
        "chapterUid": "308CB00B9377A744EF192A255CFEC62F6D2E",
        "order": 4,
        "localizableStrings": {
            "29D649581FF9C14CFF5AE2B18CD09026510D": {
                "t": "Nini?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F15BFE9B64F91145101BDA24BE1A5307702B"
                }
            },
            "3DFF9A5736D117430C2848257015E317BAD4": {
                "t": "Niniiiiii!!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DB4F7205707497484049F21439262672467F"
                }
            },
            "A2F17E5865FC64467F5A00F3968493325C7E": {
                "t": "No response...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C7DDAF7B3547B745087A84E4656074A55BA1"
                }
            },
            "D678C5DE553C974B1B1A29E4562D47AC1F31": {
                "t": "Woot woot!!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "6F66EA2B8712034C009A1A8194C86EAEEBDC"
                }
            },
            "30FBFD6206E5F6462278E7B6EAC468F76354": {
                "t": "Woot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "120BACFB4A342648F10A38A5291A994AD319"
                }
            },
            "0155BB61080AA847435A6CA20A6BA237E175": {
                "t": "Oh! Hello Luckos!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CEBE81A5529007418978CC71A81F7D366D5E"
                }
            },
            "8373F7613E05354B883A47B0D27C25455461": {
                "t": "Woot woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "F718AEBB8B71944AA889A97911B7A1904F44"
                }
            },
            "9A4A9A5269E3F54AEF49C0D2944D0A7796E8": {
                "t": "Do you want a little cuddle?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DA20631C137F474C7638DA356AE26602E27E"
                }
            },
            "80D09AE02AC06044692A25D1DF55CD2B61F7": {
                "t": "WOOOT!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "8552DC59249E734E8338A6B63784301ADEE6"
                }
            },
            "44A38478166CA8456819B9D51FBDF4B2C4DA": {
                "t": "Hehe, snuggle snuggle time!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7588659E15E0C847CF6A7CF16B1B82505B10"
                }
            },
            "CD38BCF68A52A342C66B9314CBA84192C341": {
                "t": "What... are you two doing?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "88BDA3352BA8B5440D68CBF69B2402F3E44E"
                }
            },
            "81F127BC7682E544C92A9594F4C3274A3DE0": {
                "t": "Oh! There you are, Nini!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8569DFA85C25144F12585A5486E7A9A41026"
                }
            },
            "A4A97C9516D4614E5E9A55885E3A3E46073C": {
                "t": "Woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "BBD5D6EB60F6114B2C593238D80E0E4C9B79"
                }
            },
            "2A2EDD8A7AFA614C0479D994B1BDBD04AADF": {
                "t": "I had just fallen asleep for a moment. I had too many thoughts.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "5BC116153432A448DF2A8FA4FC152CB1E5F2"
                }
            },
            "C9B620A57A88C54E8B1BE3F44F4CA770CBF1": {
                "t": "Sorry for waking you up then, teh heh!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "6BEE79003A6BF24F3F2A061531732A7319B6"
                }
            },
            "179150811CCBB24C357BF591D7737CFBA980": {
                "t": "You look... different, somehow.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "61EA529409793744C73B3717F2C7F46FC302"
                }
            },
            "9CBF352B895A354CA87803468357634F1B5F": {
                "t": "Yep! I cleared my head. And I've decided that I will support everyone as best I can!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "649657EB7758664746087978732000A836D8"
                }
            },
            "A75F55A2352A93442A2A8E43EA9FA77752DA": {
                "t": "But... you yourself need--",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "EB4EE44F258BD34353592149049715357976"
                }
            },
            "99198ABB0E96874B956A374159CD58732EE3": {
                "t": "Never mind that! By helping you, I feel like I'm also helping myself. It's good for my self-confidence!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8C9E6C8B3CFCA24C7B587217863B59D25110"
                }
            },
            "9C00965946CF534D4C796977C8C183F8E5AC": {
                "t": "Hmm, a no-loss deal, I dare say.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "7444B3807F62B648778A9212BC09229977DD"
                }
            },
            "1DA7730F8A60A74CEB79422860A4627C07C8": {
                "t": "WOOOT!!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "1D0A13FD5362D549853AFDC907FD8486C531"
                }
            },
            "09102C1B42671343452B11838AAC9E5F6777": {
                "t": "Be quiet, over there! It's not that kind of 'deal'!",
                "d": {
                    "cid": 0,
                    "eid": "13B4088212B6B24219386FC8E6B616376D27"
                }
            },
            "9BB277CA4625954352496595CD5BB6DA416C": {
                "t": "Pffft... Hahaha!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D06E05631F146847974A3E384523673C84D1"
                }
            },
            "F968EBF4557F26474B7AB5B94FCE8F29C04D": {
                "t": "Gosh. Is my hair so messed up that you feel the need to laugh in my face?",
                "d": {
                    "cid": 0,
                    "eid": "A2D92FE180A7A74ED4594F72C8082B0E3C42"
                }
            },
            "F0C69F0F50A70749DF8B0F720F11BB54AC90": {
                "t": "What's so funny now?",
                "d": {
                    "cid": 0,
                    "eid": "1437B64459783144AB7BD028608A5C848F00"
                }
            },
            "3E262D7C045DE54506481C885F8BD0C2392E": {
                "t": "Oh, no. It's just that...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "1A251F7B3C336242EC783A085A730AA5A705"
                }
            },
            "75FE21332ECD834DB24901A275FAA6E38F59": {
                "t": "I missed laughing with you.",
                "d": {
                    "eid": "C0D20D5142785142873A4C99E98597AB7846"
                }
            },
            "4DC1F56A5F0A9342643B79537A9915E8AB08": {
                "t": "It reminds me of the old days.",
                "d": {
                    "eid": "EFB88A9072FB09456A2978C10780EB7B3E29"
                }
            },
            "FC023268255D854BF88923E378B506A3D03F": {
                "t": "Come on, don't say embarrassing stuff now...",
                "d": {
                    "cid": 0,
                    "eid": "E200605F44BE1346803AF807D2E631354600"
                }
            },
            "618FDB7881FAE24BA589D3E069BC5A905D64": {
                "t": "How cute...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4FAC8D8F177F1243CE7B6C9450FDA413295B"
                }
            },
            "26B837C77139584B25296E84F8F61C5A2AE0": {
                "t": "Shiori...",
                "d": {
                    "cid": 0,
                    "eid": "711DD1661022794DE54BB928AFBEBFF21080"
                }
            },
            "3B1768A445C4114BA9593759478C74CD241C": {
                "t": "You're full of doubts about your identity, aren't you?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "AE3EF93F8196B4467F2B4971A538FFA5A4B9"
                }
            },
            "A708992A81162744E599F67540A69C90A4AB": {
                "t": "I guess it's not hard to guess after what happened.",
                "d": {
                    "cid": 0,
                    "eid": "A170ADDF14609047561B5161C95AD0AEF42B"
                }
            },
            "3E2609617CA8C349A93973F7319CD8BFE060": {
                "t": "I used to be an Archdemon, and that side of me has been absorbed by the Manacrest. I have no past. No identity.",
                "d": {
                    "cid": 0,
                    "eid": "197B5D2B19C2984B6B1A2AB23359AA04447B"
                }
            },
            "50E8D41A8C0861418C48605511D098B54A14": {
                "t": "Don't think about it.",
                "d": {
                    "eid": "8C36D9D276AB0844FE281E55E56A6289059D"
                }
            },
            "4FC6DF3B444F874FEF5B9194D179BF71CC6B": {
                "t": "What!?",
                "d": {
                    "cid": 0,
                    "eid": "7406CA6764A05445A32ACF992E9FA01D2A29"
                }
            },
            "0B9C22A233B6E7449739C8234BC3065183AA": {
                "t": "Just. Don't. Think.",
                "d": {
                    "eid": "526A76349818A5459B38E9F14DF230275100"
                }
            },
            "7321CC7E2CCBD14605196AF277B1FE40F328": {
                "t": "That's the corniest advice I have ever heard!",
                "d": {
                    "cid": 0,
                    "eid": "0B8F1F967313E9414E190493A4E9C3034C2B"
                }
            },
            "889ABDAD605F92460A6BBB077F344BAA9690": {
                "t": "But it's true! Would it do any good to keep your mind occupied with thoughts you can do nothing about?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "BC0D52B9467CA645B369B0432A67D8752B7B"
                }
            },
            "B720EFC8825CF04E2068A311063513E0A824": {
                "t": "Huh...",
                "d": {
                    "cid": 0,
                    "eid": "CE764BF47CA1A6494C39B1A10587BEC52A5D"
                }
            },
            "9B83FDB46967944BE21898B8392653988417": {
                "t": "I've been tormented by self-deprecating thoughts for weeks now.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F724002980FFC544D5681EF85149146EE75F"
                }
            },
            "E727DD6E8AEF3944C2683961F1B2A6CC6496": {
                "t": "If there's one thing I've learnt, it is that a single action can sometimes be worth more than endless reasoning.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F7D781EE46CAC848F2496173A34A0A786559"
                }
            },
            "3B48CC218CFC874A1C18F156A11FA108B773": {
                "t": "So... laugh it up, Nini!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "4D9BE0C142CC444C375B5FC907D574C82AC5"
                }
            },
            "24BB42C25D8686431018447770A05334889D": {
                "t": "Are you... serious?",
                "d": {
                    "cid": 0,
                    "eid": "C955706B10D9D142EC2900117EC61BBEA5EF"
                }
            },
            "6334DB07378C3844D90BAC28B2ECE4AD9141": {
                "t": "Yes!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2C5E7D0861D2C34E432A29618ACC0735D80B"
                }
            },
            "8B2C7C1F3B0296407E1BE991E499A4873E6D": {
                "t": "We're literally one step away from the final battle against the Demon King.",
                "d": {
                    "cid": 0,
                    "eid": "6964B74B11D1A24ED77BA6854AC591EB6AB7"
                }
            },
            "A2E26A7773C7534B5C8B6591DCC786DEFB8D": {
                "t": "Is it even fair for us to be here, laughing lightheartedly?",
                "d": {
                    "cid": 0,
                    "eid": "E00678E296A4154B28880B648A68D49F9A2C"
                }
            },
            "D262117B2D2753462A0874A630B46320A57A": {
                "t": "It is! Best case scenario, we'll defeat Hellios with our laughter!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "98C9E1D3652E0645D11AD0C50385DF2A8B45"
                }
            },
            "F04ADA383588C94BE33AFB250922B6CD6437": {
                "t": "... Pfft! Hahahaha! What in the world, Shiori?",
                "d": {
                    "cid": 0,
                    "eid": "F7051B8884C52846097914F8B79DF3DE2919"
                }
            },
            "667E289D8459D94DAB5BD18123D48FCA1586": {
                "t": "You really are something else, you know?",
                "d": {
                    "cid": 0,
                    "eid": "ADCD4EE0549A0642BE587447FBB58518A43F"
                }
            },
            "DF89D4332E531242970BD5A437267DA44253": {
                "t": "I guess I am!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "54E1F5FE8EF612427A3B3832E913C136A03A"
                }
            },
            "5BA5FAC929B3A5417A28A1E38DA63A765FCA": {
                "t": "Though I suppose I'm not as weird as the amnesiac knight who goes around asking about my feet...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "AC76EF5394236442C85A16B36083A8A74DE4"
                }
            },
            "1E9E40701D73314BCD9B6BC6CCE05DF968DD": {
                "t": "Hahaha. Stop it, you silly priestess...",
                "d": {
                    "cid": 0,
                    "eid": "A3D3854A763B28459E3AD7C4D8BC1D7B488F"
                }
            },
            "8E145B204F14B844AE08EB487F68304467CE": {
                "t": "Not a chance!\nLuckos, help me a little here!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "43EE880713F4034C024AB556A5049656C5AC"
                }
            },
            "0A775A5F1DEA784BB1389C955F1D568ED678": {
                "t": "WOOT WOOT!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "012AFD6E743C03453B59B088D900342D092B"
                }
            },
            "0BFB120368AF0242A31BBC64BAD41C1FE7B7": {
                "t": "Wait-- Stop!",
                "d": {
                    "cid": 0,
                    "eid": "3E11B5604D8E82496E2A9AB4A49F0B84222D"
                }
            },
            "E3848F5E48957643D96990A9D90DAB17AB1A": {
                "t": "Don't lick me, it tickles--",
                "d": {
                    "cid": 0,
                    "eid": "50FCA20174D9C9439F3A3CB26ECDAF973831"
                }
            },
            "6AFC863A101748423779C9F32BE81B5838BD": {
                "t": "Wooooooot!!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "A163221C5828F1484B7982B4845E3711AC3A"
                }
            },
            "0C4E51023A9462408768AB41408E12A6CC01": {
                "t": "HAHA! STOP IT!!!",
                "d": {
                    "cid": 0,
                    "eid": "C315B3233FCD4645892A09A38575BC7A7387"
                }
            },
            "56BE78BD00811141073A28680816D51B8C1E": {
                "t": "Hehehe.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8646336D5A00D449834ABBD7D51C01F7211A"
                }
            },
            "68B58CFA2CC7564FDA1BBD28565FA0347132": {
                "t": "Geez. What's wrong with the two of you? Can't you let a man wallow in his sadness?",
                "d": {
                    "cid": 0,
                    "eid": "1C09A9390C17604B667A79B44C8096CF1247"
                }
            },
            "6CDC34669C0D2149FF8A15E8926C7FAFB52B": {
                "t": "Nope!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "352242EE6923E341C87A6AD7EC3CEE07DEF4"
                }
            },
            "1329DF895D468049254A94C512B7EA750F49": {
                "t": "... Heh. I think I owe you my thanks then, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "38DEF2797E030646392AD586D4F778AB28FA"
                }
            },
            "2B74AFAD5D79C244F50B04D6A5FA3B3C1DF0": {
                "t": "I... needed that sort of energy.",
                "d": {
                    "cid": 0,
                    "eid": "CBDBB83026787548126A68E61D51A54E9DAE"
                }
            },
            "1E56D7BB75243148F16BDA0535102DDF74A5": {
                "t": "When we were in Tarmen, you told me to believe in myself and rely on you if needed. Now, it's your turn to be assisted!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "FD81366A812AA74270797AF6727F565E48E4"
                }
            },
            "3EFAFA35703CC345DC39CB46D399DB37ADA7": {
                "t": "Hey, I'm always ready to lift your morale. I already did that at the beginning of our mission, remember?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7AF95798760BA6467B7AC9A11D783AD260DD"
                }
            },
            "D4129A5606946149ED6ACCA30041E3EFB758": {
                "t": "That's the very first memory of my 'new life'. I'm very fond of it.",
                "d": {
                    "cid": 0,
                    "eid": "F410999D11312949FA2A84E083292AA14DC3"
                }
            },
            "F1249BFB6115954719891A91886CCF1F313D": {
                "t": "And I'll keep gifting you with more memories.",
                "d": {
                    "eid": "75DFD9FB3BF77648E53972E0454D326C91CE"
                }
            },
            "8BDDA2502BA0374A2128E0000AC8BC0BA04D": {
                "t": "There are precious things too in life, see?",
                "d": {
                    "eid": "65FB1DCF8D54344C488B82A741F9C52E4938"
                }
            },
            "58241DA38584084CEC4975A41D610B262871": {
                "t": "You should feel very honored. Hehe.",
                "d": {
                    "eid": "29A904DA16DC61408A895B26062237B7B236"
                }
            },
            "0D290C684DD1354D3D695FB702AB232AF680": {
                "t": "I'm... looking forward to it, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "95C2B05B480BA84A9A2967E6DF2FAB494D83"
                }
            },
            "88C7F71A0035B742D0494E09F65291693936": {
                "t": "Me too, Nini. Me too...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "669DA64588D9B242DD48F914F466365E3703"
                }
            },
            "800836024D61F4465D197DE61A73D558E6CD": {
                "t": "... That's true.",
                "d": {
                    "cid": 0,
                    "eid": "2578D8EC208A294C22696589F48D781F849E"
                }
            },
            "DC6CE071192AE34840988521D0E70E64EAAE": {
                "t": "You've always been there for me, ever since I woke up in that forest.",
                "d": {
                    "cid": 0,
                    "eid": "2509C5634C26224AC33B81B71121CC3E3AF4"
                }
            },
            "E7D05E74485C174BBC48F293881B444640FD": {
                "t": "And I'll continue to be. Demon King or not.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "10F6F39B46FDC143054B99D6FF89ED67547D"
                }
            },
            "3ED4170943334142553B0135C50F77B158F9": {
                "t": "Haha! I have no doubts about it.\nSo...",
                "d": {
                    "cid": 0,
                    "eid": "219802AF4FE9734D38384708BCD44433EB53"
                }
            },
            "1A92E48447854941B84A74131DABBD1BC8CE": {
                "t": "Ready for some action? How about we go pay Elias a visit and show him a good time?",
                "d": {
                    "cid": 0,
                    "eid": "9DEADAE42B7E854A7E196BF253B2814C4576"
                }
            },
            "F59D468A2403C04C063A6F726CD577490691": {
                "t": "I'm right behind you!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A92702855585F24FD06950A2C3760FDD050E"
                }
            },
            "20D3BAD418204440F228DED7B9A0E3FEE023": {
                "t": "And it's true. I really miss... those old days...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1E14B69C79EEE14ABE39BFF43EAF9518995B"
                }
            },
            "C547FC631BAE864F2D59BFA89123D2865567": {
                "t": "Although I also lifted you in the... literal sense.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "20C4E6697669A64BC36A9A862C9E49CFD8F9"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "nini still very hurt\ntalk about hiding\n\nthrowback to their support in 11A"
                },
                "indent": 0,
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "3DF559C491FA314E1E3BBD32DE27C7192DDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            4998,
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4065E2E3277B884D2E884B35240FE8928355"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "45EDC1384E871148329BF386BE751616634C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E4D9B98304549402E9A5D952E6468C955FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B4EE92021DEC994BDD984B0151DDB57C6A5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29D649581FF9C14CFF5AE2B18CD09026510D",
                        "defaultText": "니니?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F15BFE9B64F91145101BDA24BE1A5307702B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4836DD5D6EE73641F2281D0313CF845F74FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "685B67D17F3D0049B88AF3F534DE4B7E5A43"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "987A18D080982545410A9F0115E5B463C87E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27B4CCAE5232114A6829F8D31D09E8430C95"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4D3ABF37593A34D213B4C64B3E899143D85"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DFF9A5736D117430C2848257015E317BAD4",
                        "defaultText": "니니이이이!!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DB4F7205707497484049F21439262672467F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B257B0A849F6C74E943BBFB76681C29D72F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7598AD334983E34C292A06F431EA293D3B57"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "2CA62D921C027742B33BC3E72D5F741F1D56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F123E1D673E974D3149330147456B5D5CC1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3FB154073D1A44EB56A4EC482E758E739FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A2F17E5865FC64467F5A00F3968493325C7E",
                        "defaultText": "대답이 없네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C7DDAF7B3547B745087A84E4656074A55BA1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEF318A55A8AE44F608BFC64E89AEC89B30C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B796535D012460412389ED661A1157D0C219"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D678C5DE553C974B1B1A29E4562D47AC1F31",
                        "defaultText": "우우웃!!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F66EA2B8712034C009A1A8194C86EAEEBDC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AC7472C4032844BD849B503AAF929382835"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65611D8B4CC8964BC928B720AD0741C9456E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "3EB758C77B9FF2490B9A2A68AD9D647008A4"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B06AB3888468234FB63AB9A1D44B08D76A79"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "88A5EFDE2F37314DB34B62F1B7B6B226885C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C73A47513A53274F7A7877812C4845BA3710"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D94CB3862CAB37423F4A8065E7CDDFE30F1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAF3B9675437D94974384604DE71E58E4677"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "30FBFD6206E5F6462278E7B6EAC468F76354",
                        "defaultText": "우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "120BACFB4A342648F10A38A5291A994AD319",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F87EBCB960C2484D4669CA89E4F1CD8806D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8C493C171EA292401A2BEE828072062B09EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0155BB61080AA847435A6CA20A6BA237E175",
                        "defaultText": "아! 안녕, 루코스!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CEBE81A5529007418978CC71A81F7D366D5E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B98D91A3206134C371A3C666D3CE5CDD8F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB6AB179213BD942A648F8F99738580078B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8373F7613E05354B883A47B0D27C25455461",
                        "defaultText": "우웃 우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F718AEBB8B71944AA889A97911B7A1904F44",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FCA718749500341D4282E53BA92F7B5EEBD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8418B2BC92ECB544BC8929A19929DA50EFF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A4A9A5269E3F54AEF49C0D2944D0A7796E8",
                        "defaultText": "조금 안아 줄까?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA20631C137F474C7638DA356AE26602E27E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E87CAEB52FFD0547401A8FE6FF81B1E55619"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "0283FE4D565DE5454A792933878EA14C2D94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4EF0FCC2D372347CA598185CA4AADCBC456"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80D09AE02AC06044692A25D1DF55CD2B61F7",
                        "defaultText": "우우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8552DC59249E734E8338A6B63784301ADEE6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC254DD82975414C0D7BC054B34B9831278A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F7F3015250BA9463908B48824698ED7C397"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44A38478166CA8456819B9D51FBDF4B2C4DA",
                        "defaultText": "헤헤, 꼭 끌어안는 시간이야!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7588659E15E0C847CF6A7CF16B1B82505B10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA727CAF2A9393484B1B85463AB8DA006A9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "8AEB5E996315B446E67963035B742FDAD385"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6CC203EC10C3944BB9686B531DB617B6EE04"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD38BCF68A52A342C66B9314CBA84192C341",
                        "defaultText": "너희 둘... 뭐 하는 거야?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "88BDA3352BA8B5440D68CBF69B2402F3E44E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A809DAB917990443E31A0A14EBCA3294B630"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "4FD922538413F442A87868D97278C8FD3C34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3BDEFD4197F1446CF9A4F216E092B5832D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "81F127BC7682E544C92A9594F4C3274A3DE0",
                        "defaultText": "아! 거기 있었구나, 니니!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8569DFA85C25144F12585A5486E7A9A41026",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C20CAEE2B00F344426894725608599FA8E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "783A75B44C49D744A5881C86417177BB246F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A4A97C9516D4614E5E9A55885E3A3E46073C",
                        "defaultText": "우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BBD5D6EB60F6114B2C593238D80E0E4C9B79",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E8CFD914FA5C242B83AB39540BCE1508074"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD0B5C633128E343CF6BC08462D293CAFA54"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "40DAD4126E86E645CE2B9F15952096A064A5"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "model": {
                        "name": "Luckos.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 706,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1300,
                        "y": 685,
                        "zoom": {
                            "x": 0.27,
                            "y": 0.27,
                            "d": 0.27
                        },
                        "position": {
                            "zoom": {}
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 30,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1F712ECA1089E344072AE085B09A6AB843A8",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -60,
                        "green": -60,
                        "blue": -40,
                        "grey": 30
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7751CB4D937EC8476C49A5B7798C520CC8C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83B7325E3CFB124AEB2B39E3C4CC3A9A833A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "1AC066E3518C494BC23933D30FBC0986E1FE"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BB8B4FD77A20C14665089230C7563EAEB72C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "66FAE6A88ADF16440088A1467FCD3E4FD152"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen\nnini appears"
                },
                "indent": 0,
                "uid": "289E66603425494C589B2686506F07BC8014",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C53BCF97583E764EA86B03557AE7F18F0AB7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A20CBCA8AD0234E6E5A66862AD7C3CB0658"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A2EDD8A7AFA614C0479D994B1BDBD04AADF",
                        "defaultText": "잠깐 잠들었어. 생각이 너무 많아서."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5BC116153432A448DF2A8FA4FC152CB1E5F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75E136F1106F044C78884F24C48B1B1CE2FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C31360B513D8841422A9007097D9A7B87F2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9B620A57A88C54E8B1BE3F44F4CA770CBF1",
                        "defaultText": "그럼 깨워서 미안해, 헤헤!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6BEE79003A6BF24F3F2A061531732A7319B6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76D980A751304747BC7B473165C1EE9DE18A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E8DD59C15BEE040C5389214EFFDEF1BACCF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1A6FC984AC8924C0D0B070203ED417D6440"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "179150811CCBB24C357BF591D7737CFBA980",
                        "defaultText": "어쩐지... 달라 보이는데."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "61EA529409793744C73B3717F2C7F46FC302",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4CD0D580F0FC948ED3B72F21D0EE2498312"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4D0F25F5E62B34D165B569673B3CC852A43"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9CBF352B895A354CA87803468357634F1B5F",
                        "defaultText": "응! 머릿속을 정리했어. 그리고 최선을 다해 모두를 돕기로 했어!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "649657EB7758664746087978732000A836D8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B5D273C75B9D148E90A4879EB6787E6D4CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E0A3D141C34584BBA58D46180C8432F33D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A71698133C7FF34CE278DAC143B7DFA9E2BA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A75F55A2352A93442A2A8E43EA9FA77752DA",
                        "defaultText": "하지만... 너 자신도 도움이--"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EB4EE44F258BD34353592149049715357976",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D0DBA8456F75346055B0F6683F909850C78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39B752F48B99E54E5C89CE273EC6FD219764"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99198ABB0E96874B956A374159CD58732EE3",
                        "defaultText": "그건 신경 쓰지 마! 널 도우면 나 자신도 돕는 기분이 들어.\n자신감을 되찾는 데도 좋고!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8C9E6C8B3CFCA24C7B587217863B59D25110",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B41BAB930357E342F258A420490481D12236"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8F0F26F4E7EA4413B592FE5B37DBD814498"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5C06272267BD240D89AC041289C6165ABF4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C00965946CF534D4C796977C8C183F8E5AC",
                        "defaultText": "흠, 누구도 손해 보지 않는 거래로군."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7444B3807F62B648778A9212BC09229977DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5EDEC6487F1C3641253BE3824D32D85AC07B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9228A6584604764288596512807B0004E0F3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1DA7730F8A60A74CEB79422860A4627C07C8",
                        "defaultText": "우우웃!!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1D0A13FD5362D549853AFDC907FD8486C531",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4802DFD35E8F64412E49F3093AF293809095"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F4824791B55C34C8A4887D2AB17ABAAADC8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "780F9847474E284162994CF2C6CF09F026A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E29FC5AB9577214B5B483A326C7195708F60"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "09102C1B42671343452B11838AAC9E5F6777",
                        "defaultText": "거기, 조용히 해! 그런 의미의 ‘거래’가 아니야!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13B4088212B6B24219386FC8E6B616376D27",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B85D54C35AEF242E18A7B78507E2D3AA889"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92AB930E999C7744EC187461A7816C550BDB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9BB277CA4625954352496595CD5BB6DA416C",
                        "defaultText": "푸흡... 하하하!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D06E05631F146847974A3E384523673C84D1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BFB1AD657F3E54DD15BD972C1D91062EE00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDBFAD334E1549422C4B60370CE4AE35AC1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F950E5F76F69E84F892B9DD8DEA289B2CE6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64F44BDC28464444EB8BCBD563E959D2B42E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if sarcasm is high"
                },
                "indent": 0,
                "uid": "4EF88D3085DE14407E4874D5C6CB5FEF9703",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FFF2E7348FE4E546106BEA42177BA6BADA38"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 65,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2046C3AF655FC544E27BBDC25410527B405B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F968EBF4557F26474B7AB5B94FCE8F29C04D",
                        "defaultText": "이런. 내 머리가 얼굴을 보고 웃어야 할 만큼 엉망이야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A2D92FE180A7A74ED4594F72C8082B0E3C42",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "D43916EA40831746F93B6932D6A836C96CCA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F0C69F0F50A70749DF8B0F720F11BB54AC90",
                        "defaultText": "이번에는 뭐가 그렇게 웃긴데?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "1437B64459783144AB7BD028608A5C848F00",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "492849466EE1D74F7B88BB53EDD889515367"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87EA2AE13F43C74476498A08569B30811B75"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E262D7C045DE54506481C885F8BD0C2392E",
                        "defaultText": "아, 아니. 그냥..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A251F7B3C336242EC783A085A730AA5A705",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "B296B7790B38F74D717BED918297E2C2B997"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "75FE21332ECD834DB24901A275FAA6E38F59",
                        "defaultText": "너랑 함께 웃던 게 그리웠어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C0D20D5142785142873A4C99E98597AB7846",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4DC1F56A5F0A9342643B79537A9915E8AB08",
                        "defaultText": "옛날 생각이 나서."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EFB88A9072FB09456A2978C10780EB7B3E29",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "flirt",
                            "normal",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "2745CEE2926D184F3D8AD688D04950E7C251"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BCF369642E166340C868C8A1C4C5649C264D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "flirt"
                },
                "indent": 0,
                "uid": "6E60B3C713916345B68B25F1CECB09024512"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++aff"
                },
                "indent": 0,
                "uid": "C626E8753E9B724B7169A8510A2C7969B074",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26D6BB5E2DDC124E0B886F45AA1615241117"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3152C35A80FB6946776877932C8EF8D52605"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B3052142EF8A647747916263A6885F925DE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FEDA32F86FE454AB42A9251D14F2CC075ED"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FC023268255D854BF88923E378B506A3D03F",
                        "defaultText": "자, 이제 부끄러운 말은 하지 마..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E200605F44BE1346803AF807D2E631354600",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E62F1ED21BF1242044B37A582D0B2183D8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8FCA31A90C541473C7A53C58034492991AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "618FDB7881FAE24BA589D3E069BC5A905D64",
                        "defaultText": "귀여워..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4FAC8D8F177F1243CE7B6C9450FDA413295B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF05CDB57540414DE30BCCA3556843C9642A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20D3BAD418204440F228DED7B9A0E3FEE023",
                        "defaultText": "그리고 사실이야. 그 옛날이... 정말 그리워..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1E14B69C79EEE14ABE39BFF43EAF9518995B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8EB74A184BF92040B318BA324C2EC3C33A7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE1744184CAD164CFD58E395CB02180D3073"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B19904943733734D5A5B8DE82C9278E84BF4"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "48EF7EA28B74674ED25A2326E39CA876A043"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "normal"
                },
                "indent": 0,
                "uid": "7C07AB00472D724FC2191B5492F16BF62776"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD79A6B07B7869421F1B2C66CCF6A5845CBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D79AC93B2E400947FE497A79856E60F36E20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "26B837C77139584B25296E84F8F61C5A2AE0",
                        "defaultText": "시오리..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "711DD1661022794DE54BB928AFBEBFF21080",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0493036012229246B86B4DB66A62360A02C1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice"
                },
                "indent": 0,
                "uid": "A52B162B64C7C44BA609D2E2D5C4F272E9B5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB98B66D6AB13143F60B062658C3B9A511E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B1768A445C4114BA9593759478C74CD241C",
                        "defaultText": "넌 네 정체성을 두고 의심으로 가득한 거지?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AE3EF93F8196B4467F2B4971A538FFA5A4B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE35D8878AB3D341F45B03234F2B57F84AF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8C7E03219755842A0292A13603BD80DAF77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30A809BB1D75C144118ABEE61F9FAEF7C859"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB35F7262BAE74489549AB329E5E0A8FC04E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A708992A81162744E599F67540A69C90A4AB",
                        "defaultText": "그 일을 겪었으니 알아맞히기 어렵지도 않겠지."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A170ADDF14609047561B5161C95AD0AEF42B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2028DCF06BE8C34EB62B0896609EC6E59FCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D38095B9351057412C0B1AE2BFADDFCB996E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3E2609617CA8C349A93973F7319CD8BFE060",
                        "defaultText": "난 대악마였고, 그 면은 마나크레스트에 흡수됐어. 내겐 과거도, 정체성도 없어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "197B5D2B19C2984B6B1A2AB23359AA04447B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "E25E89A18B85E34ECE6AD7B1ABF95CE62E19"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "50E8D41A8C0861418C48605511D098B54A14",
                        "defaultText": "그런 생각은 하지 마."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8C36D9D276AB0844FE281E55E56A6289059D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEE92E7444CB204C0F7A76A50F01F2D341F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8DE170879FF1944327995F9229EDDAF6FC37"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only"
                },
                "indent": 0,
                "uid": "D47151CC1DFF7649097927E5041483748461"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A92EC896604D24FBA1A8582F907D2BFA354"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B382E2E58DB134E3E29F5E3783F042DB583"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "495948234C3EC548F48B5221CCED48DAD73D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4FC6DF3B444F874FEF5B9194D179BF71CC6B",
                        "defaultText": "뭐라고!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7406CA6764A05445A32ACF992E9FA01D2A29",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8768D27F2341E6419C580804A3E3997E7733"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0B9C22A233B6E7449739C8234BC3065183AA",
                        "defaultText": "그냥. 생각하지. 마."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "526A76349818A5459B38E9F14DF230275100",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only2",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFA0727D592EF848CA5B2C189D01D15BA954"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DA3F43BC73CF0649718AF6716EDCF5E206E9"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only2"
                },
                "indent": 0,
                "uid": "90CE230F8BE3F54B8B398193CBC53A9E79A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D60F5209019B84C0A58E632BEED632E26D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70CE82036DA9494EC01A5C5308318F00C5B6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7321CC7E2CCBD14605196AF277B1FE40F328",
                        "defaultText": "내가 들어 본 조언 중 가장 진부해!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0B8F1F967313E9414E190493A4E9C3034C2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA4C78EB5DAB39455D4A6BA58DC5C3A8ACF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A95F026703481247BB7932674B95002D8AAE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "889ABDAD605F92460A6BBB077F344BAA9690",
                        "defaultText": "하지만 사실이야! 어떻게 할 수도 없는 생각으로\n머리를 가득 채워서 좋을 게 있겠어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC0D52B9467CA645B369B0432A67D8752B7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DFC5BD75824A34D021901A8DADD0921835B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A167C2FC12C90340272B7B888FE0E5F5CF35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6344C9457C1ED046A87B01A175F536D08946"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B720EFC8825CF04E2068A311063513E0A824",
                        "defaultText": "허..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CE764BF47CA1A6494C39B1A10587BEC52A5D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "165E20924DCC6944013BCB172C6DF10BF194"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A4545931C6A8146B90A66C590799B639B0D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B83FDB46967944BE21898B8392653988417",
                        "defaultText": "나도 몇 주 동안 자책하는 생각에 시달렸어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F724002980FFC544D5681EF85149146EE75F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83CB5B565E7B384BE29A15170C64F71A49FD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E727DD6E8AEF3944C2683961F1B2A6CC6496",
                        "defaultText": "그동안 깨달은 게 하나 있다면, 때로는 한 번의 행동이\n끝없는 고민보다 더 가치 있다는 거야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7D781EE46CAC848F2496173A34A0A786559",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "882157B26709A1434578EB829ED0A4755B47"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B48CC218CFC874A1C18F156A11FA108B773",
                        "defaultText": "그러니까... 마음껏 웃어, 니니!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4D9BE0C142CC444C375B5FC907D574C82AC5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D27C9D701DD064B4E180186E5B970DAAECF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42381AB353C5494B71090F43408AA5E8E2A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D14ED3C2F790545C60BA2D7C74790818549"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24BB42C25D8686431018447770A05334889D",
                        "defaultText": "너... 진심이야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C955706B10D9D142EC2900117EC61BBEA5EF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00EF09F863FB2448C35BBFB474C625DD7C97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F88CE6A5514841401858D50753FBC4025681"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6334DB07378C3844D90BAC28B2ECE4AD9141",
                        "defaultText": "응!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C5E7D0861D2C34E432A29618ACC0735D80B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A00C12A88A205349A26ACB030C5CB4CD4A24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A71E6E03721564C511BFB16096E11C9FBB7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B2C7C1F3B0296407E1BE991E499A4873E6D",
                        "defaultText": "우리는 말 그대로 마왕과의 최종 결전을 한 걸음 앞에 두고 있어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6964B74B11D1A24ED77BA6854AC591EB6AB7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D567818A3B9FB54E4F88C97961236F9971DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A2E26A7773C7534B5C8B6591DCC786DEFB8D",
                        "defaultText": "우리가 여기서 아무 걱정 없이 웃고 있어도 되는 걸까?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E00678E296A4154B28880B648A68D49F9A2C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B87E08D04277A044856988658779CBC3B019"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D710451A1E11D74A47791FC55055344AF308"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D262117B2D2753462A0874A630B46320A57A",
                        "defaultText": "그럼! 잘만 되면 웃음으로 헬리오스를 쓰러뜨릴 수도 있잖아!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "98C9E1D3652E0645D11AD0C50385DF2A8B45",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44D9101B7447554FEE9BE48574CAC4082346"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "566095C25A41514153798F56843DE063D39E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            6,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B677A8D938268433A1BB84871AAA6BFF543"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8E257EF66B4434D5F699544A7DC5DD016AD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F04ADA383588C94BE33AFB250922B6CD6437",
                        "defaultText": "...푸흡! 하하하! 대체 뭐야, 시오리?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F7051B8884C52846097914F8B79DF3DE2919",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAE122A482FD9849184A49A859EE423F5C57"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "667E289D8459D94DAB5BD18123D48FCA1586",
                        "defaultText": "넌 정말 독특한 사람인 거 알아?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ADCD4EE0549A0642BE587447FBB58518A43F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69783C9F4CDA7743B65A60C0CD7ACFD9A92B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "496FC593563621498079AD88E21E368E8385"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF89D4332E531242970BD5A437267DA44253",
                        "defaultText": "그런가 봐!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "54E1F5FE8EF612427A3B3832E913C136A03A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9E393AF21DE1549F589F261317520FD3310"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5BA5FAC929B3A5417A28A1E38DA63A765FCA",
                        "defaultText": "그래도 내 발에 관해 묻고 다니는 기억상실 기사보다는 덜 이상한 것 같은데..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC76EF5394236442C85A16B36083A8A74DE4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E5F295861FD974C044A66F3728FBEF273D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B5FF4886095124ED58902C64E15C5AD1722"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E9E40701D73314BCD9B6BC6CCE05DF968DD",
                        "defaultText": "하하하. 그만해, 이 엉뚱한 사제야..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A3D3854A763B28459E3AD7C4D8BC1D7B488F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34E37EE14068A743435AD2F6BB344881C9D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7846636437D164D203841D1A7F41B26DFD9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E145B204F14B844AE08EB487F68304467CE",
                        "defaultText": "싫어!\n루코스, 여기서 나 좀 도와줘!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43EE880713F4034C024AB556A5049656C5AC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A6168AC38C8974E1048CB224BDAD69E06A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "767AED6E779A8546B75A5F88E28B6A282B09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64732E198C3B064660881F48B55923AE5628"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A775A5F1DEA784BB1389C955F1D568ED678",
                        "defaultText": "우웃 우웃!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "012AFD6E743C03453B59B088D900342D092B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "737E15BB5A3E364C631978187B1315EA5F7A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "31F432EF1F342242F22AD77134ABE4B1F3AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5C694A564879143249A4BC59B93A7CF1164"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "C2D7593B425A704FCE393706E4BC4FF37DD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70A7B4D159B1424E490AE422ADCF0CD3EC00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF580ECC23557547630B9F46E7B390D5C318"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0BFB120368AF0242A31BBC64BAD41C1FE7B7",
                        "defaultText": "잠깐-- 그만!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3E11B5604D8E82496E2A9AB4A49F0B84222D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A1B90982773684BC789E75462B0241FA9E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64395C361FA60342C819FE107251FA97CD64"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "9976D03E6178F741838B4858F3070E56B083"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 30,
                    "waitForCompletion": 0,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "AB0BD83C710E744A303AB37179D99394E5A0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "F9F6011861059942B9899715D36DA03EC984"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "BE76684C2D21384CC638F276F94D45D50729"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "6D57E4B88ECE144C002911B55B7026902863"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Others",
                        "name": "Luckos Hit Ornieres.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "41AE5A7584FE37451918A5924A89E304C4E1"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "DAE8C6055A3FA841B55A14D4E440779FCF4E"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 13.2,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 25,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "9246C93B97BCC14767981F26DA5C9DA598F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "2EF7FADB84778340953BBCA84513CF11BD61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "92085E856E4E3445ED292A03C521425D566D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A79B502A2668644A227BD211409602ABE235"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E3848F5E48957643D96990A9D90DAB17AB1A",
                        "defaultText": "핥지 마, 간지럽잖아--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "50FCA20174D9C9439F3A3CB26ECDAF973831",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A9416372DE5F345930A5CD5DA56BE8C909A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CFEE680F5701A94B567B6BD72CC25FF7853B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6AFC863A101748423779C9F32BE81B5838BD",
                        "defaultText": "우우우우웃!!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A163221C5828F1484B7982B4845E3711AC3A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0B242CF9D6B1744037BB771697173FA3A4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDCF9088803BF14C502A3DB5BC0970702961"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C4E51023A9462408768AB41408E12A6CC01",
                        "defaultText": "하하! 그만하라고!!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C315B3233FCD4645892A09A38575BC7A7387",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "925AD7757780C844595A8058FF98CC71F427"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D5E1B99760F53463E2A00F1AF37A1F88C59"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56BE78BD00811141073A28680816D51B8C1E",
                        "defaultText": "헤헤헤."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8646336D5A00D449834ABBD7D51C01F7211A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9518433860AE7544D7787CB5062CD6A1E210"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57AD47CD36B3B146F94993E12D1816A9EC6A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "5C32D6DB4DFCF14FCE7A4C5783E751071281"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            6000,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7496EED253AFF24B0F2A47D8AA0FF54B51FA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "92C5A5A282F031462A6812A65CA8852D9D40"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2B77CAE2A9A144D7A4807F2CF7422EC451F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "B81242363AA18849F91B0EF71A575C276F00"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "E285D02860046848C81AFC5710774C082899"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6311EE22652DD8406D78BEF0CFEA45B1AA25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95F3ECF9768BD24CD93AAC06337595782AE6"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "model": {
                        "name": "Luckos.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 706,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 1300,
                        "y": 685,
                        "zoom": {
                            "x": 0.27,
                            "y": 0.27,
                            "d": 0.27
                        },
                        "position": {
                            "zoom": {}
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "51756B421071284D604A74454F31D0FCC239",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -60,
                        "green": -60,
                        "blue": -40,
                        "grey": 30
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D5E475D13BA18476C5B4C12BFCB0CF50F21"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDB80E7A541BD54C5079D3A5C164F71760CF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6000,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "670D33397D17A048F39B578225F03325719A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "334299840DAB6840AA78D281AA28408041A2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A7E72B7C8F8A05468A39F9790639A67AA2E0"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "black screen, 5 minutes pass"
                },
                "indent": 0,
                "uid": "7E93638A7013124FBF687B94280DDC85853B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5D7D4CA61EC524EBD5BEF75208844429817"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68B58CFA2CC7564FDA1BBD28565FA0347132",
                        "defaultText": "이런. 둘 다 왜 그래? 남자가 슬픔에 잠겨 있게 내버려 둘 수는 없어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1C09A9390C17604B667A79B44C8096CF1247",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "889D4F9117DB05482E0B47F74E2503BD9F8A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB0BD48D733273464E2B65872AD8DD2450F8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6CDC34669C0D2149FF8A15E8926C7FAFB52B",
                        "defaultText": "안 돼!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "352242EE6923E341C87A6AD7EC3CEE07DEF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45CF78C164DB334A4C5B21E6C8D43328C381"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Shiori x Nini moment in 11A",
                        "index": 197,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4A9E94EF872867494E4BF6453DFEBB8BF66D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E56D7BB75243148F16BDA0535102DDF74A5",
                        "defaultText": "타르멘에 있을 때 넌 나 자신을 믿고 필요하면 네게 의지하라고 했지.\n이제 도움받을 차례는 너야!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FD81366A812AA74270797AF6727F565E48E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B29941605B0BE54DB47B87D88348AE9D542B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E39E6A566136445961A8AD541A74B251094"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5478E4F2236AE248253AC1760C014E54EC03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D91DB6D32AB186402D9B8317AA02EA18A35A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1329DF895D468049254A94C512B7EA750F49",
                        "defaultText": "...후. 그럼 네게 고맙다고 해야겠군, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "38DEF2797E030646392AD586D4F778AB28FA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "432BCCE51986A74486799DD0CDEF8ACF16AC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B74AFAD5D79C244F50B04D6A5FA3B3C1DF0",
                        "defaultText": "난... 그런 활력이 필요했어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CBDBB83026787548126A68E61D51A54E9DAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9AD678BD5FDCB24DEB0BAD600B6B5E75352F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86E420A20D6F444EA93BEFB20D942C7339AB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3EFAFA35703CC345DC39CB46D399DB37ADA7",
                        "defaultText": "이봐, 난 언제든 네 사기를 북돋울 준비가 돼 있어.\n임무 초반에도 그랬던 거 기억하지?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7AF95798760BA6467B7AC9A11D783AD260DD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6AAC7412DDEF248EE79E4277CE02EE1B299"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C547FC631BAE864F2D59BFA89123D2865567",
                        "defaultText": "그때는 널... 말 그대로 들어 올리기도 했지만."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "20C4E6697669A64BC36A9A862C9E49CFD8F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7134917D5302D641FC1B2313925818CA96A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "15707499666B66432D0AA6E83B8198D10C60"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D4129A5606946149ED6ACCA30041E3EFB758",
                        "defaultText": "그게 내 ‘새 삶’의 첫 번째 기억이야. 아주 소중하게 생각해."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F410999D11312949FA2A84E083292AA14DC3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D3893BB07EF27472188C957A85CC8FE9719"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F1249BFB6115954719891A91886CCF1F313D",
                        "defaultText": "앞으로도 추억을 잔뜩 만들어 줄게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "75DFD9FB3BF77648E53972E0454D326C91CE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8BDDA2502BA0374A2128E0000AC8BC0BA04D",
                        "defaultText": "인생엔 소중한 것도 많잖아."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "65FB1DCF8D54344C488B82A741F9C52E4938",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "58241DA38584084CEC4975A41D610B262871",
                        "defaultText": "영광인 줄 알아. 헤헤."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "29A904DA16DC61408A895B26062237B7B236",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "gift",
                            "precious",
                            "honored",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "5ED25E5F8096414EE08835A712E22F0A12A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "85E7FAD243F83940B64B373882BDD94AE467"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "gift"
                },
                "indent": 0,
                "uid": "3758FE2528162549908A86B3FAF43B62207F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "++aff"
                },
                "indent": 0,
                "uid": "B175FF273730344AAF5AA4E0770B50700B0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "51383D03841E064B387BF4C740648A90A619"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "181D20568551774A0B6988A9E971BEBB2CA5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AE1BB557CBF77420D0992E8CE143C4F3C87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D290C684DD1354D3D695FB702AB232AF680",
                        "defaultText": "나도... 기대하고 있을게, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "95C2B05B480BA84A9A2967E6DF2FAB494D83",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB482B2C82AF4449966844929F3817E4E4A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5792322211169481819E9276D55E191F0BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "88C7F71A0035B742D0494E09F65291693936",
                        "defaultText": "나도야, 니니. 나도..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "669DA64588D9B242DD48F914F466365E3703",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9558BAB5926558426D79DEE94CF66934DEAF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "final choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "C5AB7B037ACC904DF66BEE632374ADB0BFE7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "precious"
                },
                "indent": 0,
                "uid": "7F2177B57D25764B7428D9D4ADDF4EFE3C8A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "F01BBC2226B4B849E069CE75A38E01335E2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            3,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB7F41F832E2C949141B9B38A0307F28241B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "honored"
                },
                "indent": 0,
                "uid": "3873AD00218D7446EE19C46846A7B265844E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7A15D898ECF844DE11A52D170FA521CDF32"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "800836024D61F4465D197DE61A73D558E6CD",
                        "defaultText": "...그건 그래."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2578D8EC208A294C22696589F48D781F849E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF378A9972687649E5091A7699B43550A94B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "final choice"
                },
                "indent": 0,
                "uid": "5E8783D85285194C9D0BCAB34A5A447728E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87157D4C8ECA6442C3487A79024C2251C01E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC6CE071192AE34840988521D0E70E64EAAE",
                        "defaultText": "그 숲에서 깨어난 뒤로 넌 언제나 내 곁에 있었어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2509C5634C26224AC33B81B71121CC3E3AF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E60F09C80755E14E03795EA523A19B8E4EEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "60C9759A43F6A14F6C5815B87C76C6D9E7F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E7D05E74485C174BBC48F293881B444640FD",
                        "defaultText": "앞으로도 그럴 거야. 마왕이 있든 없든."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "10F6F39B46FDC143054B99D6FF89ED67547D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF9132E5238641423B2A854022CA007871F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "39245DFE1B7CE245904917A15C2693B5317F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3ED4170943334142553B0135C50F77B158F9",
                        "defaultText": "하하! 의심하지 않아.\n그러니까..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "219802AF4FE9734D38384708BCD44433EB53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0CCB0A918EFA5345335B50E0C3F8133C3EC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1A92E48447854941B84A74131DABBD1BC8CE",
                        "defaultText": "한바탕할 준비는 됐어? 엘리아스를 찾아가서 제대로 즐겁게 해 주는 건 어때?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9DEADAE42B7E854A7E196BF253B2814C4576",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D7D41E1768AEC046A36AC379B942694B9855"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C2E1B1632BE544E7C2BAF77BFD73C6F2335"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F59D468A2403C04C063A6F726CD577490691",
                        "defaultText": "바로 뒤따라갈게!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A92702855585F24FD06950A2C3760FDD050E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E1E50791386F54BDB780110BF42750B8923"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "02860C6462FFB14F4E495BA1A600E02A853E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E7F27E8F98C09243026974A650C6C4D6B8A6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "3B6E0343178AC5405168E9A49E35DEE23A0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            6,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "011FD0DB24725346E1495F690A707FDFFE2E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 21
                },
                "indent": 0,
                "uid": "B0E2714C8F6B584F6E6813B45AC26B002599"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            5,
                            "",
                            "",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "22FAB8906E3D754135191F66BDCD432487D9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "C134376D66ACA340994831C410D53008A754"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E5F2B5DF41BE2543470A96877ECC95D8B2C1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B7B32DB55F955644D52B07A54F38F09A4095"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "8EF9D6C012F50046219A87D17484417CFA47"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "93595738800D96423D2AFCF979F2A6CED79C"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Shiori x Nini moment in Ch13",
                        "index": 310,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8552ED372966B841084B3AB78BE62ACE0FFB"
            }
        ],
        "livePreviewDisabled": false,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}