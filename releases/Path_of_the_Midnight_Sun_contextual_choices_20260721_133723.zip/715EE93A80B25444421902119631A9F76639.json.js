GS.dataCache['715EE93A80B25444421902119631A9F76639'] = {
    "uid": "715EE93A80B25444421902119631A9F76639",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "P2 - Young lady",
        "type": "vn.scene",
        "parentId": "C3DAB79205216541EE9B77345B84FDB1B58D",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 1,
        "localizableStrings": {
            "6572DD8C34EF0945E278D91685D3F0FDF2FD": {
                "t": "...{W:100} Sigh.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "2162BDC4151477405C3B8533F8950FBB5B10"
                }
            },
            "92A9EBE6427D344E1D49AD16C3AE3F65B474": {
                "t": "Excuse me, is everything okay?",
                "d": {
                    "eid": "F552AA49648FD446509878F255663E0DAFC6"
                }
            },
            "A5234FDB2921434E4C6BFFF30E565A4CAD58": {
                "t": "... ... ...",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "6F27F0888593A84AB48B0082ACB67842DA4E"
                }
            },
            "606D5D3A2AAED94A4A6B4B97F0C6ACB834D1": {
                "t": "Oh, apologies. {W:150}Did you ask me something?",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "60F1AC8D221DB3457F788816CC508941C892"
                }
            },
            "B7C7F1AD8F29F740AB08769424000AAE9005": {
                "t": "Good evening. {W:150}Forgive the intrusion, but I saw you with a concerned expression and I was wondering if you needed any help.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "D963AED01FF5844F7338F8E55894F94C07A1"
                }
            },
            "24F9319B0192914E59799C06581722364EEC": {
                "t": "Oh, that's... {W:100}very kind of you, thanks. {W:200}But I prefer not to talk about it.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "A5A3D87733E0674E5D4A6FD81B52402CD496"
                }
            },
            "0B89006221D60341F9794E21168249ABB3B2": {
                "t": "Forgive me if I insist, but...",
                "d": {
                    "eid": "0748B2DD4DCE004E9D6829C1F522551DD119"
                }
            },
            "B0278E162765E843133871B4367A9D2B2594": {
                "t": "Have a nice day.",
                "d": {
                    "eid": "6AA0A67072B513473159DE85292BF0DB8EE2"
                }
            },
            "CCFDCA184B5E694F25097EC267A59442937C": {
                "t": "I'm a high-ranked soldier of the Holy Swords of Pylum.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "E1925EAB76F0E240D198B0F7EC1E29BD5BFA"
                }
            },
            "3CBA6BBA41944744984A446606B1CFD03591": {
                "t": "And I'm a priestess!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EF9AA87B8E85324ADC5B9074A837FF63BD5A"
                }
            },
            "42E26DA9501D9744E97933D2D2900F47102D": {
                "t": "If there's anything or anyone troubling you, please don't hesitate to ask. {W:200}We'd be happy to help.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C7CC34EE8C1D1740072B9005D6EF824F19A3"
                }
            },
            "C1D134615D05A143429AA553F2919D5AE924": {
                "t": "For some reason... {W:150}that came quite naturally to me. {W:150}I wonder if I used to be like this in the past?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4866682E917D824ED72BA02852DE7F94C546"
                }
            },
            "A55690101F97604ABA79C33836BBF8211FFB": {
                "t": "Oh, you're from the Holy Swords? {W:150}It's... {W:100}nice of you to be concerned about me.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "D69D98B39DC2B149BF6A379286D41969985F"
                }
            },
            "FFC2B9422CB62544C78B126115FAB68C27D2": {
                "t": "I'm waiting for my boyfriend. {W:200}We should've met here three hours ago, but he's late.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "FFB65469150C2945359B5D22200EE296C248"
                }
            },
            "799B3C443A085943EF2AF654D6F255CC739A": {
                "t": "It's not like him to disappear without telling me. {W:200}I'm really worried that something may have happened to him...",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "43A718FC23D068412E3B8761197D9D472788"
                }
            },
            "595444878D3C304EC35B2494312569507427": {
                "t": "I see... {W:150}Now I understand the reason of your concerned look, miss.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "BA5C46C53B07214DE18821B0E52573E1DD02"
                }
            },
            "BBCF073702D2C34E64192F52259574A025EF": {
                "t": "Oh, please...! {W:150}His name is Tobias. {W:150}If you happen to learn something about him, could you please report it to me?",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "FE412D07737873483779D218BF7F4067ECA8"
                }
            },
            "031369A95901A74D958B74477B90490AAFDE": {
                "t": "Celia",
                "d": {
                    "eid": "75E9FE83592A7045F31A2AE87109ADE794EE"
                }
            },
            "170E20AC1C1086400C189520F7B46E4CF2DA": {
                "t": "I'm Celia, by the way.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "2FF65BE94F6305459419E676FF684B33DA6F"
                }
            },
            "07CE4426723B154651293F9609C9E0A8090F": {
                "t": "It's a pleasure to meet you, Miss Celia.{W:200}\nI'm Sir {LT:2} Ornières, at your service.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "6900C4977B0E10404E8B38848DCCF8D4BDFD"
                }
            },
            "58022D4B00936846582AC302C12295569D42": {
                "t": "And I'm Shiori Leblanc! {W:150}Hehe.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "F318E4AC8C65564B8D0B5B78B0CB7538B970"
                }
            },
            "56F1912E741687445E3B7B4393AE73E0380A": {
                "t": "We'll do our best to find any clues about Tobias.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "72E5CECF57CBE147B33BB0665B602AB25C5C"
                }
            },
            "7E6652E18B8160421C59789568B1B2AB482E": {
                "t": "May Lord Valonja bless your kind souls... {W:150}Thank you, really.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "6F472F206392B44BB77A60136568EF8773A9"
                }
            },
            "10BB53898CC369429988FB410E88812B7B2D": {
                "t": "Is Valonja the name of the local god, perhaps?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "255C5D2A60C96643BB683762F7FA3D515DA0"
                }
            },
            "0FADB05A0CF9534FC34B0205FA7F9EE2E564": {
                "t": "We'll be back with some good news, hopefully.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "131374A77DFEF549685996D968AB19ABD0C8"
                }
            },
            "3FBFA9B116C2914DFE1944C7ED04D3238DEC": {
                "t": "I look forward to our next meeting... {W:150}good luck!",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "40AAE218431D06422858BB35199B74C712B1"
                }
            },
            "311734531CC0B14702895914ADC92A2B1159": {
                "t": "... Goodbye.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "68C7DA9D830AF440CC6AAB73DE8C407281A9"
                }
            },
            "4B9BABEA7013B644AE6A2720CC32FB36B8EC": {
                "t": "... Excuse me?",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "D0334B58527A044A7468F3E6B705A541BC68"
                }
            },
            "0185284E28F39146B5283255272E6ECCF7BD": {
                "t": "Well, we're in a tavern and you're keeping your feelings 'bottled' up inside.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "3221C2A86043574C472BCD2344FFFE1AF63A"
                }
            },
            "B8B7E2B052B13646415A27C3D0A262120672": {
                "t": "Did you get it? {W:200}It was funny, wasn't it?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "413815D14EC5E648FA69EE77FE5FE105D029"
                }
            },
            "2D5784F2512BD44C3C788114586B8E15F7F8": {
                "t": "Leave me alone.",
                "d": {
                    "cid": "D728FB618CB7404DC0795528249A958528DF",
                    "eid": "2DBE54C44E652445397BC269BFD1A58864C0"
                }
            },
            "7C219FAF70248945562BAC35A689FA61D330": {
                "t": "... I wanted to cheer her up, {W:100}but it seems my plan backfired!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D0C3FEFE30C7D845277A95F3AAFD69FD291C"
                }
            },
            "8B3C97A1078F534B877AC311A56105D7DF58": {
                "t": "Did you see anything with your power, Shiori?",
                "d": {
                    "cid": 0,
                    "eid": "9ADA1F8A331600422D5AC0B6494CB6289641"
                }
            },
            "A860B0C25D9F6543F6592617BE3EDADF0259": {
                "t": "Well, aside from her desire to kill you after she heard your pun...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "64D56C7D882BC441981875187F46B9E24E51"
                }
            },
            "57D4366F17361246B9684CD28D9F55E62E3D": {
                "t": "It seems like she's searching for someone she holds dear. {W:150}I think we might help, but that's up to you.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "6BF3C4125F53344DF298C2D7C5178ACC2172"
                }
            },
            "A47B47FE28DD784E616ADEB2BC076F95EC5B": {
                "t": "Understood.",
                "d": {
                    "cid": 0,
                    "eid": "33DEE26D8AC6184BA4486186C579CF8AEE76"
                }
            },
            "971EAA1F1AD144473F8A9028960647872A71": {
                "t": "I have the perfect pun for this!",
                "d": {
                    "eid": "9E1AD0053E0FD341E42835A8EB3838971D32"
                }
            },
            "B23541583693304BB75B04998234CF0D2583": {
                "t": "pun",
                "d": {
                    "eid": "4A84967C2CF72144738B04F2204BCF42300B"
                }
            },
            "F98C9DA910021447C62AC1B699D74B76F559": {
                "t": "",
                "d": {
                    "eid": "2436545116FF46410C98E9284984EA0A230C"
                }
            },
            "B5176D9C74F6C749795A9478AA18C2301900": {
                "t": "Dearly beloved",
                "d": {
                    "eid": "A8358C966F1DF34A192A22C6C0A0B9E502E6"
                }
            },
            "7AE128894CE76647750AB382B5A56EDCB96B": {
                "t": "\"My sweet Tobias is not back yet! He had said that he\nwould bring me \"a present\" from the forest, and we had\na date for tonight. But he is already many hours late...\nI'm afraid that something terrible may have happened.\nCould you look into it for me?\"\n- Celia",
                "d": {
                    "eid": "C96FF0B91B1A8849477AE96688057878B07E"
                }
            },
            "2058B5E390F8194F5A5BA50800C41E10A891": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "03A982436DB7054CEC4A0DF1F55F3A3E87AE"
                }
            },
            "923AC37F1388D244A26A0DE251CDA242E83E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "9998218255219947EB2A503231FBB61EBB4B"
                }
            },
            "FEFB9DA18CBBE54C274A2914987723447841": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A8C83721809ED64F2A7A8BB3AEDF9F35C03A"
                }
            },
            "6834DBAC047EF24FD608EA99CABD11F973E3": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "930490493E47924098280F62E8B1FB4953D4"
                }
            },
            "6C1152263C10724C8A79A771F64124707CD9": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "EDD284C7671D02435899774161F42C85773A"
                }
            },
            "5C7FCBF840B98745AC891FB85FDC789C4C4C": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "0BBA00777D6E61430329ACC1A6791927DFF6"
                }
            },
            "A3402FD65B9D55438B18BDF81D980F453394": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "47FE66314C1EA6438D586582DEDFE8353BA6"
                }
            },
            "848D505B22A4734E1C783909AC0637595981": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1A0237440DFEF34A561B9A40AD2E2479D3EA"
                }
            },
            "20EDA12A318A794B8F59D315354B2C9641D2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "846DBEB77678D34E3E5AAD91E55C4A00F847"
                }
            },
            "ADEFE1C06D5A98449658B9F23E93591EDC29": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D8D0209D380D534B9C5B5307F65B7921397B"
                }
            },
            "0105BAD57C14C34B0A2AAF2252AA39C806BC": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "42AAED615E5E7148F148CE088CF6AE02B850"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89C698D9241648428E3B5478AF1583AF43C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C3B444436A4D043EE68A644CCE77D16143C"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "solved?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B594E1F96273E3484B1896C3B7BB92B8ED36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "15251A187556D343D2683C347CF450A95ED6"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "solved",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "5008E7814C4BB64E5D3A1296F4871E2A3B1E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "54E017455E11E0448E892B69BCBBE346993E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "98751E3D4907024FDB2A9557551247D03BEA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2058B5E390F8194F5A5BA50800C41E10A891",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line6_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "03A982436DB7054CEC4A0DF1F55F3A3E87AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5B1F6ECA16710343326B0C335700E0CB51C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "093B31E31AFAC148AC8ACF22E9CDB6AAD269"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6572DD8C34EF0945E278D91685D3F0FDF2FD",
                        "defaultText": "...{W:100} 하아."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2162BDC4151477405C3B8533F8950FBB5B10",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C2E115DC6E9F994BCE59CB25C9643EC95230"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BFCCEA143E89F74422389AF909EF191F8546"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "second time unsolved",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "AC5C98070CEEE44A837909265B2FD4D1F8DF"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "92A9EBE6427D344E1D49AD16C3AE3F65B474",
                        "defaultText": "실례합니다. 무슨 일 있으십니까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F552AA49648FD446509878F255663E0DAFC6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whathappens",
                            "",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "55E1C9EF42744543C83973E4782309E333E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AAD3E5FA88B819475F198A49179240EE4452"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whathappens"
                },
                "indent": 0,
                "uid": "B2A2674F3A56084B266B8B03D34FF1E17151"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67239FB2138F314570281C729DFE2B0AF175"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 0,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "19407B0325FE9644137BC1A79999F0884424"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A5234FDB2921434E4C6BFFF30E565A4CAD58",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F27F0888593A84AB48B0082ACB67842DA4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "689A0E5044C63246747B7E141BE29A327FE0"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 1,
                    "idleIntensity": 1,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 1,
                        "idleIntensity": 1,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "DF580E5746C80443315874C8A4B17DB2EA3E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C97C06BA8FE4A342F189CBB31F8DE664040A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8FED4C771EDC364FCA2A2FE917AC5BA7B3CB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "923AC37F1388D244A26A0DE251CDA242E83E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9998218255219947EB2A503231FBB61EBB4B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C01D33C334508744A4392C26640ED5BE86C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "88490C0F67D5F746318B03E1DD66252E8645"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "606D5D3A2AAED94A4A6B4B97F0C6ACB834D1",
                        "defaultText": "아, 죄송해요. {W:150}뭐라고 하셨나요?"
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "60F1AC8D221DB3457F788816CC508941C892",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "133871CC631D7847F7284323EAB6EEEB26B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "781F27CF090F084961299118159BB9DB2899"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7C7F1AD8F29F740AB08769424000AAE9005",
                        "defaultText": "안녕하세요. {W:150}실례지만 걱정스러운 표정이 보여서\n도움이 필요한지 여쭤봤습니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D963AED01FF5844F7338F8E55894F94C07A1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97700D9A4157B34B7559E9242269E8CE3B6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "C77CF1AF82BE034A0338FEE0642A01D67725"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F3DBF21C34684143050A5268524B9CB30680"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FEFB9DA18CBBE54C274A2914987723447841",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line7_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A8C83721809ED64F2A7A8BB3AEDF9F35C03A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A2B3C21F645B3745716A8B3145FA092E6D8F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7503C7348B86184A7259C866E7B478EBF300"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24F9319B0192914E59799C06581722364EEC",
                        "defaultText": "아, 정말... {W:100}친절하시네요. 고마워요. {W:200}\n하지만 이야기하고 싶지는 않아요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5A3D87733E0674E5D4A6FD81B52402CD496",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "472DA91345C9514D253ACB56293A1199F59A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "second time unsolved"
                },
                "indent": 0,
                "uid": "D786FD636102C9493718C952D696B00C04B8"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0B89006221D60341F9794E21168249ABB3B2",
                        "defaultText": "계속 여쭤서 죄송합니다만…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0748B2DD4DCE004E9D6829C1F522551DD119",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B0278E162765E843133871B4367A9D2B2594",
                        "defaultText": "좋은 저녁 보내세요."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6AA0A67072B513473159DE85292BF0DB8EE2",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "pun told?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DBF7C2EB1A47274AA45AAEC6A40BBFD88B02"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "971EAA1F1AD144473F8A9028960647872A71",
                        "defaultText": "이럴 때 딱 맞는 말장난이 있지!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "9E1AD0053E0FD341E42835A8EB3838971D32",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 3",
                        "index": 246,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B23541583693304BB75B04998234CF0D2583",
                        "defaultText": "pun"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4A84967C2CF72144738B04F2204BCF42300B",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "4D1670684204C1496E19F3538AF733D6499F"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 3",
                        "index": 246,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F98C9DA910021447C62AC1B699D74B76F559",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2436545116FF46410C98E9284984EA0A230C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "whiteknight",
                            "byebye",
                            {
                                "name": "Label scelta 3",
                                "index": 246,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            },
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "77AC406C7E3E46435F1B4089DBD8C9144396"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "74E4C8B21446B34F394B85F7FFD8E01732AF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whiteknight"
                },
                "indent": 0,
                "uid": "1050D9CF2E7A144BED18E523F1116E9B02BA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "67E12AD6548AE84C267820230691BDC9E169"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6834DBAC047EF24FD608EA99CABD11F973E3",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C05-02b_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "930490493E47924098280F62E8B1FB4953D4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F414CC2143BAD04769196C85E223D296A023"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD338CC03BB00145645931F2212C4F020BA0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CCFDCA184B5E694F25097EC267A59442937C",
                        "defaultText": "저는 파일럼 성검단의 고위 기사입니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E1925EAB76F0E240D198B0F7EC1E29BD5BFA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49B2B43A3B73C345D95A1C13FFEAE38B7121"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "B0A6E1DA86F5514AC69BCE56B0F01D80B3F7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            2,
                            3,
                            100,
                            1,
                            800,
                            50,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1172747562BB084FF919F3F17DB1857242F2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "A46278016845034E3E3AF2235E2C1E11B068"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 36,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6EDE21E83A3641490969CDA32475C87EAF0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E97DE594EF02645464952627CF334766670"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3CBA6BBA41944744984A446606B1CFD03591",
                        "defaultText": "그리고 저는 사제예요!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF9AA87B8E85324ADC5B9074A837FF63BD5A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0654311606E64242DA0B44F7366E0FF06F87"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A82FC4ED30D5C645B2283D895EA6625674E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "42E26DA9501D9744E97933D2D2900F47102D",
                        "defaultText": "곤란한 일이나 사람이 있다면 주저 말고 말씀하세요. {W:200}\n기꺼이 도와드릴게요."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C7CC34EE8C1D1740072B9005D6EF824F19A3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C8099BF4C202243946BC527E5335899B450"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3C6FFFF8D279449AE6B49A5050BA1FADA2D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1D134615D05A143429AA553F2919D5AE924",
                        "defaultText": "왠지... {W:150}아주 자연스럽게 말했어. {W:150}\n예전에도 이런 사람이었을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4866682E917D824ED72BA02852DE7F94C546",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "926D9EA6867E174FC54B8906E5671C8D2C4C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7DB5449094380444560B3776F45EB0BBA4F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "1886A29853A5F043D1892779328246448C54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A55690101F97604ABA79C33836BBF8211FFB",
                        "defaultText": "아, 성검단 소속이군요? {W:150}저를... {W:100}\n걱정해 주시다니 친절하시네요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D69D98B39DC2B149BF6A379286D41969985F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BF2DA9F59CEA94D721918839A86B35B29EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CF97B8292E57C84A616903E4A6208F8B0B86"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C1152263C10724C8A79A771F64124707CD9",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EDD284C7671D02435899774161F42C85773A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "92371B6F23624942D3795A555716C53431A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A590565A065CA54E73791862AD01AA11E5A7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFC2B9422CB62544C78B126115FAB68C27D2",
                        "defaultText": "남자 친구를 기다리고 있어요. {W:200}\n3시간 전에 만나기로 했는데 늦네요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FFB65469150C2945359B5D22200EE296C248",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3ECA4A948906124A1379FAE6435267ABD0E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "E182608F7EECE244404A620747DF7CB40B5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "799B3C443A085943EF2AF654D6F255CC739A",
                        "defaultText": "말도 없이 사라질 사람이 아닌데. {W:200}\n무슨 일이 생긴 건 아닐지 정말 걱정돼요..."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43A718FC23D068412E3B8761197D9D472788",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D050EF93C5E074F6E391823246C75E876A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4A974EF7B42594E4B2894B1B933750F901C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "595444878D3C304EC35B2494312569507427",
                        "defaultText": "그렇군요... {W:150}왜 걱정스러운 표정인지 알겠습니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BA5C46C53B07214DE18821B0E52573E1DD02",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DBEBE01C30F8C44FAF382BB2CE550427522B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2052C63C7F2C76401B6BAD525CFDF51B18DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A0D65253EEA0242183BE460FDAE8D90F16D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BBCF073702D2C34E64192F52259574A025EF",
                        "defaultText": "부탁드려요...! {W:150}그의 이름은 토비아스예요. {W:150}\n무언가 알게 되면 제게 알려 주시겠어요?"
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE412D07737873483779D218BF7F4067ECA8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E522CD2E0C46034512182A11877D8506462D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "celia",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "031369A95901A74D958B74477B90490AAFDE",
                        "defaultText": "Celia"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "75E9FE83592A7045F31A2AE87109ADE794EE",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Lyvonis"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "celia",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A620965735EDC74DE86A04B607401BCAD750"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4841C2218E28844D470B0B367923D9190328"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "170E20AC1C1086400C189520F7B46E4CF2DA",
                        "defaultText": "참, 저는 셀리아예요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2FF65BE94F6305459419E676FF684B33DA6F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66F6768F358FA749C5591D83D220ABA3C73E"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "ornieres name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1A4D05C3542AE845F18AC2A3D600E91E9B2A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8932C3CB7B2C824F64882708D68E7F3A37D5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C7FCBF840B98745AC891FB85FDC789C4C4C",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0BBA00777D6E61430329ACC1A6791927DFF6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1E3C5EE524AB3346C9282145496D7755861F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A3556AD533FD943356955F4A90F9FB801AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07CE4426723B154651293F9609C9E0A8090F",
                        "defaultText": "만나서 반갑습니다, 셀리아 양.{W:200}\n저는 {LT:2} 오르니에르 경입니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6900C4977B0E10404E8B38848DCCF8D4BDFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9549B16D07F5034906686DF1E8B97CAB957D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C8F6861D282374477A29C67403C9BB9A45EE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A3402FD65B9D55438B18BDF81D980F453394",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "47FE66314C1EA6438D586582DEDFE8353BA6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8620C5373634E84B215B08F8C1CE671236DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8F39CB64C28704B6828651554771DFBE99F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "58022D4B00936846582AC302C12295569D42",
                        "defaultText": "그리고 저는 시오리 르블랑이에요! {W:150}헤헤."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F318E4AC8C65564B8D0B5B78B0CB7538B970",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E8FB0CAD1874D24399887195606DB298F79F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56F1912E741687445E3B7B4393AE73E0380A",
                        "defaultText": "토비아스의 단서를 찾도록 최선을 다할게요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "72E5CECF57CBE147B33BB0665B602AB25C5C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E3397301C16364D0018F8075BC605460ECA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD0DA05216B3A04D747BDF48DF7A9F2428E0"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "1E83B796675F52462F3A800366E21FD2DAA2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "6B246F1E2B57F34BF618B335D12127F84113"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Quest name",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B5176D9C74F6C749795A9478AA18C2301900",
                        "defaultText": "사랑하는 여러분"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A8358C966F1DF34A192A22C6C0A0B9E502E6",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Quest description",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7AE128894CE76647750AB382B5A56EDCB96B",
                        "defaultText": "\"나의 사랑스러운 토비아스가 아직 돌아오지 않았습니다! 그는 나에게 숲에서\n\"선물\"을 가져오겠다고 말했고 우리는 오늘 밤 데이트를 하기로 했습니다. 하지만\n그는 이미 몇 시간이나 늦었습니다... 뭔가 끔찍한 일이 일어났을지도 모른다는\n걱정이 됩니다. 저를 대신해 조사해 주실 수 있습니까?\"- 셀리아"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C96FF0B91B1A8849477AE96688057878B07E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EA3235C38988B64A6019D6B33077DC66B0C0",
                    "parameters": {
                        "values": [
                            1,
                            {
                                "name": "Quest name",
                                "index": 2,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            {
                                "name": "Quest description",
                                "index": 3,
                                "scope": 0,
                                "domain": "com.degica.vnm.default"
                            },
                            2000,
                            1000,
                            "7FF18EB084AD054B434B622321F85E2DDABF"
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F21F5FC07337640560970A23A84E78DBE3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0C219E9C37417042B158B2D8826E7BA5D6FF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A2630D3372220943624A84681F564411C1A8"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "905819D14101F54FC229DF83129E78305E9A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "733FF483864433450628A510FBFBA8570F25"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C599011366D1254D822B5221A0CCEC62E1AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1E8B15117EB654E084A91A1434C026775C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "659ADBD917653746C41BB4012FC38CD3A4C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C572C8F046AE147BC2AD0F32316BE7EFBB9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E6652E18B8160421C59789568B1B2AB482E",
                        "defaultText": "발론자 님께서 친절한 두 분을 축복하시길... {W:150}\n정말 감사합니다."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6F472F206392B44BB77A60136568EF8773A9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B665C829AFA554980188986FAD3FE7898D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ADFFFF57404487453F783895448C180F45B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10BB53898CC369429988FB410E88812B7B2D",
                        "defaultText": "발론자가 이 지역 신의 이름인가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "255C5D2A60C96643BB683762F7FA3D515DA0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12542AB690F8F746FB695861E6EA5C99161C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC7E2EA17655294CA518D5D79B9E3614BE1D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0FADB05A0CF9534FC34B0205FA7F9EE2E564",
                        "defaultText": "좋은 소식을 가지고 돌아오겠습니다."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "131374A77DFEF549685996D968AB19ABD0C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41D4FA64528383425F692CF85E78E487A529"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "solved"
                },
                "indent": 0,
                "uid": "2C1196F135595745EF188FF1E930BE77E21B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1908B1C883C37847BC8A2D319AA5BCA9EFC7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "848D505B22A4734E1C783909AC0637595981",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A0237440DFEF34A561B9A40AD2E2479D3EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "22A3BBAF29DEA444BB0B27525DEDF390212F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F13D047312D168468C8BBF61FAD8FC37274F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FBFA9B116C2914DFE1944C7ED04D3238DEC",
                        "defaultText": "다시 만나길 기대할게요... {W:150}행운을 빌어요!"
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "40AAE218431D06422858BB35199B74C712B1",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "solved?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BBACB3F998E312442248C6189A06DDEA186A"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "good end",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B0C1C2D3273810460D49C7F562C72BE1D251"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "byebye"
                },
                "indent": 0,
                "uid": "FA3B30FA5D8676426339D0857996BE25374E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25089D4E8B393843FF3973A0DA630E7792CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "311734531CC0B14702895914ADC92A2B1159",
                        "defaultText": "...안녕히 가세요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "68C7DA9D830AF440CC6AAB73DE8C407281A9",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "bad end",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "8AE9AD0C035BB5468D48A8F747A53098DA71"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "pun"
                },
                "indent": 0,
                "uid": "FE4C740E25420341934B3715B6AD22BF50A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAA73C2A2E370242F858A892F6F4C9923291"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABA4F2EB1CC5D44DAA5A4FA22BD03FD63E87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4B9BABEA7013B644AE6A2720CC32FB36B8EC",
                        "defaultText": "...네?"
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D0334B58527A044A7468F3E6B705A541BC68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F71F73CD849FD84C260AE3A6FFAFCBBD21C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EBD3CCEE111BF24A218987711B6397C55E89"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20EDA12A318A794B8F59D315354B2C9641D2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line24_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "846DBEB77678D34E3E5AAD91E55C4A00F847",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ED04A85151B5524A32098D41804F8F6A1E3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "700314DD14C11545332BE1B2A1185839B22E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0185284E28F39146B5283255272E6ECCF7BD",
                        "defaultText": "여긴 술집인데 감정을 병 속에 담아 두고 계시잖아요."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3221C2A86043574C472BCD2344FFFE1AF63A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B677CB9C6AB1C14128688F335AF1781F7F83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B8B7E2B052B13646415A27C3D0A262120672",
                        "defaultText": "이해했어요? {W:200}재미있었죠?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "413815D14EC5E648FA69EE77FE5FE105D029",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC45618B4FEDA84EDF5B0B04BAA1417F5D61"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "9873260B3EC7C5445928634200D7B06004E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3EDAB43F5F9FD44EB8187C9768640D4F8D5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ADEFE1C06D5A98449658B9F23E93591EDC29",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Celia_line6_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D8D0209D380D534B9C5B5307F65B7921397B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CDC0069E1FBCA34B8A3883C85230F60252C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D728FB618CB7404DC0795528249A958528DF",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FE85EAD775A674B01697A66982926D1D642"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D5784F2512BD44C3C788114586B8E15F7F8",
                        "defaultText": "혼자 있게 해 주세요."
                    },
                    "position": 0,
                    "characterId": "D728FB618CB7404DC0795528249A958528DF",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2DBE54C44E652445397BC269BFD1A58864C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27571D5793DA854FB11819E25E7E354D0F2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6901C3E143308241AE8B1613B4B363E0122E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7C219FAF70248945562BAC35A689FA61D330",
                        "defaultText": "...기운을 북돋아 주려 했는데, {W:100}역효과가 났나 봐!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D0C3FEFE30C7D845277A95F3AAFD69FD291C",
                "expanded": true
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7C5AF94862637847261A2234F6E5AD5D86A7"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 6,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "846176B07D61D146B429EE7719F97625FC7B"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "numberValue": {
                        "name": "sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "B232AFB0727A02480859EC90EF8C354176F8"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "pun told?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1EFE9DE7336EC44E1949928041F638F1E079"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "bad end"
                },
                "indent": 0,
                "uid": "713A82BD2A5A554C926ADA25AD85BDD860D1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFF18EB145D4E645606ADE983718FDEED234"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9D6EC287D2CD74F7C588D21101835CDBB56"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "1F786455988D72459E7ACE00F902E3590870"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87E984CF6BF8714F763A095471BB936EAAEA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1819F9636F5ED546213A4E34EB681E88ABFB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B3C97A1078F534B877AC311A56105D7DF58",
                        "defaultText": "네 힘으로 뭔가 봤어, 시오리?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9ADA1F8A331600422D5AC0B6494CB6289641",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A60417C88EA4E1420B1B1B1359D2D7E966EF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "0B4DE38072DD87495359DB15E67FF5C2ADA8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            1,
                            750,
                            1,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7FAB8F9E65FC064119184E64503A9F139971"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "pun told?",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2D16B5419A48954928496DE44736FBC5970A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "reflection told?",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "641200239A98834AE76B49B84D5FDB0932CB"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "reflection told?",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "11387F2E45F38347B589A7C09ED693C502EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "53099A0F5F68084B241AF6F248DC2E0C0BEF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0105BAD57C14C34B0A2AAF2252AA39C806BC",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C0.1-02_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "42AAED615E5E7148F148CE088CF6AE02B850",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "868414CD81D22647116BD4338522A3805D62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "40A5EA46207A524CE959C5F4BF2FD8465A28"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A860B0C25D9F6543F6592617BE3EDADF0259",
                        "defaultText": "네 말장난을 듣고 널 죽이고 싶어 한 것 말고는..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "64D56C7D882BC441981875187F46B9E24E51",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E15285176AAB914C189A8643B1EA23E0D6E8"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "^ solo una volta e solo se è stata selezionata la terza opzione"
                },
                "indent": 2,
                "uid": "8541664732DF744CA46B8CD2F4F85F5C7024",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C02ED0353BCE664092991517F87223BAE0D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "927AA4F12BD7434DDF4BB2A7B7B0DBBE4043"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "57D4366F17361246B9684CD28D9F55E62E3D",
                        "defaultText": "소중한 사람을 찾는 것 같아. {W:150}\n도울 수도 있겠지만 결정은 네 몫이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6BF3C4125F53344DF298C2D7C5178ACC2172",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F25EAD329D62B747BD4835629EE2462CA448"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6B136FB024BD449F17B84178FB435A1B663"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A47B47FE28DD784E616ADEB2BC076F95EC5B",
                        "defaultText": "알겠어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "33DEE26D8AC6184BA4486186C579CF8AEE76",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Prevent icon flag from triggering",
                        "index": 177,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3B87A419358F9447BF4BC5310A6B5E90A329"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "good end"
                },
                "indent": 0,
                "uid": "9318B8A270102648807BE936CD3CD25A35E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5DB68632F13D34DA60AC991C80690A8A80F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E091F5389F8544F1349C375F36375E9D402"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "solved?",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0C3ECBA57ED6F04223397B741013D15936ED"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "299E09750DBF4449FD2BF2F499877A7736CE"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "95A50C805FBEE54E727B5074B9500C4BB777"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 1,
                "uid": "368704A62F68244C915813A2B826F627E38C"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E2113C0F3CAB6644D22AF87418C8A6DC6322"
            }
        ],
        "livePreviewDisabled": true,
        "numberVariables": [
            {
                "name": "sarcasm",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "pun told?",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "reflection told?",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "solved?",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "stringVariables": [
            {
                "name": "celia",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ornieres name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Quest name",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Quest description",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}