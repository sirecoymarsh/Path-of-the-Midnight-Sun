GS.dataCache['40137A4C8DDDF740998A22B4FE35AE86A332'] = {
    "uid": "40137A4C8DDDF740998A22B4FE35AE86A332",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C10-04 And the Demon King is... (VN)",
        "type": "vn.scene",
        "parentId": "880444DA01A75341EC3B21A00BDB761DDCAD",
        "chapterUid": "75EF9E6F85E3E84744787D615C2743CE32CF",
        "order": 4,
        "localizableStrings": {
            "E9321D4D462115437769B4E82B19F57A5628": {
                "t": "... ... ...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "05380DEB5697C74D99884EB60FCC6D50DC82"
                }
            },
            "C74C54A320C6E14D7C1A4CC8EDEA1994C99C": {
                "t": "It seems she's regaining consciousness.{W:300} Thank goodness.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "F3B271C38CBD1849AE6AFB73A3F0064C5055"
                }
            },
            "9051516D7E690348598947A2F99C87C0BE75": {
                "t": "She wants to \"go back\", see?{W:300}\nNo time to lose--",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "66BF621477A354498D7A73A64D2A70964E35"
                }
            },
            "6FFEFB6206403041B61848561BC2C8858DA0": {
                "t": "What the...!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BE2491457604D940419B7E8643615584DC7B"
                }
            },
            "57C592E30E4E1843D12B0AD8EF5551237CF2": {
                "t": "Hellios! Are you alright!?",
                "d": {
                    "eid": "145E2FF05648414BA41A1FF79F27367874A7"
                }
            },
            "B682966F2685C6404E999302260D38119222": {
                "t": "What's the meaning of this, Shiori!?",
                "d": {
                    "eid": "13194CC220EB324FCB1B74A047467DCD613C"
                }
            },
            "EB64C40C6D5A66413C2B07D60C4A993DF7D8": {
                "t": "I'm beginning to lose my patience.{W:300}\nWhat's wrong with you two, now?",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "8A6B9FFD6FAB2547D8499BA8572D6C732A21"
                }
            },
            "A8238C477CA2E5416D494BA455E21F326966": {
                "t": "I share Rya's concerns... What's happening to me?{W:300}\nWhat's happening... to everyone?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "74A7EE666EFBD547491AC806BD1CBBE13CF0"
                }
            },
            "68CE6F273AB1744EDB1B7FE652EF18003929": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9CD26C647409A548766A08D25C05CE146C33"
                }
            },
            "CF8741A524716545190BAD25CCD05268BC6F": {
                "t": "Hellios?",
                "d": {
                    "eid": "5CADA5A54755F94D016B1C30A0B6E004BC1D"
                }
            },
            "61E0C3F95AFCD34591992285DBB1D1AE7F3C": {
                "t": "WHAT!?{W:300} But this makes no sense!{W:300}\nThe Demon King should be sealed inside Faratras!",
                "d": {
                    "cid": 0,
                    "eid": "BAED063F4BA98240EB8878D518ECE271A032"
                }
            },
            "252F30581B216445C32A2691B77D0C51FC3F": {
                "t": "... ... ...!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C3A68FF696D176406D8922772F4505A7F057"
                }
            },
            "274C13D01345874D2288EBC2C548367CE5FD": {
                "t": "The... The Manacrest?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "08B6D40889E899474028F0C88A8C2F2CB553"
                }
            },
            "D95869124DBA324DB628C775914277A1B04F": {
                "t": "Wait!\nFaratras is...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "6B3D7F11945D944191183E811DC1AAF18085"
                }
            },
            "93544CF76570C744964AC0449B37D0A35A49": {
                "t": "...{W:300} back!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "EA945A8B8030B4481D0A8CD17C421A282E52"
                }
            },
            "14C1986C7DAC074174398E5296F4956B5B4A": {
                "t": "Stay...{W:300} Stay back!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "F5A530866B4C674ADB5B0AD9A0E5EFBCE449"
                }
            },
            "D65BAF1406C5C246D33A882111936A608875": {
                "t": "... ... ...!{W:300}\nUnderstood!",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "0AC791AF4E93A34C5F3B81E61BACC93F0117"
                }
            },
            "2B5EF441681DF7453B2A93C28C0E88516CF1": {
                "t": "Urgh...!!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "0ADCCC8C7DABE8416328AC69F9CA82179B68"
                }
            },
            "69579DD16109D5427B3889E5CDEE5EA28CBA": {
                "t": "For some reason, I can finally sense Faratras' malice very clearly.{W:300} And...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "E3C5A3BF522B63474F5BCD4312AECA12F084"
                }
            },
            "A45372F72C02C44EA05A00A689478B3FD122": {
                "t": "...She's malicious towards you, Hellios.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "E16EB7070469F94F5B8A6E7813AF2B4642E1"
                }
            },
            "A6FDA9B99CAA384869385EF3A0129910A737": {
                "t": "What!?{W:300} Nonsense!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "F317249249B0C24B906935017B0B3220C582"
                }
            },
            "265274B71835024D253A3D858683A7E06FF5": {
                "t": "I've...{W:300} finally understood everything.{W:300} I can finally see the truth.{W:300} Since the very beginning, all of this was...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "A80949398D9866451B1B26602E7BCFE89207"
                }
            },
            "B0F1695D4D8FB044976BAE129477673ED4D3": {
                "t": "She must be delirious.{W:300} I fear the Demon King has corrupted her mind, like it just happened with him.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "6709BA06274190456538FB20E3241CF0544F"
                }
            },
            "6C3325EC1CF26741E099E992F8A3CB9EA926": {
                "t": "It was...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "5F21D7BD0E9B1745E22B8950D9A31EE2F44E"
                }
            },
            "A2305B517F36554C5E9BCDC5463108C6486B": {
                "t": "Are you all right?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "EE04EBA45401C647778957C656B9CADA12AB"
                }
            },
            "D6B95043676A89481F8954D2E4F63E10AEF6": {
                "t": "We fell right on the pedestal.{W:300}\nI hope this didn't {SP:2}{C:1}compromise the ritual{C:0} in any way.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "720EDDA90B2D984D6E8967D8106CB7B51AD9"
                }
            },
            "5EB150C63D8EA144248A44F03E7095A6F41E": {
                "t": "Faratras was constrained to kill those soldiers, since her former master had the 'brilliant' idea of brainwashing them.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "22CCE80A68B7C14CE8899E26D28EF0F0291E"
                }
            },
            "7E25C99E3A8F664C862BE29831E7DFC75E8E": {
                "t": "Then, you can surely explain how Alvano managed to accomplish that, despite not having the power to control that number of people.",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "A57F243E72EBC84AA979CD20CBF9A8090784"
                }
            },
            "73742ED8329A8240FD291167E96DB9E91B4C": {
                "t": "Are you implying that it was Faratras who did it?{W:300} Her magic wasn't any stronger than Alvano's at the time.",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "34FE669159E5F74E9A3AE69421BC0359F1A7"
                }
            },
            "E333999D87CA5546B95A85B66CD0B03EA931": {
                "t": "Lady Faratras may not have done it. But what about the {SP:1}{C:1}Demon King{C:0}?",
                "d": {
                    "cid": "DDD0AD108FC02444845849E615760F6DBD75",
                    "eid": "3688F4C06CD1C448EF48D192DFE9231AE417"
                }
            },
            "424B09820D49554F051A334869F6D320669A": {
                "t": "How did you get yourself into that state yesterday anyway?{W:300} You're not the type to lose control like that.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "72D451AF62D6314F8F090AC21148155CBFCD"
                }
            },
            "5DD86CA66ACEC0483E6AD730A54E3A2EB86D": {
                "t": "I can't remember.{W:300} I was together with everyone, when {SP:2}{C:1}someone{C:0} passed to me a glass of...{W:300} was it cider?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "C6343AE5138A2349CF999EE2B726C2CDA108"
                }
            },
            "79AC69864C9CB34F4C3983738C4688B340CE": {
                "t": "Everything after that is very blurry...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "42919481628C9348498A2944BBD931E62388"
                }
            },
            "1F14AB7061109247F18ABBE7FF9496BE642E": {
                "t": "Queen Munie betrayed you.{W:300} The idea of controlling the soldiers' minds was hers.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "180DA95B4D2D93408D8B3811CC2F5C11710C"
                }
            },
            "87D576D762A2F64B737A5650E1761862A609": {
                "t": "W-What did you say!?{W:300} Munie wouldn't do anything like that!{W:300} She...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "2982724592E1184E5A9BBF84B902CC98E93E"
                }
            },
            "106EA84B22E2F041DE5A0931AE2595956531": {
                "t": "She's like a mother to me...{W:300} despite our differences...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "545AEE3655D4E4408C49B5D30C17705E7AA3"
                }
            },
            "72836D962775C647EF4B06277641599D9302": {
                "t": "I was there when she asked Alvano to brainwash those soldiers.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "109AD54759422248BB6A86536E486ACBB246"
                }
            },
            "8497857C3293174E851A8258B16D548B9442": {
                "t": "Why...{W:300} Why were you there!?{W:300} Who are you!? ",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "180391DA01FC04478F88A1D99BB0C3A2675E"
                }
            },
            "36248C4B5B9363465B8874D6A6D3CA0F6F6D": {
                "t": "I've always been hidden in the shadows, since my own existence is sinful...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "1491E3E8468C264BDD89E308381A8A95DC02"
                }
            },
            "3ABE7D6E3642C742B748B296451CCE7B854C": {
                "t": "Faratras, I'm the secret son of Munie and your father Alfhrìd.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "48D164C377D847482D28CDC7FEE893FFCF0C"
                }
            },
            "03472D703C8E324FB10B32C4DC98848185EB": {
                "t": "N-No... {SP:1}{C:1}You're lying{C:0}...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "B48724632A0CC04CFA6B49B14303FBE69784"
                }
            },
            "350DBB69381D044F0689E6C1F4404EBCD261": {
                "t": "It was--{W:300} Since the very beginning...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "17A67B1656245745D26AF8388713AF1B7916"
                }
            },
            "BB1882FE7DAD024FEA490A1231DC33B6302F": {
                "t": "It was...{W:300} It was all a LIE...{W:300} wasn't it, Hellios?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "9ABA1E606BDCC74FED48BC959F68E1595775"
                }
            },
            "7E3CB0144DE2C546D03BC0263FDAE7063279": {
                "t": "Or should I call you...{W:300} Demon King!? ",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "226D43AC8EFF334F435A2AC6DFFEDD92F8D3"
                }
            },
            "479022D67CC4B84354785329DF80FF5229AB": {
                "t": "... ... ...",
                "d": {
                    "cid": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "eid": "B5C405A6118211440E8937F41121D5BC1045"
                }
            },
            "9201F623926B34408B7B30E8FE91FC685964": {
                "t": "... Pfft...{W:300} Ahahah...{W:300}\nHahahaha...{W:300}\nAHAHAHAH!!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3FDFD4C069480442A65BDE5676D8B548DB24"
                }
            },
            "FFCAC8B3401FF14F83582D108AD1D352103B": {
                "t": "You sure are interesting, tiny one.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "4738ED8E55AC5745895A9364D973ADDB992C"
                }
            },
            "72B2419078BFA643F91AA702377C6A2E04B0": {
                "t": "Demon King",
                "d": {
                    "eid": "9B829F07237406456A18A9643708CE82D005"
                }
            },
            "2346CB9050B4E04B74283929B285BB13822C": {
                "t": "Finally showing your true colors, huh?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "30F4C2A004D9D84C198A37633488DC725CFF"
                }
            },
            "A1F5FB9E21AE964FCE1A1FE8EA609F6C99E1": {
                "t": "I...{W:300} I agree.{W:300} How can Hellios--",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "174F32C16ABC5740F14830F2D9D11B7710AD"
                }
            },
            "BE4335F9127B354A3F2AB7E03793E35A46DD": {
                "t": "\"Hellios\" was nothing more than an emanation of my power.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "6AEBAA327A487540E01AA15302079B7211AA"
                }
            },
            "717421BB5988724464398717527384561A55": {
                "t": "Hah!{W:300} You were such a whiny girl, \"Lady Faratras\"!{W:300} Always unhappy with everything.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "DE51106D7A30B8474E589A76FE8793051500"
                }
            },
            "703A33E57365224EF869A7708190F6723213": {
                "t": "Every time your weak spirit was shaken, your seal loosened.{W:300} By taking advantage of your feelings, my power has gradually gathered outside.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "B9897DC4023DD84B5939BFB1BD70B627FFF2"
                }
            },
            "EC8EDFF55C68B249A818CBB5DEDBEA02A306": {
                "t": "And so, after twenty-one years, I was finally able to create this body!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "99B67459107CE643144B3E65741418308E0C"
                }
            },
            "1E68095637A7E64A1B7A1BC2203D30218FBE": {
                "t": "This... is...{W:300} ridiculous...{W:300} Were you the one controlling my mind this whole time!?",
                "d": {
                    "cid": 0,
                    "eid": "82D02CC78BCD9648E15931B61EAF56CF86E5"
                }
            },
            "9C2130224BDD8547788A7269FF294252EE70": {
                "t": "I considered you a FRIEND, Hellios!!",
                "d": {
                    "cid": 0,
                    "eid": "8E16703E551FB3454518A0A6F47E870DE4F8"
                }
            },
            "DD9C2D5B221DD64031385351AAE8BA1BF004": {
                "t": "HAHAHA!!{W:300} Don't make me puke now.{W:300}\nWhat's with that disappointed face?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "43E60CD430D81147AB089164D25B7DBD7D4E"
                }
            },
            "C8637EF247A53245868AD9C38A6236658E7F": {
                "t": "You were just a measly pawn in my hands!{W:300} What a shame that damn Manacrest interfered with my power.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "13C0C8CA49ECF84A2D796651070CB0EF89F9"
                }
            },
            "84EAA69179E4624E1F8A21E11FDF13FE3AC9": {
                "t": "But why!?{W:300} Why didn't you kill me when we first met, HELLIOS!?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "A19D97C54046B442921A480619255FB32418"
                }
            },
            "073B838E1D6063409E28476384129B8A52C1": {
                "t": "You should know very well.{W:300} If you had died while our souls were bound, part of my power would have been lost with you forever.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3F30038F433F11422F497DC121EBD9772628"
                }
            },
            "F29EFDCB4E61A0459C583D87A876239FE67B": {
                "t": "It had already happened with the previous Vassals.{W:300} Obnoxious to say the least!{W:300} That's why I needed to separate our souls in a 'natural' way.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "B34B31D395A76044483A5AE999A9B1290239"
                }
            },
            "91C5ADBF57E89741BE0AE072B29619185A24": {
                "t": "I had to remove the seal and weaken you to the point you wouldn't be able to control me anymore with that annoying magic of yours!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "804522AA79226846891BFC76F3BC079D7CB6"
                }
            },
            "60B2080B2D29184128694C9782C9BF8AA6BE": {
                "t": "Everything that happened...{W:300} It was your fault...",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "D32A35A0270DC94EAB696BB10CC07C1919D5"
                }
            },
            "75AF3C8C8A4543437399D747DDF1906090CA": {
                "t": "I thought it would have been harder to be honest, but...{W:300} In the end, I just had to pit you against your own country!{W:300} AHAHAH!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "E9AC33485DF5C449784A12A40B002576506A"
                }
            },
            "4CF50408785E284F048AF9F3989B658066AD": {
                "t": "I brainwashed those idiots at the castle and made you think I was your ally...{W:300} Then I proceeded to play my cards one by one.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "51333A482E05114EC559D7D1CF63F3DF2D5F"
                }
            },
            "380BDAF12092F84491181D73EDE07F4ACB4E": {
                "t": "And of course you believed me!{W:300} You even believed I was your BROTHER!{W:300} HAHAHA!! ",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "EDCB9D931E08A5442089DE45B59D8035587D"
                }
            },
            "22B4303634A700422D5A5573158980F0D6E4": {
                "t": "You...!{W:300} You used me!{W:300} You used MY PEOPLE!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "50F30B2B128EC7468A8BD5F3663F9CFAA6FB"
                }
            },
            "266422C72E4082471D786197FA197570D93E": {
                "t": "So what?{W:300} I'm the Demon King, you cretin.{W:300}\nI can lie and kill however much I want.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "C2C1CBE4536DF84FC69AF4E5FF35FF0DDC0C"
                }
            },
            "94B8A49136F4844C0259E8518B7CACF9ECA8": {
                "t": "Are you serious...!?{W:300} We fought together, Hellios!{W:300} We ate and drank together!{W:300} How can you tell us it was all meaningless!?",
                "d": {
                    "cid": 0,
                    "eid": "17A66C612BC8B0415B3A05553AAA44126CD3"
                }
            },
            "CDA302230BFB2445E10BB0D7E87F755A51A4": {
                "t": "It wasn't meaningless, though.{W:300} You escorted the Vassal all the way here, which allowed me to corrupt the Vassalage.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "4FA604FF52E0C34220987F67A5BC4B1063B9"
                }
            },
            "D05A701E3C5CD14C4028DDC41C580AF9829D": {
                "t": "And you even defeated her, pushed her mind and body to their limits, freeing ME at last!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "CE18B3ED3CF4064614892371A01099F976C8"
                }
            },
            "BBEC55B8698B384D10285CA36CCACDB661BC": {
                "t": "How could I not have seen that coming...?{W:300} Why wasn't my power working on you!?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "9E9B1B866F637147AE3B8EB24AF460FB37EA"
                }
            },
            "2E5424363F59B54AAD3B44C22F81914AF264": {
                "t": "Unforgivable...{W:300} All of this is...{W:300} UNFORGIVABLE!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "5972F68E155E2745CC2A9827B6369F28DBB5"
                }
            },
            "CCCA3DB12093D143CF5A6963BF4D503E1FAA": {
                "t": "What's truly unforgivable is that a brat like you has imprisoned me for years!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "ED338FCB04F7924AA38B9D20BA145268539E"
                }
            },
            "9B4694932B7DC143B868CEE3572DDF7C44FA": {
                "t": "Oh, but I'll make sure that never happens again!{W:300}\nNOW DIE!!!",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "ED1D3D8A53CBC74839283E428CF2082C93CF"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Can open side menu, can save, can't open Inventory"
                },
                "indent": 0,
                "uid": "98821FA872D89546024B8549D6188C9B0EE1",
                "expanded": true
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "5929B805411336494B8B5DD362B4FAEB0102"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2D020C1916A3814359783A811324EF00AF65",
                        "name": "92 - Shiori Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "AA1183296A9AD646A37B7FC3C1B13F05BC8D"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "91C3B9412067C6478C19FB851BA2E19EFD5E"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "51FE568238DE384B4F8A0356581EC6A54FA8",
                        "name": "94 - Hellios Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "FD57CE368A9C77425D7912F697E3613C818E"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "0FCC16EC8F14214F211BD711C5EF156BDE65",
                        "name": "95 - Rya Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "4E071F093F37274AA7993674C1475C10AECE"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "567F1E3489D91446CF4A0ED6AF508D6BB339",
                        "name": "96 - Cristoph Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "2D665A6F2735F9471108EE88A6797F1D9AD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 4,
                "uid": "44866D6153FAB843BB7821C7DCFB05CAAC42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "71A50C5884CC654A72297CF412478F6CE71E",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            2,
                            0,
                            0,
                            801,
                            0,
                            60,
                            -5,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "62722B568E928545061BFC82726F5FAD27C6"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 4.8
                },
                "indent": 0,
                "uid": "5AA3C5FA8EF09347E47B1D007646AD7CA2F4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            16,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB73F2255B5E12473A1B84C13443BB622D24"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 2.4
                },
                "indent": 0,
                "uid": "8224E182406431423D7A24C7878EAFF87AE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            500,
                            75,
                            -11,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D29DF0763F6A5405A9BCDA316439C018DD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            12,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "651109EE52DDD64BCA199416C288F6D08539"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A1EF2721FA63148250B3C33C0AE2EB91E1C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "CB6AB65C40B97149D5489F87CBCD64A559AA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "99085C315463B845B648F847C7A0FF824169"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "CE0A9FAE7CDE984A211A7A78191C59B8A911"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "968709828694A142F63961D54AFF6B288C3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49A52E6C1DBDD94A0A89F179BBA941F11803"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17D0174F0F604744B13BBA585C43F23AA28B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "908BF40E8529D1499A6A478395867DCA3822"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD79D7CF9C0806472B1BF16617FBDBA38B3D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D95869124DBA324DB628C775914277A1B04F",
                        "defaultText": "잠깐!\n파라트라스가..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6B3D7F11945D944191183E811DC1AAF18085",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F35452258AB0F740238B64D3879D75468084"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1618F5A5332C448EE7B6408EB8F656943D3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "74F1B48E102DB645BF4992C7BF1DCF3A91C5"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 48,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "42AA88117876C64BE1686063D0F3EB1D7AE7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "4DDCDE9D7894C84FCE1A0592B383FDA335B3"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 75,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "E4CBF20B597DB34E555B5074CE84C20E71B0"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 54
                },
                "indent": 0,
                "uid": "ECE2047F89130140682AACE50402EEE63B1D"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "358BF37F8C44C64088397E410BEF5C6B8F93"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "963D02B11897A9498A89B407C1560683915F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4E65496B0536464A8E4807789805E9419F7F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E9321D4D462115437769B4E82B19F57A5628",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "05380DEB5697C74D99884EB60FCC6D50DC82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "130EEEC64B91E049852920956DAAE15E705F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E7694311DF9D344AB8997307756C09A009D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "96B6ED3805E44841235910A3A9734AC60475"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F744C3C1516C64F78589EC0420069CB03CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C74C54A320C6E14D7C1A4CC8EDEA1994C99C",
                        "defaultText": "의식을 되찾는 것 같아.{W:300} 다행이야."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line2a.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F3B271C38CBD1849AE6AFB73A3F0064C5055",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E61259FF117A0443708BF408B6D07E97CD1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2DD5316C39C075430379F595F45E468286C0",
                    "parameters": {
                        "values": [
                            9,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "731A76365E94E54AC22A6779D347626D7934"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "099799AC7E1C61498E48AEC5B6670BA55B6C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "93544CF76570C744964AC0449B37D0A35A49",
                        "defaultText": "...{W:300} 돌아가!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "EA945A8B8030B4481D0A8CD17C421A282E52"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F52637EC3AFD1344E68854E8CD08D4E0BF84"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 33,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "968A7E39305C53442A69ABD7DFBEA61E2DC7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "56B3CD791576A740D52AD556477AFAC32352"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9051516D7E690348598947A2F99C87C0BE75",
                        "defaultText": "“돌아가고” 싶다고 하잖아.{W:300}\n시간이 없어--"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line4b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "66BF621477A354498D7A73A64D2A70964E35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA10F72D55003844136AAB26784B0A89B8DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "12F680C17B13584F516BB80161A157ADE973",
                    "parameters": {
                        "values": [
                            16,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45CD4788437EC441F6583984F03F46C8E7EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF5E5C498F9BD64BC63B7EF562745904119E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "DA3E83C0829E644F7C1A6291174FAC0CFA65"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5E8A01B76A22346E089DF16E75564E21187"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "14C1986C7DAC074174398E5296F4956B5B4A",
                        "defaultText": "가까이...{W:300} 오지 마!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line5a.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "F5A530866B4C674ADB5B0AD9A0E5EFBCE449"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "958FE39743994443D75BD252A5DE3E0F3396"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "10BB4B4F7F0793479A5A1A7605056EF2B0A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B209F9431BA4554D6D485765326C56EE1A2A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D65BAF1406C5C246D33A882111936A608875",
                        "defaultText": "... ... ...!{W:300}\n알았어!"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0AC791AF4E93A34C5F3B81E61BACC93F0117",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "963158006066A4429E7AECB84A690900ADF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAA96D444981B0426938F854AAEA5C898F2D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "B53FD5383A27B54F4B8868A87F50F5B759E1"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "duration": 33,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "3136A2077FE43348E5884F5134400F8605A2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "AB9A770C55140744618A8144B839DEB42F37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C395D716773E7437F7BF931CBD1D44DBF44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBC1C7D9607B56409C48D9A91A23356F8025"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 0,
                "uid": "90A7B7114812874BF6596258AC2CF32D5523"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Shiori attack Light.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FAE928686D7BA04B4789B610CBA23AE5AF78"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "viewport": {
                        "type": "ui"
                    },
                    "animationId": "1AFFEEA1713CC6473C384996161CBF444C3C",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 2,
                    "position": {
                        "x": 770,
                        "y": 176,
                        "angle": 0,
                        "zoom": 4,
                        "horizontalFlip": false,
                        "data": {
                            "x": 402,
                            "y": 92,
                            "zoom": 4,
                            "angle": 0,
                            "horizontalFlip": false,
                            "width": 870,
                            "height": 592.5
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "71FA02B378A5464A334BCD56D87ED4DD17A7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 9
                },
                "indent": 0,
                "uid": "763F446164363440B83AEFB32D4E67328CC5"
            },
            {
                "id": "vn.ShakeCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 13.2,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 25,
                        "x": 6
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "49E29F784056F14F542A0723E91C1BFE6145"
            },
            {
                "id": "vn.FlashCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "color": {
                        "red": 248,
                        "green": 220,
                        "blue": 148,
                        "alpha": 255
                    },
                    "duration": 15,
                    "waitForCompletion": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "05294C8C2339554022899F6108E20DE27AC6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Light flash"
                },
                "indent": 0,
                "uid": "0E935DA99197F84C922AAFE5D916BA57EC5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B66DFADA707A7142770BE62504F2576A53AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3FC41D8D724D1745717A77B40D2FE076FD2E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2B5EF441681DF7453B2A93C28C0E88516CF1",
                        "defaultText": "으윽...!!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0ADCCC8C7DABE8416328AC69F9CA82179B68",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EAE368157728114438380539648D3B11F728"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "171BF7F884F0F94C4F38B2445B903B8E3D60"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "536AC4DC45A3694CAE1A3AA2C723BC7A6DD3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3376E197D58B7432028B9D821FC6497F36E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6FFEFB6206403041B61848561BC2C8858DA0",
                        "defaultText": "대체 뭐야...!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BE2491457604D940419B7E8643615584DC7B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FB85BA14614C546875A48E20374CEFE1E94"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "81BAB74D4331B7476C1957E42A2B805F1A87"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "57C592E30E4E1843D12B0AD8EF5551237CF2",
                        "defaultText": "헬리오스! 괜찮아!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "145E2FF05648414BA41A1FF79F27367874A7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B682966F2685C6404E999302260D38119222",
                        "defaultText": "이게 무슨 뜻이야, 시오리!?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "13194CC220EB324FCB1B74A047467DCD613C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "only choice",
                            "only choice",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CED79BC7C96744088381C049D262A34646C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FEDC7AC82F76C84CED6A09396F67CB6762CA"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "only choice"
                },
                "indent": 0,
                "uid": "C5C6D2CE5F23D242E57AC993991D57A6BC60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "58817DE405F47740459847559E2342905E47"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD832D1B2C561846DA783343658098ACBA16"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "15AFA32A2AF2574A3F1A7416EBC6B4FD6C23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEFE04951320774B8B2B94A8D36256D6BEC2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB64C40C6D5A66413C2B07D60C4A993DF7D8",
                        "defaultText": "슬슬 인내심이 바닥나는군.{W:300}\n이번에는 너희 둘에게 무슨 문제가 생긴 거야?"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C10-04_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "8A6B9FFD6FAB2547D8499BA8572D6C732A21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53071C772838874C450B85A1902E0D5EED6D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82EC2AE5272516484D58A5B0144D0E031A87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8238C477CA2E5416D494BA455E21F326966",
                        "defaultText": "리아와 같은 생각이야... 내게 무슨 일이 일어나는 거지?{W:300}\n모두에게... 무슨 일이 생긴 거야?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "74A7EE666EFBD547491AC806BD1CBBE13CF0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AA58F3E52633540836A0D819DADBB7E0973"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF0562073755144FE558E9B19F45062039A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "46A34AE996632648EC79B2B6B58879C83E58"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2972F9C683CD854392683B110CB56C126D11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "69579DD16109D5427B3889E5CDEE5EA28CBA",
                        "defaultText": "어째서인지 이제 파라트라스의 악의가 아주 선명하게 느껴져.{W:300}\n그리고..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E3C5A3BF522B63474F5BCD4312AECA12F084",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B3ABE98A4F5233424E3B3427149DFBAFCD2E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A45372F72C02C44EA05A00A689478B3FD122",
                        "defaultText": "...그 악의는 너를 향하고 있어, 헬리오스."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E16EB7070469F94F5B8A6E7813AF2B4642E1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "017ED0971A87B0481E38B171676CCFFFC295"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64E262710E4C134DA52986A4B098EFF2B14A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A6FDA9B99CAA384869385EF3A0129910A737",
                        "defaultText": "뭐라고!?{W:300} 말도 안 돼!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F317249249B0C24B906935017B0B3220C582",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEB541A96209F545526A21C7D2CA8BEDAD5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "340317F506297447837A51D6C584BC918CD9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "33BA2D7D1E9A984ACE4B7E0679A843D301C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "179198487424E4407278C2E9757C71C64E36"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "7DA8806386AD434C8F3A9B657CD89870791B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EC429B84767D8417888BAB79965765CBF26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "265274B71835024D253A3D858683A7E06FF5",
                        "defaultText": "나는...{W:300} 마침내 모든 걸 이해했어.{W:300}\n이제야 진실이 보여.{W:300} 처음부터 이 모든 건..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "A80949398D9866451B1B26602E7BCFE89207"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "495F7C3117E83543F158AEF1D9257F7FB86B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EA3516DC3DE819463668CC6618CC02E57C7B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B0F1695D4D8FB044976BAE129477673ED4D3",
                        "defaultText": "정신이 혼란스러운 모양이야.{W:300}\n방금 저 사람에게 했듯 마왕이 정신을 오염시킨 것 같아."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line18.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6709BA06274190456538FB20E3241CF0544F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6B071072BB5F042FB6AD92953EADC0A8A7F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECCD89E5271DA446A409BA81252C1AF95905"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6C3325EC1CF26741E099E992F8A3CB9EA926",
                        "defaultText": "이건..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "5F21D7BD0E9B1745E22B8950D9A31EE2F44E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "A8371CF7354E024774493018B46ACF144079"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D19FDEAB28709849052886C63E8A4D662DA9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "476249867A9A35457A9B40341346645C4B0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5100,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D3BF7A71CBB684C398B0F582C06F52A6345"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "3C0FD74A29509146157AF0C58408D52EE677"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "6BD17D6427C02245D07AA6126A41090ED395"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D83A33110A70614A8F4B34B7B807A9CD165C"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "7F582D6473DE1548A689DD583A0C9BA418E7"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 4,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "53738C4235E3D14B0A889051C7CC02F84CC7"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "51942C236ED99041127941A1D55B86214F8A"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "294EBB70479264489E3A3E11BB1FE50BC173"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "34783BE7865AC548F8887F549BBC32269E5D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "DEAC2E8E42921046478B3725A7B07418FECD"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "ED39FBE18E77D644885932927BA0D0F539C0"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "1447730151A1384C7C590C658C7508A7208D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "91DF1F9A031338426F4862A8AFB617B8A7D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6DB6B19D43B5004D3D8970622DF09A6DA7C3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "65789ED7937AD7480228FD028392D7B2D7FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A02A45306E7A194D03598CC9BA3FA20A4F6D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "9F4241BF735448477B292AC6458DD8AC1B9A"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5100,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "01C5BBD291706441051B3CD4262EEB9982DE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "CB02FD74475CA843606B4595798E65A646DC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Flashback starts\n\n"
                },
                "indent": 0,
                "uid": "1B607B6E1391C14FFC7868C6436AF1E2CFE6",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "scene 1: end of chapter 9, hellios falls on the pedestal"
                },
                "indent": 0,
                "uid": "9E53D872745A824C753B8323ECA47313FCF1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B5FA470833EF146434899C7DE77BF6EEB6B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "536F7ECD7E03644BBF39F1B8209DC2B4F843"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6EA5D33B3373164BB129CF88F3A41477D69F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDBEFC658EA928468F6998545066D75FA802"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5141EA73B407443A57B5D37E098270B32AE"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D2C0CBB575011342B69BD218B09D74C65A11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A2305B517F36554C5E9BCDC5463108C6486B",
                        "defaultText": "괜찮아?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "EE04EBA45401C647778957C656B9CADA12AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "354A94FF093DC94CBC5AD966E3152BF2A2BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B5B4B892764224887382273DEEFC5F8900A"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "106FB9CF6F3F06478B6A7422CA77879CDDBF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF1BD01D638804486E894283587944F6F535"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40B53DCD70E76440444ACAD8853FABD6932E"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3B16052B9084A94A819BB4D2B177BB300EAB"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2B7D434B86FBE7453F59C5415E7AF1A2D33D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D6B95043676A89481F8954D2E4F63E10AEF6",
                        "defaultText": "우리가 받침대 위에 바로 떨어졌어.{W:300}\n이 때문에 {SP:2}{C:1}의식에 문제가 생기지{C:0} 않았으면 좋겠는데."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "720EDDA90B2D984D6E8967D8106CB7B51AD9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3ECA30D6A3D134B707B4AA909479C109179"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EED7AC82D40504E5568A1468CD843CAB8AC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "A5CB18C846B69046528B5C905B0095DD5198"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5100,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29B1CBB9945CA6433F5A75D387354A923D2F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "02C6087C564256480F9B4D56B289457A8CA4"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B282EC3F7538F3434B690AD3CBBC6C40A2C1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B79077391834454B5A5B04F3EFBB78402CDD"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "363B6BFF25499640670B04B3A9400ACC7522"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 4,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B1CB7CE71E75D342F2887707AF562C15A232"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F4AF31C16C88D6473898118259D90E7EB4E6"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "363FBDE09608E7497C4B5355A5268F60E61D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "D5E2550E2CFB214AB029334385D797811AAC"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "ADEDF120390D4244CF8A4C6434BD56EFF8D9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8E019231A5640439E798D362251D0FE7AA7"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "model": {
                        "name": "commander.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4994,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 307,
                        "y": -332,
                        "zoom": {
                            "x": 1.9,
                            "y": 1.9,
                            "d": 1.9
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "F087CAFE04EAC847FC79F707706D5EAB213E",
                "expanded": false
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BDA2421687B83447DC4B6A82B0D1AF9C8A5A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "28A3E1F41E56344AC95AB758FBA81DE1DAEF"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5100,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5960DC777A6BF641096A33D072AFD34EADCF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "ED46F61A71C0214767296313E0F678F2F9AD"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "scene 2: C9-03, Saai's words"
                },
                "indent": 0,
                "uid": "0F4CCF9171F5D14A7D29DC020779B35F5A1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "037B963640B5F54DDD6A96B5EE3F2A652177"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC2280F5875A86427B29AFB4D26333E47601"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E4E23FB1D1AF848CC49C5D6F5D9F770F66E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1ACB01DB39C9874C032AE199E12F300D36B4"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "572FCD892434614E433A2FD4EE7B90CDF3F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5EB150C63D8EA144248A44F03E7095A6F41E",
                        "defaultText": "파라트라스의 옛 스승이 병사들을 세뇌하는 “기막힌” 생각을\n떠올리는 바람에 파라트라스는 그들을 죽일 수밖에 없었어."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "22CCE80A68B7C14CE8899E26D28EF0F0291E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "04F919483409274C0D498B292F69041C4066"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A53D49AF536F1741B02A031135AFF4F05965"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E123E668641094F971B4BD17F0B865449DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E25C99E3A8F664C862BE29831E7DFC75E8E",
                        "defaultText": "그렇다면 그만한 사람을 조종할 힘이 없던 알바노가\n어떻게 해냈는지 설명할 수 있겠군."
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Saai",
                        "name": "C10-04_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A57F243E72EBC84AA979CD20CBF9A8090784",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFD67B6068BA6448D51B3C377B6C728EE380"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "A766D3B5585BB1414B391F8591F125EBCDE9",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43704AB5503318430359376295FF192C41F0"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C7AAE776270CD346851A26C119A2C9B369C3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "73742ED8329A8240FD291167E96DB9E91B4C",
                        "defaultText": "파라트라스가 했다는 뜻이야?{W:300}\n당시 저 여자의 마법도 알바노보다 강하지 않았어."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C10-04_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "34FE669159E5F74E9A3AE69421BC0359F1A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E13F075004FC04FF889227448449E99D073"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "DDD0AD108FC02444845849E615760F6DBD75",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "322B37832FED214C4D3B6254AF35EE33308F"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "78E440F11DAEC54B6269A735425EEEE26C4B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E333999D87CA5546B95A85B66CD0B03EA931",
                        "defaultText": "파라트라스 님이 한 일은 아닐 수 있지.\n하지만 {SP:1}{C:1}마왕{C:0}이라면?"
                    },
                    "position": 0,
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Saai",
                        "name": "C10-04_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3688F4C06CD1C448EF48D192DFE9231AE417",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB04A23A633934409D2A90311C33A00A76FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95484DB2388BB74CFB68DFA5D66F7C5AB4AA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "387DCC474D57C44FDE8A04E359C9F9874CEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5100,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11CA0A603EF1704C84499F960728BEE4EFF3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "9419802A9343614DBB495297C67BA61F0313"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F1F761E1598AE44BC09953C8EA6B41625A8B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "853FB977988A964DF61AA111A574DF7F216D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E051470C0706F145B46912A2D0F0022EFB45"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 4,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "64F23715036D0542356B95D20EFC93D92700"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2962BC1613E4B0461B7A2622941C78FEE43B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 10,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "2E95170B71B05849475B9B12F8908A048092"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 11,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B0B8624A9DDC014CCE4B2854DA5DA5669DC1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 12,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "A5BC020E1398F04FE04AC36661F8E4DB5FEA"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "DDD0AD108FC02444845849E615760F6DBD75",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "8113AFF62189F845B4288111AEA64057E3B2"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "1B2F57A66397A3483B0A0558200D509E421E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "439E0D490B4484457C3907706C8BD45730FD",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB7F666C50FDC640B018A8C39AD94CBA574F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "77A0A22657B3584C7A8A53C9692E4DF8A972"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5100,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "4D23EEA915175342678A508879FCF46437E1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "0E2A5C139C8BB9424578C7928DD07165A62D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "scene 3: C8-01, outside of Ferasew"
                },
                "indent": 0,
                "uid": "A987D1A08EB628429769E2B9E9F842D1A3CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5FDB108B59344446B53A81D627AA3DAB8681"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D2D7D81808669471A5A2FB1AF4A169D16DB"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "61E5A99D2B52884A772B28D12253A628AB77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23EEB40D4619744AD628646201B8E2C7A59F"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3A4EAF5D528AF74D149AEB05267E015D62EA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "424B09820D49554F051A334869F6D320669A",
                        "defaultText": "그런데 어제는 어쩌다가 그런 상태가 된 거야?{W:300}\n그렇게 통제력을 잃을 사람이 아니잖아."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C08-02_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "72D451AF62D6314F8F090AC21148155CBFCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7A24EA12EBCF543606839D3AD20EC278BB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A4B58D75467F643102B74B9277C6046C45C"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D31EC9C925BE454E17087E858C9DAE3011DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1361D9A7498A634DE33A569816F643CC9534"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F9253D6D5524684A92699AD29453648ED0F3"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E67335674F7F0242F6998260D89DB7898CB0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5DD86CA66ACEC0483E6AD730A54E3A2EB86D",
                        "defaultText": "기억나지 않아.{W:300} 모두와 함께 있었는데\n{SP:2}{C:1}누군가{C:0} 내게 잔을 건넸어...{W:300} 사과주였나?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C08-02_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C6343AE5138A2349CF999EE2B726C2CDA108",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89E9FDF244A6A4454D09F24634B096E70336"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79AC69864C9CB34F4C3983738C4688B340CE",
                        "defaultText": "그 뒤의 일은 전부 흐릿해..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C08-02_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "42919481628C9348498A2944BBD931E62388",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "47C4D13028DCD04EE898C135D41E24C5C664"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5D5E64B012EB74406086C03876E5E31A9C7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "C99CDAA95DDED1403E0A1AB698475E6F09D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5100,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F13A4037048854897681CE494B4B57CD979"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "3D39F308067B53484D48F8656C02B2034196"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "3C1CB3E78C94E244CE7921844060B1C017F6"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 6,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "53E298872ED0C946C75A56F799F2B62D33EE"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "3778559278A1114B80494055A6985DA6E036"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FBE97F211A99D64C389BB1C15BEF1A80D6BB",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E7377190C436348363A3047205E7EF3C5D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            900,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CD9FAED1266C748F22953E8D155C7FED8C4"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "796E29BD2C75974A09993993CD5DFDAC3C2A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "86BA205E2221C84A5A3BF8D8E3FBD815F04D"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5100,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "C84B716D44E6A1436318CB687908FC084115"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "5D5AF38703AF25485D3B5D217CA0A8314329"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "scene 4: End of chapter 3"
                },
                "indent": 0,
                "uid": "19D584D77B889144995AD698B85B97A4DC05",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "914564530D3FB243D268EB460786832AC515"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87CC8B1690A10840965B500680BA2FE8B63B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1F14AB7061109247F18ABBE7FF9496BE642E",
                        "defaultText": "무니 여왕님은 너를 배신했어.{W:300}\n병사들의 정신을 조종하자고 한 것도 그 여자야."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "180DA95B4D2D93408D8B3811CC2F5C11710C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7B244BC59FE7C34B2E287DC3AEE8F3150E3F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6D9C6F3257398480C69330242D61BD38557"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "660A1C933B1A274A337879B2776371647368"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "791B8AB74DAF1849321A3DD5C15464223054"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F380E9453B8DD848A769CB72A66CBF621294"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "000C41D25862E949AA481DA4115815A22EF8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "87D576D762A2F64B737A5650E1761862A609",
                        "defaultText": "뭐, 뭐라고!?{W:300} 무니가 그런 짓을 할 리 없어!{W:300}\n그 여자는..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line61.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2982724592E1184E5A9BBF84B902CC98E93E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3388E8AD4A919244DA39DE694B597A57543E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "106EA84B22E2F041DE5A0931AE2595956531",
                        "defaultText": "서로 다른 점은 있어도...{W:300}\n내게는 어머니 같은 사람이야..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line62.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "545AEE3655D4E4408C49B5D30C17705E7AA3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F76C8DE4C26164FB7483518CC8856315994"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2883DBA46AE46446DF3A460324697DB27988"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C679BAED339C95403788D411EC1C0E66472C"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A590588E8BA1F74C738A8646FAE943A5873B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "72836D962775C647EF4B06277641599D9302",
                        "defaultText": "그 여자가 알바노에게 병사들을 세뇌하라고\n명령할 때 나도 그곳에 있었어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "109AD54759422248BB6A86536E486ACBB246",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DFC8D5B71F8BC341D08BC338F6F93F9536B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDB05B988D71A541AD4AC350C3C3EB50F01B"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": 10,
                        "green": -5,
                        "blue": -15,
                        "grey": 170
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "88D273478B0A0040CC3AF8262EFC20BE8620"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8497857C3293174E851A8258B16D548B9442",
                        "defaultText": "왜...{W:300} 네가 왜 그곳에 있었지!?{W:300}\n너는 누구야!?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "180391DA01FC04478F88A1D99BB0C3A2675E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D1F3AC08850014BB04B9D06A90CCDB5545A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7C5F1827720774C9F6B36492144D35D9532"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "72AF9EA1876A0845989889D2D6DDC29DA2A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "989C86362E1A084A932AAC0756D08DF56785"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "470096DC3A3501466948BF27FDD0D51084D3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36248C4B5B9363465B8874D6A6D3CA0F6F6D",
                        "defaultText": "내 존재 자체가 죄이기에 줄곧 그림자 속에 숨어 살았어..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1491E3E8468C264BDD89E308381A8A95DC02",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62F43CD5851D634FF149C13855CA7C647305"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3ABE7D6E3642C742B748B296451CCE7B854C",
                        "defaultText": "파라트라스, 나는 무니와 네 아버지 알프리드 사이에서\n비밀리에 태어난 아들이야."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C03-04_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "48D164C377D847482D28CDC7FEE893FFCF0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C4371F8D53F7A6407479CCA626B7264866D0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8E52E2C01A7E2143178BD102A289F1C2BCE6"
            },
            {
                "id": "vn.TintCharacter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "tone": {
                        "red": -10,
                        "green": -25,
                        "blue": -40,
                        "grey": 185
                    },
                    "duration": 0,
                    "waitForCompletion": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5185E9CE5150B245DC592D29AF1B46D2B7E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "03472D703C8E324FB10B32C4DC98848185EB",
                        "defaultText": "아, 아니야... {SP:1}{C:1}거짓말이야{C:0}..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C03-04_line68.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B48724632A0CC04CFA6B49B14303FBE69784",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D96D377F66DA524EDC8A6E376D70CA7C3BC9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81E3CA46232AE0428A18720406AFE13BA8D5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "78C6314C8D3B944099196EC758FEFE1D7398"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            5100,
                            500,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A600F2987B7624F0A79E5D994AC79E29E9A"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "E9C273A18EB2A6432E79AAF37722245A4E1E"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "6BE1C8278012754E09282EC2422FB8C183FA"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 3,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0DCCB8384D8BD146EF9A6C714024C648BCA8"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 49978,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "88EAF72B8351A248772B23F70F85D23DE51B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 49979,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "E1321A751DE1E945213BB5A660299C9CCB46"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 49980,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B67E65B645A123489B2A71023D3E3C5D9F3B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "B8B9F3E235410343B1584ED19EF101CA3440"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "9677383F1A019049854BACF06A477797CE79"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DE0B2B767D47F149BB498527FD744F29E061",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC60126C2CC614447F79B575519E171D7A6A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "6EACFE6390D701404449A2B2D4A723380C6F",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0,
                            500,
                            75,
                            -11,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "12646974394BA54DFA386186CCED2F18C700"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CF4D13964E00248D43A8163B7B95249ABC4"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "3A553F2A52B3734CA13A9805D1FF56ABA9F5"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 5100,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F8E60EB467D7D644AE9A67D5FDA9337AFD1E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "9C741CCF3082F640702A78953C6C71CB7AA4"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "End of flashback"
                },
                "indent": 0,
                "uid": "D3E784E736EF9847EF8A74E43758DCB7E04F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            2
                        ]
                    }
                },
                "indent": 4,
                "uid": "278D57116F16464EF789FDF3DE097CC59140"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4D473E4865B8B54FD64A610057CDA3D3FCCA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4C1E1962FB3D1427E2AAD918C3D878D5D80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA5B8650643A5646719B9A940FDD3F59E533"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "68CE6F273AB1744EDB1B7FE652EF18003929",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9CD26C647409A548766A08D25C05CE146C33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F2F5A9697AD4E2456A78B902C326E713EBBF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "350DBB69381D044F0689E6C1F4404EBCD261",
                        "defaultText": "이건--{W:300} 처음부터..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line35.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "17A67B1656245745D26AF8388713AF1B7916"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "38AEB10A61FDF84B6C587AD023C5F967DB55"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F598852D3739C742BF3BFEF2274DAE6A58A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BB1882FE7DAD024FEA490A1231DC33B6302F",
                        "defaultText": "이건...{W:300} 전부 거짓말이었어...{W:300}\n그렇지, 헬리오스?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "9ABA1E606BDCC74FED48BC959F68E1595775"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "769E6F6B4FB7A4460E5B46F389FF302224E9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7E3CB0144DE2C546D03BC0263FDAE7063279",
                        "defaultText": "아니면 이렇게 불러야 하나...{W:300} 마왕이라고!?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "226D43AC8EFF334F435A2AC6DFFEDD92F8D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30E5417E854F9346DF89207957481E9F2118"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BE73CD4227BD94B41790950E61D70245364"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2FEA0E9236B1D045EA2A4EE6052A0CFA4FC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3BE8D9D132A164DC24AD004CB697C5D6715"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "479022D67CC4B84354785329DF80FF5229AB",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "A766D3B5585BB1414B391F8591F125EBCDE9",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {}
                },
                "indent": 0,
                "uid": "B5C405A6118211440E8937F41121D5BC1045",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1060B26A7270404FFA2BA9A371ED39AA200B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08216EBD30B9D747536BF200AFBB12E8315C",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE38FC5A4C46584DBD190F54CB6FA9C55A06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF8ADA18291F584A1F69D4D53390BB8ECA4A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF553E5736DE334E112B8295EE9AD5C6FFE1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "ADC537FF2688954E232993F0F750078D79F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6321FBF2601C5841E12A4A60944191D16368"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9201F623926B34408B7B30E8FE91FC685964",
                        "defaultText": "...풉...{W:300} 아하하...{W:300}\n하하하하...{W:300}\n아하하하!!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line38.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3FDFD4C069480442A65BDE5676D8B548DB24",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C9BB2E25B0039423418C82353D0EF9A4093"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F15D82D1A43F2444E6A3961E9522434180E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "F0D64A9C54F12247679802591C3BDA3F4BB1"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E57DEE4494F7D746071B7FE6CD38C7E9E4DC"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "9A424DC976B767496D3AC654A652B7C5C4E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "69E2E5A91BFC454E4F9A69F5271597D74191"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "A5EE33AA5812C545DD290627F21FB8757C1E"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "hellios disappears"
                },
                "indent": 0,
                "uid": "D73035878ED2E54C472B9CF48C576AD66D3F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Hellios' name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "CF8741A524716545190BAD25CCD05268BC6F",
                        "defaultText": "Hellios?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5CADA5A54755F94D016B1C30A0B6E004BC1D",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Hellios"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Hellios' name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0E79293F04E25847B10933B41EFF9EA2A1FB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "evil font"
                },
                "indent": 0,
                "uid": "2E59A287034CD141FD888C1738D3E0533AC2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F873C52A1218C44C6989EA25EF0CB99E1339"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DB229CC1738124CEC78BB33D38575167B53"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FFCAC8B3401FF14F83582D108AD1D352103B",
                        "defaultText": "정말 재미있는 녀석이구나, 작은 것."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4738ED8E55AC5745895A9364D973ADDB992C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "010AF2A34477884EC15B4C07D418DEE2BDB6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FC90B528471C147843A81C636E24EF21B41"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "405708E980DFF14B530B5F5703608CAF8CF5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Hellios' name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "72B2419078BFA643F91AA702377C6A2E04B0",
                        "defaultText": "Demon King"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9B829F07237406456A18A9643708CE82D005",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Hellios"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Hellios' name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F0B067D61B37A54C397A7596FE3CE666FD76"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Hell_Teleport.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9BA14E8524A4F14EC81B1CC31775039D403C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            180,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C1CE9833F3476484B4A8734977C434F6D96"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "model": {
                        "name": "Demon King.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 800,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 250,
                        "y": 150,
                        "zoom": {
                            "x": 1.05,
                            "y": 1.05,
                            "d": 1.05
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 9.6,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "8E81DEAB104BA74F996BD232DAAC3153E8AD",
                "expanded": false
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "param": {
                        "name": "PARAM_RED_EYES",
                        "value": 0
                    },
                    "duration": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3E7B103483CAB24C9D6A6B181B3A5A4A678A"
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.75,
                    "idleIntensity": 0.65,
                    "lipSyncSensitivity": 1.05,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 0
                    }
                },
                "indent": 0,
                "uid": "3F9019EE133A01448B3A4C174DB76956CA08"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 42
                },
                "indent": 0,
                "uid": "4468B5DE10B2D34EF3683BF3A4ACDC927531"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CEBD272B39754142DF6872E600B722AEC079"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "6E5DD48D13461649E428850891B82BB65AE6"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D032AB6980C83745F1381263BCD8C954E54D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "2891390144A3E84F693A0047C37809209515"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Hellios reappears, DK Model"
                },
                "indent": 0,
                "uid": "75BD9FFF2AD0884E17290403C0B87F8C1FE7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D65981D36610714AD239A9E9E94C4451AE3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C1B49BD08AB2546DB68267797A7C6C01E1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "C2ACCF3C3969934F673B6F83E820C850D323"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0385B1F87DB0F84B90582F18898951F74FB1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2346CB9050B4E04B74283929B285BB13822C",
                        "defaultText": "드디어 본색을 드러내는군?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "30F4C2A004D9D84C198A37633488DC725CFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1ABAB90B1B57584F5F29105378FC4CF01885"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D433B5D3076DB74C2B3A18E6A4885AE8328E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61E0C3F95AFCD34591992285DBB1D1AE7F3C",
                        "defaultText": "뭐라고!?{W:300} 하지만 말이 안 돼!{W:300}\n마왕은 파라트라스 안에 봉인되어 있어야 하잖아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10-04_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "BAED063F4BA98240EB8878D518ECE271A032",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "034B3FD234A283469F891454DEE57C2398C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D20668D558AA445FC8B9178C6EDCF2542F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B7AC060E185ED84F8A3BC654EF7A66091243"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A1F5FB9E21AE964FCE1A1FE8EA609F6C99E1",
                        "defaultText": "나도...{W:300} 동의해.{W:300}\n어떻게 헬리오스가--"
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "C10-04_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "174F32C16ABC5740F14830F2D9D11B7710AD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C36ABFDD0D81F1472338AE55973BE1961768"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Look_Down.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A17FFA384D90E048F15892A6578D0188C97C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "002A990F43F73044BC5806B8FE13D3C57646"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE4335F9127B354A3F2AB7E03793E35A46DD",
                        "defaultText": "“헬리오스”는 내 힘이 만들어 낸 화신에 불과했다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6AEBAA327A487540E01AA15302079B7211AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD0843C13A070040B35B9FB6D2AE1EE6F012"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33D741727822A847E26A67B8DB23DAC9372C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "252F30581B216445C32A2691B77D0C51FC3F",
                        "defaultText": "... ... ...!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C3A68FF696D176406D8922772F4505A7F057",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "86F7049C167C76420E6BFB84BB8D43FF6F22"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A2ABC44B4255C7457D190651EFDEFDFF4C5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "610964D57778124067499B62B8BEFB333E24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "443811F75B0419403A8AE551183AA32F8AD1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "717421BB5988724464398717527384561A55",
                        "defaultText": "하!{W:300} 참 징징대는 아이였지, “파라트라스 님”!{W:300}\n언제나 모든 것에 불만을 품고 있었어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "DE51106D7A30B8474E589A76FE8793051500",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "32B519E6554D724133497158F67ED8F2AB21"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "82AF12DB7CA4E442EA1844E45D734CEA0EBF"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D57E4AA77E1D2740D77BC8E2554E9AEB6C54"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Standard.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DFBE451A8B0C0149B3489EA556CDFCE2E200"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "703A33E57365224EF869A7708190F6723213",
                        "defaultText": "네 나약한 마음이 흔들릴 때마다 봉인도 느슨해졌다.{W:300}\n네 감정을 이용해 내 힘을 조금씩 밖으로 모았지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B9897DC4023DD84B5939BFB1BD70B627FFF2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9ACCA63A4FE5C548706943A80B001F5E737F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC8EDFF55C68B249A818CBB5DEDBEA02A306",
                        "defaultText": "그렇게 스물한 해 만에 마침내 이 몸을 만들어 냈다!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "99B67459107CE643144B3E65741418308E0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7EE6B0798E94334E92593796E442CA731135"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AB6F8C1A2A541948CD9AF0890FC030E81315"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1E68095637A7E64A1B7A1BC2203D30218FBE",
                        "defaultText": "이건...{W:300} 말도 안 돼...{W:300}\n지금까지 줄곧 네가 내 정신을 조종했던 거야!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10-04_line50.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "82D02CC78BCD9648E15931B61EAF56CF86E5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B3DF8F31592644A6559FB975F5947B6F51F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if affection is very high"
                },
                "indent": 0,
                "uid": "757FDDDD6C6E2740352A53042FA412D8C0F4",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Ornières x Hellios",
                        "index": 402,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 58,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0284BFE93264474D044975955546EECB10B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C2130224BDD8547788A7269FF294252EE70",
                        "defaultText": "나는 널 친구라고 생각했어, 헬리오스!!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10-04_line51.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "8E16703E551FB3454518A0A6F47E870DE4F8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BA3F89C868BFD2472359E58700843BA822BA"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "082274B91236C649684AA9C212843BAAC3F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "D0B43C975D580646E9686BA5C07DA95E98C0"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "Demon_King_Hellios_Crossed_Arms_Look_Down.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C2C9AA8428EBB249E838F47634EB2EC62814"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BA5D6C80DAF41413D4860911F16AAE1C5FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DD9C2D5B221DD64031385351AAE8BA1BF004",
                        "defaultText": "하하하!!{W:300} 토할 것 같은 소리 하지 마.{W:300}\n그 실망한 표정은 뭐지?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line52.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "43E60CD430D81147AB089164D25B7DBD7D4E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B643AAD770B394112289BD8263B0EA0A42E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8637EF247A53245868AD9C38A6236658E7F",
                        "defaultText": "넌 내 손안의 하찮은 장기말일 뿐이었다!{W:300}\n망할 마나크레스트가 내 힘을 방해한 게 아쉽군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line53.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "13C0C8CA49ECF84A2D796651070CB0EF89F9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BE4635630D184487728C57939A7AF3DBE07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70DE497E32276441132803B83DEDCC463798"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "274C13D01345874D2288EBC2C548367CE5FD",
                        "defaultText": "마, 마나크레스트가?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "08B6D40889E899474028F0C88A8C2F2CB553",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "879CBFB84FD9F24AC988B1864D7435C19A27"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18563F8F5FEFC14BDF394958469A2C9D73D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "ACA68B35351C264D2C2AA3B676AC5F1F212F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BE4C62CA1B4D12463B3976B2413AFB96237C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84EAA69179E4624E1F8A21E11FDF13FE3AC9",
                        "defaultText": "하지만 왜!?{W:300} 처음 만났을 때 왜 나를 죽이지 않았지,\n헬리오스!?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line55.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "A19D97C54046B442921A480619255FB32418"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "08B705092DB8A244C05BB2D667747752458F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "DAC48B814623C9463B288884B3BE5C5BFF2B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "073B838E1D6063409E28476384129B8A52C1",
                        "defaultText": "네가 잘 알고 있을 텐데.{W:300} 영혼이 묶인 채로 네가 죽으면\n내 힘의 일부도 너와 함께 영원히 사라지니까."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line56.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3F30038F433F11422F497DC121EBD9772628",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1313F8251D73984887796BB67F2915AA7FA4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F29EFDCB4E61A0459C583D87A876239FE67B",
                        "defaultText": "역대 그릇들에게도 이미 있었던 일이지.{W:300} 정말 불쾌했어!{W:300}\n그래서 우리 영혼을 “자연스럽게” 분리해야 했다."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line57.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B34B31D395A76044483A5AE999A9B1290239",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A3DF2BE5D7C2349D759AA21FE2494FAB4B9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "91C5ADBF57E89741BE0AE072B29619185A24",
                        "defaultText": "봉인을 없애고 네 성가신 마법으로 나를 통제하지 못할 만큼\n너를 약하게 만들어야 했어!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line58.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "804522AA79226846891BFC76F3BC079D7CB6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2324F884F1022485C7BBD119109AF543502"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05F966B6197EE049CA68C692E7FA06705833"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "60B2080B2D29184128694C9782C9BF8AA6BE",
                        "defaultText": "지금까지 일어난 모든 일이...{W:300} 네 탓이었어..."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line59.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "D32A35A0270DC94EAB696BB10CC07C1919D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B097E4B35B2F546054B7643C355F895FBAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8F644D83674AF34BC23843C6A603ECF14537"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75AF3C8C8A4543437399D747DDF1906090CA",
                        "defaultText": "솔직히 더 어려울 줄 알았지만...{W:300}\n결국 너와 네 조국을 서로 싸우게 하기만 하면 됐지!{W:300} 아하하!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line60.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "E9AC33485DF5C449784A12A40B002576506A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C195A39D3D538740675AFA14176DD30D81E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4CF50408785E284F048AF9F3989B658066AD",
                        "defaultText": "성에 있던 바보들을 세뇌하고 내가 네 편이라고 믿게 했어...{W:300}\n그 뒤에는 계획한 수를 하나씩 실행했지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line61.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "51333A482E05114EC559D7D1CF63F3DF2D5F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A81F95F37907F840EF3A32F534ED244B1A90"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "380BDAF12092F84491181D73EDE07F4ACB4E",
                        "defaultText": "물론 넌 나를 믿었어!{W:300}\n심지어 내가 네 오빠라고도 믿었지!{W:300} 하하하!!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line62.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "EDCB9D931E08A5442089DE45B59D8035587D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "96C79CAA72B8B241B14916D35DF32D77EED4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AAA582952842A64D59897DB40F676B69F38B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "22B4303634A700422D5A5573158980F0D6E4",
                        "defaultText": "너...!{W:300} 나를 이용했어!{W:300}\n내 백성까지 이용했어!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line63.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "50F30B2B128EC7468A8BD5F3663F9CFAA6FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FCCE8C61E0D2544F46BA298F4EF2B9F388E"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "01_Serious.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2D23094284A117463A4A4D85A54AB03E1728"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E13BB2612CA574A017924B550CE823AC58E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "266422C72E4082471D786197FA197570D93E",
                        "defaultText": "그래서 어쩌라고?{W:300} 나는 마왕이다, 멍청아.{W:300}\n원하는 만큼 거짓말하고 죽일 수 있어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line64.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C2C1CBE4536DF84FC69AF4E5FF35FF0DDC0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5E241878D3F924F9C3A1654D2CB2A309F42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "42018F1D03A1A841342836C2B7285A6778B1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94B8A49136F4844C0259E8518B7CACF9ECA8",
                        "defaultText": "진심이야...!?{W:300} 우리는 함께 싸웠어, 헬리오스!{W:300}\n함께 먹고 마셨다고!{W:300} 그게 전부 무의미했다고 말하는 거야!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C10-04_line65.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "17A66C612BC8B0415B3A05553AAA44126CD3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "689B23C18F0C104FE49959E1312F72F482F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F91D5220469D14EEE6896E4F488A4160F34"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDA302230BFB2445E10BB0D7E87F755A51A4",
                        "defaultText": "무의미하지는 않았어.{W:300} 너희가 그릇을 이곳까지 호위해서\n내가 그릇 계승 의식을 오염시킬 수 있었으니까."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line66.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4FA604FF52E0C34220987F67A5BC4B1063B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A466D3A61196241CE2B90C9F5A876B9ADDD"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "486AF7686815D54CF99B245269489E09F47E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D05A701E3C5CD14C4028DDC41C580AF9829D",
                        "defaultText": "심지어 그 아이를 쓰러뜨리고 몸과 마음을 한계까지 몰아붙여\n마침내 나를 해방해 주었지!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line67.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CE18B3ED3CF4064614892371A01099F976C8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD21D10B19C3774849593735F4CBFD90BDFC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7278A80C7633F24B9C0840927352FE01D131"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "CE609D361EC9694BED39E1907814B0C7A721"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E30D2E970D28A04833591E320C6CAC9EAE09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2F6CF9E015A35495D390E8310AB763ED4CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "660E142D5F5EB9473D6BD8507F8EF45BEE49"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BBEC55B8698B384D10285CA36CCACDB661BC",
                        "defaultText": "어떻게 이 일을 예상하지 못했지...?{W:300}\n왜 내 힘은 너에게 통하지 않았던 거야!?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C10-04_line68.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9E9B1B866F637147AE3B8EB24AF460FB37EA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90B086485774B246FA49795776791E24338C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FF758D19C1EB042E349D6B694FC652104AD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "20B351BC869BF146680A1C2425C4FCFC84D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "886F32CA6412394FD57A67C5674CF2257360"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "0E29DB0F5C7D3345754979F8FFB1F7C2AABF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "478C263830C9154C480BA485332DEDF8D213"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E5424363F59B54AAD3B44C22F81914AF264",
                        "defaultText": "용서할 수 없어...{W:300}\n이 모든 일은...{W:300} 절대로 용서할 수 없어!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C10-04_line69.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "5972F68E155E2745CC2A9827B6369F28DBB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DE33DC647A79541367B3B32F2096DD42109"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "03_Angry.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3C903EB21082004C377B19A6AF9D74978810"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "DC10FCDC542C9644611A0ED9712D9B1F4181"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "06_Idle_All.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2C3D6C1B6DF0D946E4996017753480737E10"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "032B63843CC407498F1BF764475480FAD69B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CCCA3DB12093D143CF5A6963BF4D503E1FAA",
                        "defaultText": "정말 용서할 수 없는 건 너 같은 꼬맹이가\n나를 수년 동안 가둬 두었다는 사실이다!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line70.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ED338FCB04F7924AA38B9D20BA145268539E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5D6DAA4F249953411468DC463A1DB1C4CA51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "29373D1E86EE134E915943738605B289314D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9B4694932B7DC143B868CEE3572DDF7C44FA",
                        "defaultText": "하지만 다시는 그런 일이 없게 해 주지!{W:300}\n이제 죽어라!!!"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Demon King",
                        "name": "C10-04_line71.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ED1D3D8A53CBC74839283E428CF2082C93CF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "33DDD6E44888F748E61BC9477E1CC8EEFE9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D6E0BEAA3B96804E016AAAF8761EC16F70FF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "95AEB06B556FD6400468F8C7196803A4C76D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BCFB2398B33754E2179567661B2576BE838"
            },
            {
                "id": "vn.L2DMotion",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "loop": 0,
                    "fadeInTime": 1000,
                    "data": {
                        "model": {
                            "name": "Demon King.model.live2d",
                            "folderPath": "Live2D",
                            "hue": 0,
                            "opacity": 255,
                            "blending": 0,
                            "tone": {
                                "red": 0,
                                "green": 0,
                                "blue": 0
                            }
                        },
                        "motion": "00_Default.mtn",
                        "position": {
                            "x": 0,
                            "y": 0,
                            "zoom": {
                                "x": 1,
                                "y": 1,
                                "d": 1
                            }
                        }
                    },
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "fadeInTime": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BF7A59693650824A256B33E8D15507300A73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "0708048657768342AD296D87704068217D59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D11A411C8A77F1445018C5C6BB0A86656799",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B3E623DE38B8E3442229EC598213973BCDFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1E8C396462160048620BB661717B45EFC46C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D2E052D1E58C446DB29C5910938542D1549"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "param": {
                        "name": "Livello",
                        "type": 0,
                        "value": 1
                    },
                    "targetVariable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1B760902792FF141411886F150A7C56CC084"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero Multiuso 1",
                        "scope": 1,
                        "index": 0,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "Numero Multiuso 15 bis",
                        "index": 174,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 4,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9132896C838C0349601934969885DE94258A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "08B6930722F90640139BB772D8B05FFAE61F",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            {
                                "name": "Numero Multiuso 15 bis",
                                "index": 174,
                                "scope": 1,
                                "changed": true,
                                "domain": "com.degica.vnm.default"
                            }
                        ]
                    }
                },
                "indent": 1,
                "uid": "19F5C1FD87D0A8458A1BEBB8EE8891E379CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B153D2291649B7460E3B95098FC31B34C4A4",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            8
                        ]
                    }
                },
                "indent": 0,
                "uid": "086B19D67B04A34AA528D7344995407CBB10"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "param": {
                        "name": "Salute Attuale",
                        "type": 0,
                        "value": 200
                    },
                    "numberValue": 100,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 0,
                "uid": "EFAC06357DA9044A921BD6F7AE79804FB72B"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "7CF9F2719DDE604484080FB34135E1165CC1"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Black_Transition.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AD760A1E32070740A43BB958E207A438F6F1",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255,
                                "color": {}
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1300,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 75,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "19.png",
                                "folderPath": "Graphics/Masks",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                }
                            },
                            "vague": 50
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0,
                        "zOrder": 1,
                        "blendMode": 0,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "BBB5C9D165C1774F5E59BEA8A8E22CAA19AA",
                "expanded": false
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "ADB9991F8CB151477B5935E1462DEEE42621"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "00E490CB68ED224D1E2B142158B274458754",
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "77F4CA63866CF745C72985B861481DBA2B81"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B0A093064365624F5828CCD7BAD7C6708EAB",
                    "parameters": {
                        "values": [
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "ED44844F07A473482A189EA6EC011F5EEB24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B8327CDC5C57C1491078E3D1B12DA412BC4D",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            0,
                            "97B511787039D74EA03AEE256702FAC6DF4D",
                            85,
                            2,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "",
                            0,
                            0,
                            "AE168532797DF8472D399BF80055AE7C7F9B",
                            "Graphics/Avey's Battle Backgrounds/Dark Ruins night.jpg",
                            "6E5DD48D13461649E428850891B82BB65AE6",
                            0,
                            0
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B2686322507F98434059DF08A76C9BD52AE1"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "AE168532797DF8472D399BF80055AE7C7F9B",
                        "name": "C10-04 Battle! VS DK Hellios"
                    },
                    "savePrevious": 1,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A72CADBD9EE7E647175BED2881F44BA434C8",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "C12BCF35747D2840788910A0732561369F6D"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "6EE7805E7502C84C721AE4F81CBB4F23156E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "70E220D11F799843D048731684E2BEF6B26D"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "2625875802624048DD48B92147BA4BEC2635",
                        "name": "C10-05 After the battle (VN)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7C6D173186E95247EB0907069792E2A44608",
                "expanded": false
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Hellios' name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}