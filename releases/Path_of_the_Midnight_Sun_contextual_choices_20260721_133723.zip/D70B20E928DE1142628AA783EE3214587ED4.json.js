GS.dataCache['D70B20E928DE1142628AA783EE3214587ED4'] = {
    "uid": "D70B20E928DE1142628AA783EE3214587ED4",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-11c Hot springs CG (Men)",
        "type": "vn.scene",
        "parentId": "A7FCFC4348D2B5495C78E1E2314C71FCF916",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 23,
        "localizableStrings": {
            "A90B2207992A914D70497F233B0585413AD5": {
                "t": "Haaah...{W:300} I must say, we really needed a little break after that fight.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "32D05CF54BF043499F5BDBE8D80AFEF5D269"
                }
            },
            "690D26F526A02449AB2ABC16D07DDE575EDF": {
                "t": "I agree. This place is awesome!{W:300} I didn't know that huge pools of warm water like this even existed.",
                "d": {
                    "cid": 0,
                    "eid": "B4C5A4B5102C3741FE29079777C50DF0F2AE"
                }
            },
            "DFEC910C1F189342858AEA63D54C4C3EE4FF": {
                "t": "Come on, buddy!{W:300} We used to bathe together in the hot springs of Sacrépilier in Pylum all the time!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "390432EA61C0A549F4781ED2238344C4CB2F"
                }
            },
            "6B417DA31C649142AE581480792A06DEB348": {
                "t": "... ... ...",
                "d": {
                    "cid": 0,
                    "eid": "F2E930F763C6834D8B296D42FF7DE51D82E4"
                }
            },
            "A4D36D2188BEB74B5B5A4E9837ADC5A752F0": {
                "t": "Woot woot!",
                "d": {
                    "eid": "223074ED8F58B846C128F7385A8D02E3024B"
                }
            },
            "FA79AEA577E6C345F44B51B3CA984112A586": {
                "t": "Woot?",
                "d": {
                    "eid": "3A789364034D584C92791957A666921BA91F"
                }
            },
            "5B15AB4F40B95543C11831F13C984BFE0673": {
                "t": "Woot!",
                "d": {
                    "eid": "484572EA6B43E645B05A2DF68D774668F5A9"
                }
            },
            "05BC4141285B79421729B7349CFAD6779A00": {
                "t": "Woot woot...",
                "d": {
                    "eid": "8E3109511556694B4979AF0688452356BD8F"
                }
            },
            "1967CE402B05E6489D2AF114D9337A68AED6": {
                "t": "Exit the hot springs?",
                "d": {
                    "eid": "D18E84154E627344D56AEDE01653BDEBB059"
                }
            },
            "4D56C3661609C04BBB38D7324F1B3F80DABF": {
                "t": "I find that hard to believe...{W:300} After all, I would remember those ridiculous muscles of yours.{W:300}\nAmnesia or not.",
                "d": {
                    "cid": 0,
                    "eid": "4044C9F15DD7994168692BD609509D9D76F6"
                }
            },
            "3C01980166D2624ADE8A4A41BFAD3CFBAFED": {
                "t": "Say what!?{W:300} Are you trying to insult me!?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "3352158C21178849544AED80518FA4157E09"
                }
            },
            "AC87D66C5ECE3749411B6908F676BD5B69E9": {
                "t": "Yes!{W:300} Huh, actually, no!{W:300} Can you stop taking everything so competitively!?",
                "d": {
                    "cid": 0,
                    "eid": "2F37913000A1364E3C895FB273A6DB858D77"
                }
            },
            "F79180E16FBC534FD38A7D202E61D394F0DB": {
                "t": "Lower your voice, you two!{W:300} Faratras is bathing in the neighboring area and I don't want you to disturb her.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "751B73AE666E61470A4B50526A5E3DD46A4A"
                }
            },
            "592BDDE01308764DB358C2D134D553836CCF": {
                "t": "Is-- Huh...{W:300} Is the girls' pool behind this wall?",
                "d": {
                    "cid": 0,
                    "eid": "ABB4E9438D51584A019804371CE22D8A28F5"
                }
            },
            "C9840ED716B0D0458D0BB5B23B87839769CB": {
                "t": "Don't even think of doing anything funny, dude!{W:300} Princess Rya is there too!{W:300} And I'm a man of the cloth!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "A0E777D4881F7349393902983745593F87D0"
                }
            },
            "728ABA4840470541BB49E277AC5C11EE7AEF": {
                "t": "As I said, Faratras is there too.{W:300} But you know what?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "C90DB3EB590DF746564BC7E5108384A8B597"
                }
            },
            "3A20E55A2436A8462C3ADBD52E80BB6883F1": {
                "t": "A little exercise after a bath would be nice, since you seem to have an early death wish.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "145D62BC28725342111AECF22C7A3CC62B75"
                }
            },
            "963F457D4C9A9644723BE407C6106A564757": {
                "t": "You guys got it all wrong!{W:300} That didn't mean what you think it did!",
                "d": {
                    "cid": 0,
                    "eid": "4E43108684BAB049B81807F7DDBE5D2DE2A8"
                }
            },
            "06DBC74B5B1B7849CC2B55B10D5DF4B031EB": {
                "t": "That MIGHT be true, but having extra security can't hurt!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "078207323169D44D2F1A8148A32957A69D2D"
                }
            },
            "4209054747E5724D686B10D594974147045F": {
                "t": "Considering how sarcastic and vulgar you usually are, I'm allowed to have a doubt or two!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "BFAF9888125637487F8BCCC918C9A4EAA7E4"
                }
            },
            "50878BDE54C7D245176BF4323376E2617090": {
                "t": "Didn't I just tell you to lower your voice?{W:300}\nIt's not time to fight...{W:300} yet.{W:300} I need to rest properly before punching your face in.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "24BF99F839EE0549376AE793AD5802DA986E"
                }
            },
            "E897AA4D70030643D0888D3754194C9DE26F": {
                "t": "Besides, it seems we've attracted our furry friend over there.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "AD2F697D661702462B4B8C1649EA832EA880"
                }
            },
            "24E18951399C464D462BDB867A093D4FF7D1": {
                "t": "Hello.{W:300} The water feels great.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "273114E420D5C34D9B7B1273C8E7653B05CE"
                }
            },
            "92679F8B702DB14BAF9B99F5A098D8387B5B": {
                "t": "Hey, if it isn't Luckos!{W:300} How are you?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "5D5DC6888B4AE74D1C9BF0F91F6B3C8F49E9"
                }
            },
            "286FFD393FCF51493F682C36F1E7FB946CA5": {
                "t": "Wanna come here and have fun with us?{W:300} Good boy!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "38DB9D71444C494AB37BD4B0FB5C2C593A79"
                }
            },
            "C9E98C6778978746B458D875565533C0E5F8": {
                "t": "No way!{W:300} And what is he even doing in here!?",
                "d": {
                    "cid": 0,
                    "eid": "7E2E56564848724CA89A9C17336AECF8BFB4"
                }
            },
            "BF14AFE54D5F93481C99BDB15C143E476497": {
                "t": "You shouldn't interrupt the private bathing of us battle-tested men, Luckos!{W:300} It's our only chance to recover from the horrors of war!",
                "d": {
                    "cid": 0,
                    "eid": "7F942A281FC397482D4AB5725DF0DC94B8B3"
                }
            },
            "2685828C9BDA564D8F7952365EA96AA86913": {
                "t": "Are you sure you didn't just want to peep at the ladies?",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "3DBA6F4215059243C918B197710E7C7BA779"
                }
            },
            "7D2DC4943608634AA73A3E34E6C2708155DD": {
                "t": "Besides, isn't Luckos attracted to you due to the Manacrest?{W:300} It's the whole reason he's here to begin with.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "91DD9D786876F8419B2B93F7237F8F798E23"
                }
            },
            "8B1A8E8249A81140504B7F346F29F4743A03": {
                "t": "Shut up, you hooded ruffian!{W:300} Whatever happened to your trademark anxiety?",
                "d": {
                    "cid": 0,
                    "eid": "95DD318D2B686747E60B3BB470B2F50B40AE"
                }
            },
            "4DEA99E46548C447EF8A767693D851EEC91F": {
                "t": "And I don't even have my Manacrest with me!",
                "d": {
                    "cid": 0,
                    "eid": "95ABBFD619BAA74E3549FBE64FEC45FEC3FB"
                }
            },
            "0D22FB651E3251482B49BDB870E3D2EB1221": {
                "t": "\"Hooded... ruffian\"?{W:300} You seem to forget that you're talking to a prince of Hoikade.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "937E82BE798F044F8F583F3600907EB42620"
                }
            },
            "17E883151420C54F4958065513DC551024BF": {
                "t": "Oh, I'm going to enjoy seeing you executed for your lack of tact...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "79B19A1739A26643D4193080E48A4770917D"
                }
            },
            "08E1FFDE0D2A684677695EF37163D208737D": {
                "t": "No one even knows you in Hoikade!",
                "d": {
                    "cid": 0,
                    "eid": "0FDA4DF390A4E346A45816A50C77C6CBB030"
                }
            },
            "8C704A4B5BD00346D59882C1739A1F15EBC0": {
                "t": "Hey hey, things have really heated up around here, haven't they?{W:300} Hahaha!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "30B974A666D5A84D012944D6C80DD8D310E0"
                }
            },
            "2A06D37A8A96D2489F790DE4C9CD2411FEC0": {
                "t": "You'll scare Luckos if this keeps up!{W:300} Come on, man...",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "B2CB51B304DAD3461B88F2A27AAF4BC23491"
                }
            },
            "C6DA5055340A9349BE3AAA18825EA2156231": {
                "t": "What are you talking about?{W:300} Hellios is the one provoking me after asking us to be quiet!",
                "d": {
                    "cid": 0,
                    "eid": "04BE33531C4FB84BAE2B604819A6B5F0C552"
                }
            },
            "477F134B4B788640048A43E7DA7D65ECCC4B": {
                "t": "And your 'thing' is showing, Cristoph!{W:300}\nHave some dignity for once!",
                "d": {
                    "cid": 0,
                    "eid": "0DC823F007EED74BB6691E055A4ECFAB4F1F"
                }
            },
            "10DEB66D3BDAD748894B5301769EFCD530E9": {
                "t": "W-Why should I cover myself in a pool!?{W:300} And why you looking in the first place? And what's gotten into you lately?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "9721EF2A8E7CF744FF7A32F73D642A3F2E0E"
                }
            },
            "E73EFC776ACCB24E813BACA8FBAB08D188AE": {
                "t": "Either he is agitated because his chance to be a pervert has not been realized, or the heat has gone to his brain.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "CA1EE4E98DD126486279CB322D2593931F8E"
                }
            },
            "2110E47227E95348F879D394B824F9B5A020": {
                "t": "The first option, you say?{W:300} Poor man, in fact he doesn't remember any of his lovers' bodies...{W:300} if he ever had any. He must be desperate.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "55C3CA2B36D924427A1B0CA13769EC0FF4E5"
                }
            },
            "37815E280EEC0440886AE3D74457D4675F35": {
                "t": "Must be the heat then, eh?{W:300} Poor man...{W:300} He didn't have much of a brain to begin with, and now this happens...",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "027184FB317D7247FD4803168EE6F810B167"
                }
            },
            "95B8656C61E0C348221BD10380100C318BB4": {
                "t": "STOP TEASING ME, DAMN IT!",
                "d": {
                    "cid": 0,
                    "eid": "5133BC3C31666943CB1B08385E0F7A4CABF9"
                }
            },
            "401C51D07E277046AB6B8627D1671AAB6C41": {
                "t": "Hahaha, who knew it would be so much fun to spend this time together?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "7F6A4BC075041348DC7B7A365FC77B323C26"
                }
            },
            "070305E95F47544FE58AC8C59C7A2BF0B48A": {
                "t": "Hey! Let's have a splash fight, friends!{W:300} I call dibs on the holy water!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "6E6D55774738564B0E7A4D425E4BE371EFB4"
                }
            },
            "DB5ECF0A8FA57843AA7B8B43739C80FBBFF6": {
                "t": "...{W:300} Count me in.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "D444650271B70741271A4211BBF7BA3A648D"
                }
            },
            "E31C186E732C714DF66840B41A3A22453B5D": {
                "t": "And Luckos, if I were you, I'd get away while there's still the chance.{W:300} I wouldn't want to get you involved.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "4D039CA297FF1647260883D735409DAE5F28"
                }
            },
            "2C48B25949AEC4481D3B52238F1E04427E01": {
                "t": "ARGH! It's all your fault, you treacherous mini wolf!{W:300} No meat for dinner tonight!",
                "d": {
                    "cid": 0,
                    "eid": "1CEF68D77DA90642206BFF192E6869271DFC"
                }
            },
            "50E889245AE99148A8494BB3CA46CF617109": {
                "t": "Luckos!{W:300} Don't make me angry now! Let these battle-tested men settle their score with a splash!",
                "d": {
                    "cid": 0,
                    "eid": "BBA8057041207745053ACFD699C3B9F4F69A"
                }
            },
            "E5B351E93CD718478F7A2DA5395707B3A85B": {
                "t": "Are you staying?{W:300} I see, you have pride in your heart after all.{W:300} But I fear I have to agree with the knight here, this time.",
                "d": {
                    "cid": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "eid": "DB2A89CB64D723421B79ECB6B83F3E60D73B"
                }
            },
            "756B65C45AE0624B8B9A8877649B2139E580": {
                "t": "I have an idea, buddy!{W:300} Why don't you go see what Rya is doing, if you haven't already?",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "81D7819E7729B44DC52B72C79E000BCE82C0"
                }
            }
        },
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F6B378D227BB06473469D0143EBCF78E65A3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "45DE602685EE2248AB3B5D3708BF9583AACD"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 4,
                "uid": "6426A8AA849772450F58EE4237C26D8464FB"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "scene"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1,
                    "blendMode": 0,
                    "zOrder": 1,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "Hot spring CG BOYS VERSION.png",
                        "folderPath": "Graphics/Pictures/CG Gallery/Chapter 8 CGs",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "expanded": false,
                "uid": "FDC383F7630F7142E57AC9C7A46D1F5C431B"
            },
            {
                "id": "gs.PlayPictureAnimation",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 2,
                    "viewport": {
                        "type": "scene"
                    },
                    "animationId": "52DAEC8C8323124E341B618628FDDD3CC158",
                    "predefinedPositionId": 0,
                    "blendMode": 0,
                    "zOrder": 2,
                    "duration": 0,
                    "origin": 0,
                    "waitForCompletion": 0,
                    "positionType": 1,
                    "position": {
                        "x": -6,
                        "y": -40,
                        "angle": 0,
                        "zoom": 4,
                        "horizontalFlip": true,
                        "data": {
                            "x": 0,
                            "y": -20,
                            "zoom": 4.7,
                            "angle": 0,
                            "horizontalFlip": true,
                            "width": 2110.3,
                            "height": 1189.1000000000001
                        },
                        "color": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "alpha": 0
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 0,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "52D4124542F7B642566B5D53FA71A6693167",
                "expanded": false
            },
            {
                "id": "vn.SetObjectData",
                "params": {
                    "objectType": 0,
                    "number": 2,
                    "numberDomain": "com.degica.vnm.default",
                    "layer": 0,
                    "characterId": null,
                    "field": 8,
                    "numberValue": 180,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 1
                },
                "indent": 0,
                "uid": "310FEC308C632344BE1A16064D5FD9EE6176"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 320,
                        "y": 320
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6757B1163EF9144AA22A7D4106C9B91B5EC4"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 185,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "53BA41DA173E5747606BEF97DFC2EF382E69"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "356351F22030E449655B55F1442DB91C0D14"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C6AF3DFB0FDEF8406879AEC3F1FE008E3596"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "BD00B14A08A4D34AC57B4ED73C75BB1F006D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "93A990527CD5C1428218FAA98AD722783F44"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2CC8BECC12F8B2492D3BECC5A7DE56D2ADD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06A0A4661AD959423F0831977EEFD8A397A4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C8151094330794441B387963CE8B4842B355"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A90B2207992A914D70497F233B0585413AD5",
                        "defaultText": "하아...{W:300} 그 전투 뒤에는\n잠깐 쉬는 시간이 정말 필요했어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "32D05CF54BF043499F5BDBE8D80AFEF5D269",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D69C6CB1463D746BE39A5786CDA16156AAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDDD7E710CE4E84C7A284C191B6760E70525"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "690D26F526A02449AB2ABC16D07DDE575EDF",
                        "defaultText": "동의해. 이곳은 굉장해!{W:300}\n이렇게 거대한 온수 욕탕이 있는 줄도 몰랐어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B4C5A4B5102C3741FE29079777C50DF0F2AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F82EE03C5F7B2748DF9A60941E31F5B1796D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4555D2D085A9874EF0291BE4ACFA370BED6B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DFEC910C1F189342858AEA63D54C4C3EE4FF",
                        "defaultText": "왜 이래, 친구!{W:300} 파일럼의 사크레필리에 온천에서\n우리 늘 같이 목욕했잖아!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "390432EA61C0A549F4781ED2238344C4CB2F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "631063BD801F4740715A5D07A3203A00BED3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83711E9D60E34048A74AD95343FE3817B9BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4D56C3661609C04BBB38D7324F1B3F80DABF",
                        "defaultText": "믿기 어려운데...{W:300}\n그 우스꽝스러운 근육은 기억했을 테니까.{W:300}\n기억상실이 있든 없든 말이야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4044C9F15DD7994168692BD609509D9D76F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5DF461AB65BED449241B84E1C7C6B595A54E"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_2.ogg",
                        "volume": 100,
                        "playbackRate": 83
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "65B0BBFB785F434A4139F3C457B56A231E41"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 0,
                "uid": "8D9368DB70ACD1408F18A0642D318C760EF8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "17BA37AB48F081415A788C97898E844582F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C01980166D2624ADE8A4A41BFAD3CFBAFED",
                        "defaultText": "뭐라고!?{W:300} 지금 나를 모욕하는 거야!?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3352158C21178849544AED80518FA4157E09",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C3170572A522346AC48F8749B1E01A15AF7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B05F6F98453AE94F7F1BE2D368E7A4A16B1C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC87D66C5ECE3749411B6908F676BD5B69E9",
                        "defaultText": "그래!{W:300} 아니, 사실은 아니야!{W:300}\n모든 일을 경쟁처럼 받아들이지 않으면 안 돼!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "2F37913000A1364E3C895FB273A6DB858D77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BD2319470C5C344403A93331A19B3DB0DBE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFAD384C7D80C94C82495D169CA582E8FC61"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F79180E16FBC534FD38A7D202E61D394F0DB",
                        "defaultText": "두 사람 다 목소리 낮춰!{W:300}\n파라트라스가 옆에서 목욕 중이니 방해하고 싶지 않아."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line7.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "751B73AE666E61470A4B50526A5E3DD46A4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "49D7215672F0314C3088D05364F585DF7BDD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EE68B2A4357404C2B3A9E44BE3094236B5D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B417DA31C649142AE581480792A06DEB348",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2E930F763C6834D8B296D42FF7DE51D82E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "905A334A042C024FC5389E99A73D711EBDC1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "592BDDE01308764DB358C2D134D553836CCF",
                        "defaultText": "설마-- 어...{W:300} 이 벽 뒤가 여탕이야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "ABB4E9438D51584A019804371CE22D8A28F5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2552E7572FDCC9436A7808C3C415563BAEE4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D2D7F4960AB09480C496809A8BD4F302D06"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C7815D76841E824BA55A9188E587421BEC83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9840ED716B0D0458D0BB5B23B87839769CB",
                        "defaultText": "수상한 짓은 꿈도 꾸지 마, 친구!{W:300}\n리아 공주도 거기 있어!{W:300} 게다가 난 성직자라고!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line10.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "A0E777D4881F7349393902983745593F87D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDEF0CE624BFB6448B58DFE253E8ABE90771"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "004E6EE824DEE5442F5BDC72A208308EDBF7"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "2B3640723A6D4742554B04B245BF1739CE61"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4C9700BC53A85543EE2BCC32A8CCE69769D1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 72,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "F5F3A60B1F15D74B1379A5C643B6ED8FB094"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "699D48988B7DF6476119DAB79DDCD284BBDF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "47562E5C79DEE648452BE4421B66A105FDF3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "35DA2288366F5147285A5648CED0F58FD4B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D721E2227752643842BB13894A62BA0B436"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "728ABA4840470541BB49E277AC5C11EE7AEF",
                        "defaultText": "말했듯 파라트라스도 거기 있어.{W:300}\n그런데 말이지?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line11.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "C90DB3EB590DF746564BC7E5108384A8B597",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0FDB7652152D344E6B8931813AEDDF0EBFF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3A20E55A2436A8462C3ADBD52E80BB6883F1",
                        "defaultText": "일찍 죽고 싶은 모양이니\n목욕 뒤에 가벼운 운동을 해도 좋겠네."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line12.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "145D62BC28725342111AECF22C7A3CC62B75",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC3C69D317D7694317097034C9CA95EF848A"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_2.ogg",
                        "volume": 100,
                        "playbackRate": 150
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9B8F62016E60A54B7C397D89C6360FC963CD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "77D673C052D9704B9B690C028C13F88D3C74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F1C737D83CD9247208951F16454155C8364"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "963F457D4C9A9644723BE407C6106A564757",
                        "defaultText": "다들 완전히 오해했어!{W:300}\n그런 뜻으로 말한 게 아니야!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4E43108684BAB049B81807F7DDBE5D2DE2A8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A200200630698648858A4D98F3CF66FBC4F6"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if ornieres not sarcastic"
                },
                "indent": 0,
                "uid": "231009FB69B6B148B758E283930686AF7094",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A4BCD1115ED9944468485F529B97933CBAFB"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A3D6D3FB43CE7444743901C831A78AD4E996"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "sarc",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 56,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 5,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "08C5F2A142FA914DD13967D84CBBF76A5F11"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "06DBC74B5B1B7849CC2B55B10D5DF4B031EB",
                        "defaultText": "그럴지도 모르지만, 경계를 더한다고 나쁠 건 없지!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line14.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "078207323169D44D2F1A8148A32957A69D2D",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "2FE739BA226ED142CD2AB41071C2D0D1C8E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4209054747E5724D686B10D594974147045F",
                        "defaultText": "평소에 그렇게 빈정대고 상스럽게 구니\n의심을 한두 번쯤 할 수도 있지!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line15.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "BFAF9888125637487F8BCCC918C9A4EAA7E4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D88E23100BD23341B18B42042A28CD9AF313"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3418BD5A431BB5429B7A692053AAC3FB8BAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50878BDE54C7D245176BF4323376E2617090",
                        "defaultText": "목소리 낮추라고 방금 말하지 않았어?{W:300}\n싸울 때가 아니야...{W:300} 아직은.{W:300}\n네 얼굴을 때리기 전에 제대로 쉬어야 하니까."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line16.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "24BF99F839EE0549376AE793AD5802DA986E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "27C98DA328F8F442ED2B4971F7C427959444"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A103D6B36DDC34CDA79A9F191A470C87417"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E897AA4D70030643D0888D3754194C9DE26F",
                        "defaultText": "게다가 저쪽의 털북숭이 친구까지 끌어들인 것 같군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line17.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "AD2F697D661702462B4B8C1649EA832EA880",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41602D05672C46497E0806F5C7D7EEB74C70"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A4D36D2188BEB74B5B5A4E9837ADC5A752F0",
                        "defaultText": "우웃 우웃!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "223074ED8F58B846C128F7385A8D02E3024B",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FA79AEA577E6C345F44B51B3CA984112A586",
                        "defaultText": "우웃?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3A789364034D584C92791957A666921BA91F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "woot",
                            "woot",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "8233866E2FC2064A7999CAC0BB754673A862"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E4459F738BD826467B292E777A51B6652C74"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "woot"
                },
                "indent": 0,
                "uid": "C76D077B6E560943A65AF0F19701ED274F63"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "624BC6C36C1388484528E21397E4FB34372B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "24E18951399C464D462BDB867A093D4FF7D1",
                        "defaultText": "안녕.{W:300} 물이 정말 좋네."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "273114E420D5C34D9B7B1273C8E7653B05CE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C6294F820007524E248973160E98DD579141"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": 128
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3B69734C1BB3C149D13BF94392C23B0A0F0E"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 170,
                        "y": 170
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2A7B658A8D95E74F8E4AABA6DA7890E5D5ED"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 1,
                    "position": {
                        "x": -350,
                        "y": -185
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "5495858225DEC64199897B35F33D8EB7E861"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E046C043F92214F8958C8133DA5FEA0209F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "92679F8B702DB14BAF9B99F5A098D8387B5B",
                        "defaultText": "이게 누구야, 루코스잖아!{W:300} 잘 지내?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line21.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5D5DC6888B4AE74D1C9BF0F91F6B3C8F49E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F94E04003E83349C33B14D504EF4C4744D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "286FFD393FCF51493F682C36F1E7FB946CA5",
                        "defaultText": "여기 와서 우리와 같이 놀래?{W:300} 착하다!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line22.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "38DB9D71444C494AB37BD4B0FB5C2C593A79",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "977B660B230E37415C2BDA091CB02B79DADE"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": 81
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7F71608A522CC1457A89220749F9E6B93470"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 270,
                        "y": 270
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B85ADCE25CCAE044733BF978EBB5EF849DC9"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 560,
                        "y": -180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BA10B2618B6A774A370A2B353187E5F03DC5"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "5A5E676B5145E641650A4897E44B21518850",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "AC892F0C570B1449AF6AB52968060EAC3460"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "F04070A17E2418450A8959B1BF47137A3E22",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F667B6B90CC8241CA38F2A5B4C903905502"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C9E98C6778978746B458D875565533C0E5F8",
                        "defaultText": "말도 안 돼!{W:300} 그런데 저 녀석이 왜 여기 있어!?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line23.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7E2E56564848724CA89A9C17336AECF8BFB4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09A6430E700AA94137799387CD4C5F0A0D06"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF14AFE54D5F93481C99BDB15C143E476497",
                        "defaultText": "전투로 단련된 남자들의 은밀한 목욕을 방해하면 안 돼,\n루코스!{W:300} 전쟁의 공포에서 회복할 유일한 기회라고!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line24.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7F942A281FC397482D4AB5725DF0DC94B8B3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26C267ED8912E6479C480B48BFCD3C77EBD2"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 320,
                        "y": 320
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "785C98BA5B24874FD538F12552E90826371B"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 185,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "AC3B21167033654EA13A710324FEC8326BFD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B671399A6CDA524C988A68F43DF60C164D48"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2685828C9BDA564D8F7952365EA96AA86913",
                        "defaultText": "사실 여자들을 훔쳐보고 싶었던 건 아니고?"
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line25.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "3DBA6F4215059243C918B197710E7C7BA779",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C724BDAB3B40174FF75A0BF3B17CE4D56298"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7D2DC4943608634AA73A3E34E6C2708155DD",
                        "defaultText": "게다가 루코스는 마나크레스트 때문에\n너에게 끌리는 것 아니야?{W:300}\n애초에 여기 있는 이유도 그거잖아."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "91DD9D786876F8419B2B93F7237F8F798E23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8498E6CE4E7997420998D1323E87E16D668D"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_2.ogg",
                        "volume": 100,
                        "playbackRate": 121
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DC474B8D23FAC64B825807114A8F9C7F78C3"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 270,
                        "y": 270
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "6716C1E16F356741C98864B12166E48F3BB2"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 560,
                        "y": -180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "1BEF9DFF586E7041E2998EF11F0FB6DFD6A0"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "C18141B71DAD964D620B738294CFE05D195C",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "2165CF9366BA944EEF8B7FA4EDDAF5845467"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "A59904589AF2C54621495877E3FE0A2C78E2",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AB4C061416D994066096A738D8B54E4E50B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8B1A8E8249A81140504B7F346F29F4743A03",
                        "defaultText": "조용히 해, 후드 쓴 불한당!{W:300}\n늘 달고 살던 불안증은 어디 갔어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line27.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "95DD318D2B686747E60B3BB470B2F50B40AE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DD9B431F52F60347376A38D9942A96BB2FBC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4DEA99E46548C447EF8A767693D851EEC91F",
                        "defaultText": "게다가 지금은 마나크레스트도 안 가지고 있어!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line28.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "95ABBFD619BAA74E3549FBE64FEC45FEC3FB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB38B412993644423E49919209A11E8B82D1"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 320,
                        "y": 320
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "BDDE0CAD3219E9461B2BC4A7EF8FAF86D255"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 185,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "21FF3CE436F7C842CA4AEE74C5CF3B134AA2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A0D6F140756584B175971C085FFC92C6888"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0D22FB651E3251482B49BDB870E3D2EB1221",
                        "defaultText": "\"후드 쓴... 불한당\"이라고?{W:300}\n호이카데의 왕자에게 말하고 있다는 걸 잊었나 보군."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line29.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "937E82BE798F044F8F583F3600907EB42620",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B22690BA36A8E74B8D6B6EE41391BBADF024"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "17E883151420C54F4958065513DC551024BF",
                        "defaultText": "무례한 죄로 네가 처형되는 모습을 보면 즐겁겠어..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line30.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "79B19A1739A26643D4193080E48A4770917D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C0315A9E1EBA0246A0296C2351506B7ADF71"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_3.ogg",
                        "volume": 100,
                        "playbackRate": 74
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "68793E5E7A66794E153B10D50BD3EA76D1B3"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 270,
                        "y": 270
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B1A0DFA79A761147397BFDE4EDD0BAD2A472"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 560,
                        "y": -180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "313661E342FAC04C154889B67F35B601CD41"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "CA05D346305CE4414F49E2B1EB15C35FCFA5",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "43E412E9004494454F9B26364A2CFD2E5759"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "4BA9344E5F87F6441E794390A04FF597781B",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4486C4828356664982784AF0485DE9EB3AAA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "08E1FFDE0D2A684677695EF37163D208737D",
                        "defaultText": "호이카데에서는 아무도 널 모르잖아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line31.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0FDA4DF390A4E346A45816A50C77C6CBB030",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E3AC17856E19A8475118C2E007871C949749"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": 150
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "23C30E174C4D944E6659C520AD5F897F91FD"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "FFD8815B3D5B7441448957030C1585A1BB93"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 170,
                        "y": 170
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "F8D7CCF649C7084F2348C9F2001FC9012C17"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 1,
                    "position": {
                        "x": -350,
                        "y": -185
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "003A3C31530B57449E6B4781D32B05653323"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "8A834949856A6040787B4590634988D2B212",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "9155EBA6886A88431A59E01420EBFBD3B2F7"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "5AEA398739764049BF3AE38212633EF17747",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E292B1C8790DC44B5B59C2E3C6788754AFDA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C704A4B5BD00346D59882C1739A1F15EBC0",
                        "defaultText": "이야, 이곳 분위기가 정말 뜨거워졌는데?{W:300}\n하하하!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line32.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "30B974A666D5A84D012944D6C80DD8D310E0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8D6B9C8545F14848E75B0308C24A97F8F7BF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A06D37A8A96D2489F790DE4C9CD2411FEC0",
                        "defaultText": "계속 이러면 루코스가 겁먹겠어!{W:300}\n그만 좀 해, 친구..."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line33.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "B2CB51B304DAD3461B88F2A27AAF4BC23491",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0264B00120ED304374399617DBC1B963AA70"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_2.ogg",
                        "volume": 100,
                        "playbackRate": 90
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BB60F099276A52497A1A42E973D1BDBC04F5"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 270,
                        "y": 270
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "630A63A721D9654EE5587D64822A33ECF642"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 560,
                        "y": -180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "28E95C87807CC146DC0860B279F6E84C2EB0"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "F456A8A67413474EB6194C54FB9896A2DBAB",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "EFAE20AE1655C14FDC7BA85256ED0048E60F"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "54B0D2FF86E0694B24882812EDE1D13EAC16",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBF31272024963481F3946D12FE2DE5A8333"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C6DA5055340A9349BE3AAA18825EA2156231",
                        "defaultText": "무슨 말이야?{W:300} 조용히 하라던 헬리오스가\n먼저 나를 도발하고 있잖아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "04BE33531C4FB84BAE2B604819A6B5F0C552",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "131DE72A0159C043F58BD090D7052D4EF205"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_3.ogg",
                        "volume": 100,
                        "playbackRate": 119
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6D0343D82F52074B6D393307FC9C91C12239"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 190,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "3D68C208631E2647FB697614DF53541044A3"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": -250,
                        "y": 250
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "778116F3172DA347582B6C94FEFD7E4765E4"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "CBE367EA5C4F214B6B78FA552535394DF360",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "2AA81E73466EE64FEC1A23C2E6D2D02381DC"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "DDF1A297295D0448A75AE1E00FCC9FBC80D5",
                "expanded": false
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "477F134B4B788640048A43E7DA7D65ECCC4B",
                        "defaultText": "그리고 네 \"물건\"이 다 보이잖아, 크리스토프!{W:300}\n한 번만이라도 품위를 지켜!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line35.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "0DC823F007EED74BB6691E055A4ECFAB4F1F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59289D4C81FFF94330589A4781B9895AB04C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E0230CCA2DD85448E738A832F144EFD63063"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "10DEB66D3BDAD748894B5301769EFCD530E9",
                        "defaultText": "무, 물속에서 왜 몸을 가려야 해!?{W:300}\n애초에 넌 왜 보고 있어? 요즘 왜 그러는 거야?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line36.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "9721EF2A8E7CF744FF7A32F73D642A3F2E0E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2024484327225540681A23533C77C3F4DBAA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DB1D22FB23A67747B21869A54AF9A476B0D2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E73EFC776ACCB24E813BACA8FBAB08D188AE",
                        "defaultText": "변태 짓을 할 기회가 사라져 흥분했거나,\n열기가 머리까지 올라간 거겠지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line37.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "CA1EE4E98DD126486279CB322D2593931F8E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD2985F122239644622AF595174B53F39EA2"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5B15AB4F40B95543C11831F13C984BFE0673",
                        "defaultText": "우웃!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "484572EA6B43E645B05A2DF68D774668F5A9",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "05BC4141285B79421729B7349CFAD6779A00",
                        "defaultText": "우웃 우웃..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8E3109511556694B4979AF0688452356BD8F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "teasing1",
                            "teasing2",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5481BEF155CA4442E981E537082EC540ADC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "930FEA034F51C24094397A647E5BDD593DD7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "teasing1"
                },
                "indent": 0,
                "uid": "5E79BAA5383F2847934A0716FF3C769C30EE"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 320,
                        "y": 320
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "2721E07F122D624D92480CE02113016B5BFB"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 185,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "591A3D8C1BF7F94AD05A67A34FBADC65C814"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDFE165B3AE6514D0F4A7F46875EA5FD26C6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2110E47227E95348F879D394B824F9B5A020",
                        "defaultText": "첫 번째라고?{W:300} 불쌍하기도 하지.\n연인이 있었더라도 그 몸을 하나도 기억 못 하니까...{W:300}\n필사적일 수밖에."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line40.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "55C3CA2B36D924427A1B0CA13769EC0FF4E5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C85497F4C95A643C89904E94A9197D3431F"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after teasing",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B78ED9797C784342C478C9A1ED156DEE6287"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "teasing2"
                },
                "indent": 0,
                "uid": "DC7F6F5C3CB0D142AD9B147160D45101D54D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1638FA6181A344FBD7AF4F39E6CDB4D4EE1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "37815E280EEC0440886AE3D74457D4675F35",
                        "defaultText": "그럼 열기 때문인가?{W:300} 불쌍해라...{W:300}\n원래도 머리가 별로 좋지 않았는데 이런 일까지..."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line41.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "027184FB317D7247FD4803168EE6F810B167",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "007B98F2172D704D214B8AC187AAA00AC652"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after teasing"
                },
                "indent": 0,
                "uid": "1B3E4E4B41F757410388F507D45EBD13233B"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": 86
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "30137D9C8A46A44A4D8A1B884FA14690FDCF"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 270,
                        "y": 270
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "C294513291D0B643CB6BD3F1CA790B192C16"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 560,
                        "y": -180
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "1FD60BEF3B41544B994B14C1E628CA573BF6"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "5FCC28B41EBB53458C986E957673E8F45576",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "40DE46A1235A434B3F48EFA153F9531B031E"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "019035421F64864D266B8A3276C046D91D46",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CAE6F7F64B32024A1B7A16A28ED30B1AFAAE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95B8656C61E0C348221BD10380100C318BB4",
                        "defaultText": "그만 좀 놀려, 젠장!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line42.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "5133BC3C31666943CB1B08385E0F7A4CABF9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6802F2EF7105A24DCD79BDF181D265EEC847"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Splash_1.ogg",
                        "volume": 100,
                        "playbackRate": "138"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "62490FF244511642A5194DE5737DEFE8E5AF"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 170,
                        "y": 170
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "75E0038354FD264B73299C502422A10BC398"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 21,
                    "waitForCompletion": 1,
                    "position": {
                        "x": -350,
                        "y": -185
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "92361A9332B62646135811F5F51CD283A2E5"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.799999999999999,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 50,
                        "x": 60
                    },
                    "speed": 120,
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "0DD4A7E512150444C4090559263BEEACC991",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "109550ED46B9594D7668D90829471C847650"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 10.200000000000001,
                    "waitForCompletion": 1,
                    "range": {
                        "y": 90,
                        "x": -15
                    },
                    "speed": 110,
                    "easing": {
                        "type": 0,
                        "inOut": 2
                    },
                    "fieldFlags": {
                        "easing.type": 0
                    }
                },
                "indent": 0,
                "uid": "4DD067C12637E94255691CD9F959BECD20E1",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D447DD51077234E552884B39204854C4473"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "401C51D07E277046AB6B8627D1671AAB6C41",
                        "defaultText": "하하하, 함께 보내는 시간이\n이렇게 재미있을 줄 누가 알았겠어?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line43.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "7F6A4BC075041348DC7B7A365FC77B323C26",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "945CB2BF00971443B1198F6208FB65F68016"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "070305E95F47544FE58AC8C59C7A2BF0B48A",
                        "defaultText": "이봐! 다 같이 물장난하자, 친구들!{W:300}\n성수는 내가 먼저 쓸게!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line44.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "6E6D55774738564B0E7A4D425E4BE371EFB4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D27D7096A94B1489309CD419E7639F98183"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 320,
                        "y": 320
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "605B67E96ED3704345393285CC6337D174BC"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 185,
                        "y": 190
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "165579C4058181442368F5A90098BC12FD12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AE26FA72D53E04A8C590EA9BD4750468F62"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E03D2E7E3AEAD94E7538D2384BCDBC0DFA66"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB5ECF0A8FA57843AA7B8B43739C80FBBFF6",
                        "defaultText": "...{W:300} 나도 끼지."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line45.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D444650271B70741271A4211BBF7BA3A648D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D05B9C76449D54C0E5A3ED76D969567DFCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA822DA002374846326902923CDEC1836686"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 24,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 100,
                        "y": 100
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "B33E387873506040CB5B22D780BEF97B0EF3"
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 24,
                    "waitForCompletion": 1,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "91DED4006613D249698884D1E1CE8AC8B39E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "A9A3FE595AE3C442E018CAC389E247EF209D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B6A4D07E45A33244AA7B8A176E28AA29F557"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40018D07492F574F83289627941E3031F9B1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BD747318033CC249223935717A1F559532CD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E31C186E732C714DF66840B41A3A22453B5D",
                        "defaultText": "그리고 루코스, 나라면 기회가 있을 때 피하겠어.{W:300}\n너까지 휘말리게 하고 싶지는 않거든."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line46.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "4D039CA297FF1647260883D735409DAE5F28",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE629BCF17285848DD1BDA19CDE914243519"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7A8BF440923027477B6BD68909D7B36D22D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "975304FD6A0437471D6A86D07A746F1FCDDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2C48B25949AEC4481D3B52238F1E04427E01",
                        "defaultText": "으악! 다 네 탓이야, 배신자 꼬마 늑대!{W:300}\n오늘 저녁에는 고기 없어!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line47.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "1CEF68D77DA90642206BFF192E6869271DFC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "986727799B6B444D28089A571EB577C31126",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7C972A4439A9234EE3883577D106AB396C30"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BC7EB468CAA3141CF6A4CE08E57EF1D699B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5FF573BD835F8240CF184BA442106AF808EA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "889B2F801F25354BA778ADB7086439FC5BB1"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "start of timer"
                },
                "indent": 0,
                "uid": "BBD737C37E6AD54DEC5BE8E98C67FEE34E7E"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "timer value",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 1,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 4000,
                        "end": 6000
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7371302740E0364C986A751112800C584FE7"
            },
            {
                "id": "gs.StartTimer",
                "params": {
                    "number": 1,
                    "interval": {
                        "name": "timer value",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "action": {
                        "type": 0,
                        "data": {
                            "label": "time out",
                            "commonEventId": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "03A825BF8BFB854CC14A2A01D9561F1AF9AB"
            },
            {
                "id": "gs.WaitForInput",
                "params": {
                    "key": 102,
                    "state": 1,
                    "action": {
                        "type": 0,
                        "data": {
                            "label": "$$C50EA7EF0592134BEF59E098BD7961D34EB4",
                            "commonEventId": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "217E72A17E432243324A34E1AADF30703D99"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "E31B66CB1F62B347C31BDE37280FD876FEC3"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "time out"
                },
                "indent": 0,
                "uid": "3BC74C98615695431229E3D5C16A8D46340B"
            },
            {
                "id": "gs.StopTimer",
                "params": {
                    "number": 1
                },
                "indent": 0,
                "uid": "EE16280A526EC64CE2294C65C535CDB3952D"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "creates a list that extracts one random sentence; the previously selected sentence can't be repeated if you return here"
                },
                "indent": 0,
                "uid": "35B75EFF140417448C9965F62DA93DB7F13C",
                "expanded": true
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "25D2BABD1FFC364368290785D37885142DD4"
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E1030E9C992F694546989F6798ADDF898A55"
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5E37F16F59CB6542578AE03543DC473172A3"
            },
            {
                "id": "gs.LoopCommand",
                "params": {},
                "indent": 0,
                "uid": "DE9216EF24019646E01B54A57CD4337C88D4"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "lenght",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FA4A2FFE6C9752425969BB54F7EE01FC8870"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "lenght",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "4B0E5E815471E24D4F8836B55A4A85CD1CC1"
            },
            {
                "id": "gs.ListShuffle",
                "params": {
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "E278C8D73BC87745BF3B656922B5C7B8C210"
            },
            {
                "id": "gs.ListShift",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "possible sentences",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "906D9CB5677FC3419E69FA42381BECB71A7C"
            },
            {
                "id": "gs.ListIndexOf",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "already extracted numbers",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "index of previously extracted number",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "952A77737DE408464F39818163F256B8B5DD"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "index of previously extracted number",
                        "index": 2,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": -1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "22413E181E6FD84BD48AC0C875FBFFCE9493"
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 0,
                    "listVariable": {
                        "name": "already extracted numbers",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "CFD0D35C492FE54CA49B8110E386430EB9C8"
            },
            {
                "id": "gs.BreakLoopCommand",
                "params": {},
                "indent": 2,
                "uid": "B8456D5F4B4BE446204AD27646274C2137EC"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "C28F07CE1E0A9149098BEEF5145D66E8CF66"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.02
                },
                "indent": 2,
                "uid": "64D62AEC83B95346354B36F1C324B4F308D1"
            },
            {
                "id": "gs.ListLength",
                "params": {
                    "listVariable": {
                        "name": "already extracted numbers",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "lenght",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "17B9D70B89F7A6405A7AC1C435D83D935C1A"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "lenght",
                        "index": 3,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2FF907866DA1A44C4C88A4A92A209402DD40"
            },
            {
                "id": "gs.ListClear",
                "params": {
                    "listVariable": {
                        "name": "already extracted numbers",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "914E8480482DB344324B72A6D3F6B3A873E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E15D19AB556BF14574188DC3B3EA3A025E8E"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3C20624715A1134E26692F09C0437BEBD8DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "41627A3B4C895243102BC00597314BA08B83"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "50E889245AE99148A8494BB3CA46CF617109",
                        "defaultText": "루코스!{W:300} 이제 날 화나게 하지 마!\n전투로 단련된 남자들이 물장난으로 승부를 보게 해 줘!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "C08-11c_line48.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "BBA8057041207745053ACFD699C3B9F4F69A",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "30DB8DFF5F723244D82A2081050D25597F9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CE022772468CE849363BF6D3F2C0D3001328"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E5B351E93CD718478F7A2DA5395707B3A85B",
                        "defaultText": "남을 거야?{W:300} 그래, 마음속에 자존심이 있기는 하군.{W:300}\n하지만 이번에는 저 기사의 말에 동의해야겠어."
                    },
                    "position": 0,
                    "characterId": "525FBAAA1F79E7477F1A99C505BE1D2EBA2E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Hellios",
                        "name": "C08-11c_line49.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "DB2A89CB64D723421B79ECB6B83F3E60D73B",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "extracted number",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "69B8D7CB4434584FA95B7CC4DD9B714AEABD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1BCA003E43D001410868037613090558E202"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "756B65C45AE0624B8B9A8877649B2139E580",
                        "defaultText": "좋은 생각이 있어, 친구!{W:300}\n아직 안 가 봤다면 리아가 뭘 하는지 보러 가는 게 어때?"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C08-11c_line50.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 1,
                "uid": "81D7819E7729B44DC52B72C79E000BCE82C0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0AA29BE93C72C541D80A59D6E0C31BBB63BE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8E6A8E31069504F1F0BCD000CBCC04C19B9"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 1.2
                },
                "indent": 0,
                "uid": "130FACAB3509894EF81B2897D2677E58882C"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "start of timer",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "8FEC9E8F0E9C224FD5694C83AB58AC25AA5E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "814302877274C64DAE883FB6D8C1149D6E9B"
            },
            {
                "id": "gs.StopTimer",
                "params": {
                    "number": 1
                },
                "indent": 0,
                "uid": "23F6C7F14F9D08440F7A7FF52C2C52267D83"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo del messaggio",
                        "index": 19,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1967CE402B05E6489D2AF114D9337A68AED6",
                        "defaultText": "온천를 종료하시겠습니까?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D18E84154E627344D56AEDE01653BDEBB059",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "B66ECF95405857448D4BDDD38DBABD1B66D8",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C77F296F6ED7C6496C59D1D60AB3DB358539"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4F884595201AF04EF37930395B50D36F7798"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "start of timer",
                    "target": "activeScene"
                },
                "indent": 1,
                "uid": "3637F3D6533E384CCF788F365FB8F8DCD321"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "DE28C7E277C0C84AD23934B08899AC065A1D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 1,
                "uid": "0115566F4935C640AF986EE3F48344620B0E"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 1,
                "uid": "E967BD3941337349D32811E5A18AD40525B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            1200,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "81A51D4A57ABF649317BA601E266BC654789"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "CG Lock 7 (MaleHot)",
                        "index": 26,
                        "scope": 2,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AAC7D0BF4E64704AD15AA1277E5BB7E57151"
            },
            {
                "id": "gs.SavePersistentData",
                "params": {},
                "indent": 0,
                "uid": "B778FEA97DAF6348F898DDD389F724FD299D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "281E2CDF7D6A2348611A5471064CD639BFC6"
            },
            {
                "id": "gs.FreezeScreen",
                "params": {},
                "indent": 0,
                "uid": "A757B5D518FB814F387A6230DE7E161CFB4D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "B912338228D1E64C87693F5228AC03BF41AA"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1EC033312821774B775B7D36C39D53896243"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 1",
                        "index": 160,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "CA06D8286871F64113384F7506B95BF23987"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "54712F9D78637342EC287958D630ECF050B3",
                        "name": "C8-11x Hot springs (Exploration LUCKOS)"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "FE4038CE1F177744708963872FB57B68CAF8",
                "expanded": false
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "E0F4504B84DFB341EF6A6F03E9F7BD10FF46"
            },
            {
                "id": "vn.ChangeScene",
                "params": {
                    "scene": {
                        "uid": "1DA9A6C7449D034DB2886F719A1364D6E82A",
                        "name": "C8-12 After the hot springs"
                    },
                    "savePrevious": 0,
                    "erasePictures": 1,
                    "eraseTexts": 1,
                    "eraseVideos": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D355F82F60698843FC8956F407398E572702",
                "expanded": false
            }
        ],
        "stringVariables": [
            {
                "name": "name",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "sarc",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}