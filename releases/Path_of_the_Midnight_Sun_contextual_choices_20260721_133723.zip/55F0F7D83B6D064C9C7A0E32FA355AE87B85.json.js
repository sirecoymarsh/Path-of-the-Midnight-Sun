GS.dataCache['55F0F7D83B6D064C9C7A0E32FA355AE87B85'] = {
    "uid": "55F0F7D83B6D064C9C7A0E32FA355AE87B85",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-08b S3 Flag",
        "type": "vn.scene",
        "parentId": "025DBC8E572FB14C9F2937720A15DBA23D43",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 2,
        "localizableStrings": {
            "6261F43C2561B342153844C30BFBE2966875": {
                "t": "Let me guess, this is the national symbol of Lazulis.",
                "d": {
                    "cid": 0,
                    "eid": "BE1BCCC221F5B5474238E13063489FCFC7D3"
                }
            },
            "D91D9CC3353D6445C77B3EA0E97CB6AE6959": {
                "t": "Yes, it looks cool.",
                "d": {
                    "eid": "3CEF65D31E76B245634AF6A03F053E0502FC"
                }
            },
            "7163723C4841C54EB408CBC88A7DEC1DEDCE": {
                "t": "I'm not a fan of turtles.",
                "d": {
                    "eid": "12C93A4F61CED84C7089F26486F3EA177F67"
                }
            },
            "58633B1812B5A3454B9A04C4064160AD67C2": {
                "t": "I don't know. What about you?",
                "d": {
                    "eid": "00759018691FE94ADA68A1F7DE42AF007A90"
                }
            },
            "3F9577ED52B0334FD7592E5360753BA98722": {
                "t": "I'm glad! It's a symbol that Lazuleans are very proud of.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "626D39AC930E28433A59A8D6DE03B0136BE0"
                }
            },
            "2758504D98FA184F3C6873E76E482AAB079C": {
                "t": "Oh, I see. That's understandable.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "A0A00BB3230CA144FB2BA3888A124928CDF3"
                }
            },
            "CEA9F5198F27F64CDD9B8035036C0CA37221": {
                "t": "I don't know either, Nini. I can't see it.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "FFED88A87A7189444938FE01CA05F4DB09B8"
                }
            },
            "9C7E2D555045474E5F48AA26520D027DCC33": {
                "t": "Oh, right. Why do I always fall for that!?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E2DDBF702E3D144B2D281900B7BE7E721FD1"
                }
            },
            "79A5B1A411D440469C78DF60A72F38E5A3F3": {
                "t": "Pft. Don't worry about it.",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "5CE626A19A4355411E39EAE1F3ACB637702D"
                }
            },
            "CA38FFC4255848483F4B58024EC18245513F": {
                "t": "You're getting sharp about these! Yes, it's the Fortortoise. Do you like it?",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "11B2C12303063644272BD8D392BA6F3FF42A"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "031147F62B656548B8986DA99B0D398C89A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A38F6314D3CA847C16A499603626C098415"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6261F43C2561B342153844C30BFBE2966875",
                        "defaultText": "어디 보자, 이게 라줄리스의 국가 상징이지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "BE1BCCC221F5B5474238E13063489FCFC7D3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B5808F62B78274F7B58094477ED1F48D599"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1A3ECBBF17A47142EC3861E2717128580C71"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "2A9F44586B106449B948AC94A106080D0D94"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5D7DED8F002B214B3F8B632267ABA6ECF5C7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C92C4E087D4EC348A55B17910655FF133C0F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA38FFC4255848483F4B58024EC18245513F",
                        "defaultText": "이런 건 점점 눈치가 빨라지네!\n맞아, 포르토터스야. 마음에 들어?"
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "11B2C12303063644272BD8D392BA6F3FF42A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "82073F572FF28542C46877A26390CB231FB1"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D91D9CC3353D6445C77B3EA0E97CB6AE6959",
                        "defaultText": "응, 멋있어 보여."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3CEF65D31E76B245634AF6A03F053E0502FC",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7163723C4841C54EB408CBC88A7DEC1DEDCE",
                        "defaultText": "난 거북이는 별로야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "12C93A4F61CED84C7089F26486F3EA177F67",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "58633B1812B5A3454B9A04C4064160AD67C2",
                        "defaultText": "모르겠어. 넌 어때?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "00759018691FE94ADA68A1F7DE42AF007A90",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "nice",
                            "not nice",
                            "maybe",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "162E7B507B86B643566984700B521FB2A8AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3672791C229A59486928DD22AD53C99EAD93"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "nice"
                },
                "indent": 0,
                "uid": "83F042B288C541424B5892462D8DEE271848"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "755CB2D131296343378A2B345157CA4EBF05"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F0FCBF26BC9C24A388A0814227A5D332AEC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3F9577ED52B0334FD7592E5360753BA98722",
                        "defaultText": "기쁘네! 라줄리스인들이 무척 자랑스러워하는 상징이야."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "626D39AC930E28433A59A8D6DE03B0136BE0",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "3789E5794FDB2649172B040439D8E99B8AB8"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "not nice"
                },
                "indent": 0,
                "uid": "DEDACEFA9C05134580191F64B03FC784ADD8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C90D51219874F746EF4AE58903D944A33F94"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2758504D98FA184F3C6873E76E482AAB079C",
                        "defaultText": "아, 그렇구나. 이해돼."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A0A00BB3230CA144FB2BA3888A124928CDF3",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of event",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "4274947670C462408A2982E214818C814933"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "maybe"
                },
                "indent": 0,
                "uid": "10370F6B491F204DF74833E1D36F1C232F04"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-sanity"
                },
                "indent": 0,
                "uid": "8FF1025585ABB24FEE5A1FC2DB471E7CFA43",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7D626A2951541343201AC8E4723FC4856FFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEA9F5198F27F64CDD9B8035036C0CA37221",
                        "defaultText": "나도 모르겠어, 니니. 난 볼 수 없잖아."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FFED88A87A7189444938FE01CA05F4DB09B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CE5ACD524026445E98BE5B60083395F35F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            1,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "738EB5756ED2A244787B2A554B94DEB6F583"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "45A729A012821449484BF8B1AA37083CBF7B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C7E2D555045474E5F48AA26520D027DCC33",
                        "defaultText": "아, 맞다. 난 왜 매번 속는 거야!?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E2DDBF702E3D144B2D281900B7BE7E721FD1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC7651FE8DEE96423B6A49B4B377A0A05B1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "569B8BF939562840B65A3C64F07E6875697C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79A5B1A411D440469C78DF60A72F38E5A3F3",
                        "defaultText": "풋. 신경 쓰지 마."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CE626A19A4355411E39EAE1F3ACB637702D",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "E406B72E25D5214840484138808E7AC1AA73"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A023FF2855A0E540C7884521C67D3845A11C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "522B6505085AF648063B32C1533ACA9C8059"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "496B1BC76090174E1A0BBA66A4C050D28FF2"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}