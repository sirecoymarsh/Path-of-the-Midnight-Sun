GS.dataCache['F6F9946007AE8542E66BD8E4250367653055'] = {
    "uid": "F6F9946007AE8542E66BD8E4250367653055",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "P2 - Child",
        "type": "vn.scene",
        "parentId": "477F2E69522E9146694943E9D6C72B3BC6B2",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 1,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7359DD268E34C747054847169B00149D2C72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0148762D5CF61548C15AA328F23A684EEDE7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "059546126D6C754B866AB991B7C8C97D576A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "82D37FEE84E2C24E632A6733555E1336A434"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "72399CA01831C84EF419A7E209194C97E44B",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "D456DE305ED0614B678A5C171F8590563BAA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6D181CCA18558541070AC8F3EE7BBAA65621"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8E4851EE3EFCB546022B6C27FBD68049CB95"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8DFEA623A80084141281B430685B42884ED",
                        "defaultText": "이봐!{W:150} 한참 전부터 너희를 보고 있었어."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "62C7F60E76B427445D6A4A529E41AA80AA8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6A0A46062FB783492E8BF34275A8111198DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "40DE55412CF5734404887BC01C6B54BA2415"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CEA831401AE2E446EC4B88522AA0332D245D",
                        "defaultText": "어... {W:150}안녕, 꼬마 아가씨—"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "AFA659595C43E74EBF382DC0A8A4B790783E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "25330F5A7402C141BF686CB3830C8C75015A"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Nana",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "04EFDC18973568425B3AB6254DFADBC744B0",
                        "defaultText": "Nana"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "8514AD849D63D447F17B1443C032BC25CC62",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Child"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "Nana",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "C939C90775BF6644E318CC5357635203D7A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "BCB7C0933626224FFC19AAB42485776E59C2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1A925C293D50574D528AB9219D6B59322C4F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "746B5EC347999540634A9DD4A8D4602AAE7E",
                        "defaultText": "내 이름은 나나야!{W:150} N-{W:50}A-{W:50}N-{W:50}A!!{W:200}\n그리고 난 꼬마가 아니야!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "76DA198F0817564B98498F21D9B52A462B35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6DF3539E3CB4E04A41693F63A0DA57B692BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "6A6C4CCE8778F247705B7F24B0E5860FEB56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "455175191E86F142A78A4C385A0C7D9F9415",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line26_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E680A1B737253349FD3A8E5598FE0C62B705",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "754E7360356B214FD45865950B37215C92F3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "3AAA1A1A933C684AFA19F571EF72B9980AE0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "97016B3F24D5A348600BD1F736E2443F1D20",
                        "defaultText": "그래..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8736A6E740F007484A6970B384FB3773E84A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D74789BF2925B542AD7805D12ACE1A4DBDB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "DC5BBD146ACCE24BA97A75C7F20ACEB95C49",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            3,
                            500,
                            1,
                            800,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D7F4CAC60D74254B132889E287B6164E816D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1D4D93362E392442CC1A905196C705801CFE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B1CA59D1FF4D5494788A0F76923B0041A33",
                        "defaultText": "미안해, 나나. {W:200}널 화나게 하려던 건 아니야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "EDC763B53241984957490E73FC0875A2E162",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B604E05B0C84A84532592090CF92CC3E87BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "426CF175772059453C1B2EB35A69B75FA551",
                        "defaultText": "아까 우리를 보고 있던 이유가 있니?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E5DCE2D24CE9A24C5B1A8105C275BDBDCF39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F38C845C14D20841906963638547DB1B21C4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "63F9B1B31D745541C78BA2512C3B89C870DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BDC8819B437EE9404F3B9B987E97499C256E",
                        "defaultText": "시오리는 이미 답을 알고 있지 않아?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "21BDB40F4E09934A47081037A2B9ACF71A86",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "B8A62B9E77A6F943097934B45AD8CE4AA033"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3270D154281F348813AEB288B344E1F516E",
                        "defaultText": "아마 내가 맞춰 주길 바라는 거겠지..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C4CF63A56C73A7455F1A40027E502D19BAB9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "BC039DB46680024B3F885091A1A71604616A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            1
                        ]
                    }
                },
                "indent": 1,
                "uid": "A0195E0067187643BC2A54D56FCF6872F143"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "8C0E245012741443E73BB7E358AAB9416891"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "46228F724C7A54493C4BE5D5C2F10FC5504A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line6.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "53E4F77D6F53E44F5A4ABEE52F3298726824",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "B0C63C974B86B3451D1875B7480993FA535D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "8334F38547405348DB3A9E708DDFDE9FA3D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21F5764530A3A246CE9BBDF50D6957CFF023",
                        "defaultText": "와아! {W:200}이 아가씨가 저 남자보다 훨씬 똑똑해!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "59835DFC782AD748AB28DFB4CB66A84E7C8E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0D42A6D68666F344C07AAE385552690BCA45"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "Sarcasm",
                        "type": 0,
                        "value": 50
                    },
                    "targetVariable": {
                        "name": "Sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1C24D6AD1673114BE829BCA1440E1CF290F4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Sarcasm",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 53,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 3,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "2EB5B13D14DD55451628653994BE1C868F98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "2C9BCE3836CBC0430C2B29A81E2D5DE6670F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CAE7946948A20441C23AEDC4B0FC275977AD",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line24_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "414AFFFA448C0045AD6B7732E8AC06F40902",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "DB192FD768201740612BE6C53DA976956D73"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "E56A368A377AD244321A7B60451BFD9B68E1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA7CCAC88407F44D9E5A3EB4C5A6F204647E",
                        "defaultText": "사실 요즘 너무 혼란스러워서 내게 뇌가 있긴 한지 궁금해!"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "expanded": true,
                "uid": "7412C8E944721846BD9AA5D4D3DEFD75C023"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "7B2F551E7819934BA60B89667968C606D41E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "497859655C0802478D4BEE157557F6104AA1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "29D5FDFA893EE141615B2E927562DA73A8EE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line7_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C020371393860940C15B6AA39BC900672C88",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "FB8F660722D89147BF38B5C3F8BD98BDBACE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "1BAE6007604E774C3A79ED61FBA315E65296"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC6F389377E16141F38AEA67481677B00A60",
                        "defaultText": "우와, 너 같은 사람이 그런 {SP:2}{C:1}빈정거림{C:0}을 할 줄은 몰랐어!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "expanded": true,
                "uid": "63EE88BA06B1C5444E4A2E95B283E4F437C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "C7E2FB8C7DDB664DD53838064050E1A6A5EA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C2D664C622A5354A9C3A8047695B77983DFB",
                        "defaultText": "자기 비하 농담까지 했으니 가산점!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "expanded": true,
                "uid": "FB34E5FF80C686400E68683776A1B4EAB441"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 1,
                "uid": "2681C31679B83142075A7DA4CFA6B6D5007F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "2F4329585A09B84A198983C78D4D46FE7F77"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC56C6E30890C24C1918CAA1ABBCEE1A93D2",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line32_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "D6A078C48C59B54273792A17AC1EA46D5FBF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "A36F0A2A0942E5498A6B4E2428FA4A0E6255"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "288FFC8360E516436C396869BB5EB3FA4653"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CE5EAEDC7DE6C24FF12BB8822C95715AAF5D",
                        "defaultText": "나 다 들리거든!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "C8A1E36231FB584F167A2F34E604FE744578",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "EB2F9543801C4241F2285CD7CDE5FB007571"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            4
                        ]
                    }
                },
                "indent": 2,
                "uid": "E55F029240B0B94B222B235193DBDE070C8B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "416E083150481240727AF6D223D410E3B22E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DE52D0375732E14F84080AD7953313D456BE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line5.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "uid": "A290CF3E51D8F6424129F65350D0A156BBC1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 2,
                "uid": "EF538F0294C7B6425978ADF4AB9E6D7441F1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 2,
                "uid": "2BD9A83D7F571543166BCE217F9D073CC995"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F0EC454A7FAA8544AF486671A1E905ABF9BC",
                        "defaultText": "우우!! {W:100}하나도 재미없어... {W:200}\n좀 더 {SP:2}{C:1}빈정대는{C:0} 대답을 기대했는데..."
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 2,
                "expanded": true,
                "uid": "646013B46046B640BB1971C414F8DF19074E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "79D075C77E48494414293DC103043A992555"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "831C93798BBBC648CF98FF63E97071B673CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "5CDBC4E89E01804D036A7B5270382E356AAC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2E054595363A8140995BC25590D28273358A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C7B3825B58D3E84CF98BFF015EDD7F13C29B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "3AFAD3831CA69743861B3DA8185C7CF404E4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "06B804C189064847A45A3D91BD9224F4BE20"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA32AD167ECF65416748C004904DA412721A",
                        "defaultText": "헤헤!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9E2AF96D14B7924296496AE5B5D09B8F1508",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "28F2D2E8310FB740FC38A2C8BFDA53D3B647"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "55B1C7CE55F3A543A54B8CA5FF537BB577EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E19B7E6F86BFF945EC896B19F40833CE8CFD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B840AB4D1EE7F34B2C3BCA24543F5D76053D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line4.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "077DC58230FA684967299202F3A9F0AD7736",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "52186DA597B241471F8B3064BEE33C6ABAE2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F22489A17C293846E069F0A57F8D43BF154E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ED012B6C2D4A7143B02BC3259CA574D98839",
                        "defaultText": "난 마을에서 제일 똑똑하니까 모두의 대화를 듣는 걸 좋아해!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1F251DE5648F5645B34B7E4401F29FB7928E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "878A51B4512BD84FDD095AD29F9F96D22474"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "13A95D738514914DE42914E80A01F69C8495"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "Second time skip",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "A2F199868E32B34B7819C768B7BD011F35C1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "16A0307D9DBFF84830686C82830C8F21CE24"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0E93ACD7834AF64FDB4BD15227440B1F63E3",
                        "defaultText": "사람들은 가끔 너무 피상적이야. {W:200}선택과 교류에 따라\n성격이 바뀐다는 사실조차 모르거든!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B236425003F1E1473D6863D6AF7270853D78",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "072310F16971754E646AECF2C265BE96775D"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "541A85DA8A070643351A1E448DE4C5D67214",
                        "defaultText": "알고 있어! 일부러 이렇게 말하는 거야!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "77DCF7852E80754CF958659467F1E1D2FD6A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8F0021A16A3FB544BF2BAEB307EA9CCA2215",
                        "defaultText": "어… 뭐라고?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0FBDF63E3C7214419239AD62EADF63924D9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "meta",
                            "wut",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF8A2D95134F5545176B730436A2C6F08ADE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2C4F54E12E5774477A8A967236C592F6D317"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "meta"
                },
                "indent": 0,
                "uid": "0E10FC279036D648881BFCE759DFDE225D34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            8,
                            4,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D56989800355D5491D480859F676D49E10E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F8489AD38FC7845F66ABE164655F4277359"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE01E5A95DF1E6495F1B9211851555F0F159"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63FE89F4772766493E3B81F55324CB83DE0E",
                        "defaultText": "그렇지? {W:200}역시 이해하는구나, 헤헤!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F2C411C4295985482F2BD384DC254CC3FF3A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "300DB52D10D7A14187591588293F001E4EB5"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "end of choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "817B93912DE20444E868D391F6A33D2062D7"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "wut"
                },
                "indent": 0,
                "uid": "FE0F6BDD77B9A146C59BD1B895014C5C9621"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            1,
                            8,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "82CB19A58F6992476D399EA5315C27BDDCC6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "045B8DF77E8AB04BAD2B78B7F19F0B4F076D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B4611AE186D7647E72AB2A781E5EF34F57B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C0C000B66463984A5B2824B78124536665ED",
                        "defaultText": "정말 이해 못 하는구나?"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E09DEBF0793DD94CD969C0683A3AB1271E8A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E02F12B527D923423C9AC66517104C3452A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F94FEF2B52BBB84C25089BC2571F7A03DD36",
                        "defaultText": "아니... {W:100}잠깐, 일부러 그러는 거구나! {W:150}\n역시 내 말이 맞았어!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA0A3DA1568A584228880EF854090DFEAFEE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EA644E411DF9040DA4910F2601EA8D3649D"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of choice"
                },
                "indent": 0,
                "uid": "91B0A5BE49C602413B7B9311B785BEBF145E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "544E1CE838C4C148C00A17E89ECDFEDAE185"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5F43544212FE8641FD28D145C25A20843C8D",
                        "defaultText": "이 아이가 천재인지 완전히 미친 건지 모르겠군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5F9075284D35634F273963732EABCF869EE7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2CCA39D943BCF744836BB3D006B1E818AD98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "359141CE43087248611A1253FC0285D0315F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA68910A28B1D4428149EDF6EDA4A0F2E5F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB58F8B19F277841E7390DF4EBDE170404F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5890328C6196854B419AC17358BC6919172A",
                        "defaultText": "이제 정말 가야 해. 다음에 또 보자, 나나!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CBAFCBAC31448844EA4993A748127AF95BE3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FF6B540D0A10D244F1194994771B7E2C8F6F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6055234F285AF84DA87B60147AE22D835064"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B9A8A2215584284D4729B3A4C20B971BCA87"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "02D15EEF5A98D44BEF18EAD4CC87FC234096",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/EXTRAS",
                        "name": "E3-Nana_line7_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C08EF276373F3048913A13B73037D8D72D4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "05F28B207F91B142D35B6518F7488BEB5F5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "FA72429357D43349B2781CC7A1E2818C5673",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "66EA26E3202697471729E3884560A789C22E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A599205019C2E744DD29D7A90BE0B514E260",
                        "defaultText": "좋아! {W:100}계속 지켜볼게!"
                    },
                    "position": 0,
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6C1448573DC545437C8AEAE133CE6E395799",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "672709697C22E44BE34A80A53D432E18704B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "Second time skip"
                },
                "indent": 0,
                "uid": "6E6A7D645AFBF144E5586DD305A5870C5601"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "759830652FB4C5449E7B69E1BA80460B65BD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C06BA69C2E046249CB09A9387BBA4B7129D4",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97748E6C732ED940893B8BC1B8D9AD572986",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "803BCEAA4F95A845E25A7E63D55B8B3D9E7C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "06F8FAA560963140C3288C719D9CB3244550"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "56E0AFF953DED4471B5A8087E5D674F6FBFC",
                        "defaultText": "부모님께서 남의 사생활을 존중하라고 가르치진 않았나 보군."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6E2EF8CF51FE6841CB99E328A84D8B534E4A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "98CB6C765541974E335A9F40E2EF92649813"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4243B31460128847040BE087CBB5CBFE7859"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7E1E79D32660944D618B91E0CE0CFC4324AC"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 1,
                "uid": "4CE598354ECA774F9B08AC154739BEB3BEB9"
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "FA72429357D43349B2781CC7A1E2818C5673",
                    "param": {
                        "name": "Legame",
                        "type": 0,
                        "value": 0
                    },
                    "numberValue": 1,
                    "textValue": {
                        "scope": 1,
                        "index": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 0
                },
                "indent": 1,
                "uid": "3E70157F4F9E244F532A5B37D10349C53016"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "D31713849A2BA2486F5B17957A4E75BB01A8"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 15
                },
                "indent": 1,
                "uid": "0A0AE33B2C4BB9435638D83506E22D3CB1C4"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8077323D68B7D84507580F49B27AAF94B82A"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "read",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "E6AD1A054A8B184E74780992F0ED9A9F21C5"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "E62FBA003BB3E54C330AD594512E8E8A210E",
                        "name": "[Tutorial] Secret Personality Traits"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "A3851C8E7816784F8149B3891702F9142DFF"
            }
        ],
        "localizableStrings": {
            "A8DFEA623A80084141281B430685B42884ED": {
                "t": "Hey!{W:150} I've been watching you for a while now.",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "62C7F60E76B427445D6A4A529E41AA80AA8C"
                }
            },
            "CEA831401AE2E446EC4B88522AA0332D245D": {
                "t": "Er... {W:150}Good afternoon, young girl--",
                "d": {
                    "cid": 0,
                    "eid": "AFA659595C43E74EBF382DC0A8A4B790783E"
                }
            },
            "746B5EC347999540634A9DD4A8D4602AAE7E": {
                "t": "My name's Nana!{W:150} N-{W:50}A-{W:50}N-{W:50}A!!{W:200}\nAnd I'm not a young girl!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "76DA198F0817564B98498F21D9B52A462B35"
                }
            },
            "97016B3F24D5A348600BD1F736E2443F1D20": {
                "t": "Sure...",
                "d": {
                    "cid": 0,
                    "eid": "8736A6E740F007484A6970B384FB3773E84A"
                }
            },
            "6B1CA59D1FF4D5494788A0F76923B0041A33": {
                "t": "Forgive us, Nana. {W:200}We didn't mean to upset you.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EDC763B53241984957490E73FC0875A2E162"
                }
            },
            "426CF175772059453C1B2EB35A69B75FA551": {
                "t": "Is there a reason why you were looking at us earlier?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E5DCE2D24CE9A24C5B1A8105C275BDBDCF39"
                }
            },
            "BDC8819B437EE9404F3B9B987E97499C256E": {
                "t": "Doesn't Shiori already know the answer to that?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "21BDB40F4E09934A47081037A2B9ACF71A86"
                }
            },
            "F3270D154281F348813AEB288B344E1F516E": {
                "t": "Perhaps she wants me to play along...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C4CF63A56C73A7455F1A40027E502D19BAB9"
                }
            },
            "21F5764530A3A246CE9BBDF50D6957CFF023": {
                "t": "Yaaay! {W:200}The lady is much smarter than the other guy!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "59835DFC782AD748AB28DFB4CB66A84E7C8E"
                }
            },
            "FA7CCAC88407F44D9E5A3EB4C5A6F204647E": {
                "t": "Well, actually I've been feeling so confused lately that I'm wondering if I still have a brain!",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "7412C8E944721846BD9AA5D4D3DEFD75C023"
                }
            },
            "DC6F389377E16141F38AEA67481677B00A60": {
                "t": "Whoa, I wasn't expecting that kind of {SP:2}{C:1}sarcasm{C:0} from someone like you!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "63EE88BA06B1C5444E4A2E95B283E4F437C1"
                }
            },
            "CE5EAEDC7DE6C24FF12BB8822C95715AAF5D": {
                "t": "I can hear you, you know!",
                "d": {
                    "cid": 0,
                    "eid": "C8A1E36231FB584F167A2F34E604FE744578"
                }
            },
            "F0EC454A7FAA8544AF486671A1E905ABF9BC": {
                "t": "Boooo!! {W:100}You're not funny at all... {W:200}I was expecting a more {SP:2}{C:1}sarcastic{C:0} response...",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "646013B46046B640BB1971C414F8DF19074E"
                }
            },
            "FA32AD167ECF65416748C004904DA412721A": {
                "t": "Teh heh!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9E2AF96D14B7924296496AE5B5D09B8F1508"
                }
            },
            "ED012B6C2D4A7143B02BC3259CA574D98839": {
                "t": "Since I'm the smartest person in town, I always like to listen to everyone's conversations!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "1F251DE5648F5645B34B7E4401F29FB7928E"
                }
            },
            "0E93ACD7834AF64FDB4BD15227440B1F63E3": {
                "t": "People sometimes are SO superficial. {W:200}They aren't even aware that their personality changes based on their choices and interactions!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "B236425003F1E1473D6863D6AF7270853D78"
                }
            },
            "541A85DA8A070643351A1E448DE4C5D67214": {
                "t": "I'm aware! I'm choosing to say this!",
                "d": {
                    "eid": "77DCF7852E80754CF958659467F1E1D2FD6A"
                }
            },
            "8F0021A16A3FB544BF2BAEB307EA9CCA2215": {
                "t": "Er... what?",
                "d": {
                    "eid": "0FBDF63E3C7214419239AD62EADF63924D9D"
                }
            },
            "63FE89F4772766493E3B81F55324CB83DE0E": {
                "t": "Right? {W:200}You get it after all, hehe!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "F2C411C4295985482F2BD384DC254CC3FF3A"
                }
            },
            "C0C000B66463984A5B2824B78124536665ED": {
                "t": "You really don't get it, huh?",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "E09DEBF0793DD94CD969C0683A3AB1271E8A"
                }
            },
            "F94FEF2B52BBB84C25089BC2571F7A03DD36": {
                "t": "Or... {W:100}wait, you're doing that on purpose! {W:150}So I was right after all!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "EA0A3DA1568A584228880EF854090DFEAFEE"
                }
            },
            "5F43544212FE8641FD28D145C25A20843C8D": {
                "t": "I can't tell if this child is a genius or utterly crazy.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5F9075284D35634F273963732EABCF869EE7"
                }
            },
            "5890328C6196854B419AC17358BC6919172A": {
                "t": "We really need to go now, but we hope to see you again, Nana!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "CBAFCBAC31448844EA4993A748127AF95BE3"
                }
            },
            "A599205019C2E744DD29D7A90BE0B514E260": {
                "t": "Okie! {W:100}I'll be watching you!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "6C1448573DC545437C8AEAE133CE6E395799"
                }
            },
            "56E0AFF953DED4471B5A8087E5D674F6FBFC": {
                "t": "I suppose her parents didn't teach her to respect other people's privacy.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "6E2EF8CF51FE6841CB99E328A84D8B534E4A"
                }
            },
            "04EFDC18973568425B3AB6254DFADBC744B0": {
                "t": "Nana",
                "d": {
                    "eid": "8514AD849D63D447F17B1443C032BC25CC62"
                }
            },
            "C2D664C622A5354A9C3A8047695B77983DFB": {
                "t": "Bonus points for the self humor!",
                "d": {
                    "cid": "FA72429357D43349B2781CC7A1E2818C5673",
                    "eid": "FB34E5FF80C686400E68683776A1B4EAB441"
                }
            },
            "72399CA01831C84EF419A7E209194C97E44B": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D456DE305ED0614B678A5C171F8590563BAA"
                }
            },
            "455175191E86F142A78A4C385A0C7D9F9415": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "E680A1B737253349FD3A8E5598FE0C62B705"
                }
            },
            "46228F724C7A54493C4BE5D5C2F10FC5504A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "53E4F77D6F53E44F5A4ABEE52F3298726824"
                }
            },
            "CAE7946948A20441C23AEDC4B0FC275977AD": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "414AFFFA448C0045AD6B7732E8AC06F40902"
                }
            },
            "29D5FDFA893EE141615B2E927562DA73A8EE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C020371393860940C15B6AA39BC900672C88"
                }
            },
            "DC56C6E30890C24C1918CAA1ABBCEE1A93D2": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "D6A078C48C59B54273792A17AC1EA46D5FBF"
                }
            },
            "DE52D0375732E14F84080AD7953313D456BE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A290CF3E51D8F6424129F65350D0A156BBC1"
                }
            },
            "2E054595363A8140995BC25590D28273358A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C7B3825B58D3E84CF98BFF015EDD7F13C29B"
                }
            },
            "B840AB4D1EE7F34B2C3BCA24543F5D76053D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "077DC58230FA684967299202F3A9F0AD7736"
                }
            },
            "02D15EEF5A98D44BEF18EAD4CC87FC234096": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C08EF276373F3048913A13B73037D8D72D4A"
                }
            },
            "C06BA69C2E046249CB09A9387BBA4B7129D4": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "97748E6C732ED940893B8BC1B8D9AD572986"
                }
            }
        },
        "stringVariables": [
            {
                "name": "Nana",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "Sarcasm",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "booleanVariables": [
            {
                "name": "read",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}