GS.dataCache['17E797B554D2904A7399B560826E7A869FB7'] = {
    "uid": "17E797B554D2904A7399B560826E7A869FB7",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C1-03e Chat with Shiori",
        "type": "vn.scene",
        "parentId": "F7F581B17D00D5435868B5C374116B4EBEE3",
        "chapterUid": "CF7E3CE62FB82749AB7B39C1990AC623D042",
        "order": 7,
        "localizableStrings": {
            "9D2A4F6555875640EF6B8AC7932AD95FA231": {
                "t": "Okay, I may go with this.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "AC91CC877AEB374F5B59F6586749ACE644F6"
                }
            },
            "5D38F944426A264F7F297252189068BE8FC5": {
                "t": "What do you think of your power?",
                "d": {
                    "eid": "7C95ED123C753741C889BED5EB9B1F9D5206"
                }
            },
            "5112249967AD734EA52A9E40269C0C4D73AE": {
                "t": "Aren't you cold?",
                "d": {
                    "eid": "007BD741560EC44A1B8BCFD7331D8BCF096B"
                }
            },
            "B5BA829572CC364BC83BC4B72534E8884A29": {
                "t": "How can you 'see' the luckos?",
                "d": {
                    "eid": "FA754FF74F056045647859B510B2C746ED75"
                }
            },
            "B2FEE5F889198847229A3F7163FA4F3B9130": {
                "t": "Oh.{W:100} Why are you asking?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3AB8BA263919044441490689D84D5A80EE3C"
                }
            },
            "A217A01C01AD1141D09ABB03181819F2AB77": {
                "t": "I've been asking myself this for quite a while, actually...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "2EC3982B3C505341A85BA221DDE14128915D"
                }
            },
            "8A78AF191AE50246222B2683B695A5FD1482": {
                "t": "When we defeated those bandits in the forest, I told you your power was incredible.{W:200} But you didn't seem of the same opinion.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4B5CC0713440E04AA17BD6275410F638DDEB"
                }
            },
            "5BD1ECC76D4521489818DA625F92B5FA3DD7": {
                "t": "... ... ...",
                "d": {
                    "cid": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "eid": "458937E2397A87463B6938321AFE58EA9DA0"
                }
            },
            "8C0A2D847C76134FD54A53E67EC81BC9E3BF": {
                "t": "Forgive me, perhaps that was inconsiderate.",
                "d": {
                    "cid": 0,
                    "eid": "C0A2AF88833C394DD67B9CD79E8D7BD57673"
                }
            },
            "5E95788C478DA446C48BE3B8973BC6DE1116": {
                "t": "Quite the opposite.{W:150} I just find it surprising, that's all.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A7D4C80B4A0EB041D56AF638DAC8E63B11E7"
                }
            },
            "F907CA8D6435C64882290DF6DF514DC7278D": {
                "t": "You've always been quite introverted, so it was very rare for you to bring up this sort of conversation.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9AD4A9489895064B1B4B68619DE5EDF79A9D"
                }
            },
            "64B2ECFB0EF838417E692653BCB7E7C99AE9": {
                "t": "So my older self used to behave differently...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "EDE656B774632443526AE6226EE4BF7DA376"
                }
            },
            "FF1369598102524081789535764466470387": {
                "t": "In that case, should I try to align with his... {W:150}er, my previous personality? {W:200}Or is it okay for me to live as it comes naturally?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "53EA30F986C6484C8D09D603C2641F416782"
                }
            },
            "3712EB206633884E2D1BB9849D460E83CBA0": {
                "t": "Gods, what a headache...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FE27371B8811754FE42A93D1DDFF3B033F77"
                }
            },
            "CA9135130B1FD64D0159C3D3192A110C4C2C": {
                "t": "I feel that my observation is troubling you. Please, don't worry. You asked a legitimate question and it made me happy.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C13D565E345D18439D88566753D779B50CF7"
                }
            },
            "DAC8BA0436F49843FF99E2D7E63183E0755C": {
                "t": "What I think of my power, huh?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "13638C5734A823446648C810157BDD6B8A46"
                }
            },
            "3C85803B57ACB3476C082DB24972B04F124D": {
                "t": "Earlier today, you said to me that being able to sense other people's malice is \"incredible\"... {W:200}However, I don't like it.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "FAA1AA1148B89747B948CB820C1149299DCD"
                }
            },
            "42D979B221A757417F4ACBE91F7DBE8A7D9A": {
                "t": "You don't?",
                "d": {
                    "cid": 0,
                    "eid": "9B8D53FE56A492442868E3E8E12DF6B1BC04"
                }
            },
            "84F43F175FFE374437985F5042E563242EBE": {
                "t": "Imagine that you are constantly hearing other people's voices...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DDB563668176424E0C9B2FE500F0908F2A1C"
                }
            },
            "440CD3D8730B6648CC49F2F0F481C6A937D8": {
                "t": "Their hatred,{W:150} envy,{W:150} perfidy,{W:150} and all that leads to hostility towards others.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3665196115F677481F4978427EB1D271DE2B"
                }
            },
            "79AAB0BF3C74514CA26A8C740AA8AF66895E": {
                "t": "Can you...{W:200} imagine such a life?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5CDB840C716E8240FC4A2564D87768803054"
                }
            },
            "D47620056EA0634F687A81673E37129CAEB9": {
                "t": "I understand your feelings, Shiori.",
                "d": {
                    "eid": "6DA464116F832645BB8B11953CB83EDD4398"
                }
            },
            "E304F9C065F42247A26A9954416E974BFF28": {
                "t": "No...",
                "d": {
                    "eid": "C6033E572131B143278AF6943407FBF924DE"
                }
            },
            "150911634CDEF146E90BA08283E21AA27AF0": {
                "t": "",
                "d": {
                    "eid": "5098300D37A3B6467519EC0308383BFF73A8"
                }
            },
            "2BB822CC24E5574E6A2809321B8286292453": {
                "t": "",
                "d": {
                    "eid": "799CACDD77BBC7494B99F608C601CF9D03D5"
                }
            },
            "018C19A139C6564B6E4B33E6DD71825B3148": {
                "t": "For real?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3DC720514F59514C41494654673EF9674400"
                }
            },
            "D27470020664A54DBA5AD61850BB43A8795D": {
                "t": "That kind of power has its drawbacks.{W:200} Sensing other people's emotions must be very stressful.",
                "d": {
                    "cid": 0,
                    "eid": "63A5E20610DE20431D5907D32D8E5FD47A23"
                }
            },
            "B9848DAC497A5449141AC731CE74B32AB4F2": {
                "t": "I think it goes deeper than you think, though...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7321BC863D69B845A43BBC50615873576F77"
                }
            },
            "346E99031231C148B77935A3FFC06ACFCFD2": {
                "t": "I sincerely appreciate your honesty. {W:200}Indeed, this power isn't something that other people can fully grasp.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "838459D83248B64BAE59EB374DA7D8C67D8C"
                }
            },
            "D27716E03BDE1143FC898178192F2DA2DF38": {
                "t": "Imagine having to live surrounded by other people's negative thoughts and feelings,{W:150} constantly and without interruption...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5CDBBAD62A6AA74F4E89B615814C5DBA11F1"
                }
            },
            "1EE1E82861E8244FEC6A04B6F6F4B4198E41": {
                "t": "If you close your eyes, {W:150}you see them anyway.{W:300}\nIf you plug your ears, {W:150}you can still hear them.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D7CFA2694A52194B60798E957709FE111FA9"
                }
            },
            "CA73979E56240547FC5AF952D1AA63B77A9C": {
                "t": "From the first second you wake up, to the last moment of your day...{W:200} You're never alone.{W:150} Your inner thoughts get constantly mixed with theirs.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "DA6972A8812AF54E18797EA2425BBA62A097"
                }
            },
            "FE009D413D0A664289083594F7CA20780034": {
                "t": "Could you...{W:200} handle this burden?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "2FDCE7292E2F7747ED4BC6558C90DEDB7160"
                }
            },
            "5D8659884619984519882522C98A4FBE8A4D": {
                "t": "I try to imagine hearing hostile voices in my head.{W:200}\nI can't hide.{W:200} I can't stop them.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "508FB9EB8706324F4248D108F04CB7893194"
                }
            },
            "ECCE71CC8299F7449E89FC87D3A12EEAAB18": {
                "t": "I have already experienced this before with my visions.{W:150} However, they last but a brief moment.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FFA393E199B6134CFE7B91951A5D8462F618"
                }
            },
            "DC07EE6508BD4546B748CC816ABB08AEFD01": {
                "t": "If I had to constantly live like that, it would be...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "785A60EC8B61F9401149D12469F2DFBCB1D0"
                }
            },
            "94D709486390C44BE74946E4584B00B9EFE7": {
                "t": "... {W:100}It would be extremely hard, Shiori.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "C8C9D64017168048538A588612420A417263"
                }
            },
            "B7C9EF4B338E2147D12970154770C3536E7C": {
                "t": "I have a feeling my question was truly inappropriate...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "E15B4717340F7245AD8AB94378896E34A8B7"
                }
            },
            "D165AB8D338F824DFD889787CF6E70F769DA": {
                "t": "Now you're feeling guilty, right?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EBE818178CD00842BA0AFBA13EF977A4BB01"
                }
            },
            "21730A427BC9724E7849D2779249AF0DEC69": {
                "t": "... How did you guess?",
                "d": {
                    "cid": 0,
                    "eid": "76CD25CE5687D84F1E78E4A175C238E08188"
                }
            },
            "EC707173298AB047E818D4F47A1575472DEA": {
                "t": "Because you're being malicious towards yourself.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E63F31FF7B183143CC688B12F86EEE06B189"
                }
            },
            "A8527F73613C2447BD4AB3018B7BD1FC8B65": {
                "t": "... ... ...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "7D27FCF73B0C0846996B44E4470DD9C8C4E9"
                }
            },
            "FB01C5A727289849AD1B1A666AEFF7465ABC": {
                "t": "I can understand a lot more things than I show, Nini.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5024FFDB5306134DCB8AA5C8B411E054D6D5"
                }
            },
            "623D750B402EF345216AFC9696859475F631": {
                "t": "But to have a normal conversation, sometimes it's better to pretend not knowing.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A5310A660BAD084E6E783C36D63F223E43B8"
                }
            },
            "83EA1D5E556AA84E7A4A2A95833364CC506C": {
                "t": "So not only are you forced to sense malice,{W:100} but for the sake of others you also try to hide it?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "BC02988990E5B74EEA29B5234DF0151BB254"
                }
            },
            "AC700A1A44DEF7470D786347398EED0DBCAA": {
                "t": "I'm...{W:100} sorry to hear that.",
                "d": {
                    "cid": 0,
                    "eid": "CD9F5B55298E934D3D387B7333ABAB8D982A"
                }
            },
            "AAC0B16D3114A546C71B4D2101E0D6B93AB6": {
                "t": "The only thing I can do for her now is to minimize my feelings of guilt...{W:150} I don't want her to carry this burden, too.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "D8169BE129C3074C23888E265D21604ED3D3"
                }
            },
            "173A536A341D05462C586F74D5D62D82869B": {
                "t": "Don't worry,{W:100} your emotions don't bother me.{W:200}\nIn fact,{W:100} you were sweet to worry about me.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "520A3C127E080548776A7E051D1DBCACEB01"
                }
            },
            "318D15F68AE3D24E1F0BEF03C9A8352D9B1C": {
                "t": "I don't know how much an amnesiac's word matters, but you can count on me.",
                "d": {
                    "cid": 0,
                    "eid": "F0C3F0E51DE9244CFA99E3330B1ECF09F0ED"
                }
            },
            "4F8C0A127A3C554A5C8A1F04029AE4EF6C0D": {
                "t": "It matters more than you think.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "67C810848603184C379967345B3EF9AC4188"
                }
            },
            "6159C4D28DEC6445CB7BC441C050EC2B597B": {
                "t": "Hahaha, not at all!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "0A7BD0651164294A8E79A858A43ABE2FACD0"
                }
            },
            "548808D69023F645BD8B296534058361A380": {
                "t": "But we're freezing here...{W:200} and in the forest earlier it was even worse!",
                "d": {
                    "cid": 0,
                    "eid": "A7CA9B985C5D2743965877505486FD4BE9F3"
                }
            },
            "07D0755B6C40F54EA75B3DF8F6DFDDA80981": {
                "t": "Anyone born in Pylum is used to these temperatures.{W:200} But I guess you forgot? Hehe.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "E0C590156091284FBD3A71B32BF8A43FF089"
                }
            },
            "47DC17244E9097447D294228ED374010589A": {
                "t": "... {W: 250}Of all the visions I've had so far, this was certainly the most bizarre.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "089BD2637404594D4C7B357719F0C0F56EFD"
                }
            },
            "67EF755A172484498F5B7F2563AE1F737BAF": {
                "t": "What did you remember this time?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "6E9A29032CE0434B1058F6698E0AC81F20E2"
                }
            },
            "BF3E683B469A6244E42BE378CF0AE575A415": {
                "t": "There was... {W:200}someone, I can't really recall his name, who used to play his own belly like a drum.",
                "d": {
                    "cid": 0,
                    "eid": "794F17952FF80648A96B0D44218F5C140E1A"
                }
            },
            "B404AD93671968437128CC46DFB58B487A8D": {
                "t": "Even in the middle of a snowstorm, I could distinctly hear this person's...{W:150} special music...",
                "d": {
                    "cid": 0,
                    "eid": "2FBBDA1632A9364EB2881211641901FAF96C"
                }
            },
            "1FB06CA731CD5741F03BAA8122A843075057": {
                "t": "Oh, it's an ancient Pylumese mantra!{W:200}\nPeople do that to chase away bad thoughts and fortify the spirit.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D782B571899E834A5068F975AA740E58962A"
                }
            },
            "DB6B57164066A24A038B5DA2FAB256DB1847": {
                "t": "... The only thing I want to chase away right now is this weird image from my mind.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "F4AC103284F8A646ED4A2D1631AC69D8EC03"
                }
            },
            "F82D32E440CE114CB21864F77645FFA2F512": {
                "t": "Let me answer you with another question!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3EB2C4A68D57F44ECE38B9C39D3EA159BC1E"
                }
            },
            "7DACF0F93D7D3445642A916870C287E4EDA4": {
                "t": "Do you think there's any difference between the malice of a human and that of an animal?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "AAE72C683C1FC14AFC293B38C63DF9F7A9BB"
                }
            },
            "4F1BE06D1634334CDE38ABC520E2300609A0": {
                "t": "Humans are more malicious.",
                "d": {
                    "eid": "8B81102465EBB84BF86854019672B9185C3F"
                }
            },
            "F6A9A2181218984C6B78A47454CD5335C3D5": {
                "t": "Animals are more malicious.",
                "d": {
                    "eid": "6E2547836034564F356B7041DDF5B84772E2"
                }
            },
            "5FCC95BA1938474902499F053114BF978535": {
                "t": "I don't know.",
                "d": {
                    "eid": "58CDB31922A1334BBD287D71D219EA8859D1"
                }
            },
            "457AA1561108054CF22B5C816214BB6F77FF": {
                "t": "",
                "d": {
                    "eid": "2CF1D253309C47481B58F603052F638EFB02"
                }
            },
            "36CC51F649DE124BF6796A8407AE640D5868": {
                "t": "That's what you think, huh?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "94EAB1388D246645837AFD76B06255384A0C"
                }
            },
            "7F3BBEC256E2B841F6288343CC3C2D14112F": {
                "t": "Your doubts are justified.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "08559C017FE427474F097D31C424BDF96DF4"
                }
            },
            "83E4BFA556C17048586B5DE767118A282E8E": {
                "t": "It doesn't make much sense to compare the two. {W:200}Both species are malicious, although for different reasons.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "3035427C192F5342008B6708D921C19BF2FD"
                }
            },
            "9A207F0F3F30D145BD2993B5FC7FA9914DE8": {
                "t": "Animals are more instinctive, whereas human beings are more complex and sometimes sneaky. {W:200}But we're still talking about malice either way.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "EA4A8A5B0CD6944E7479004345B50D37B5B9"
                }
            },
            "5DE257EA1C44A84BDF7968E8E988B306D013": {
                "t": "I see. So the luckos is...",
                "d": {
                    "cid": 0,
                    "eid": "B067843272484444E75929B060A9AB0142B4"
                }
            },
            "7585160B3F68A545892B86810250BFDF3D65": {
                "t": "Woot?",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "B3360E461AE4B34B396B0739F9A64613F34C"
                }
            },
            "80F2C8283AD1D245F87B7466C34847C9862E": {
                "t": "That luckos is an exception. {W: 200}Despite being an animal,{W:200} it has the malice of a greedy human tormentor.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "A70AA7D23745D34C5A2944341AF3A0CFFDC3"
                }
            },
            "7CF30D8F07A8054A6449D325C05FF67972C3": {
                "t": "Woot woot.",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "E018A7714DFDE64F11887F1140C02C2CFA94"
                }
            },
            "2004369A880C0441FF994A82361EE1B6D56B": {
                "t": "I don't want to know what's going through its head...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "0CDD262763EF8649F04A4D32895AEC6AA901"
                }
            },
            "8898A56F3400D249CF7994B7542C0D4916D7": {
                "t": "I can't think of anything else, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "F6408F5D3AE1574F2408216834058787CC23"
                }
            },
            "44CED77511D03847F41A9E28F651CDF34E00": {
                "t": "No problem!{W:100} Teh heh.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "8BD5D5B4175EF04B2D392129BC656144854A"
                }
            },
            "0391CE5B4F57D449B41B2854497455534212": {
                "t": "(I don't have anything else to say.)",
                "d": {
                    "eid": "D8E5B56D44BD6548855B2ED54E64D38385F6"
                }
            },
            "6A11BE6A884CA14F8458F66410C249B67B9D": {
                "t": "finediscorso",
                "d": {
                    "eid": "1D4A074344EDA143C81BA741AEC71192E108"
                }
            },
            "B263AE4E4596134F495918616A93F187993D": {
                "t": "What about your memory?{W:200} Anything else came to mind while talking to me?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "397BD7A61C2E484BC86AD515ACE821AB71AA"
                }
            },
            "CDA9778B8D76F44F723BD6610B678217D133": {
                "t": "Nothing relevant, I fear.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "40304C9D3321E0472279DFB186B50E3DD11E"
                }
            },
            "0C8739A682B163481049B807A47E6F749A2F": {
                "t": "I see. {W:200}Don't worry, I think you just need some more time.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "9F2FE04885708641FE1A5572FEE22AF3F289"
                }
            },
            "A90C494F542929437A197419AC5C3ECF1E83": {
                "t": "In any case, our dishes should arrive soon. I'm excited!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "78BB7EB451F79441F46BCDB4FB5C1C38DB9A"
                }
            },
            "F85F748E78A5664F9388585208381F3C53F6": {
                "t": "It was a good idea to ask Shiori this question. {W:200}I feel like I know her a little better now.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "51A13FD53CB0B249047B74B8AB2FE91EE6AD"
                }
            },
            "1D8D4DE66AF2F4447B0AA3C9024A07DA5AD4": {
                "t": "It was a good idea to ask Shiori these two questions. {W:200}I feel like I know her better now.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A17F6E9B86D715422C4979572E1A0CD5DE56"
                }
            },
            "92C195D46D6ED74C9799FCE221B1A7034F65": {
                "t": "It was a good idea to ask Shiori these three questions. {W:200}I feel like I know her a lot better now.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "CF1535B18305B14926296E317C26E18D8E1C"
                }
            },
            "A0BAA1D551B8604A041B5D591C2CEA377329": {
                "t": "Okay, this silence is awkward.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FCFE0D5757FDE247256B8423334D278BC191"
                }
            },
            "A397F3021D3FB6454D19E831103D9C5F6BA2": {
                "t": "Do you want to talk about something, Nini?{W:200} Time will pass faster with a little chat.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C12AE6B71F7AA24CD62967A83988EE270BAE"
                }
            },
            "781F8AB519D3164A4B693D9164A010AF97D0": {
                "t": "To be fair, I've no idea what to say. Let's see if something comes to mind...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "700EB5250335104E8389BCA6E0E9B5C0D003"
                }
            },
            "7965951496A8394D7D5B61A19D47DB78323B": {
                "t": "Hmmm...{W:150} What now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F3799DEE7AA27240E96A8389AD126FE4660E"
                }
            },
            "34C28B9B6E9BD54F5418CE77DA7CCD4DFE50": {
                "t": "Do I have any other conversation topics?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "880DC86C6864B44B9C394265CAC4F2F1DF26"
                }
            },
            "D09497449FD0914F2368C49915F9426F1978": {
                "t": "People can get very...{W:150} defensive once they understand that their private feelings are being violated.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "262128800CE9224FC41A5C32643CEE3495FD"
                }
            },
            "AEF3F9A42423014C8C5B3BB58E9174C63C27": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F5DF7AAE21A32446D27A0CD0BF8C40A941FE"
                }
            },
            "2942B8417463C6496C5AFC80BD7A3E087809": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1F5EFC441E4FB3460D3ABA3115FC4ACC3FD4"
                }
            },
            "D51548DB0ED0E741730A64757C5B4C867D0E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "2D1BCBA59C1ED24E372A3594BA23606924A4"
                }
            },
            "C166FC150573474B0F3AB3F527EF7D88A7DE": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "AB0B54B19EFCB44F8D3A5316CA8E5D6A522D"
                }
            },
            "3FF2C0A0342BA64E3E7B46B14C44979A3431": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "533342596AF31343715A057375D8A71FCC7A"
                }
            },
            "01F1980987B66147798A10055A008C352FBF": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "F6834C98376B984CCE6981524FDA8B66E751"
                }
            },
            "B45F22C1167DE344A508141447C459302E4D": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "18B866627AAF07453C582A073C5F2F7792F4"
                }
            },
            "D2919E9387D5734C9B5B6F78EED3C00DBCA8": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "877A366A8ACAA74D0A1B5DB2A4DA697D4164"
                }
            },
            "8AA54A9B29CE554DF32897D2E5CC13DF28B6": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1B6BC0E909822440374BA275DC03A2D0A565"
                }
            },
            "D65093006F23C8473629CE114DF8D1E65EA6": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5F94A5DD837B4140CB198965E77A11632D39"
                }
            },
            "6170BBA11EB16248133AD157FD24F072044F": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "5998368B5D160443008AE56455BC366622A7"
                }
            }
        },
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "342F4B843219D5477E8ADD289E9D85D6B897"
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 0,
                        "width": 100,
                        "height": 100
                    },
                    "visual": {
                        "type": 0,
                        "quad": {
                            "color": {
                                "red": 255,
                                "green": 255,
                                "blue": 255,
                                "alpha": 255
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1400,
                    "blendMode": 0,
                    "zOrder": 0,
                    "duration": 1.2,
                    "origin": 0,
                    "waitForCompletion": 1,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 1,
                        "blendMode": 1,
                        "visual.type": 1,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 1,
                        "size.type": 1,
                        "size.width": 1,
                        "size.height": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "graphic": {
                        "name": "sfondo nero.png",
                        "folderPath": "Graphics/Pictures/CG Gallery",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    }
                },
                "indent": 0,
                "uid": "02004336196B584CBB3AD318D7F28CACCDF8",
                "expanded": false
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E6DCFAED29A7C94915283534CAA811E17E14",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD4BFBAA89C3B14DF84A5597757EABEE3B33"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "21CB77C16DEB404FA26A8F35BFB39B2FD0D7",
                    "parameters": {
                        "values": [
                            "FEEB28CE186A3342E70A634062AF25688319",
                            "AF0193483CAB5143EF682B46ACA3BD0118D4",
                            "",
                            "",
                            "",
                            "",
                            ""
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "43E2E11E8A93664FC97AB5F654954447316B"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 15,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1
                    }
                },
                "indent": 0,
                "uid": "D6FD658F774E42417A28EE61E2D3A747A033"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 16,
                    "duration": 0,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 1
                    }
                },
                "indent": 0,
                "uid": "B00A1578952338453688904968E62A20BDCA"
            },
            {
                "id": "gs.ZoomScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "zooming": {
                        "x": 210,
                        "y": 210
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "4EAE215D8BC63343644976A6A4A4460EFD65",
                "expanded": false
            },
            {
                "id": "gs.PanScreen",
                "params": {
                    "duration": 0,
                    "waitForCompletion": 0,
                    "position": {
                        "x": 120,
                        "y": -60
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "fieldFlags": {
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "5AB32AC776B35248C378FB50F4043521EBD8",
                "expanded": false
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "ui"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "model": {
                        "name": "Shiori.model.live2d",
                        "folderPath": "Live2D",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 707,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 2,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 450,
                        "y": 160,
                        "zoom": {
                            "x": 1.08,
                            "y": 1.08,
                            "d": 1.08
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 1.2,
                    "waitForCompletion": 1,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 0
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "2ACF9A254F30E34FD10A0EE768BF7013183B",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.6,
                    "idleIntensity": 0.3,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "C7E37C2E42263641428B08D4FAFBEE6795D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            13,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3C928C638BBB7649B69A48081F5F76B45F6F"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 60,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 2,
                        "movement": 0,
                        "mask": {
                            "graphic": {
                                "name": "9.png",
                                "hue": 0,
                                "opacity": 255,
                                "blending": 0,
                                "tone": {
                                    "red": 0,
                                    "green": 0,
                                    "blue": 0,
                                    "grey": 0
                                },
                                "folderPath": "Graphics/Masks"
                            },
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CBA3B5AF3CFE8645FD58CA13A0B4F67E1F36",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "DAA7D9D1787B85489B1A55D2C59974841D12"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "88346E6C570A5148AB7A8667E4843E025EB5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2BFA23445A332748C21A4D180153E150D6FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            20,
                            200,
                            1,
                            2000,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B3920AF6F78514BA08BC6D3EFF1AFFCDA06"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "04BCDED629F1A3498D79B1D4B4D65E313EF4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "859F3A7B672C2649241A1562EF4F94A3F7A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C805396A54EC3241161BA625EA479565E6F5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DC04F204D7E2546E72BCC750FCA0FFD2A63"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A0BAA1D551B8604A041B5D591C2CEA377329",
                        "defaultText": "좋아, 이렇게 침묵하고 있으니 어색하네."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FCFE0D5757FDE247256B8423334D278BC191",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E347D7FD2BADB645F9289C38A6A52C6B3C64"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC8C3C63431D7849347859F5D93668DB1855"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A397F3021D3FB6454D19E831103D9C5F6BA2",
                        "defaultText": "무슨 이야기라도 할래, 니니?{W:200} 대화하다 보면 시간이 빨리 갈 거야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C12AE6B71F7AA24CD62967A83988EE270BAE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DC473100A09A84D1E2A3703FBFA0F8460E7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "818486689F38704B618AA1193F7B8F7F3C53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C18762048A1005413F288D12BEDF0CF73766"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "781F8AB519D3164A4B693D9164A010AF97D0",
                        "defaultText": "솔직히 무슨 말을 해야 할지 모르겠어. 뭔가 떠오르는지 생각해 보자..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "700EB5250335104E8389BCA6E0E9B5C0D003",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18DF5C758914A746B07A2D52452BDA9B9242"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D4E9E766315E4477D1A3227B29440754835"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 81
                },
                "indent": 0,
                "uid": "E1B04FBB911D2841F8695774587E7713EFCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "507D89782F6DA54A359854768C8FA229796B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37C35D5024F0714E2B5A95039C90492FB8BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9E3C51DE942FB345D36A94A8976071EB0B51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9D2A4F6555875640EF6B8AC7932AD95FA231",
                        "defaultText": "좋아, 이 이야기를 해 볼까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AC91CC877AEB374F5B59F6586749ACE644F6",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5D38F944426A264F7F297252189068BE8FC5",
                        "defaultText": "네 힘을 어떻게 생각해?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "7C95ED123C753741C889BED5EB9B1F9D5206"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5112249967AD734EA52A9E40269C0C4D73AE",
                        "defaultText": "안 추워?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "007BD741560EC44A1B8BCFD7331D8BCF096B"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B5BA829572CC364BC83BC4B72534E8884A29",
                        "defaultText": "루코스를 어떻게 '보는' 거야?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": true,
                "uid": "FA754FF74F056045647859B510B2C746ED75"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "potere",
                            "freddo",
                            "lookos",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "DF0BBD2B375E914A0F3B9456DB25A6D13B06"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "loop di scelte"
                },
                "indent": 0,
                "uid": "01D190177F2BA14EEC39462166C50BF0B6E1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "8A8F1C006B9DF740285A49C3963AAB77F2C7"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1019A7D611EAA14299089B629A22306FEA19"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "856DCC4251C8934EC06981C4A6B52FD8080A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "0C2E1F011BEA57461068F014AFE8B03FAEF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7965951496A8394D7D5B61A19D47DB78323B",
                        "defaultText": "흐으음...{W:150} 이제 뭘 하지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "F3799DEE7AA27240E96A8389AD126FE4660E",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Numero risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2F605F55626508448288F6326146C8C34CDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D37D22687AF9704483093100A58392368AC2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "508B07CA1B9F874169498621C694E891F4FA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "34C28B9B6E9BD54F5418CE77DA7CCD4DFE50",
                        "defaultText": "다른 대화 주제가 있을까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "880DC86C6864B44B9C394265CAC4F2F1DF26",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F19520654512E04B268AEC930DDAF7551BB0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F4E9ECCB7A15C749373BA6F870A709D100EF",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2E2B3EF29ED696463178FCE53E1F05DB6FAD"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "potere"
                },
                "indent": 0,
                "uid": "F753D80B6798D647D57A74359958E54638B3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C36347C5B26F646E64AA356769DF5745D3C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3A77FEEF19F6C4405E4B74752E0A7D02EC6A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AEF3F9A42423014C8C5B3BB58E9174C63C27",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line31_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F5DF7AAE21A32446D27A0CD0BF8C40A941FE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "9326A494524B3449C17A1CA577252B21F371"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "34FB086668E57842DF7BD6503940565A4FB9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B2FEE5F889198847229A3F7163FA4F3B9130",
                        "defaultText": "아.{W:100} 왜 물어보는 거야?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3AB8BA263919044441490689D84D5A80EE3C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E5720BF16C6B4749A14982650AA07C724BC0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEB61F75765B45455878CD73B786BA81B191"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A217A01C01AD1141D09ABB03181819F2AB77",
                        "defaultText": "사실 한동안 계속 궁금했어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2EC3982B3C505341A85BA221DDE14128915D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E957F3E54AFBE3476639C3F89E900CC48B03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "762B29777F76E742A13ABDF137B256F651E3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8A78AF191AE50246222B2683B695A5FD1482",
                        "defaultText": "숲에서 도적들을 쓰러뜨렸을 때 네 능력이 대단하다고 했잖아.{W:200}\n하지만 넌 그렇게 생각하지 않는 것 같았어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B5CC0713440E04AA17BD6275410F638DDEB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F0727617DB6A1471E98EB1626F4DF8F36EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BADA0AD3BBE3346526971F2F24FD464B977"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C2CE78C9E3A714EE15B68A2AE13129DA47B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5BD1ECC76D4521489818DA625F92B5FA3DD7",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "1729CC7B604A89458248B2D6EA5A8E3C0DE3",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "458937E2397A87463B6938321AFE58EA9DA0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F28867326F184742F8381F1189DF94B53393"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6040796B193BF04B436B7AE1372149071EF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C0A2D847C76134FD54A53E67EC81BC9E3BF",
                        "defaultText": "미안해. 배려 없는 질문이었을지도 모르겠네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C0A2AF88833C394DD67B9CD79E8D7BD57673",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FD7566964E2A241D069C193F0F0B91018B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7AC9FE7E86C6254CEF29371976FEC253D42A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "823CE12C9C51D6401C7AF298C797BD8ECD57"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "09A7509E1530F346E28A6EC534796D081D68"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5E95788C478DA446C48BE3B8973BC6DE1116",
                        "defaultText": "오히려 그 반대야.{W:150} 그저 놀라웠을 뿐이야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A7D4C80B4A0EB041D56AF638DAC8E63B11E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FF95BB37150F24D0A98E5108271D3D1EC4F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F907CA8D6435C64882290DF6DF514DC7278D",
                        "defaultText": "넌 원래 무척 내성적이라 이런 대화를 먼저 꺼내는 일이 거의 없었거든."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9AD4A9489895064B1B4B68619DE5EDF79A9D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A12A1CAD8BEAD3487D98B32959CE1646206B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9E9F52D54BF524A29789764AC10F07B75FA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E0BE2172512A543D009D6847DEB0E105443"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 21,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "64B2ECFB0EF838417E692653BCB7E7C99AE9",
                        "defaultText": "예전의 나는 다르게 행동했구나..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EDE656B774632443526AE6226EE4BF7DA376",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E59FC8A469D2741258A2E46300BA947740F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 36,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FF1369598102524081789535764466470387",
                        "defaultText": "그렇다면 예전의... {W:150}아니, 내 이전 성격에 맞추려고 해야 하나?\n{W:200}아니면 자연스러운 대로 살아도 될까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "53EA30F986C6484C8D09D603C2641F416782",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8827800D54DA27471D494345D5ECA9A88D3E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 18,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3712EB206633884E2D1BB9849D460E83CBA0",
                        "defaultText": "세상에, 머리가 아프네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FE27371B8811754FE42A93D1DDFF3B033F77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "69B4171B21A8B648172B9D48D67B78394AA8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "BBF1748C368DD240C919D8F3C53FCB984916"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "74A7112F1E2F084222188D97C5679BF5C298"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D55EB7E2142CB741430BA1F320CE8BF39C48"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA9135130B1FD64D0159C3D3192A110C4C2C",
                        "defaultText": "내 말이 널 고민하게 만든 것 같네. 걱정하지 마.\n당연한 질문이었고, 오히려 기뻤어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C13D565E345D18439D88566753D779B50CF7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4B6E98F9403FB34D429831F37840966A2BAF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F84C0A544D6FD5476B890BB742B70D29EA5A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2942B8417463C6496C5AFC80BD7A3E087809",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1F5EFC441E4FB3460D3ABA3115FC4ACC3FD4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1612A345011FA7426E3B79B585F04BA8CDBB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0DD3A80697075441FA3BF706ECD3F98F38DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51AE40404047B342356B0B865C6DF7E28C23"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DAC8BA0436F49843FF99E2D7E63183E0755C",
                        "defaultText": "내 능력을 어떻게 생각하냐고?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "13638C5734A823446648C810157BDD6B8A46",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37175B426BFC454F527996B56F9C8C01B13F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3C85803B57ACB3476C082DB24972B04F124D",
                        "defaultText": "오늘 네가 다른 사람의 악의를 감지하는 능력이\n\"대단하다\"고 했지... {W:200}하지만 난 이 능력이 싫어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FAA1AA1148B89747B948CB820C1149299DCD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EBE5115516AF524B88091579796F6D47CD0F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1AD98D7539BE5343C89A88D6F098BA6D37B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "42D979B221A757417F4ACBE91F7DBE8A7D9A",
                        "defaultText": "싫다고?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9B8D53FE56A492442868E3E8E12DF6B1BC04",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A8A2CF70CC2214F401ACFC7AFCF95E9C961"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2277942259E722422848DE671AF3A99B3C97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "206E011E13AC814D165AA9D5510B6CFBD625"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84F43F175FFE374437985F5042E563242EBE",
                        "defaultText": "다른 사람들의 목소리가 끊임없이 들린다고 상상해 봐..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DDB563668176424E0C9B2FE500F0908F2A1C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "84864F537AD83244886864378D72CEBFD91B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "440CD3D8730B6648CC49F2F0F481C6A937D8",
                        "defaultText": "그들의 증오,{W:150} 질투,{W:150} 배신,{W:150} 그리고 타인을 적대하게 만드는 모든 감정을."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3665196115F677481F4978427EB1D271DE2B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5F62335F4C4FC54C6D290E949E83E055C941"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41B3FE7A67A08845DE7934D73D151B052380"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79AAB0BF3C74514CA26A8C740AA8AF66895E",
                        "defaultText": "그런 삶을...{W:200} 상상할 수 있겠어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CDB840C716E8240FC4A2564D87768803054",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC387F6864BA314801283A439A9AA6C7E048"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Choices",
                        "index": 500,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Choices bis",
                        "index": 507,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "199EAB893501F445E6183534B7993423E318"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista targhe Choices",
                        "index": 501,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Targhe Choices bis",
                        "index": 508,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6BAD025947F7894007382BE54F480363D2C5"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D47620056EA0634F687A81673E37129CAEB9",
                        "defaultText": "무슨 마음인지 알아, 시오리."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6DA464116F832645BB8B11953CB83EDD4398",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "E304F9C065F42247A26A9954416E974BFF28",
                        "defaultText": "아니..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C6033E572131B143278AF6943407FBF924DE",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "150911634CDEF146E90BA08283E21AA27AF0",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5098300D37A3B6467519EC0308383BFF73A8",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "2BB822CC24E5574E6A2809321B8286292453",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "799CACDD77BBC7494B99F608C601CF9D03D5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "empatia",
                            "sincero",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EC0F94A65F7344E883AFD556B38B16632D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4D4D3AD53B35774C90385B52E04B6006AAEB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "empatia"
                },
                "indent": 0,
                "uid": "E587B63B2F99054A320BD235DCF0D2D8F120"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "268DAE2B7CDC73481099C5B3A41DC8B527EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "018C19A139C6564B6E4B33E6DD71825B3148",
                        "defaultText": "정말로?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3DC720514F59514C41494654673EF9674400",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "744CA9D85FE2234FCE38B641372CAF469706"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0BCFB94C68EC5344CE790C22D85B036FE20F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D27470020664A54DBA5AD61850BB43A8795D",
                        "defaultText": "그런 능력에는 단점도 있겠지.{W:200} 남들의 감정을 느끼는 건 무척 괴로울 거야."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "63A5E20610DE20431D5907D32D8E5FD47A23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DDEE7BF53EE15348AD7A49A12B8BD9802088"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "099BA1D803EFE54C190ADB324914DF0DDDEC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FD01F46B17F46049228A67F493FEF66A055B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5740B5538AE92448017A1C56E323A912A58E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B9848DAC497A5449141AC731CE74B32AB4F2",
                        "defaultText": "네가 생각하는 것보다 훨씬 깊은 문제인 것 같아..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7321BC863D69B845A43BBC50615873576F77",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2DCB801496DC8149C21A82B6B911FCD5D852"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "momento drammatico",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "841BDEA8149B55442078C81162FDF3C560D2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "sincero"
                },
                "indent": 0,
                "uid": "0B9EFF0C37027140003A9B73973C3708D628"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            3,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B8907040F462845E66A4FA22AD91192E6EB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8885C3182F51C24A627BC793314958264051"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1B6593553069E84DA49B59D660F04840FA28"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "346E99031231C148B77935A3FFC06ACFCFD2",
                        "defaultText": "솔직하게 말해 줘서 진심으로 고마워. {W:200}\n그래, 다른 사람이 이 능력을 온전히 이해할 수는 없어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "838459D83248B64BAE59EB374DA7D8C67D8C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ABE51CE915B9A84A422B3E87F2249F5B798E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "momento drammatico"
                },
                "indent": 0,
                "uid": "1DE5EA4B5AA41240B67BAF075A416968BA59"
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 20,
                        "speed": 15,
                        "orientation": 2
                    },
                    "duration": 15,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 800,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "CF98A99944EB1542E62AD3B2E9C64A9223CB",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 1,
                        "width": 2016,
                        "height": 1134
                    },
                    "visual": {
                        "type": 4,
                        "quad": {
                            "color": {
                                "red": 0,
                                "green": 0,
                                "blue": 0,
                                "alpha": 85
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1069,
                    "blendMode": 0,
                    "zOrder": 797,
                    "duration": 30,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 0,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 0,
                        "size.type": 0,
                        "size.width": 0,
                        "size.height": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": false,
                "uid": "69F39A072A3C544EA398C0270D64DF6B2CAE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "96E8865C46A6744AF298785563F5D69BB4F3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "3A8010CF2165B248498804A2AB1A04DC2BCC"
            },
            {
                "id": "gs.PlayMusic",
                "params": {
                    "layer": 2,
                    "loop": 1,
                    "music": {
                        "folderPath": "Audio/Sounds/Ambience SFX",
                        "name": "Tavern Background.ogg",
                        "volume": "30",
                        "playbackRate": 100
                    },
                    "fadeInDuration": 18,
                    "playTime": {
                        "min": 10,
                        "max": 30
                    },
                    "playRange": {
                        "start": 10,
                        "end": 20
                    },
                    "playType": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "music.volume": 0,
                        "music.playbackRate": 1,
                        "fadeInDuration": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4657B1E06D03D84F0418F2E22ED39E140459",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "E366925B2BA1174B792827D6445A457832F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D27716E03BDE1143FC898178192F2DA2DF38",
                        "defaultText": "다른 사람의 부정적인 생각과 감정에 끊임없이 둘러싸여\n살아야 한다고 상상해 봐...{W:150}"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CDBBAD62A6AA74F4E89B615814C5DBA11F1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "260901FD6C5256493329F4D8638879DF279A"
            },
            {
                "id": "gs.PlayMusic",
                "params": {
                    "layer": 3,
                    "loop": 1,
                    "music": {
                        "folderPath": "Audio/Sounds/Ambience SFX",
                        "name": "Tavern Background.ogg",
                        "volume": "45",
                        "playbackRate": "90"
                    },
                    "fadeInDuration": 18,
                    "playTime": {
                        "min": 10,
                        "max": 30
                    },
                    "playRange": {
                        "start": 10,
                        "end": 20
                    },
                    "playType": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "music.volume": 0,
                        "music.playbackRate": 0,
                        "fadeInDuration": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1683DD60389E3644E259DBA118B0391EA4F4",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 1,
                        "width": 2016,
                        "height": 1134
                    },
                    "visual": {
                        "type": 4,
                        "quad": {
                            "color": {
                                "red": 0,
                                "green": 0,
                                "blue": 0,
                                "alpha": 85
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1070,
                    "blendMode": 0,
                    "zOrder": 798,
                    "duration": 30,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 0,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 0,
                        "size.type": 0,
                        "size.width": 0,
                        "size.height": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": false,
                "uid": "38708F7D2B03C547848B1FD6A5CB194CAD30"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "05057A4472BC0744727BF93186CD5B94EFCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "875CB9655399C7440F380E68EFC9A2A9A18E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1EE1E82861E8244FEC6A04B6F6F4B4198E41",
                        "defaultText": "눈을 감아도, {W:150}여전히 보여.{W:300}\n귀를 막아도, {W:150}여전히 들려."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D7CFA2694A52194B60798E957709FE111FA9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "457906101264814B48789193655FE20090A7"
            },
            {
                "id": "gs.PlayMusic",
                "params": {
                    "layer": 4,
                    "loop": 1,
                    "music": {
                        "folderPath": "Audio/Sounds/Ambience SFX",
                        "name": "Tavern Background.ogg",
                        "volume": "70",
                        "playbackRate": "110"
                    },
                    "fadeInDuration": 18,
                    "playTime": {
                        "min": 10,
                        "max": 30
                    },
                    "playRange": {
                        "start": 10,
                        "end": 20
                    },
                    "playType": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "music.volume": 0,
                        "music.playbackRate": 0,
                        "fadeInDuration": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5C94D3E013552946048AB057F8413A8EA517",
                "expanded": false
            },
            {
                "id": "gs.ShowPicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "viewport": {
                        "type": "ui"
                    },
                    "size": {
                        "type": 1,
                        "width": 2016,
                        "height": 1134
                    },
                    "visual": {
                        "type": 4,
                        "quad": {
                            "color": {
                                "red": 0,
                                "green": 0,
                                "blue": 0,
                                "alpha": 85
                            }
                        },
                        "frame": {
                            "thickness": 16,
                            "cornerSize": 16
                        },
                        "threePartImage": {
                            "orientation": 0
                        }
                    },
                    "predefinedPositionId": 0,
                    "number": 1071,
                    "blendMode": 0,
                    "zOrder": 799,
                    "duration": 30,
                    "origin": 1,
                    "waitForCompletion": 0,
                    "positionType": 0,
                    "position": {
                        "x": 0,
                        "y": 0
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "origin": 1,
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "visual.type": 0,
                        "visual.frame.thickness": 1,
                        "visual.frame.cornerSize": 1,
                        "visual.threePartImage.orientation": 1,
                        "visual.quad.color": 0,
                        "size.type": 0,
                        "size.width": 0,
                        "size.height": 0,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "expanded": false,
                "uid": "2495E7FA927EE84E81387CB549C434DA94A3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "4D458C8837D9A44E44692B88FBF29CE70103"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CA73979E56240547FC5AF952D1AA63B77A9C",
                        "defaultText": "눈을 뜨는 첫 순간부터 하루의 마지막 순간까지...{W:200}\n절대 혼자가 아니야.{W:150} 내 생각은 계속 그들의 생각과 뒤섞여."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DA6972A8812AF54E18797EA2425BBA62A097",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE5CDA566CA66443D64A63828814D9DAF5CC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FE009D413D0A664289083594F7CA20780034",
                        "defaultText": "이 짐을...{W:200} 견딜 수 있겠어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2FDCE7292E2F7747ED4BC6558C90DEDB7160",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C9C5EE969362B548A048B2778AE26B0805CC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E103B5587AAE39439C1AF737AB170E33C327"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D8659884619984519882522C98A4FBE8A4D",
                        "defaultText": "머릿속에 적대적인 목소리가 들리는 모습을 상상해 본다.{W:200}\n숨을 수도,{W:200} 멈추게 할 수도 없다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "508FB9EB8706324F4248D108F04CB7893194",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1CCF80779261D04EF74BBD19E7C788DA4B91"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ECCE71CC8299F7449E89FC87D3A12EEAAB18",
                        "defaultText": "환영 때문에 비슷한 일을 겪어 본 적은 있어.{W:150} 하지만 잠깐일 뿐이었지."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FFA393E199B6134CFE7B91951A5D8462F618",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A255EE334937F1446E791646CFEC16F384D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DC07EE6508BD4546B748CC816ABB08AEFD01",
                        "defaultText": "늘 그렇게 살아야 한다면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "785A60EC8B61F9401149D12469F2DFBCB1D0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93C312F88AB7274F1D5836A333691605FFCE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C2F6D4E671BCA44C4F09D8B80C2745F2D54A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D51548DB0ED0E741730A64757C5B4C867D0E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line28_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2D1BCBA59C1ED24E372A3594BA23606924A4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "333FB0F45A729745B54815478B410DCBF872"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "610460D356139640718A9BA72912DA7BC8BC"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "94D709486390C44BE74946E4584B00B9EFE7",
                        "defaultText": "...{W:100} 정말 견디기 힘들 거야, 시오리."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C8C9D64017168048538A588612420A417263",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B1FC70048E456348E33928A6740419985630"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64809F8D5749044E1B789B5282249FFC60B8"
            },
            {
                "id": "gs.StopMusic",
                "params": {
                    "layer": 2,
                    "fadeOutDuration": 60,
                    "fieldFlags": {
                        "fadeOutDuration": 0
                    }
                },
                "indent": 0,
                "uid": "8C8EA10614D13241260B21A6E1EE86D6D10A",
                "expanded": false
            },
            {
                "id": "gs.StopMusic",
                "params": {
                    "layer": 3,
                    "fadeOutDuration": 60,
                    "fieldFlags": {
                        "fadeOutDuration": 0
                    }
                },
                "indent": 0,
                "uid": "3E33709F0949414E974BC58341EDC8FD4475",
                "expanded": false
            },
            {
                "id": "gs.StopMusic",
                "params": {
                    "layer": 4,
                    "fadeOutDuration": 60,
                    "fieldFlags": {
                        "fadeOutDuration": 0
                    }
                },
                "indent": 0,
                "uid": "6A69A3B487A0A24E7479F2322A9F0A6FFF5D",
                "expanded": false
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1069,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "FDD85AD665B9E648F398B183F1A57256FFF1"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1070,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "0856A1F53D01584D376A38A77A92211AAEED"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1071,
                    "duration": 60,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "67EAE3760234974D173AC71609995A56C4B1"
            },
            {
                "id": "gs.ScreenEffect",
                "params": {
                    "type": 0,
                    "pixelate": {
                        "enabled": false,
                        "size": {
                            "width": 10,
                            "height": 10
                        }
                    },
                    "blur": {
                        "enabled": false,
                        "power": 0
                    },
                    "wobble": {
                        "power": 0,
                        "speed": 0,
                        "orientation": 2
                    },
                    "duration": 15,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "zOrder": 800,
                    "fieldFlags": {
                        "zOrder": 0,
                        "easing.type": 1
                    }
                },
                "indent": 0,
                "uid": "F72555E01C1EB24E998B969543BDCFE479A9",
                "expanded": false
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 120
                },
                "indent": 0,
                "uid": "EE09EDE26C2B104950789729874390500A2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "D85798AC746EC848256B6091F875A1BFC61F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "89F5835265AFB344121ADB59B9F4E7F6CA53"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC7566FE17CFE2480949F947687A206E415A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B7C9EF4B338E2147D12970154770C3536E7C",
                        "defaultText": "내 질문이 정말 부적절했던 것 같네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E15B4717340F7245AD8AB94378896E34A8B7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D28F342267F0364AC7888601AF0F2B6F99CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F23705AD008B474BD13864C4C3E2079AE50A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B2471EBB66067449C638EAA72CA00C8C0C97"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41D66DE1561DF348645ADDF5A91E3F3936D8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D165AB8D338F824DFD889787CF6E70F769DA",
                        "defaultText": "지금 죄책감을 느끼고 있지?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EBE818178CD00842BA0AFBA13EF977A4BB01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6B34EBD68EEF234A1188AD6324E024C6389C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6BEF0616556A640A76B7E93944B8B306EE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "21730A427BC9724E7849D2779249AF0DEC69",
                        "defaultText": "...어떻게 알았어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "76CD25CE5687D84F1E78E4A175C238E08188",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A1D8C6490D17248583A9146124AEF523D59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6315FA90726E834213689CA0315EEC311E61"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EC707173298AB047E818D4F47A1575472DEA",
                        "defaultText": "스스로에게 악의를 품고 있으니까."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E63F31FF7B183143CC688B12F86EEE06B189",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40DC473A39CF334A61490291D7610CB1AF82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A3F40FA215B2D1445A9AAA81E64DB38C1B57"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A8527F73613C2447BD4AB3018B7BD1FC8B65",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7D27FCF73B0C0846996B44E4470DD9C8C4E9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F12D9E419FBDA24D917B4AA17E30DA69288C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05B57C3E78B3E749A668A331A7456E80AEF1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FB01C5A727289849AD1B1A666AEFF7465ABC",
                        "defaultText": "난 드러내는 것보다 훨씬 많은 것을 알 수 있어, 니니."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5024FFDB5306134DCB8AA5C8B411E054D6D5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6C0C6E4D4A6558465A38874008F19300952F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1B956D3340A0245B8396E2274E9B4F6FCA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "623D750B402EF345216AFC9696859475F631",
                        "defaultText": "하지만 평범하게 대화하려면 때로는 모르는 척하는 편이 나아."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5310A660BAD084E6E783C36D63F223E43B8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C28C9C12827825403028AD6200241E5DF4A5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D09497449FD0914F2368C49915F9426F1978",
                        "defaultText": "자신의 은밀한 감정이 침해당한다는 걸 알면\n사람들은 아주...{W:150} 방어적으로 변하거든."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "262128800CE9224FC41A5C32643CEE3495FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62DF3C613DCCC24E3F8845A2A8BD2725D0F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9732D7347D93E140531B8502795E72DB1993"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83EA1D5E556AA84E7A4A2A95833364CC506C",
                        "defaultText": "억지로 악의를 느껴야 할 뿐 아니라,{W:100}\n다른 사람을 위해 그 사실까지 숨기는 거야?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC02988990E5B74EEA29B5234DF0151BB254",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0DB8C637AECB84E3048E7C64C00CB2F6BEF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "467C8207719AD34DD969B655B33C45F0DEC2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "83D190DD7146C64CA249DE47EAF0C60660F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "74CB3B5423767845D73B0EE1351DF1471851"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5A86AD8E06F264469418AEF3F9FFF2818592"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C166FC150573474B0F3AB3F527EF7D88A7DE",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AB0B54B19EFCB44F8D3A5316CA8E5D6A522D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2D12A37C2E69C849693AF41375E209E3C90F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9FBA86AF3947A549DD692A64DE260E72252C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC700A1A44DEF7470D786347398EED0DBCAA",
                        "defaultText": "그런 말을 들으니...{W:100} 마음이 아프네."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CD9F5B55298E934D3D387B7333ABAB8D982A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA119CFE858C194EFE58398644FDE3C2178C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "C10BC6C23675C44BEA8A49223A0EEA87C126"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "428A56105F12F143457BAF9402973B8B4CF3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 30,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AAC0B16D3114A546C71B4D2101E0D6B93AB6",
                        "defaultText": "지금 내가 할 수 있는 건 죄책감을 줄이는 것뿐이야...{W:150}\n시오리에게 이 짐까지 지우고 싶진 않아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D8169BE129C3074C23888E265D21604ED3D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7F738BE41A0B448CC2A0167223D3C94CC51"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3E603C14611CF24E50898E57D515FA4970C9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FC37855C12704545355802B56A89B883B660"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3FF2C0A0342BA64E3E7B46B14C44979A3431",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C0.1-01_line26.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "533342596AF31343715A057375D8A71FCC7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "F9F140F852B0E64934186438320F89A9ECFF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C55B4A024A6CB6442F58F2B3AE61D91FB125"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 30,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "173A536A341D05462C586F74D5D62D82869B",
                        "defaultText": "걱정하지 마.{W:100} 네 감정은 날 괴롭히지 않아.{W:200}\n오히려,{W:100} 날 걱정해 주다니 다정했어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "520A3C127E080548776A7E051D1DBCACEB01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "579854E22CA07442267AC3479B8905BC5164"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B16E7AB257C8040E73AAC8394B270CCF0F0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 24,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "318D15F68AE3D24E1F0BEF03C9A8352D9B1C",
                        "defaultText": "기억상실자의 말이 얼마나 의미 있을지는 몰라도, 나를 믿어도 돼."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 0
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F0C3F0E51DE9244CFA99E3330B1ECF09F0ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A77ED2A84E28A4456F286296DF2132FF40D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1E9E540230CE445A26A99A90DA7170BBB92"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "833D823C65C42049D5692BD3E0004B171E70"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4F8C0A127A3C554A5C8A1F04029AE4EF6C0D",
                        "defaultText": "네가 생각하는 것보다 훨씬 큰 의미가 있어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "67C810848603184C379967345B3EF9AC4188",
                "expanded": true
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "ORA PUOI PROCEDERE, GLI ALTRI 2 DISCORSI NON SONO IMPORTANTI"
                },
                "indent": 0,
                "uid": "13C764B959D2754BC878A9F156F3FE5A72A5",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Puoi procedere?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "0A31BFBB20FE0241509A35E67CA690A03C9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "DDCBE3494B66564B7A79781394738F395645"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "748687F24B3BE644674B3C51006B25CA4F0E"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Choices bis",
                        "index": 507,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Choices",
                        "index": 500,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "570DF7848608644D429BF573A2DE9599E551"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Targhe Choices bis",
                        "index": 508,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista targhe Choices",
                        "index": 501,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3D115B2483C1D8485369EE11A9BBAA6C540D"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "coda del loop",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "A3133ABB8390C84AF8792BB08F986473754A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "freddo"
                },
                "indent": 0,
                "uid": "8FDE605D4075D649CA7A509126D7B98F98A8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B5A158B4511CA64A181920A27F6FA5EA6F2E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "009D504F2FA321407E3909A18624D4E7008E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "368ABE903876C44A82399D84F51E1CFB4E12"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "01F1980987B66147798A10055A008C352FBF",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6834C98376B984CCE6981524FDA8B66E751",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "25ED563F48EFC349353894F8728EAD3238ED"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF1015386B80A84FAB2B0278A57B07A95E4E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6159C4D28DEC6445CB7BC441C050EC2B597B",
                        "defaultText": "하하하, 전혀 아니야!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "0A7BD0651164294A8E79A858A43ABE2FACD0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEBC91A28FC6C6472188A6F370019EEE248E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C6B4BE74E58204F47799089AFF2D5D590DB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "548808D69023F645BD8B296534058361A380",
                        "defaultText": "하지만 여기선 몸이 얼어붙을 것 같아...{W:200} 아까 숲에서는 더 심했고!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A7CA9B985C5D2743965877505486FD4BE9F3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "850D63479A60594B154B37F29D07E5418009"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC464D1E83F3914CB2482E95967743729FA3"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "07D0755B6C40F54EA75B3DF8F6DFDDA80981",
                        "defaultText": "파일럼에서 태어난 사람은 이런 기온에 익숙해.{W:200}\n하지만 넌 잊어버렸나 보네? 후후."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E0C590156091284FBD3A71B32BF8A43FF089",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1693DA5E29E75041BF68EBD997D899C8C7E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13ABD94C63D5044C472B0897F993EB4E5EA1"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "REMEMBRANCE SHORT.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6AE2D51D061B33445D1A2C23A1E6066D5AB3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            900,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC0C42439CC3C14CD5285B58EB541292B788"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "BDF2D73F2B73F24BC10B67A542C5E9617BF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "54AD22391AB3A548908B9C78825793C7108C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1851964877E7C4467F384234939855DB493E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "47DC17244E9097447D294228ED374010589A",
                        "defaultText": "...{W: 250}지금까지 본 환영 중에서 확실히 가장 기묘했어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "089BD2637404594D4C7B357719F0C0F56EFD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A254031738AE274CFF6BED031A81D3F7D08B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            8,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9937F7971351584EF91ABDC3FBD8A48A13B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C6535150BA7094AD1485A44E4E44E6B69B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "67EF755A172484498F5B7F2563AE1F737BAF",
                        "defaultText": "이번에는 무엇을 기억해 냈어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6E9A29032CE0434B1058F6698E0AC81F20E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1EA5D856191402414E2BA8313EB6F37FDA5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "43EC348A4724664F47182134830C5B36E966"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B45F22C1167DE344A508141447C459302E4D",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line34.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "18B866627AAF07453C582A073C5F2F7792F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "EE4FDF7E718B7341C33B167851655AFF280B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "380CAFA83949A64F5F7A41431640AE70A988"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BF3E683B469A6244E42BE378CF0AE575A415",
                        "defaultText": "이름은 잘 기억나지 않지만... {W:200}자기 배를 북처럼 두드리던 사람이 있었어."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "794F17952FF80648A96B0D44218F5C140E1A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBF380BD61B3114BB5391C45AE6DAA80774B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B404AD93671968437128CC46DFB58B487A8D",
                        "defaultText": "눈보라 한가운데서도 그 사람의...{W:150} 특별한 음악이 또렷하게 들렸지..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2FBBDA1632A9364EB2881211641901FAF96C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74A54A9D8BB9B64D706B30C2299CC73E0793"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE49BF327532864365287B35FECFA61DE678"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F98F90C39B90C445388AD902F62BE830D84A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6DC3407A2360884E34784082EF97D0D4A3C5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1FB06CA731CD5741F03BAA8122A843075057",
                        "defaultText": "아, 고대 파일럼의 주문이야!{W:200}\n나쁜 생각을 몰아내고 정신을 굳세게 하려고 그러는 거야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D782B571899E834A5068F975AA740E58962A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7612C099823E734E496BEC569070B13F624D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE43EC5E0515554E334BCA17D3705958B86E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E5FB193B8D33534CBC8AC5D83A31F23E36F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB6B57164066A24A038B5DA2FAB256DB1847",
                        "defaultText": "...지금 내 머릿속에서 몰아내고 싶은 건 이 이상한 모습뿐이야."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F4AC103284F8A646ED4A2D1631AC69D8EC03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            12,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECF9EDC67229E744933A0D46C69E2FF4B9B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97E0CBB017FDC2467A0B88B051E4900E6AA0"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "coda del loop",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "C1A56A1C4345A641064AD4A4D9A66781315E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "lookos"
                },
                "indent": 0,
                "uid": "A2A7D7F486C55545E2988F90C96F3E8D352D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            14,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FDF093BA217D6444382903A9250CB0453EDE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "370C534C42AA974BC8992B736CB50E0C6AF0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3DC1C27B3F1010446468C5111DC8E4149A12"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F82D32E440CE114CB21864F77645FFA2F512",
                        "defaultText": "다른 질문으로 대답해 줄게!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3EB2C4A68D57F44ECE38B9C39D3EA159BC1E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0B63B59D3565274B912973B89D29A1BD47F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B61E955A3809F744643912A4AD3FC87C84F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0F5950E0496AD647E96B6BC8015F933B6E71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7DACF0F93D7D3445642A916870C287E4EDA4",
                        "defaultText": "인간의 악의와 동물의 악의에 차이가 있다고 생각해?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AAE72C683C1FC14AFC293B38C63DF9F7A9BB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C25BFCEF6D8FA045D689DF3346D89C05C8F3"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Choices",
                        "index": 500,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Choices bis",
                        "index": 507,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5D92695E5954E346E848F7D36551AB82F9CD"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista targhe Choices",
                        "index": 501,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Targhe Choices bis",
                        "index": 508,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F5C9ACD86858B74A599BC38691BA59B681AA"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "4F1BE06D1634334CDE38ABC520E2300609A0",
                        "defaultText": "인간이 더 악의적이지."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8B81102465EBB84BF86854019672B9185C3F",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F6A9A2181218984C6B78A47454CD5335C3D5",
                        "defaultText": "동물이 더 악의적이지."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6E2547836034564F356B7041DDF5B84772E2",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "5FCC95BA1938474902499F053114BF978535",
                        "defaultText": "모르겠어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "58CDB31922A1334BBD287D71D219EA8859D1",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "457AA1561108054CF22B5C816214BB6F77FF",
                        "defaultText": ""
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2CF1D253309C47481B58F603052F638EFB02",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "humanity",
                            "humanity",
                            "whoknows",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF1748616B842549B309D257516706077531"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "09E5CE538F51404A12880472BB3D3D2FBA8A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "humanity"
                },
                "indent": 0,
                "uid": "6B1070D2102C9645522991E23DC38CE01AB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "114D500F671B50419069A5A5F29383F7F8D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF42053B24A805468D59D6B3B37F78BDE22D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36CC51F649DE124BF6796A8407AE640D5868",
                        "defaultText": "그렇게 생각하는구나?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "94EAB1388D246645837AFD76B06255384A0C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDCB49D297FB114FB07B2169906AEE31D6B0"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "esitodelquesito",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "DFC378178868784ABF48B4D9EF27A9973137"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "whoknows"
                },
                "indent": 0,
                "uid": "86B06B3A962C064838296256C56B3E297696"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "044AAAE696C506486B6B5581DD084DEC7963"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C77226574DBF6241B47A216238CEB77EA6B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F3BBEC256E2B841F6288343CC3C2D14112F",
                        "defaultText": "그런 의문을 품는 것도 당연해."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "08559C017FE427474F097D31C424BDF96DF4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB0CDE6E713B1642FC7AEC6024188B1EF9E2"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "esitodelquesito"
                },
                "indent": 0,
                "uid": "2A85904C0505464688693B67CBC716585B2D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64E690CA68E9484CDD1991E2ED832A928381"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "83E4BFA556C17048586B5DE767118A282E8E",
                        "defaultText": "둘을 비교하는 건 큰 의미가 없어. {W:200}이유는 달라도 두 종 모두 악의를 품으니까."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3035427C192F5342008B6708D921C19BF2FD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95B709F96C64A6495D6B227587EC5BCDBEE7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A207F0F3F30D145BD2993B5FC7FA9914DE8",
                        "defaultText": "동물은 본능적이고, 인간은 더 복잡하며 때로는 교활하지.\n{W:200}그래도 결국 둘 다 악의야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EA4A8A5B0CD6944E7479004345B50D37B5B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "267B4B2685F1B440A548CF267B76C4B2443E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D9B7D9543C0404DC318BE140BE3128795D1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5DE257EA1C44A84BDF7968E8E988B306D013",
                        "defaultText": "그렇구나. 그럼 루코스는..."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B067843272484444E75929B060A9AB0142B4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D7DFC52714F86488F3817D9047D46D633D6"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "28609ADD46E1E34353683BF900296BD3C875"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "81BBEDD113B2354DDD99F2B4549B68C34731"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            3
                        ]
                    }
                },
                "indent": 1,
                "uid": "3CE1BF45514C1149678809C97A2195B8FF32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "89D476FA01E0414D9149645511E07930E24D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D2919E9387D5734C9B5B6F78EED3C00DBCA8",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "877A366A8ACAA74D0A1B5DB2A4DA697D4164",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "9F5C07E6826C6442DB0B0D055A058158E69E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D6D61F8A3DBB334B612B3918A283A3778852"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7585160B3F68A545892B86810250BFDF3D65",
                        "defaultText": "우웃?"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "B3360E461AE4B34B396B0739F9A64613F34C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "6A9F308D041A914CBC8B1431554988D426CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45602F1C00299940D09A7586221D129C25FC",
                    "parameters": {
                        "values": [
                            13,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "869899B8636AD24B368B8843ABF7FB52C845"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "76CEAE8180B7B24E93682BA7D5D3BECB8626"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C37FD98791C1A84CEC794212E7C1C5D115CF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8AA54A9B29CE554DF32897D2E5CC13DF28B6",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line19.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1B6BC0E909822440374BA275DC03A2D0A565",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CED79FFA42F2774EC649451584F6442F8992"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FFB4E594F62F6468A3AF9C01EAA8DC45C6A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "17F3C8D52BF918444D6AD8179B6E0E590DA4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "80F2C8283AD1D245F87B7466C34847C9862E",
                        "defaultText": "저 루코스는 예외야. {W: 200}동물이면서도,{W:200}\n탐욕스러운 인간 괴롭힘꾼의 악의를 품고 있어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A70AA7D23745D34C5A2944341AF3A0CFFDC3",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Luckos con noi?",
                        "index": 180,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1C6F0A72952FC44E0D2A589533F5D976DCB2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "D7B477A733BD454CBF683090C9DAB0C97235"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1BA7CA46937AD846C6296BA2AFE8CF79AE0B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "0FD43044654AA64E571A9F55EC87FD43542E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D65093006F23C8473629CE114DF8D1E65EA6",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "LUCKOS_BARK_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "5F94A5DD837B4140CB198965E77A11632D39",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "503589544DF80047A169440131FFA7526D0D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "EEC47E9C93BDC445B30BA213A6B918038199"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7CF30D8F07A8054A6449D325C05FF67972C3",
                        "defaultText": "우웃 우웃."
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "E018A7714DFDE64F11887F1140C02C2CFA94",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "CB3EC8078981C546528AA36896F4BAC6AA02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "F016592D4E5C07449E7B80474DD43FBEEED6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 1,
                "uid": "08615D492F7D1642829A5E99B919B8D99F47"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2004369A880C0441FF994A82361EE1B6D56B",
                        "defaultText": "무슨 생각을 하는지는 알고 싶지 않네..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "0CDD262763EF8649F04A4D32895AEC6AA901",
                "expanded": true
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Choices bis",
                        "index": 507,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista Choices",
                        "index": 500,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8BC55CCF7BA88649788A127931B9AFB7A359"
            },
            {
                "id": "gs.ListCopy",
                "params": {
                    "listVariable": {
                        "name": "Lista Targhe Choices bis",
                        "index": 508,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Lista targhe Choices",
                        "index": 501,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5D2BC54487959044952BC9273CAE74B166BE"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "coda del loop",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "B7CB4120628FC34F111AC1C89CD84C0C95EC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "finediscorso"
                },
                "indent": 0,
                "uid": "E609A967617F5449B69A2B040C79DE3A8E34"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "60602AF27B28894F2B48E0481E05CDE945F9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8898A56F3400D249CF7994B7542C0D4916D7",
                        "defaultText": "더는 생각나는 게 없어, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F6408F5D3AE1574F2408216834058787CC23",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1FFFF6234232F14DC02A07E6F0C5A6DFE1DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "C6A6694514CA7741E08B79B9BA9D88C73401",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05EB254B8539034EB47BC7F435C453F3E55C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "71C72D9C64F4D241AE2B25F7675D0BF37C35"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "6D41247C95D42347F6081314386A174E2C97"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "44CED77511D03847F41A9E28F651CDF34E00",
                        "defaultText": "괜찮아!{W:100} 테헤헷."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8BD5D5B4175EF04B2D392129BC656144854A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "354F5F249F1451455E5A1634EF410B4851D5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA4BD6F45C7F334E847920E0E57B671E84BC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "4903D4F3268CE149EE699BA93978A2435D99"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "fine della chiacchierata",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "5556F2177C38024E937B4243C3460E296335"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "F I N E    S C E L T E"
                },
                "indent": 0,
                "uid": "9E6A1E6E75610548BA092931C2C69DCBC6BA",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "coda del loop"
                },
                "indent": 0,
                "uid": "7CCB8774415A604B7459CE01E1E7B118FAA9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "64DCB9FD475CC947FC8AB877C2148E0EBF56"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D48DA496219E2447A2381308CD0B27E7C6BA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B50272241BB4834F2A1AEFA64371AFD044FD"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Numero risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 1,
                    "source": 0,
                    "sourceValue": 1,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E18EA19C08EDC5436E4BFEF313D3C532D907"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C27C72378FD2F542B338DCA6E1767F865BFF"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "fine della chiacchierata",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "7D9005D17624B241007A440756FFDCF38A11"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Aggiunta quarta opz.?",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "54026F961CDC464C212886B5DF68E9E809C0"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "aggiungi quarta",
                    "target": "activeContext"
                },
                "indent": 1,
                "uid": "111AB3164257014A3F5B24A119843152B122"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "loop di scelte",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "695D18598BAB2641065B6314FDA0CF419B85"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "aggiungi quarta"
                },
                "indent": 0,
                "uid": "B98BDA6B31FA7445053B4BE1B06A7A7E1588"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Quarta aggiunta?",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "19DEF7821119E7428F7A9EE30330247171E4"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Quarta aggiunta?",
                        "index": 4,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "0D3E7DBF997F3645914B1CF10317FCEA9605"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0391CE5B4F57D449B41B2854497455534212",
                        "defaultText": "(더 이상 할 말이 없습니다.)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "D8E5B56D44BD6548855B2ED54E64D38385F6",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Label scelta 4",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6A11BE6A884CA14F8458F66410C249B67B9D",
                        "defaultText": "finediscorso"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "1D4A074344EDA143C81BA741AEC71192E108",
                "expanded": true
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista Choices",
                        "index": 500,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "name": "Testo scelta 4",
                        "index": 243,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "0F70094B5EF5004B9C2A4010571ED737A553"
            },
            {
                "id": "gs.ListAdd",
                "params": {
                    "valueType": 2,
                    "listVariable": {
                        "name": "Lista targhe Choices",
                        "index": 501,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "switchValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "stringValue": {
                        "name": "Label scelta 4",
                        "index": 247,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "listValue": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "3105C4328D97464DEA2A09B7C5CF57D94117"
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "loop di scelte",
                    "target": "activeScene"
                },
                "indent": 0,
                "uid": "0721F6C11A41784A3A6830F8735FE21C1EAC"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "fine della chiacchierata"
                },
                "indent": 0,
                "uid": "79F523DC138592425959CEF42088FD2C39AB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "84B36B000E28E74822583BF433014DBFF23B",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "20A0EAD68A21C8457F0850D63D05380DF526"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "04BAB76B312DF448721BD0361EA777EFD36E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2B19A95F636B7740E43A0F2973D2489CA24F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0FC382EE28C3254D3A785583B6B64ED85BAB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6170BBA11EB16248133AD157FD24F072044F",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "C0.1-02_line2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5998368B5D160443008AE56455BC366622A7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "C16A1B3741C0E1413048648515442F2194E3"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "187A60D0469C134C0A793AD5FBBEAF3DCF61"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B263AE4E4596134F495918616A93F187993D",
                        "defaultText": "기억은 어때?{W:200} 나와 이야기하는 동안 다른 게 떠오르진 않았어?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "397BD7A61C2E484BC86AD515ACE821AB71AA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F66201ED7153D74C9D3B39853477AFDFBBB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D8C0A8C38E6F5740373B1AE160FAEF282C41"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CDA9778B8D76F44F723BD6610B678217D133",
                        "defaultText": "유감이지만 중요한 건 없었어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "40304C9D3321E0472279DFB186B50E3DD11E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CDF9D78191B3444DEB5A4BB4C370ACF22DE7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "63F09279342CB645948BF994251D10585394"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0C8739A682B163481049B807A47E6F749A2F",
                        "defaultText": "그렇구나. {W:200}걱정하지 마. 시간이 조금 더 필요할 뿐일 거야."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "9F2FE04885708641FE1A5572FEE22AF3F289",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F0D29F3A05629443AE993C123E2A5EC4BB86"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A90C494F542929437A197419AC5C3ECF1E83",
                        "defaultText": "아무튼 곧 음식이 나올 거야. 기대된다!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "78BB7EB451F79441F46BCDB4FB5C1C38DB9A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "79862F8341C7B343E22A0940FF6B9B055DD9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4EFD3B524DCB0542AF4959874E739FCD4AD7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "98F1F706323D2644EA4AC777911A35CB1F6A",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "89CBF9EA3405D948284B616225F9829CCE90"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Numero di risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 1,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1AEC698B3EDB284D85687C778B5B897DB013"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            4,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "DF6DE07C5782624609886D14E0B46585D123"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F85F748E78A5664F9388585208381F3C53F6",
                        "defaultText": "시오리에게 이 질문을 하길 잘했어. {W:200}이제 시오리를 조금 더 알게 된 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "51A13FD53CB0B249047B74B8AB2FE91EE6AD",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Numero di risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 2,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A7332F141123134163486563644EFF6D58E9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            7,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "482EBB4D28DC444BAC48B48358AC63346535"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D8D4DE66AF2F4447B0AA3C9024A07DA5AD4",
                        "defaultText": "시오리에게 이 두 질문을 하길 잘했어. {W:200}이제 시오리를 더 잘 알게 된 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "A17F6E9B86D715422C4979572E1A0CD5DE56",
                "expanded": true
            },
            {
                "id": "gs.ConditionElseIf",
                "params": {
                    "variable": {
                        "name": "Numero di risposte",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 3,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 0,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "6A19F92E999E1847582A3946F359430FA1A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            10,
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "69307AC796BB264C7118FAD220C7DD0A1BEE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "92C195D46D6ED74C9799FCE221B1A7034F65",
                        "defaultText": "시오리에게 이 세 질문을 하길 잘했어. {W:200}\n이제 시오리를 훨씬 더 잘 알게 된 것 같아."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "CF1535B18305B14926296E317C26E18D8E1C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F178D1447A9B441735AE9E7C038DD1E7B2B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C4FAA441CA70449E62B1A24A87B400A7633"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "7F54E46B4920B740AE8A90387FE94FEF54F8"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "06180994450E7742753B374426D87E47B012",
                        "name": "C1-03e2 Chat wish Shiori (continue)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "B5DFB9F478B21347D968A5727AC84C6DF9B7"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "ID item",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ID beer",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ID steak",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ID crab",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ID water",
                "index": 4,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "Numero risposte",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "item qty",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Vecchia Sazietà",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Nuova Sazietà",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "index",
                "index": 4,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "slot",
                "index": 5,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "cura",
                "index": 6,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "nutrimento",
                "index": 7,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "sollievo",
                "index": 8,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "listVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "Puoi procedere?",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "ON = Eat, OFF = drink",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Vista scena alternativa?",
                "index": 2,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Appreciated?",
                "index": 3,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "Quarta aggiunta?",
                "index": 4,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}