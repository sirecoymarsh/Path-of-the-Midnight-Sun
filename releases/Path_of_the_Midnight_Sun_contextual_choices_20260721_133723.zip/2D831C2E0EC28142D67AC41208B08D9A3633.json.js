GS.dataCache['2D831C2E0EC28142D67AC41208B08D9A3633'] = {
    "uid": "2D831C2E0EC28142D67AC41208B08D9A3633",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C12-5 P1 Munie (part 2)",
        "type": "vn.scene",
        "parentId": "13B4166B2A0E174B7209C352E0B76CE2F77B",
        "chapterUid": "6050980F4DA8824E656AEA34864FAEA22853",
        "order": 0,
        "localizableStrings": {
            "C1F344745825B143D14B2DB61C176E651379": {
                "t": "So. Are you ready to kill me, Fa?",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "49D159121625B346E059DD23987F49B8DC7F"
                }
            },
            "A5DE5EA475B1144FBE19CE7508C6378A3ADE": {
                "t": "Okay.",
                "d": {
                    "eid": "BB4FC643623FF642208B67F85EE16ADCCE0A"
                }
            },
            "F2B3C8350495644F02992EC49563112DAFD7": {
                "t": "Mother...",
                "d": {
                    "eid": "4E10E5C877B383406E68F7E8EFF61DD27212"
                }
            },
            "7B340521581B6049615A2642E32F3E2025B0": {
                "t": "Understood... I'll kill you.",
                "d": {
                    "eid": "E87B5A671B00B74BA12AA942405E67D33F82"
                }
            },
            "3B2EB0A25872654EC59AA8E26CA82FE98BFB": {
                "t": "Give me one more moment...",
                "d": {
                    "eid": "71FF2001298F954B9F98DF094C9643A3B692"
                }
            },
            "A0E10AEB12C2E7487C8B32910AE8BAD1948C": {
                "t": "It must be her true form.\nCome at me, Queen Munie!",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "FAD205EE8954574F663958067D308B6E7C10"
                }
            },
            "2A38D15C1EDE9345D48AA009B9DD22ECE518": {
                "t": "This isn't the time to hesitate, you know.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F4F9E32C65E14646F5096688E9B2464AAB64"
                }
            },
            "727226936AF816448D4935029A37891D697E": {
                "t": "Good. You HAVE grown up, then.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "D3BBEB390076814838083E296F20DDC7D1F6"
                }
            },
            "527DC2D95E85354EED6AE7E4D5638E86BBC9": {
                "t": "My life is in your hands... my foster daughter.",
                "d": {
                    "cid": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "eid": "F942990221B3A54A666ADA5677D26CD34602"
                }
            },
            "F000E7E96EF67742DB4BDF18BBAC04662975": {
                "t": "What is... that?",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "647258B041574841D15A47875713E7EEEFB1"
                }
            }
        },
        "commands": [
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C44A524371A2D14BD81A6594C828CEF83297"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E81FAA4D5A8C84463D78FC0787373994B516"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C1F344745825B143D14B2DB61C176E651379",
                        "defaultText": "그래. 나를 죽일 준비는 됐니, 파?"
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-5_line1b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "49D159121625B346E059DD23987F49B8DC7F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC58B2D048B9E8425D1A1C63969DC8A12D24"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "A5DE5EA475B1144FBE19CE7508C6378A3ADE",
                        "defaultText": "그래."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BB4FC643623FF642208B67F85EE16ADCCE0A",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "F2B3C8350495644F02992EC49563112DAFD7",
                        "defaultText": "어머니…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "4E10E5C877B383406E68F7E8EFF61DD27212",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "okay",
                            "mother",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "7F1EC0A531CE084E845B9199ACEAF521D39D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B4EB9C1853A4B74F0F28CBE941B31FC9EF17"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "mother"
                },
                "indent": 0,
                "uid": "38D971A059E2894C46492A49E37D2227A7CA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AD88414561149421A881E062C4E7F39A4EB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2A38D15C1EDE9345D48AA009B9DD22ECE518",
                        "defaultText": "지금은 망설일 때가 아니야."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-5_line4-002.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F4F9E32C65E14646F5096688E9B2464AAB64",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C5410A47816554332493298CC1F27B2483E"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "7B340521581B6049615A2642E32F3E2025B0",
                        "defaultText": "알겠어… 내가 죽일게."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E87B5A671B00B74BA12AA942405E67D33F82",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "3B2EB0A25872654EC59AA8E26CA82FE98BFB",
                        "defaultText": "조금만 더 시간을 줘…"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "71FF2001298F954B9F98DF094C9643A3B692",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "okay",
                            "end of event",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D950CBDD1A1C50443A4914837EB7FAAFE095"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B38E3B0E23CD0542398AC0E3AC131E651687"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "okay"
                },
                "indent": 0,
                "uid": "A571F0BD9EFC664C123B3E80ACE872252C9B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "CAF132033C9A814EDB39A0081EEADE0B2A43",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE330C44680D654FDA694985EAD4B1A29B56"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "727226936AF816448D4935029A37891D697E",
                        "defaultText": "좋아. 그렇다면 너도 성장했구나."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-5_line7-003.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "D3BBEB390076814838083E296F20DDC7D1F6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A26DCC5723F044D7D79B92529D56AAB541D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "527DC2D95E85354EED6AE7E4D5638E86BBC9",
                        "defaultText": "내 목숨은 네 손에 달렸다... 내 수양딸아."
                    },
                    "position": 0,
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Munie",
                        "name": "C12-5_line8b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "F942990221B3A54A666ADA5677D26CD34602",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "4A528B5D3D486249AE7B4DF8CE69DDA869A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D1EEB1C75F86F642A138E4D973E1B201B399"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "D103A55C124F4747516B0E057F35FD154D9A"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Battle Animation sounds/Spell sounds",
                        "name": "Candelabra.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "230A72E82F026641715A4FA536AB8A87231F"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "CAF132033C9A814EDB39A0081EEADE0B2A43",
                    "duration": 15,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "978A0C7976C11545517B82886A5496A6704E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "577D4C6E2D68654FF2883C59BF0F9D33436D",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            250,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "2F1988227D7B694DC67B8BB3ED187FF42EE1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 0,
                "uid": "5655DDDD8F12B24E8038F0E6273A6A6E1B8F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Flash"
                },
                "indent": 0,
                "uid": "C6085D85970D41493B8BF35888BA0FF5F2EB",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1871689618B7324E1D6B0AA2C3D3D6E402A5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5811EA9F4D56F641C0694CA49975D660D0DE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F000E7E96EF67742DB4BDF18BBAC04662975",
                        "defaultText": "저건... 뭐지?"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Cristoph",
                        "name": "C12-5_line9.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "647258B041574841D15A47875713E7EEEFB1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D59E4955337404B1F38CC04EEAC5B5E629E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2ADAB8656DEF5140317A4837CF86058655B5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A0E10AEB12C2E7487C8B32910AE8BAD1948C",
                        "defaultText": "분명 진짜 모습일 거야.\n덤벼, 무니 여왕님!"
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": [],
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "C12-5_line10b.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    }
                },
                "indent": 0,
                "uid": "FAD205EE8954574F663958067D308B6E7C10",
                "expanded": true
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Flag locale 9",
                        "index": 168,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "EFAFDA3F5B61C94B7949A9B25ACB12BACBBB"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "end of event"
                },
                "indent": 0,
                "uid": "F19372636FC2F54E9A2B3B983141EDFE0133"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "trigger flag that triggers battle in main scene"
                },
                "indent": 0,
                "uid": "B0149B3D16CB374D192AA683F14E1551B4CE",
                "expanded": true
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}