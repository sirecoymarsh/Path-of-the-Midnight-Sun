GS.dataCache['B1636A20786F86444A5925F3B9ADA76D812A'] = {
    "uid": "B1636A20786F86444A5925F3B9ADA76D812A",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C11A-1 Return to Tarmen",
        "type": "vn.scene",
        "parentId": "03704B7C7D05F0498F98DAB7850BE4F8CCEB",
        "chapterUid": "EF3BAE1B50D8764F0D184715C435B627D64E",
        "order": 0,
        "localizableStrings": {
            "6788732F593A0447E27AA8F36D78D2E62EF3": {
                "t": "???",
                "d": {
                    "eid": "F62DAFE268E17343302AC3908E242ABCFA01"
                }
            },
            "CC779FF112A96647B93A1D9567984BF7E384": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "212BF21B2026484C283B4F02BC49A5A23833"
                }
            },
            "98A95EB969444548E15A5045784AEC7FFB5D": {
                "t": "It's been a few weeks since the events at the Midnight Shrine. So many things have changed...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FC810E6C8AD355440C4BB773749D9D244DDF"
                }
            },
            "5D27C5438DB2284ADB6BF758A6675DC5B212": {
                "t": "More than a month has passed since that fateful day at the Midnight Shrine.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4906A66A94377043B128358692BAAAA22B5E"
                }
            },
            "BE554CD18F1E244C932B41C6C818FD24E4F5": {
                "t": "Now I can see everything. Even the simplest things, like the trees and snow which used to be invisible to me.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "34CE3D286B2C524A8159AEB57624262229B6"
                }
            },
            "99C0BB402AB2574F451A2C05513497E80E3A": {
                "t": "But I still haven't gotten used to this new reality of mine. On the contrary, it feels as if I'm blinder than ever...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5E2F395662AA6844BC99019736421CDD1370"
                }
            },
            "25D3AC5C3A35634CDD9BACC8E8DCA287FED0": {
                "t": "It's still hard to digest all the new information about what's what. Everyone tries to help me but... it's overwhelming.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "56259C8022C1244DDF0B228328064D3C7EFF"
                }
            },
            "20B17F772E96C84120592A62221EDC731CD0": {
                "t": "And so, before I've even had time to process it all... we return to a place that should look familiar to me.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "78EE9CA247FB3049FF3BEC28AD62A9DD1F49"
                }
            },
            "4579ADE03308414AD14AB596ACC46D80B123": {
                "t": "Tarmen... It's sure been a while.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "84E02271609D82448309DAD5897C3BEE09E2"
                }
            },
            "DAD0FA2B328BA449A4188DD11F6BCDE34B29": {
                "t": "And it seems less lively than ever. On top of that, the Scourge is extremely intense here.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "51431244173B2543D2293AE08DFFAA63EDF8"
                }
            },
            "5C941CAF958235454C5BC1808EDD1450749B": {
                "t": "It's just like the situation we found in Midbar. So... it's likely that an Archdemon lurks here, as the Matriarch suggested.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "77D31FB62C2A7846E5199630DFDFA412BC68"
                }
            },
            "E14FFCF816DBF644FC294D76CBCEFA14994F": {
                "t": "Is this a side effect of the Demon King's awakening?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4C6A014B6FE2994AFF18FF1318738DBE5CCA"
                }
            },
            "7F96CE2E4BBEF041227AC9180EBA550A1AB2": {
                "t": "We've finally arrived. So, how are your {SP:2}{C:1}feet{C:0} right now?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "54C3B1A81EC1B9454819CFA7A2CEA4F3ED54"
                }
            },
            "954EAE8C56E3234EC56927D18BC0A861ACD1": {
                "t": "E-Excuse me, my-- what?",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "ABACD6B23B7CC54E8939ECE37B1416A9D516"
                }
            },
            "23F5BAC37BDB8341B549D8F3BBB8E7C2E77E": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "53127C8E1E50474F66993392E361503CD92F"
                }
            },
            "61FBFB4644DAD543F908B479B07A57618A28": {
                "t": "You're the worst! We're still recovering from wounds both physical and mental, and you think about her FEET!?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "44620FD76F9F3046205A0DC2E3878FA7E560"
                }
            },
            "E0DED1B01D1A6445B26B9C37679ECCF569CA": {
                "t": "Awww, come on! Why do you always assume the worst about me?",
                "d": {
                    "cid": 0,
                    "eid": "4981AB7035ED994A6629091101FE27891A0B"
                }
            },
            "CF2D024A3422C64FBA5B57E6F5AAF5E8446A": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C5D2656F4EDC074CD66B1AD874218E2AC3B0"
                }
            },
            "C11372E378AF1845E44B7B84D47C93BA31D1": {
                "t": "Pfffft... Hehe!!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C5DB7C2A907EF246A809FC10346DF9B406B9"
                }
            },
            "61CF77FE1D09A342F988CB96A0C1F4CD24C2": {
                "t": "I think I know what he meant, actually!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "732888BF7626F54D7A799584DEC964F97B01"
                }
            },
            "1F487D1E8BE972407229ADE844217902BE6F": {
                "t": "We talked about my feet before!",
                "d": {
                    "eid": "9D3841DF6CB2A8477D0A076713F2F6776D74"
                }
            },
            "692BFE927F0B14455E39C447A4A29FAC6CB3": {
                "t": "He was worried that a snake had bitten me.",
                "d": {
                    "eid": "497439DB1158924DBE2A6A2844565F98CAC7"
                }
            },
            "337D9F5B5BD7E04DDC8AA031C312F4CBB834": {
                "t": "He has a feet fetish.",
                "d": {
                    "eid": "680540644067594F5D29242166104541CAEF"
                }
            },
            "42A84F012F5CB645313966043C1BE6837BD9": {
                "t": "You... You did what?",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "8898AFE37B7F624DA32BC0B348BEAA35DFC8"
                }
            },
            "8BF722074A60B5486B58C357FEEA974C81CA": {
                "t": "Huh, not really. Do you remember what you told me when we first came here?",
                "d": {
                    "cid": 0,
                    "eid": "A099ECC850CBE84AAD099A068629710ED0BC"
                }
            },
            "A98B92476AD6C74D2A4A15E5307DD1EF91BF": {
                "t": "When we first arrived in Tarmen...\nOh! Sure!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "564C21A64F0F8148AF6A4068ED7B6E296C63"
                }
            },
            "F3F94DF711288341F569445979A8CCE4383B": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "A5269E31174451495E8B73266F749354A363"
                }
            },
            "CE70F65764E1214DEC2BC413EF05C5EB420B": {
                "t": "That's right-- WAIT!",
                "d": {
                    "cid": 0,
                    "eid": "C03B392B8FA8E44D721889162EDD6848209B"
                }
            },
            "D337637E7D7DE74FF8194A076FAC91AFB59C": {
                "t": "Ahem, just kidding!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "B4555E879AF2D14BA07ADAE60851B4D6E0AB"
                }
            },
            "6154B6005644844A528902A45C7A8A87E3ED": {
                "t": "Back then, my feet hurt from all the walking.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "12E4067A84687647F84AB467BEF7C584036D"
                }
            },
            "8F80B04F74D8F849D289AFF10250C55D3560": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A457F7377DD2E5486F6ADD1636EE8738B2C2"
                }
            },
            "9A7C59C6454CB8459F995241FD332ED9FE3B": {
                "t": "How could I ever forget such a detail?",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "04B93B6F5D90C843F369CDF73F5200310B21"
                }
            },
            "17F654A61A91C94981788967CA63CF31A105": {
                "t": "Can you stop being a degenerate with my sister!? You sure have a death wish!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "CB60F83E6C2A8541B80B60D8981DAAE6A1F0"
                }
            },
            "625E57DC2141C6455F1BBF63F2DEE5774B73": {
                "t": "H-Hey, that's not what I meant at all! And she's been your sister for only a few weeks!",
                "d": {
                    "cid": 0,
                    "eid": "28AF0D443053D64FDC2888429BBC0F3581E7"
                }
            },
            "B69791E92D4D8343F88AA2225D642B004089": {
                "t": "Are they quarrelling? Are they truly angry at each other?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "43A771491F83E349399B45F32BCAD2FF601A"
                }
            },
            "2D56C2232A61F64CA489D6158E492CE3517B": {
                "t": "Without my power, it's a bit hard to tell, but...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4083F0B35FD2A14DED1B49D3B2E40B4C330C"
                }
            },
            "FCF9D2801D6FC24D1C2BAD15456153920C54": {
                "t": "You sure look lovey-dovey, teh heh!",
                "d": {
                    "eid": "FEC1D1786B94434A28588A675014E4468A4E"
                }
            },
            "B178B3EC195FD34AB77A4DB18C89932D0CF7": {
                "t": "Please get along, you two...",
                "d": {
                    "eid": "91F65B4A365FF148C408A643548B874E870C"
                }
            },
            "F346BE7525D7F74A38390C041D2519933391": {
                "t": "What!? N-No way!",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "EBD9B89C273B35437C88E3B66D072412AB69"
                }
            },
            "0A02C8E44819254F7D1AD66894EFE32EDBE3": {
                "t": "Me and him? Hah, not a chance.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "B6EEDF6016E1D148A14890D8CC65BCCB501A"
                }
            },
            "39A2078E3CC0B2487738377648382C73EBD9": {
                "t": "Aren't you just trying to hide your true emotions now, Milady?",
                "d": {
                    "cid": 0,
                    "eid": "CF6CBA6E34A4D3471C6803E6F91207B9018D"
                }
            },
            "B37D31F54D78644A453BA6604F8DAF49C71F": {
                "t": "... Okay, this is getting a little bit confusing. Was I wrong after all?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "1839AC9551B22249BF3A8A55DEDE6C85B0D7"
                }
            },
            "4495AB2388998241C22ACCA250F7DCE1CBDB": {
                "t": "... ... ...",
                "d": {
                    "cid": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "eid": "9C6473A1621BC1476F9A0A57CE3EEC061827"
                }
            },
            "8E3877C269708143A0393277AEAB60978BBB": {
                "t": "Don't make me laugh. Besides, this is really not the time for small talk.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "AD9652D45AAF2445AC593EE81931878417DE"
                }
            },
            "9F7528732E57624D9119D7A7F0AC28A4FC29": {
                "t": "She's right.",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "75BF8DBA16AAC64439698DC419AF7671D32D"
                }
            },
            "36B214DD403AF944CC2BB2235D2CE0A69D90": {
                "t": "The Scourge keeps spreading through the town, and what are you doing? Talking nonsense!",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "FD2B34C2185796413C8BDE36E560C18F28BC"
                }
            },
            "7FD3B41D346A514CEA582F125E5659FE6890": {
                "t": "Rya... It's my fault. They started fighting for my sake.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "C11878238FB7E34D722A3EE90E009C5CA03C"
                }
            },
            "5987D8C277BD3441BF296DB965F63B1E2854": {
                "t": "We aren't really fighting though, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "E7DC6BD46803E648AA2A2E26D66FD2ED1C2C"
                }
            },
            "8EC43F5D12DC75439F198422BAAEE34192C0": {
                "t": "We ARE fighting.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "5F31CECA276BD84DBB890A32319938EEB33E"
                }
            },
            "85EE128C49DBE240B12A6285154E566B4254": {
                "t": "This situation is quite baffling, without being able to read their true emotions...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "F78A409824D0E84F773A132457FF6A6DBB3D"
                }
            },
            "3DBB14457234924B852BA78336BD97D6B373": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "C35A6CE16214424EB44926936BBCD2150AE1"
                }
            },
            "436299807ACD6641BA7A02B2288AC256C651": {
                "t": "S-I-G-H.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "193F23CD26B224432D1956D6C62A9D5B3BC9"
                }
            },
            "FA2F36D61BF30141F03A2464C917021E04E6": {
                "t": "Whelp! Let's leave that for later, shall we?",
                "d": {
                    "cid": 0,
                    "eid": "D14AF8E671C1634778295B8069947386EBD5"
                }
            },
            "36296642326B134D2B7B7DA3145201A26F79": {
                "t": "That's better already. And it wouldn't be unwise of you to be more considerate from now on.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A550A6584DAF2543774A20038A1EF2ABB890"
                }
            },
            "731C8A8924C1A449EF38A364B6236C72A7FA": {
                "t": "As you already know, Shiori and Faratras have been through a lot lately.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "EFC73B1F2E61B24EF69831968148F82DFC42"
                }
            },
            "63E4D84D54F49647294A8D95FEF03235E340": {
                "t": "I'm quite sure that Nini has been suffering a lot, too...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "5CF743392C000042D66BBB0085F27D84081A"
                }
            },
            "059AF8F237099241DA5AE01200BF4DDB41C3": {
                "t": "Everything that happened in Midbar must have instilled even more doubt in his heart...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "C1CC35D0405E64459E9BD14156306FF20199"
                }
            },
            "FEA4BF3F724ED5450C6A72642860F8B51690": {
                "t": "All the clues we got from Hellios and Kabeer seem to indicate that he was cursed...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8C9402A34D88F944D1181D24521281E72A03"
                }
            },
            "7A9B67597A0C144F904904E26BE1A119ADA1": {
                "t": "As for Rya... Rediscovering her traumatic past must have been a real shock for her. I just hope she's able to cope with it.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8CA2386A4892E349FD681FF134375D551B64"
                }
            },
            "8960E32C4736F14A448AA8793BFD419D4D19": {
                "t": "After all, we still don't have any information as to why Hellios had corrupted his mind...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "FC54522D3A51A3441B68BFB429F338E2F2F4"
                }
            },
            "BAFB92DD636D2846E368FE58F2B917FD97D1": {
                "t": "As for Rya... I read her emotions in the past. And I wonder if she overcame that trauma of hers...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "8121EDC45521774E994A7CA8A40EC3F38376"
                }
            },
            "C8CE665D1AD291445E68D042EE25BD7A0F25": {
                "t": "I can't sense their malice, so... I can only make assumptions. But what if I failed to understand them...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "A3C5D14C48A27849444AEC7048FFD17651D3"
                }
            },
            "F3B9548E49B051417F4BB22389EC8CE8A3D5": {
                "t": "We've all been through a lot. I guess we're just... nervous.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "3FBCB40C810D3048B129B2D77B5058FA45CD"
                }
            },
            "96342E7641F7B6453E987185564B92789B3C": {
                "t": "So, umh... I'm sorry if I overreacted.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "1802247271DC8141CC6B1311D926BE61DB35"
                }
            },
            "3BC727442ECAE4471439517954FA537C6CC7": {
                "t": "Yeah... my apologies.",
                "d": {
                    "cid": 0,
                    "eid": "46C6424F04B09243E0594BF282455FD5F60A"
                }
            },
            "1D9ACB808234414F088AFF2543FFA387A826": {
                "t": "If you want to apologize, do it to Shiori.\nYour little play has undoubtedly confused her.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "B4E1DF846DF99746B46ADA697366B0671A0A"
                }
            },
            "2D98327F26B1F346585A19815217ADDB1699": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "A1938C018FE3434E879A54A284F40115EBF3"
                }
            },
            "8E42FDCB377806487A794344BCFB27A82C92": {
                "t": "Forgive me, Shiori.",
                "d": {
                    "cid": 0,
                    "eid": "344EE3D46F1941416F2B5C46F58162C207DF"
                }
            },
            "1C817B861067F343616B9424089B052866F8": {
                "t": "dummytext",
                "d": {
                    "cid": "0D869FF412D69247502956758DAD1635470C",
                    "eid": "1A2065C46D315748C25829059867EF13CC52"
                }
            },
            "95A6B13F3F451541C58ADD72D06C9B85E364": {
                "t": "I'm sorry, Sister.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "D1C23BB25D2FB1498A8AB968030D886CDAC3"
                }
            },
            "8D3638D474C3234F595B0130687558601700": {
                "t": "H-Hey, stop...",
                "d": {
                    "eid": "240DBD5F8A3AF449DD393BF2020B0F1EF3D1"
                }
            },
            "D5AF5D79448C254F608802A1B639E4116BAB": {
                "t": "It's fine, teh heh...",
                "d": {
                    "eid": "7EAB57A101BA1040B42BD6906BAB8DCA3C59"
                }
            },
            "D32D99D0954D8344B489589235AE4FBACD3D": {
                "t": "That's a great look on your face, you know?",
                "d": {
                    "cid": 0,
                    "eid": "3C9E6C28725D424B238B7B489A3062B99AA2"
                }
            },
            "77952D7A8D02074DD05BA2F7AE77D397A74E": {
                "t": "I-Is it?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "DAD917634A8B044447096B65942FE3C2D519"
                }
            },
            "F7241BC615B1F84F2859BC333103D215D6C2": {
                "t": "Hey guys!",
                "d": {
                    "cid": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "eid": "4B70BEA67DB5D54AB4298292DEFE74628670"
                }
            },
            "79F2C7A53459434E2C3AE5219DFE23831D43": {
                "t": "No trace of the Archdemon so far. Perhaps we should search for the Matriarch's envoy--",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "1E6097BB66CC464CE98A2D172DA3F47C9F30"
                }
            },
            "B73C130C030DA34AC45B44751332BA6E61AB": {
                "t": "Oy, Shiori! Blushing again?\nAt least all that red suits you.",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "91B817D7816B0241143BB5C2D99EB3E75E53"
                }
            },
            "39B99D407D66E84E7C2B6251858757D63CD0": {
                "t": "You're lucky I can't insult you in front of Shiori since I just said we should not confuse her any further.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "D36259742D149349F15A5B55AD57DDEA5CC8"
                }
            },
            "DF7C53C34FA1824B533B6443DD8B1F659C57": {
                "t": "Huh, did I miss something? Are you hurt, Shiori? I can help you if you want!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "97E178EA8B35734D2C3ACD576C70634AA16D"
                }
            },
            "E19DB58930673844230960182A411ED389ED": {
                "t": "Oh, it's... It's nothing, Cristoph, really. Hehe...",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "D026B60C64CB974F107859A21A3E6344B91F"
                }
            },
            "F12F1BF6669E934E984BC9E37F50C2797029": {
                "t": "Umh...",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "FC601CFD3ED12349F05A75D35DDE286FB2BA"
                }
            },
            "75EE2624294F574D297B36721FD44EA8EBDA": {
                "t": "... ... ...",
                "d": {
                    "cid": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "eid": "4FBFD1B208AD7440164B86863FF82BCB707B"
                }
            },
            "6B97FE982231784C1D3B8CA215D90604EFC7": {
                "t": "Hmmm.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "BC69A6B153BF6141F84BA0292D74DBED5561"
                }
            },
            "9C1DAB3F02A3B84C4C995BC7C339C3F88214": {
                "t": "Why are they all glancing at me and Cristoph now?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "5A49129B1DD8104EAD7A53204E645E3FD266"
                }
            },
            "1CEDD2629E01C146747B22B791EF04E79719": {
                "t": "You know, actually Cristoph's frivolity might be a good thing for you right now.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "C921E7D06DA3C647D50BC747723B7463DA54"
                }
            },
            "D718D9642DFE9944B57B6165078AB2ECC366": {
                "t": "I was thinking the same.",
                "d": {
                    "cid": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "eid": "4C29A0C341D4224E2B1A99D3115C3EC24868"
                }
            },
            "EB985C4091F5E64FB798C3F7E63171D3D63E": {
                "t": "Sister, why don't you take a look around the plaza with Cristoph? It might help you clear your thoughts.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "D6A802A396C60645AA494EF7E1839E9176E6"
                }
            },
            "61B338645FFCB44B7F8AC756EECD944C2FF8": {
                "t": "You're giving me credit? You're gonna bring a tear to my eye, man!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "77BB06BB89BC4447875961B0B4F79F22C83F"
                }
            },
            "6CDD3E2D812533401029B0E6893089C933E4": {
                "t": "Hmm, I still haven't quite gotten used to this new way of 'seeing' things...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4499F24A98E72143216B4422F57143EE2371"
                }
            },
            "538FCEF8425C7641263A3F364E2F7A657EB4": {
                "t": "Going to Midbar didn't help me much either. Everything was just too... different from what I was used to.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "349C54728803F4411618B229104140998BF7"
                }
            },
            "99AD36322A59304FD75B1151331D0DDD704C": {
                "t": "And we went through so many sudden dangers that I didn't have time to sit down and reflect on my circumstances.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "878198CE01FA074A338A34E19CCCB798C8A4"
                }
            },
            "2276EC398CB90247CD1BA364F2C967FC7B37": {
                "t": "What should I do...?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "701172017DD6844CB43943C2B0FF7359F2F2"
                }
            },
            "FAB0F94E2A1BC7420B4B8251F8B947BE1791": {
                "t": "Good idea! Shall we go, Cristoph?",
                "d": {
                    "eid": "7481659C9786914FDC1AE49838B7B90DF5B7"
                }
            },
            "98157D6C5816D7494D1B3982FE382EE5D5E2": {
                "t": "I don't want to...",
                "d": {
                    "eid": "A0823F546789F4430E680A3557DA500629FC"
                }
            },
            "95FEB4B66119954ACC1B74849241D924DDE1": {
                "t": "Sure! We'll be right back!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "AEA31098514576498828A8566BD562AD09EC"
                }
            },
            "84B7F2612895814A1D0A5E689F0EC35BC3F2": {
                "t": "Awww, but...",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "340D30D50116884AD729CF586EEC98C16BF7"
                }
            },
            "19123D834DB7034E491A2962139BD55FC838": {
                "t": "I can understand your reluctance, but I have to insist. It's for your own good.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "B13C06FC3C9CA24821484E07A49FEDCDC948"
                }
            },
            "43D7F56437C1E64A68988CE24E28CED195A7": {
                "t": "Is that so?\n... Sigh. Alright, then.",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7B9C034D419302420C5B87A5DD1D501B48B9"
                }
            },
            "27ACA8D93EC33940F16BFD9307F768464E32": {
                "t": "Woot woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "C9D7A0475564734BA728EB922607DF67174F"
                }
            },
            "824976B43AB8544F4E49CE39D414090B82DE": {
                "t": "Yes, I understand. You can go with them. This place certainly brings back a lot of memories, right?",
                "d": {
                    "cid": 0,
                    "eid": "F480C18E88DEC14A8498585865E84EAE794B"
                }
            },
            "2287E5CC0097964E16081831375AC61A572F": {
                "t": "Woot!",
                "d": {
                    "cid": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "eid": "1A76891499D791456369F8F28CB82E77174C"
                }
            },
            "298A3A4D1030634BD67B1976DB031751755E": {
                "t": "In the meantime, we'll search for the Matriarch's envoy and for any clues regarding the Archdemon.",
                "d": {
                    "cid": "31019CFA31DF1544562828A94FC08499502B",
                    "eid": "384162C058F8214CFD1BBB185BA0C8B583B9"
                }
            },
            "DBA0D8207393734AA2582D2154C3F61BC09A": {
                "t": "As soon as you're done, {SP:2}{C:1}wait for us{C:0} here in the plaza.",
                "d": {
                    "cid": "45918E0E12BBF148635A9360998958409EFE",
                    "eid": "A289C38A4B53C34E8C6801202526A1F13E7A"
                }
            },
            "4E31E3DA543E3343FD7A8B27E2536007F01E": {
                "t": "Yeah! This is gonna be fun, man!",
                "d": {
                    "cid": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "eid": "03C895FE79B3D24B7719D9F13407593AD55C"
                }
            },
            "DD595C120DD13545FC694A678AC44A35689D": {
                "t": "That's fine. See you soon, everyone!",
                "d": {
                    "cid": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "eid": "7365C2604F57E84B4E794EC58D24E2C3CF9B"
                }
            },
            "CB7A7B658AE2E84E096A0451FAFCEAB37900": {
                "t": "Okay, umh... Let's explore Tarmen!",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "B44BBD13244D134F4B68B1B4B3FD0D38FCB0"
                }
            }
        },
        "commands": [
            {
                "id": "gs.Comment",
                "params": {
                    "text": "\nSHIORI'S POV"
                },
                "indent": 0,
                "expanded": true,
                "uid": "69722EA111D71749700BDBD161CB552C2692"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "80AB9864583CE946108B7D68B72F3CE55BA1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "56B4852D8F03E846056B06F8A790D6ECF0FE",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CEFDE7FC3188F94E768B66220891A4318135"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "FEEB28CE186A3342E70A634062AF25688319",
                        "name": "1 - Luckos"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "19F82EE85CBC464BD3982297EDDA122A4000"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "2B96228807C91543086AF8734CBB0AD4A6B9",
                        "name": "93 - Faratras Overworld"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 5,
                "uid": "A87A56A31282814E841B5025921D3F8D3506"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "45918E0E12BBF148635A9360998958409EFE",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "CB11606C21A6A34E136A0B80A64FE758992F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "7A52F8DE55D159434B499B596439193E987E",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "57B8303C50D29148AC0BDBB4BC4ED189230A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "942D16A85E0B3342745815540D0D511A07B0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "4CAB747B3D40314AE26B00950301EB27FF16"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "3C575D903E339247DD286CF97EAE00A87273"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3033B4736E389445146A083828AD633B3487",
                    "parameters": {
                        "values": [
                            0,
                            20,
                            1,
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "99541749142E0747AD3A54C868D6D2259192"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 6
                },
                "indent": 0,
                "uid": "0617339B5332714E475B9F6111C08436E8C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "85F510EE42AAB14A5248FDE13C5FEFE947E2",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1D657F10369DF7425A8AE321395D84140E45"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "18405A0D77F2824A1F0A48E63560038793FE"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "finn name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "6788732F593A0447E27AA8F36D78D2E62EF3",
                        "defaultText": "???"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "F62DAFE268E17343302AC3908E242ABCFA01",
                "expanded": true
            },
            {
                "id": "vn.CharacterSetParameter",
                "params": {
                    "characterId": "C36139F346BCE24F144824D6D9CE7B1414F9",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Finn"
                    },
                    "numberValue": 0,
                    "textValue": {
                        "name": "finn name",
                        "index": 1,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "switchValue": 0,
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "CF2AD49A6902014ABD4962C1330C48B3D015"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "F6E433B061534144A08BFFB67AD10A0553A9",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7CA437892EA0224FA7185CA8B32C4C35E22D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CB714D94714A504FBA8BF0D8BC0540C586A7",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF7CF4EE5EF81848A40A4187A138958A77D6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "03DEA4954ABD5648B72A16630CB12FEB0C7F",
                    "parameters": {
                        "values": [
                            5,
                            200,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9C830FC5E1643431F49EB635A8CC6A35370"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "B64D0705543A0849F02A22476CB994EF154D"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A6934A0539AB0248806BCB573D1B11B2B593"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 66
                },
                "indent": 0,
                "uid": "89AF1B150A3F1748A4285DB1D5139A27E07A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "EDD20366205C264A723800C6AB0B8B31DDD0",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "89AF11E3650A654A245AD8044CB1EAD5AF60"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65D8ED9C434D76431628582842C8631886EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "2B9C446F8519C64074295062585130C69A3D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC779FF112A96647B93A1D9567984BF7E384",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line31_1.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "212BF21B2026484C283B4F02BC49A5A23833",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E80FAD2A676294499F798A44A4B928249F32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC80538E8DE7F44E74489BC3D2BEB41BE110"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 0,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "E541B13319A4B640FC4B71368D3465BBA87A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "98A95EB969444548E15A5045784AEC7FFB5D",
                        "defaultText": "한밤의 성소에서 사건이 벌어진 지 몇 주가 지났다.\n정말 많은 것이 변했다..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "FC810E6C8AD355440C4BB773749D9D244DDF"
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "995ED3704D001241E93B576703C350541802"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5D27C5438DB2284ADB6BF758A6675DC5B212",
                        "defaultText": "한밤의 성소에서 운명을 가른 그날로부터\n한 달도 넘게 흘렀다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "expanded": true,
                "uid": "4906A66A94377043B128358692BAAAA22B5E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41B5238589C5B844848A70995FF2DD5A2518"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BE554CD18F1E244C932B41C6C818FD24E4F5",
                        "defaultText": "이제는 모든 것이 보여. 예전에는 볼 수 없었던\n나무와 눈처럼 아주 평범한 것들까지도."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "34CE3D286B2C524A8159AEB57624262229B6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26B63263383C614521090CD709EA09B2ADCF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99C0BB402AB2574F451A2C05513497E80E3A",
                        "defaultText": "하지만 난 아직 이 새로운 현실에 익숙해지지 못했어.\n오히려 전보다 더 눈이 먼 것 같은 기분이야..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5E2F395662AA6844BC99019736421CDD1370",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FB6AAFB715B671456318F812937327E49A03"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "25D3AC5C3A35634CDD9BACC8E8DCA287FED0",
                        "defaultText": "무엇이 무엇인지 새로 쏟아지는 정보를 받아들이기 힘들어.\n모두가 도와주지만... 너무 벅차."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "56259C8022C1244DDF0B228328064D3C7EFF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "327B27341CEB484D8658342094B398B08679"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "20B17F772E96C84120592A62221EDC731CD0",
                        "defaultText": "그 모든 걸 미처 받아들이기도 전에...\n내게 익숙하게 보여야 할 곳으로 돌아왔다."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "78EE9CA247FB3049FF3BEC28AD62A9DD1F49",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "68CF64CC0DAA8446808A97705FB8E695BBCB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "81CEC6DF1CD16243C12B730216454C1D7122"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC034B612F208747D80803B2AC5941C1C721"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 36
                },
                "indent": 0,
                "uid": "5E416E47787F134584388A11BC470762A2C0"
            },
            {
                "id": "gs.ErasePicture",
                "params": {
                    "numberDomain": "com.degica.vnm.default",
                    "number": 1400,
                    "duration": 54,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "72F367DE7F5BA44B864A1A1714E8DDAE2000"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 51
                },
                "indent": 0,
                "uid": "2099627A5191D147EE496E18F81FCB35E314"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "685DAD9F3F8C324FA49870A22E78123C1ED5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CCD4BE9569E11646A51B85F514EC1C73B5C7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4579ADE03308414AD14AB596ACC46D80B123",
                        "defaultText": "타르멘... 정말 오랜만이네."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "84E02271609D82448309DAD5897C3BEE09E2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "37C1B48B2B405546667A3232D23CCA46713F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C694F036D505441142B6C63880CCE173CFF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DAD0FA2B328BA449A4188DD11F6BCDE34B29",
                        "defaultText": "전보다 훨씬 활기가 없어 보여.\n게다가 이곳의 마나 재앙은 굉장히 강해."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "51431244173B2543D2293AE08DFFAA63EDF8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6D6FDF188464C848295AD4C7352772407D37"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if Midbar first"
                },
                "indent": 0,
                "uid": "C0D820D7386D0646FC1911C40B432092F4AF",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "3B1964623DBF034C0C6A4275D5BCD7AC9BDB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5C941CAF958235454C5BC1808EDD1450749B",
                        "defaultText": "미드바르에서 본 상황과 똑같아. 그렇다면...\n대모님의 말씀대로 이곳에 대악마가 숨어 있을 가능성이 커."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "77D31FB62C2A7846E5199630DFDFA412BC68",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "A0C2B9BE11E61742E788BF3283FC30B67203"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "246863AB13957648FD292073A3BFE0011EB2",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E14FFCF816DBF644FC294D76CBCEFA14994F",
                        "defaultText": "마왕이 깨어난 부작용일까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "4C6A014B6FE2994AFF18FF1318738DBE5CCA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "97BF1D1868F41743D4580E123F0CCA7E0ABD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "173B7EE25DFEF8401D7989C856B358B64C82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "9CAC19643E6F654C2C8942852CFEE75B8AE4"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "D397ED5E4B6E92444E0A65835A4393284D44"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "BDA2D9CD7BEF84429238C9857079F6C7B110"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen"
                },
                "indent": 0,
                "uid": "EECB466D7B8428496539C4858A261154B44B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E5A3357856BBA246E61B24A2282F51EDEDF6",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0,
                            0,
                            550,
                            0,
                            802,
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "25C556827F6C754CDF58AB9820B84A0E6C42"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9D6472B10402664D4B099C45E7B6B7F66BA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            3,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D4ACB537324DF340DA4910B4BE254A9A57DA"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "8B7E44F383ADD147546B6512527CC6FF0ECB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36719D168FDA074B5D8B049408939DDB0300"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1A81DA674BD8F24F1D585E1122B821219535"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7F96CE2E4BBEF041227AC9180EBA550A1AB2",
                        "defaultText": "드디어 도착했네. 그래서 지금 네 {SP:2}{C:1}발{C:0}은 어때?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "54C3B1A81EC1B9454819CFA7A2CEA4F3ED54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2015E07A5A5C694C9D5B7D2687BC6720E912"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3591CEC926F7846B64A94A2904EB91C48A4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "954EAE8C56E3234EC56927D18BC0A861ACD1",
                        "defaultText": "자-잠깐, 제-- 뭐라고요?"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "ABACD6B23B7CC54E8939ECE37B1416A9D516",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE0D372F3D01C24EFF79FF33135F2AFEEBB5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4713A03E50B9F34173283790A58C8A657E3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "558F79217BB275437178BBE88E55D87D86C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "ACCDA21062FD7440DF0A110370DF30F52698"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "23F5BAC37BDB8341B549D8F3BBB8E7C2E77E",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E2-Faratras_line2_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "53127C8E1E50474F66993392E361503CD92F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "DBE681697A0B0148B128A4F7353D2C68CA9A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90E0AD2A2CE2944B621A983496DCEE7252C9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61FBFB4644DAD543F908B479B07A57618A28",
                        "defaultText": "정말 최악이야! 몸과 마음의 상처가 아직 낫지도 않았는데\n시오리의 발이나 생각하는 거야!?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "44620FD76F9F3046205A0DC2E3878FA7E560",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "216B9A363B7C4347865A0691F940FC06D8B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "757A7FC52075E14F2E19B97333064AD3B08D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41836A001366024FE9589CE5DACD178F6FAF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E0DED1B01D1A6445B26B9C37679ECCF569CA",
                        "defaultText": "아, 왜 이래! 넌 왜 항상 날 최악으로만 보는 거야?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4981AB7035ED994A6629091101FE27891A0B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "33832768904C6346E889BA985F4D9D3C1AEB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "41A73431049C304B251883D20ED0F709A80E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF2D024A3422C64FBA5B57E6F5AAF5E8446A",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Shiori",
                        "name": "E3-Shiori_line23_2.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C5D2656F4EDC074CD66B1AD874218E2AC3B0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "5720E86C40479245763B15F9DCC2F6CA18CF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BFA5BC208595854DE56AE0B290528BE86FF2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C11372E378AF1845E44B7B84D47C93BA31D1",
                        "defaultText": "푸훗... 헤헤!!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C5DB7C2A907EF246A809FC10346DF9B406B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D510D5D501411747C428522308736B3AFA82"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE449D9F4A93954F725B7B7862161ACD6FE9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61CF77FE1D09A342F988CB96A0C1F4CD24C2",
                        "defaultText": "사실 무슨 뜻인지 알 것 같아!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "732888BF7626F54D7A799584DEC964F97B01",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "AC7DBB6A8DA4B343F24916C0DCD08C147364"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "1F487D1E8BE972407229ADE844217902BE6F",
                        "defaultText": "전에 내 발 얘기를 했잖아!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9D3841DF6CB2A8477D0A076713F2F6776D74",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "692BFE927F0B14455E39C447A4A29FAC6CB3",
                        "defaultText": "내가 뱀에 물렸을까 봐 걱정한 거야."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "497439DB1158924DBE2A6A2844565F98CAC7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 3",
                        "index": 242,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "337D9F5B5BD7E04DDC8AA031C312F4CBB834",
                        "defaultText": "발 페티시가 있어."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "680540644067594F5D29242166104541CAEF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "correct",
                            "wrong",
                            "silly",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "C7BEEF6A792A414CC3386C76056A27D26BBA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "B01C237E3392164C9608B052F72DA88084EF"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "correct"
                },
                "indent": 0,
                "uid": "4C5D3BFF1C72F547765B6D95DE52A1F4D274"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            3,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "6276F46927D6484B2E48B6827B2233AF8C95"
            },
            {
                "id": "vn.CharacterGetParameter",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "param": {
                        "name": "First name",
                        "type": 2,
                        "value": "Suzaku"
                    },
                    "targetVariable": {
                        "name": "name",
                        "index": 0,
                        "scope": 0,
                        "domain": "com.degica.vnm.default"
                    },
                    "valueType": 2,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "99EB11BA6206C3416269717971337708446A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18F696DD41DE7140B17ABE75FED9A2682639"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "42A84F012F5CB645313966043C1BE6837BD9",
                        "defaultText": "너... 네가 뭘 했다고?"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8898AFE37B7F624DA32BC0B348BEAA35DFC8",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "67B96778349BB0462488029547BC07FBF11B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "wrong"
                },
                "indent": 0,
                "uid": "E8D97F6129DB8849930828921A33B1E6C8F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6CDD940937181443E3BED545581113673B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "57539B4712D8954A424AC82718332697C6E2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8BF722074A60B5486B58C357FEEA974C81CA",
                        "defaultText": "응? 그런 게 아니야. 우리가 처음 이곳에 왔을 때\n네가 한 말 기억나?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A099ECC850CBE84AAD099A068629710ED0BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E20929461B806342A269BB26F4C93DD62875"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BB47D21A9B118946722AE6A2B27F3CF3FF93"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "A98B92476AD6C74D2A4A15E5307DD1EF91BF",
                        "defaultText": "우리가 타르멘에 처음 도착했을 때...\n아! 물론이지!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "564C21A64F0F8148AF6A4068ED7B6E296C63",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 1",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "5484606736BDC64FA40BF2C29FFC527CF871"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "silly"
                },
                "indent": 0,
                "uid": "A54133C58BCA73457808C348A6BB6B98CAF6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0,
                            3,
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B40F6F48B59A8411C1B484619B2B73025F5"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "8ECBEDC6144D7642E4682F86B703AAC2B6B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0,
                            5,
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "2190C87F34034842700BE9C2FC70E7281873"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7C7B077088C5234C1B5B8B3604F7B8177530"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3F94DF711288341F569445979A8CCE4383B",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A5269E31174451495E8B73266F749354A363",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6FE502E544153644F27B0789680F8AF869B8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AE097F6E1B48B24318799D76C3DA3047AF5A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9273B7ED6D0FA3465F4BAB8365EF29BF4E24"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CE70F65764E1214DEC2BC413EF05C5EB420B",
                        "defaultText": "그래, 맞아-- 잠깐!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C03B392B8FA8E44D721889162EDD6848209B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFCAFE380BE8B642123A991886FE6CA60BDA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEC4617E2B4E034C05382A5496FA616DB74F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D337637E7D7DE74FF8194A076FAC91AFB59C",
                        "defaultText": "크흠, 농담이야!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4555E879AF2D14BA07ADAE60851B4D6E0AB",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 1"
                },
                "indent": 0,
                "uid": "1803D9160F99964E879B964458ADB4D166F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EFB23A1920E1E54D896AA3C21FE5B78D93B7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "655161DC26BD7046FC380CE4CF00BBFBF921"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6154B6005644844A528902A45C7A8A87E3ED",
                        "defaultText": "그때는 너무 많이 걸어서 발이 아팠지."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "12E4067A84687647F84AB467BEF7C584036D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5A5E235693E748427B1A8E129DF92ABA0497"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "40036A8959C0B2464E2A56B43A15EF690EAC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CA6839E6B1C814DDD2875E08620E9D78A09"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "7D1D7D9281CA5546DE389CE504489FD446D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8F80B04F74D8F849D289AFF10250C55D3560",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line8.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A457F7377DD2E5486F6ADD1636EE8738B2C2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "CF9F2B894825E54C528909C7B9D36E232336"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E9CA24A741C92940DE79CA58D997FE1E7A36"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9A7C59C6454CB8459F995241FD332ED9FE3B",
                        "defaultText": "그런 세세한 일을 내가 어떻게 잊겠어?"
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "04B93B6F5D90C843F369CDF73F5200310B21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44A3167F091B6345409AC402EA4977BCA032"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CE3788604C48F048CD6930046EA43D1EA277"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "17F654A61A91C94981788967CA63CF31A105",
                        "defaultText": "내 자매한테 추태 좀 그만 부려!\n정말 죽고 싶은 모양이구나!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CB60F83E6C2A8541B80B60D8981DAAE6A1F0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0A20D8378F60B6421E687AF023AA86275C77"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6AD1D0225CF6A84D4E69F67322A3ED3D961B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            10,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2A189C665F3FA849885A4447ED9C3FB4310B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "53E02C935D659741334915887CC868B5954F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "625E57DC2141C6455F1BBF63F2DEE5774B73",
                        "defaultText": "아-아니, 그런 뜻은 전혀 아니었어!\n그리고 자매가 된 지도 몇 주밖에 안 됐잖아!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "28AF0D443053D64FDC2888429BBC0F3581E7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "046155318CEB6743A41AA74263E02D17B3D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2712CE80508C9344F11804B763F1965AD74B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B69791E92D4D8343F88AA2225D642B004089",
                        "defaultText": "둘이 다투는 건가? 정말 서로에게 화가 난 걸까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "43A771491F83E349399B45F32BCAD2FF601A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F4F709170B372420F7BF8721741794968F2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BBF52F58114DD64E0F7A26416A66386B65F5"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D56C2232A61F64CA489D6158E492CE3517B",
                        "defaultText": "내 능력이 없으니 알아보기 조금 어렵지만..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4083F0B35FD2A14DED1B49D3B2E40B4C330C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "F5271D09986717431F8A4B561FE49553B231"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FCF9D2801D6FC24D1C2BAD15456153920C54",
                        "defaultText": "둘이 정말 알콩달콩하네, 헤헤!"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "FEC1D1786B94434A28588A675014E4468A4E",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "B178B3EC195FD34AB77A4DB18C89932D0CF7",
                        "defaultText": "둘이 사이좋게 지내면 안 돼...?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "91F65B4A365FF148C408A643548B874E870C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "lovey",
                            "get along",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F9E96AA55324024E226B3C98623E405C903C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0205500323D7114DDB3BF56103C7041B809E"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "lovey"
                },
                "indent": 0,
                "uid": "3C1ED47097A8A14A249A165714C44CD31546"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "F06EC5C25BCFF74CF96BF7F5C1E414F53597"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3A9A7AB53491C84FA858B2A58D585B945FDD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F346BE7525D7F74A38390C041D2519933391",
                        "defaultText": "뭐!? 그-그럴 리가!"
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EBD9B89C273B35437C88E3B66D072412AB69",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after choice 2",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "2F8ECAE6276BF64CB2689DA7D330B775E359"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "get along"
                },
                "indent": 0,
                "uid": "85C8463D4C46E6424558CC270F1E683B61EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            3
                        ]
                    }
                },
                "indent": 0,
                "uid": "32D683BD462A0142F08A4AC0935F954600E5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "598312F1131A2449E1282B38DE91933CAD39"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "0A02C8E44819254F7D1AD66894EFE32EDBE3",
                        "defaultText": "나와 저 녀석이? 하, 그럴 리 없어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B6EEDF6016E1D148A14890D8CC65BCCB501A",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after choice 2"
                },
                "indent": 0,
                "uid": "4DAC1B9B156C914C3209C814AC278BB29C50"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "080BC429512A584F742A3B822D4CD7EEF453"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9CBED11811C025406A19B0D232BFAF458D02"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6329183576592040D03A0D56AA551A075208"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39A2078E3CC0B2487738377648382C73EBD9",
                        "defaultText": "지금 진짜 감정을 숨기려는 것뿐 아닌가요, 아가씨?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CF6CBA6E34A4D3471C6803E6F91207B9018D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FFD04C603C5E0443515AF345AE2645F32FD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "70CBC00D8373524376690941FC53E56B4FD7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B37D31F54D78644A453BA6604F8DAF49C71F",
                        "defaultText": "...좋아, 점점 헷갈리기 시작하네.\n결국 내가 틀렸던 걸까?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1839AC9551B22249BF3A8A55DEDE6C85B0D7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A291BD39719F504C8E69D7583B7947F0D8D4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43419BF17592E14AF82B8C6181559BF663E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "2560B4898EB4204AEB1B1E57C9BA3BECF74C",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "FB6E22A825FD754736480A472D9EEC3E4DDE"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Result of calculation: T/F?",
                        "index": 39,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "C86C38247D5E8548909998E766D8B7137C93"
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "PARAM_BLUSH",
                        "value": 1
                    },
                    "duration": 13.2,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 1,
                "uid": "78D61AC062540046E6580B12AFA6AACD0595"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4495AB2388998241C22ACCA250F7DCE1CBDB",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "D4B1310C61ED7146F01A4BD7E6B1A698E28E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "9C6473A1621BC1476F9A0A57CE3EEC061827",
                "expanded": true
            },
            {
                "id": "vn.L2DParameter",
                "params": {
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "param": {
                        "name": "PARAM_BLUSH",
                        "value": 0
                    },
                    "duration": 13.2,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 1,
                "uid": "00F572194F12F149931857831FC8DFFE2434"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "1408EA5C8421A644B10BD8E3EDD3B2004E3B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "50142E478E75E549A948A7620AEB60C84172"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E3877C269708143A0393277AEAB60978BBB",
                        "defaultText": "웃기지 마. 게다가 지금은 잡담이나 할 때가 아니야."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AD9652D45AAF2445AC593EE81931878417DE",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19F5D1AD67AA1647CB5B9AB6FF9A3A230CCC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00EEF54985C27548C33960537141AFB86DD5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "67F327304E22B34E3A6B73F4CC1D55478AFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "444074ED8F72E54056480A68F9FB065476AE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9F7528732E57624D9119D7A7F0AC28A4FC29",
                        "defaultText": "맞는 말이야."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "75BF8DBA16AAC64439698DC419AF7671D32D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "6768F84456F90240F49942C444FAABD176DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDED4A6A4A46134ACC7ACD05EBF077959787"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "0DE07E6020D67944402816317AC0E8CBF974"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "Rya appears"
                },
                "indent": 0,
                "uid": "5EA6655D3307D64FE539CD2150B6CA792AB6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "FF3CB6A82BA3F543FE7A3C88D43FBE81ABE4",
                    "parameters": {
                        "values": [
                            0,
                            1,
                            0,
                            0,
                            600,
                            0,
                            801,
                            -100,
                            12,
                            -7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A0A1A52081658143247ACC5190F296D48A9D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "765B6D4C2CC0304A5B8901F410FF578FB10F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F05842DC488C254D064B92750506E30954F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 72
                },
                "indent": 0,
                "uid": "5E9237BB043ED746CF59C180AA3AD7B8CC9E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EC58113B18F0B24CD389058599C06AFF31A6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5B8916437B9A5438D8887312C4D0BFF5845"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36B214DD403AF944CC2BB2235D2CE0A69D90",
                        "defaultText": "마나 재앙은 계속 마을에 퍼지고 있는데\n너희는 대체 뭐 하는 거야? 쓸데없는 소리나 하고!"
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FD2B34C2185796413C8BDE36E560C18F28BC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78F2CA3F644DB848EE2A69325C6247BD382F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C07DE1F93C3DC542076895E1D8DA13F69ED4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7FD3B41D346A514CEA582F125E5659FE6890",
                        "defaultText": "리아... 내 잘못이야.\n나 때문에 둘이 싸우기 시작했어."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C11878238FB7E34D722A3EE90E009C5CA03C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F3D5AA382932964A3188EE67DE4E0D7D33F9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F24F7A6F9844564D6D59EEE7D66D48A61B24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BBAC6D80728554F44294D30E956A43189C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5B1800681BD7A24FE958F3E36286E04DBD9F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "5987D8C277BD3441BF296DB965F63B1E2854",
                        "defaultText": "하지만 우리는 진짜로 싸우는 게 아니야, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E7DC6BD46803E648AA2A2E26D66FD2ED1C2C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "28BAD96E66F95443D76B045553012D7214C0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "320938BE9C6687407C4844E2F0C0339D9425"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "CA3957C74DE2B4423D7B8968F4863572E6A1"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "02631A430D91C14AEF2ADFC1FD9A55CF65DF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8EC43F5D12DC75439F198422BAAEE34192C0",
                        "defaultText": "우리는 정말로 싸우고 있어."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5F31CECA276BD84DBB890A32319938EEB33E",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "67E5B51A8583964B9A2A82716174C059FB0E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FBE6BC61227702446E79A906B102589BE4C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "85EE128C49DBE240B12A6285154E566B4254",
                        "defaultText": "둘의 진짜 감정을 읽을 수 없으니\n이 상황이 너무 혼란스러워..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F78A409824D0E84F773A132457FF6A6DBB3D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "753CEC4425190746B168BF8718F0B59EC31B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EF9FF1E35B92744C5148B891F437A18CE936"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA793515877414472E5839E9AA7A74F0AB6E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "AB93CC886E9F314D9D4833B633F4E767A59A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3DBB14457234924B852BA78336BD97D6B373",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Rya",
                        "name": "E3-Rya_line24_3.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C35A6CE16214424EB44926936BBCD2150AE1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "A1D328C52E0A5645483911062FC59037F445"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "524A6B61621D424BEB9948755600EE41451C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "436299807ACD6641BA7A02B2288AC256C651",
                        "defaultText": "하-아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "193F23CD26B224432D1956D6C62A9D5B3BC9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97859B69782E1246213BF7A153376300C527"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "366D3B2C7AB64741AB28E6D3A140D7F6DF80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            9,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5BEDBCCA7489E2484B5889345165F9DD79D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "61E29BA297F70049FB387764083AD6D3642A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6F7B1AC274571448942A99651E625BDC4CDB"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FA2F36D61BF30141F03A2464C917021E04E6",
                        "defaultText": "좋아! 이 이야기는 나중으로 미루자, 응?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D14AF8E671C1634778295B8069947386EBD5",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BF9734518A2DB748110977C98A2B6609B189"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1DBC83660019084BE3289FE2FF812C2D62F4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "36296642326B134D2B7B7DA3145201A26F79",
                        "defaultText": "이제야 낫군. 앞으로는 좀 더 남을 배려하는 것도\n나쁘지 않을 거야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A550A6584DAF2543774A20038A1EF2ABB890",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "413F821E9CD8C0425B6B4F46BA1FAB4D5C91"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BEB1F09737E5424FD74A1CE934505EAF5D28"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D5C1E9FA4A8C584B041924D64B37984AD17F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "731C8A8924C1A449EF38A364B6236C72A7FA",
                        "defaultText": "이미 알겠지만, 시오리와 파라트라스는\n최근에 너무 많은 일을 겪었어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EFC73B1F2E61B24EF69831968148F82DFC42",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "05FDD5418D7BA04D35593676369D16010B23"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "85DD3F293118C842545A0DD6BEED79C6DF85"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "63E4D84D54F49647294A8D95FEF03235E340",
                        "defaultText": "분명 니니도 많이 괴로웠을 거야..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5CF743392C000042D66BBB0085F27D84081A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "78EC082B6DC618461268B3104ADCA37D3C1F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B8356DCD4F98A34BB2782A78DC9EB2BC2575"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if the group went to Midbar first"
                },
                "indent": 0,
                "uid": "1A452D249351B14A273B7E24751861AD1D8F",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "40BF2C4B8432874618790C86FD7BFB0BA49E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "059AF8F237099241DA5AE01200BF4DDB41C3",
                        "defaultText": "미드바르에서 벌어진 모든 일이\n그의 마음에 더 큰 의심을 심었을 테고..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "C1CC35D0405E64459E9BD14156306FF20199",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "E2B8656D292AF64909888E38BBC03D8CE2D7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FEA4BF3F724ED5450C6A72642860F8B51690",
                        "defaultText": "헬리오스와 카비르에게서 얻은 단서들을 보면\n그가 저주받았다는 것 같아..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8C9402A34D88F944D1181D24521281E72A03",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7DB9E5C57213644ECC2B17D1B0B1A1FBFBAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "7A9B67597A0C144F904904E26BE1A119ADA1",
                        "defaultText": "리아는... 끔찍했던 과거를 다시 알게 된 것이\n엄청난 충격이었을 거야. 잘 이겨 낼 수 있으면 좋겠어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8CA2386A4892E349FD681FF134375D551B64",
                "expanded": true
            },
            {
                "id": "gs.ConditionElse",
                "params": {},
                "indent": 0,
                "uid": "2FC82F2954FAD44CD538BCE202997DBA4C72"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "else"
                },
                "indent": 1,
                "uid": "1B87288A2B43B245A48AF800513987945DDE",
                "expanded": true
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8960E32C4736F14A448AA8793BFD419D4D19",
                        "defaultText": "결국 헬리오스가 왜 그의 정신을 타락시켰는지는\n아직 아무 정보도 없으니까..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "FC54522D3A51A3441B68BFB429F338E2F2F4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "45595899902658471839AC68AFCC1C1069DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "BAFB92DD636D2846E368FE58F2B917FD97D1",
                        "defaultText": "리아는... 전에 감정을 읽은 적이 있어.\n자신의 상처를 극복했을까..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "8121EDC45521774E994A7CA8A40EC3F38376",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6EDFCECB8BCAE642118B1AB1CC62D566CD19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8CE665D1AD291445E68D042EE25BD7A0F25",
                        "defaultText": "이제는 둘의 악의를 느낄 수 없으니...\n짐작할 수밖에 없어. 하지만 내가 이해하지 못했다면...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A3C5D14C48A27849444AEC7048FFD17651D3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6541A04663BB43491D2876F0FBF8C2340784"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9B45E02121B422486B79F4A5B865AA963C5B"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F3B9548E49B051417F4BB22389EC8CE8A3D5",
                        "defaultText": "우리 모두 많은 일을 겪었잖아.\n아마 그냥... 불안한 것 같아."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3FBCB40C810D3048B129B2D77B5058FA45CD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F54D171774BB1540858803E8A4B2E38E9F46"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            2
                        ]
                    }
                },
                "indent": 0,
                "uid": "04A492B54CA1394EE008201530F4E5487266"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "96342E7641F7B6453E987185564B92789B3C",
                        "defaultText": "그러니까, 음... 내가 너무 심하게 반응했다면 미안해."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1802247271DC8141CC6B1311D926BE61DB35",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "30CDD953983C6446055993B4A7DAD0137037"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            2,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D851A12A2A17A14B6029A047D407AF4D4AB0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51A6C08E24395342391B90E5A1ABAB1FF347"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3BC727442ECAE4471439517954FA537C6CC7",
                        "defaultText": "그래... 나도 미안해."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "46C6424F04B09243E0594BF282455FD5F60A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "19D8857B74A648440E89369768DC8B179617"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "87B6E87F5176A545529BA1F69AB0E86B8416"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1D9ACB808234414F088AFF2543FFA387A826",
                        "defaultText": "사과하고 싶다면 시오리에게 해.\n너희의 작은 연극 때문에 분명 혼란스러웠을 테니까."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B4E1DF846DF99746B46ADA697366B0671A0A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1785219A0A9487463E8BE48422BB825F7744"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43CDAB193B47704F2D6B60C7366FED9B63B4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C93567D4619F143796873981F876670E4CD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1159E68F1AFE304AAB4980A33A687C85817D"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2D98327F26B1F346585A19815217ADDB1699",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Ornieres",
                        "name": "E3-Ornieres_line13.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A1938C018FE3434E879A54A284F40115EBF3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "E1A804566C4BE5428E3A1D506728BF046AF9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7BAAE37E24F93849575A7FA1761AD61C4D26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8E42FDCB377806487A794344BCFB27A82C92",
                        "defaultText": "용서해 줘, 시오리."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "344EE3D46F1941416F2B5C46F58162C207DF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "51AEEDE72B35354F999BF49579E111FBE8F0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "25612A720739C9495948C844110D6F0BDBE3",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "271DD9A667FAD4484B0A2B885C9CDAD4BCBA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 0,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1C817B861067F343616B9424089B052866F8",
                        "defaultText": "dummytext"
                    },
                    "position": 0,
                    "characterId": "0D869FF412D69247502956758DAD1635470C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    },
                    "voice": {
                        "folderPath": "Audio/Voice Over/Faratras",
                        "name": "E3-Faratras_line20.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A2065C46D315748C25829059867EF13CC52",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "45797172275FF449E24BB660F88DC560260D",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "BDFF432A8F2AF64EE6095A5516265FF644EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "14E63DF13FB8E149088A99A526CD97BE6F8E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95A6B13F3F451541C58ADD72D06C9B85E364",
                        "defaultText": "미안해, 자매여."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D1C23BB25D2FB1498A8AB968030D886CDAC3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8FD9D76D60DBA548771A41C95868710556A7"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "8D3638D474C3234F595B0130687558601700",
                        "defaultText": "자-잠깐, 그만해..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "240DBD5F8A3AF449DD393BF2020B0F1EF3D1",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "D5AF5D79448C254F608802A1B639E4116BAB",
                        "defaultText": "괜찮아, 헤헤..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7EAB57A101BA1040B42BD6906BAB8DCA3C59",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "blush",
                            "blush",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "F92B0AE3147CA143B24AE6D83286583B2D98"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "0F86E79097E8914D7A48FD76506DCB70CE72"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "blush"
                },
                "indent": 0,
                "uid": "6A37142712FD854A924AFBA0EBC20A4ED355"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BAB1A39213B7664CC26BC595C2CEF5CB41F6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D38E385153F06846B86BF2521756013067EE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "981A27566A881940F32B4FD02E7F105C3984"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D32D99D0954D8344B489589235AE4FBACD3D",
                        "defaultText": "그 표정, 정말 보기 좋은데?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "3C9E6C28725D424B238B7B489A3062B99AA2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D9098F757C02E34E9C2BE5E3E5B66C009C1C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "00FBC10519ECD1411C2A49E7666B0DC26771"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "77952D7A8D02074DD05BA2F7AE77D397A74E",
                        "defaultText": "그-그래?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "DAD917634A8B044447096B65942FE3C2D519",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0D003D9B613D43462E38B273FE106E5F9089"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B205238D548D3647805955F796E76660BE54"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B79322A4501B314D047BA8270DFDA0CA36A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5C5E4F4F2FC5774A633A7EA5725F38EEB420"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AF1D7B9384332643527A4A87EFB36776A8D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "5766F6BD3921774C804B4043FFAE9189C10C",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "296B590716CED74E812AAF72ED5308A41ED6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F7241BC615B1F84F2859BC333103D215D6C2",
                        "defaultText": "다들!"
                    },
                    "position": 0,
                    "characterId": "5766F6BD3921774C804B4043FFAE9189C10C",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4B70BEA67DB5D54AB4298292DEFE74628670",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "39D01443756DC1484A690D667C21AFDFCFBC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E44A6C9224CD61488B489782FF7DA9F70822"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "2EE4C0BA7C22C8460038B84154DFC05F453F"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "close;reopen after Cristoph joins next to Rya"
                },
                "indent": 0,
                "uid": "BD13B1F00BECA143673978F1287CC86F58FF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "601965023B979749E05A20B15B0848CFE086",
                    "parameters": {
                        "values": [
                            2,
                            2,
                            0,
                            0,
                            600,
                            0,
                            0,
                            80,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1388A9B40BCEA643871AEE179FA4875F15E0"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "59604DB765C8544DC5684E5381D0F13CE36D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            4,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "95571BE42C6F69444F499EF71F47A867D7DC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "067074D33F4B6646F088B9380FE6BC39F3C8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "44E8121481216143BA8B033227762F4AFEDB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "307770E16BE35348DC5A1753238D0B1C2C54"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "79F2C7A53459434E2C3AE5219DFE23831D43",
                        "defaultText": "아직 대악마의 흔적은 없어.\n대모님의 사절을 찾아보는 게 좋을지도--"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1E6097BB66CC464CE98A2D172DA3F47C9F30",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9230C13D6F5DB24DFD1A23627D91973F63A7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            3,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AD5878737A50234DF65984A5F8894D6CAD59"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8ADC683331F31846D1894B063C88E3C3D9A8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B73C130C030DA34AC45B44751332BA6E61AB",
                        "defaultText": "어이, 시오리! 또 얼굴이 빨개졌어?\n적어도 그 붉은색은 너한테 잘 어울리네."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "91B817D7816B0241143BB5C2D99EB3E75E53",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4C5A78705EBC8942A37BB3F3184EAE51FA3A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            8,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1D8A40522FB901491D1B1FA7D1175C92EC24"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "623566674AD0994FA84B11F4B1775D032C71"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "39B99D407D66E84E7C2B6251858757D63CD0",
                        "defaultText": "방금 시오리를 더 혼란스럽게 해선 안 된다고 했으니\n시오리 앞에서 널 모욕할 수 없는 걸 다행으로 알아."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D36259742D149349F15A5B55AD57DDEA5CC8",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1679DCB487B65142CC2914B414F0342B2FA6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2BEB88273CFFE14BB819A373237263E1617B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            2,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3F425B3F0106964D1F794441814A5B67F5F8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C37807AF4327E1413C791B07BC9B8AFCCEE2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DF7C53C34FA1824B533B6443DD8B1F659C57",
                        "defaultText": "응? 내가 뭔가 놓쳤어? 다쳤어, 시오리?\n원하면 내가 도와줄게!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "97E178EA8B35734D2C3ACD576C70634AA16D",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "73EED9628B6D334C5B587A1989FAC8025EC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDC5A26F5278C84594895476AA71D415130F"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E19DB58930673844230960182A411ED389ED",
                        "defaultText": "아, 그게... 아무것도 아니에요, 크리스토프.\n정말이에요. 헤헤..."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D026B60C64CB974F107859A21A3E6344B91F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BDEC3C8D30C7364D622ACB2460B9728210E2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A492BBE833A757413E7AEFC272817E9A8480"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A636AF050D17D849EE3B4CA783F1A9885F4B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA474AD44EB3A74C9779AA880D6E97A59F32"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EB7424921D03274DC25B01493E28FA3B0B17"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "F12F1BF6669E934E984BC9E37F50C2797029",
                        "defaultText": "으음..."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "FC601CFD3ED12349F05A75D35DDE286FB2BA",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FAB917C14E16824E5D18D128DFBA1D835169"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DEA561863ED4264D144BB2A485CF849FC719"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "75EE2624294F574D297B36721FD44EA8EBDA",
                        "defaultText": "... ... ..."
                    },
                    "position": 0,
                    "characterId": "67F327304E22B34E3A6B73F4CC1D55478AFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4FBFD1B208AD7440164B86863FF82BCB707B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D6EED7DC803D894D24490284F4D030B0C9EC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            13,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BC07291B17C177418A5AC7E102E789C1D1A9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E9E22A3784BA7446D1B7AD0CA5577F61203"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0EC98B256B404846929ADFA9378121A8FD03"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DC1E53865273D7427D2BAFB25A4699D5BEF7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6B97FE982231784C1D3B8CA215D90604EFC7",
                        "defaultText": "흐음."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BC69A6B153BF6141F84BA0292D74DBED5561",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "837C5AE29F81D84E0C682408D98F25C3C611"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D3A96BEB00FF264F8A79D4D295EF79D535D9"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "9C1DAB3F02A3B84C4C995BC7C339C3F88214",
                        "defaultText": "왜 다들 나와 크리스토프를 힐끗 보는 거지?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5A49129B1DD8104EAD7A53204E645E3FD266",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ECB2FECB1F569143784BA3C50EEE9D4812D8"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "CDAA49A652C4F7467F2A5BD22DA9AEBAD0A4",
                    "parameters": {
                        "values": [
                            4,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "964EAF2B47047444686AF49676F4AB7B8049"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "54FBAAB55DAD3046D49B6D858033C8E9123A",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B9960FFF884551400A69DBE3699BD4F6D5FB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            6,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "68AD9F8A1982164DCB4944C5C82B25CB1D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4F44B0F75C1E294A811B7255C28DD14BD9E4"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1CEDD2629E01C146747B22B791EF04E79719",
                        "defaultText": "생각해 보니 크리스토프의 가벼운 성격이\n지금은 네게 도움이 될지도 모르겠어."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C921E7D06DA3C647D50BC747723B7463DA54",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EDEC33B559D11749C288C2B82EB1C31AE212"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CC31E1E33149C541AA0BA91375941262BA37"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "636BE6319557F34B4669083197DF43036F38"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "D718D9642DFE9944B57B6165078AB2ECC366",
                        "defaultText": "나도 같은 생각을 하고 있었어."
                    },
                    "position": 0,
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4C29A0C341D4224E2B1A99D3115C3EC24868",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "43D38940612DC4403529E401597AEC6F96B9"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9C91C5C72EC96142A829EC90BA80801EA468"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "EB985C4091F5E64FB798C3F7E63171D3D63E",
                        "defaultText": "자매여, 크리스토프와 광장을 둘러보는 게 어때?\n생각을 정리하는 데 도움이 될 거야."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D6A802A396C60645AA494EF7E1839E9176E6",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D43EDB9836212147579A5A645E9D6C6B537C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "97E0E00D5768A4446258A9D45CEA575B3723"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            7,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6865CFED4BDF2443C15BD0025E120E114854"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A1D04CDD423115489629E4E7C344B0E0558A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61B338645FFCB44B7F8AC756EECD944C2FF8",
                        "defaultText": "나를 인정해 주는 거야?\n감동해서 눈물 나겠는데!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "77BB06BB89BC4447875961B0B4F79F22C83F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4CB865094735C84A6268E4812F0C21E3C0FE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F1F80A4401D0C24A5E1871C3D459DE71DEE8"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "6CDD3E2D812533401029B0E6893089C933E4",
                        "defaultText": "흐음, 이 새로운 방식으로 사물을 ‘보는’ 것에는\n아직 완전히 익숙해지지 못했어..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4499F24A98E72143216B4422F57143EE2371",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A20B86248A18C84B35198D00EC7D3412CE52"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "if Midbar first"
                },
                "indent": 0,
                "uid": "7B91730B879CB0484009EC3613C451E7BA2C",
                "expanded": true
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Defeated Kabeer?",
                        "index": 231,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "",
                    "switchValue": 1,
                    "valueType": 1,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "80647D7F52E7F9469079200283C6AEC54281"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "538FCEF8425C7641263A3F364E2F7A657EB4",
                        "defaultText": "미드바르에 다녀온 것도 별 도움이 되지 않았어.\n모든 것이 내가 알던 것과 너무... 달랐으니까."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "349C54728803F4411618B229104140998BF7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "914C8C9F5E1AF14127999DC1FAB4A45B5941"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "99AD36322A59304FD75B1151331D0DDD704C",
                        "defaultText": "갑작스러운 위험을 너무 많이 겪느라\n앉아서 내 상황을 돌아볼 시간도 없었어."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 1,
                "uid": "878198CE01FA074A338A34E19CCCB798C8A4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 1,
                "uid": "7A4CFE7A1318314C636832222918EEC12F8C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            1,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5728C91E47346848326886284E281C429314"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2276EC398CB90247CD1BA364F2C967FC7B37",
                        "defaultText": "어떻게 해야 하지...?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "701172017DD6844CB43943C2B0FF7359F2F2",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8B05C1E15A43114E1E7B0134A74742989078"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "FAB0F94E2A1BC7420B4B8251F8B947BE1791",
                        "defaultText": "좋은 생각이야! 갈까, 크리스토프?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "7481659C9786914FDC1AE49838B7B90DF5B7",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "98157D6C5816D7494D1B3982FE382EE5D5E2",
                        "defaultText": "가고 싶지 않아..."
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "A0823F546789F4430E680A3557DA500629FC",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "let's go",
                            "no thx",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "D981A9452D3C76452768059766E247A660E6"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "1F8DFC191FA2644BCF8A9EB6CC22CD14A48B"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "let's go"
                },
                "indent": 0,
                "uid": "18B657668E3ED144406B6C05013DAC8509AB"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "+aff"
                },
                "indent": 0,
                "uid": "223105A826117242F44822F1DBBD3D39CFD7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            0,
                            0,
                            4,
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F739B16821EED841220B2ED1BFB3D7366BFA"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "807C8CC3326B14433148AAF6A957799749DA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "95FEB4B66119954ACC1B74849241D924DDE1",
                        "defaultText": "좋아요! 금방 돌아올게요!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "AEA31098514576498828A8566BD562AD09EC",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after final choice",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "A2300ECB242EE245B049D4B462D5FFE70B9A"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "no thx"
                },
                "indent": 0,
                "uid": "2DE088D3882EC8483688B3C4BCC05931C75A"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "-aff"
                },
                "indent": 0,
                "uid": "392FD7871AED3845A7782A441661C5564EA4",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "38119367693D67499A49BD56E4037918772B",
                    "parameters": {
                        "values": [
                            5,
                            1,
                            0,
                            3,
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FC07B5B76B0CB3499558AD345CE7F67DCA89"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            7,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B90128B262881144AF49DF3730B32271FA8D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "26C32C27683B814A539AD35275E2A0C1D161"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "84B7F2612895814A1D0A5E689F0EC35BC3F2",
                        "defaultText": "아, 하지만..."
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "340D30D50116884AD729CF586EEC98C16BF7",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9A6C742816FAB2495A8B6E039F09FD32F42D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9BE93E6517D6C84CFA9B3B21C4C654AC9816"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "19123D834DB7034E491A2962139BD55FC838",
                        "defaultText": "내키지 않는 건 이해하지만, 그래도 가 줬으면 해.\n다 너를 위한 일이야."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B13C06FC3C9CA24821484E07A49FEDCDC948",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AEE8EDBA52487640862B8A554AA0C74160C5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E4A61FEC8FF1F14D0279DC36DA206E58E115"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "43D7F56437C1E64A68988CE24E28CED195A7",
                        "defaultText": "그런가요?\n...하아. 그렇다면 알겠어요."
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7B9C034D419302420C5B87A5DD1D501B48B9",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after final choice"
                },
                "indent": 0,
                "uid": "0980F34C4DA287436E8BF1A6AE3D3CE45E4D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DE84DA462A13F647CE6BD3138D56BB169DC5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A302FE3F8C6EB44DB47B41533D713A0B8758"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2D3DAC7642FE03457D890183964321C169AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3B81DCA8916F6749C1885133A13447CAAEFC",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6E943742356E8043D05A88B029067CB74468"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "36B7EA5F6212F3483E1A2B4677106E02EB19"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "27ACA8D93EC33940F16BFD9307F768464E32",
                        "defaultText": "우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "C9D7A0475564734BA728EB922607DF67174F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F7C50F922998334AC5497A9730FC4BB6041C"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "0E92B9478780B942EF4B3D7732AD209E6A11",
                    "parameters": {
                        "values": [
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EEB017495501E0423A2BCF18758D0A2255B2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "8842386C65B8084F4C3B33C6E3BA8FFBFF13",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E47046872E94944003183E560C657B222D5B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D30C10D8766916429C8B37456E5D39B824DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "824976B43AB8544F4E49CE39D414090B82DE",
                        "defaultText": "그래, 알았어. 다녀와도 돼.\n이곳에서는 정말 많은 기억이 떠오르겠지?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "F480C18E88DEC14A8498585865E84EAE794B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "ADAA0DBB98D0E74942697048C3F257DC089B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "D817084774AB154CCE68B7B2587B0058EBFA",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "7E4BE6BB77B3464C586ADA175B35390DC0F1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2287E5CC0097964E16081831375AC61A572F",
                        "defaultText": "우후!"
                    },
                    "position": 0,
                    "characterId": "D817084774AB154CCE68B7B2587B0058EBFA",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "1A76891499D791456369F8F28CB82E77174C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E6A7FF41168CF84DF378029159523CE6C4BF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "31019CFA31DF1544562828A94FC08499502B",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CF3D0EE475C25147758979E88FDAE3AE0FDE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "298A3A4D1030634BD67B1976DB031751755E",
                        "defaultText": "그동안 우리는 대모님의 사절과\n대악마에 관한 단서를 찾아볼게."
                    },
                    "position": 0,
                    "characterId": "31019CFA31DF1544562828A94FC08499502B",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "384162C058F8214CFD1BBB185BA0C8B583B9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "65CA01B83E6734464159BB01EDB4E7353206"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F477C28415BA564826497B3322091DCFD5A1"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DBA0D8207393734AA2582D2154C3F61BC09A",
                        "defaultText": "다 둘러본 뒤에는 광장에서 우리를 {SP:2}{C:1}기다려{C:0}."
                    },
                    "position": 0,
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "A289C38A4B53C34E8C6801202526A1F13E7A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "365BAC3C5BC4924F96195D66F9803880440A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            5,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C3E10E8473912643D34B8E88772B86E469BB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E2BEC67721B0724E8B3BB7086F817E6E7235"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "4E31E3DA543E3343FD7A8B27E2536007F01E",
                        "defaultText": "좋아! 재미있겠는데!"
                    },
                    "position": 0,
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "03C895FE79B3D24B7719D9F13407593AD55C",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C633C0B6CF605436B5A7617C3D3997D4F74"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8DA0C9793E3A254C1F9A83F486D2AEE4829A"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DD595C120DD13545FC694A678AC44A35689D",
                        "defaultText": "좋아. 다들 이따 봐!"
                    },
                    "position": 0,
                    "characterId": "AB6AC0D89A68C143E328CA74B4BB26755D07",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "7365C2604F57E84B4E794EC58D24E2C3CF9B",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "20F674A3984DE346B52A8A51F78261AEDA07"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3A58662524198340BE498F6197E3C2A6CA01",
                    "parameters": {
                        "values": [
                            5
                        ]
                    }
                },
                "indent": 0,
                "uid": "3241C0434EC1234D35485401C1543E7C007E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "90F008B280CD0440F64B8D9703D8A52CED7C"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 18
                },
                "indent": 0,
                "uid": "4F8C437C260F5748A99B7891542E9889DA4B"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                    "duration": 27,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "278E33A10579104E75588A82C1F0D8335969"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 12
                },
                "indent": 0,
                "uid": "3F579B848F21D14B0449BE07E4CD6C35237F"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "45918E0E12BBF148635A9360998958409EFE",
                    "duration": 27,
                    "waitForCompletion": 0,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "5FD62B959D611140C27AB1A71F62B3D92379"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "A224D67810525640CD2A77B32606EFB286BC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "D9F45EDD07CD9642480AB7B7875FD98ACADE",
                    "parameters": {
                        "values": [
                            2,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "07C7459873B949404598C1F29E5B7718A925"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "136E92CC4DC3B645A749F1C40DAB4F3D753B",
                    "parameters": {
                        "values": [
                            8,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B6BF5AA50A5CF049526BA7460FEA2E354D2F"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 0,
                "uid": "6E8A2C083A662845E93B5F4086DBE50B24C0"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "1E87A6E896FBC641D738D673AC2E9CEC788E",
                    "duration": 27,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "EAD0D2C5236903410238EDB4B140A9195996"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "D4B1310C61ED7146F01A4BD7E6B1A698E28E"
                        ]
                    }
                },
                "indent": 0,
                "uid": "F8537070162197488579D5423DFB18289D72"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810"
                        ]
                    }
                },
                "indent": 0,
                "uid": "D13F5CF62CBF7640508A71957035437F3AC4"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AA53A3133140C74BB979A0645E51B4BE7E40",
                    "parameters": {
                        "values": [
                            "45918E0E12BBF148635A9360998958409EFE"
                        ]
                    }
                },
                "indent": 0,
                "uid": "360C7AEA9A38F44EFF8BAF15BAC8E740AB44"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 1",
                        "index": 20,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "Vuoto",
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "2A83242D6623814F644BB3428E14A60BD5A3"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 2",
                        "index": 21,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "numberValue": 0,
                    "textValue": "Vuoto",
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 1,
                "uid": "AC5205BE822E1241AD1A63B61AC02A6C1B78"
            },
            {
                "id": "gs.Condition",
                "params": {
                    "variable": {
                        "name": "Character Slot 3",
                        "index": 22,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "numberValue": 0,
                    "textValue": "Vuoto",
                    "switchValue": 0,
                    "valueType": 2,
                    "operation": 0,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 2,
                "uid": "614964BC87A2F24172588755186A342F0382"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "A1D985ED15C11240A32B0359FDACB5E75EAB",
                    "parameters": {
                        "values": [
                            "",
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            "",
                            "",
                            "1E87A6E896FBC641D738D673AC2E9CEC788E",
                            ""
                        ]
                    }
                },
                "indent": 3,
                "uid": "B81121E56AD4D345AE2A9923D87F458B3E73"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 60
                },
                "indent": 0,
                "uid": "819C3C607BD05541DC7A0C367A6CD9A0CADC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "103551C503A3644F6849F39843429038C862"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "AB6AC0D89A68C143E328CA74B4BB26755D07",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "CD475ED07C18F942E9494E228E3340C848FA"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CB7A7B658AE2E84E096A0451FAFCEAB37900",
                        "defaultText": "좋아요, 음... 타르멘을 둘러봐요!"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B44BBD13244D134F4B68B1B4B3FD0D38FCB0",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5CA433523CB9154CE85B2EC309A32CB177DD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2E75F7231A764343820845D2AE23FC39DA5F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "1EFCA37B4E29B240878B1F43C77E0011A478",
                    "parameters": {
                        "values": [
                            "B88275A059C20048307A08C8A80232FF6B33"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "BCCF5C54263546441268076687464CA53EF2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "491D626C40FA144C1B4832E147AEC0586E74",
                    "parameters": {
                        "values": [
                            1,
                            "7CFA662122221140C47913D5AD58B48783D0"
                        ]
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5B13367C5F0D104D3D3A4AC8CA33AB6ED25B"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E6230C567FB46248DF3B5A91C2AAD05178C4",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "32D1B6B3730091475559C3F53D68082FA4B9"
            },
            {
                "id": "gs.ChangeNumberVariables",
                "params": {
                    "target": 0,
                    "targetVariable": {
                        "name": "Exploration Unique No. (Lazulis, Midbar)",
                        "index": 359,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetScope": 0,
                    "targetRange": {
                        "start": 0,
                        "end": 0
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "operation": 0,
                    "source": 0,
                    "sourceValue": 0,
                    "sourceRandom": {
                        "start": 0,
                        "end": 0
                    },
                    "sourceScope": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "sourceReferenceDomain": "com.degica.vnm.default",
                    "sourceReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "8C60DE49868524464D3AB592C9D1A177FD4C"
            },
            {
                "id": "vn.CallScene",
                "params": {
                    "scene": {
                        "uid": "7CFA662122221140C47913D5AD58B48783D0",
                        "name": "C11A-1b Tarmen Plaza (Exploration)"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5BBBFD702DB6A741115BCB67ED3F3DC05E30"
            }
        ],
        "livePreviewDisabled": true,
        "stringVariables": [
            {
                "name": "check",
                "index": 0,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            },
            {
                "name": "finn name",
                "index": 1,
                "scope": 0,
                "domain": "com.degica.vnm.default"
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}