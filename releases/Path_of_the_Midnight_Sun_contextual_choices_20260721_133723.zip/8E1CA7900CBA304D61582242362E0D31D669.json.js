GS.dataCache['8E1CA7900CBA304D61582242362E0D31D669'] = {
    "uid": "8E1CA7900CBA304D61582242362E0D31D669",
    "isLoaded": true,
    "lastModificationTime": 0,
    "items": {
        "name": "C8-08e Talk - Schwarz",
        "type": "vn.scene",
        "parentId": "73075B5274DA444C2D0BBC62835D1622F736",
        "chapterUid": "823DFD145789F24D466B6858151B6EA2F9AB",
        "order": 3,
        "livePreviewDisabled": true,
        "commands": [
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 3
                },
                "indent": 0,
                "uid": "4C93F17556D9234C9E484E958A4990E6B39F"
            },
            {
                "id": "vn.L2DJoinScene",
                "params": {
                    "viewport": {
                        "type": "scene"
                    },
                    "predefinedPositionId": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "model": {
                        "name": "schwarz.model.live2d",
                        "folderPath": "Live2D/Z4 - Adjutants",
                        "hue": 0,
                        "opacity": 255,
                        "blending": 0,
                        "tone": {
                            "red": 0,
                            "green": 0,
                            "blue": 0,
                            "grey": 0
                        }
                    },
                    "zOrder": 4998,
                    "origin": 0,
                    "blendMode": 0,
                    "positionType": 1,
                    "motionBlur": {
                        "enabled": 0,
                        "delay": 2,
                        "opacity": 100,
                        "dissolveSpeed": 3
                    },
                    "position": {
                        "x": 489,
                        "y": 24,
                        "zoom": {
                            "x": 1.6,
                            "y": 1.6,
                            "d": 1.6
                        }
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "easing": {
                        "type": 0,
                        "inOut": 0
                    },
                    "duration": 36,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "duration": 0,
                        "easing.type": 1,
                        "animation.type": 1,
                        "motionBlur.enabled": 1,
                        "origin": 1,
                        "zOrder": 0,
                        "blendMode": 1,
                        "viewport.type": 1
                    },
                    "previewBackground": {
                        "name": "",
                        "folderPath": ""
                    }
                },
                "indent": 0,
                "uid": "F725DD19393DA24AFE890CD3D54FF483F74B",
                "expanded": false
            },
            {
                "id": "vn.L2DSettings",
                "params": {
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eyeBlink": {
                        "enabled": 1,
                        "interval": 4000,
                        "closedMotionTime": 50,
                        "closingMotionTime": 100,
                        "openingMotionTime": 150
                    },
                    "breathIntensity": 0.75,
                    "idleIntensity": 0.75,
                    "lipSyncSensitivity": 1,
                    "fieldFlags": {
                        "breathIntensity": 0,
                        "idleIntensity": 0,
                        "lipSyncSensitivity": 1
                    }
                },
                "indent": 0,
                "uid": "0CE6872F3D0DB44A1B7B00A06D4CF31360AE"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "18CAA7A38A201640845A5BD586F55A1B7FDC"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 48
                },
                "indent": 0,
                "uid": "F9433CEF6DA781480A19F1D8E80AF5B6317A"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "F4837A897A00614C9528F779DE9B0D517288"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1F08A8D911EBB043C96BCCF8C4EE4EF29B00"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "115FAD855CD82641C318BFE2BB33ED4FB216",
                        "defaultText": "누가 내 휴식을 방해하는 거지?"
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "16452DBC213B644A7C4819C16B62E524936F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AEE8D1891697F641244B83D30D5151BE5F5D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "FE870A0B6392E24DD768A536F159F06A17F6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2970233C46F6714AF86881112CFF9A9F0635",
                        "defaultText": "만나서 반가워. 저기... 슈바르츠, 맞지?\n리아에게 네 이야기를 들은 것 같아."
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2736D9415985234FDB78A077DF4296272B21",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "75150A6B2149244BCD382DA569C7279AC719"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "818453D02A9F054DBC7B16662934916E09C0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B96DA6198E44A54E2D5BAF30F7B8017F2B0F",
                        "defaultText": "쳇. 단장과 할 이야기는 없다."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "6AFC91E31E6E434EA06B0859D669E365D99D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "D95098842A00C8437779DF17857D4C3344AC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "004196B38A76984B004B7425A5A820AB2E38"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "80C8950E5D9A984CFF3AEC23F1E64EB3DEBE"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 0,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "0B6F292B887B854FC42B8E95B95314D9181D"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 84
                },
                "indent": 0,
                "uid": "E8259CED5A58D34F1B0A8C76BE026BF170AC"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "he goes away; close reopen"
                },
                "indent": 0,
                "uid": "0A9851C138193846E258B8A27E1BE784DED1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "076E2D6870D6D84BF2193498025382A1A660"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D76BF92C953BD645A37B01B8EC77913B291C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "137266D68C3A044D4449ABC1BD7959454D7E",
                        "defaultText": "잠깐! 물어보고 싶은 게 있어!"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8B8A3BB4663F08460049A527F7DF7F536AA3",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "503D7CFB882BC14F9D89B223634BEB400CA3"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 30
                },
                "indent": 0,
                "uid": "B227F505602602471F58E482EB3D0DDA7324"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "224B82793054D14E0E281E905AF76F3CD3CE"
            },
            {
                "id": "vn.BlendCharacter",
                "params": {
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "opacity": 255,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "EA48459318FC304B778875893AC75609871B"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "he goes away; close reopen"
                },
                "indent": 0,
                "uid": "3BB3F9CD8EDEE64CFC288D049AEC6D362CDF",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            1,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E7B57C77F7996482578736043E1C51B7E26"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "B72F98EF58D94242F898B2C8010B521EBCEE",
                        "defaultText": "아, 귀찮군. 뭘 원하는 거지?"
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "expanded": true,
                "uid": "D3D62EF0380F9349C24A4B67A8C5F11D1538"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "8A1170357CE2124AD39A4BD8D1740183CF27"
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 1",
                        "index": 240,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "0B92B4F31AF917489E487C78036219AE06AD",
                        "defaultText": "방금 나를 ‘단장’이라고 했나?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1BBC4B8A0D1F174745496E17852A163096F2",
                "expanded": true
            },
            {
                "id": "gs.ChangeStringVariables",
                "params": {
                    "source": 0,
                    "target": 0,
                    "sourceVariable": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Testo scelta 2",
                        "index": 241,
                        "scope": 1,
                        "domain": "com.degica.vnm.default",
                        "changed": true
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "operation": 0,
                    "valueType": 0,
                    "textValue": {
                        "lcId": "517CCE4B5858D34B49789B3587968F831E92",
                        "defaultText": "내게 아직 볼일이 남았나?"
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "5AA9A538284D8646F96A555426D81C27B554",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "78827271603F3243D77A8BC4BC96047DD140",
                    "parameters": {
                        "values": [
                            "captain",
                            "business",
                            "",
                            ""
                        ]
                    }
                },
                "indent": 0,
                "uid": "48BFF8CD68E756438D88E425E09CA9D0917D"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "135C8B3E7ACFA444804B3348C40E7784CFD1",
                    "parameters": {
                        "values": []
                    }
                },
                "indent": 0,
                "uid": "733B2CA69DA3884A15280601EA902F75CB00"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "captain"
                },
                "indent": 0,
                "uid": "005C3D091AD1F641F369A3437C9CA5A8AC00"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2C9A1C2D65841346A74B78F815719F3B5719"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "2AD8924800C33447FA1B1F627C48DC775ABE",
                        "defaultText": "그래. 뻔한 것 아닌가?"
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "B2EF211C52BAC5440A8B2C413AB8CDA68B0F",
                "expanded": true
            },
            {
                "id": "gs.JumpToLabel",
                "params": {
                    "name": "after",
                    "target": "activeContext"
                },
                "indent": 0,
                "uid": "79B41A129DBA3143161A0325714E9E1E3342"
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "business"
                },
                "indent": 0,
                "uid": "0C4D6327409D4041C778F9A5A7EBDF39B4EF"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3AC1D06E103F02490A0B2808DF1D62DAC926"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "E54B36566623624D2E0A9B7396654005B993",
                        "defaultText": "뭐? 무슨 바보 같은 질문이지?\n우린 전에 만난 적도 없다."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "329F5E27238FC84F3E4889A912AC6F7FFC33",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "B98A91D3184C244C4D99FF869EF17B3BBB01"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "2382CDFB3D8785444A38EA828E9673ED0A65"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "DB17830E5137E644B90834A8EC79946ED3D9",
                        "defaultText": "좋아. 이 사람은 과거의 나를 모르는 모양이네.\n그럼 어떻게..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "12A2FD7B3A1A224A6B7949A55EC08244A48B",
                "expanded": true
            },
            {
                "id": "gs.Label",
                "params": {
                    "name": "after"
                },
                "indent": 0,
                "uid": "C225C69779B5434D9B3A91232EB5BAAF9361"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "4818BCA6633A83435A69FAF44153AAA96ADC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "DA8F3B54859DB1462A7861E28D1D840D2AF5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "22C70EEB1D9DA547A04B9982BF3794D8E6DD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "1265365135EBD64D8D2AEB2573546FBF7D6E",
                        "defaultText": "네 검이다. 마나드롭이 붙어 있군.\n나를 감옥에 보낸 자들의 검을 잊을 리 없지."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "CDE5F57251BA494A302AE207D733802B8BBD",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "41FDFC78119C91482F884341AF75ABAC790F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "93FA201E4BD7624F113A9391C3FB8E90AAAD"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "ADCF9F1710453642A70BBD44FD6F56827379",
                        "defaultText": "그럼 과거에 성기사단에게 붙잡힌 적이 있어?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "8F6813100A0A764CC79B9A94ED917233BE0F",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "890AEEA8683B664A913B5AA36203929674DB"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "6A60C97A4AF4254BD339EC326406081D9D51"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "8C066372852C23450B28C1490EA5C8E2DAED",
                        "defaultText": "오래전의 긴 이야기고, 너에게 말할 생각은 전혀 없다."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "6AB2BA6F9320D346522A95532E8F57088555",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "62F724936939D849DA9BB0521B946DFE1B78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "23B7F6C165C1134B717822E257B17C3AD8FE"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "3B9C04FF6A9B55457218FDF8B804C6642F3F",
                        "defaultText": "정말 속을 알 수 없는 사람이네!\n한번 도발해 볼까..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "4764F6EC3ADAF54DC72AE893B2CFF95A4689",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "A349D5197D5B93481649BFF218A2681E4A80"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "480234E122C206486F0803F3324E7E52381E"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CD526E579850A84FA57B7A42ED248B9FD4BA",
                        "defaultText": "기사단에 있었지만 네 이야기는 들어 본 적도 없어.\n별 볼 일 없는 녀석이었나 보네?"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "E630724174CB974C91387A81B61196177FE9",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "BACC005942776841E71A79945D2D5FB27CE5"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "E82FA01664D7E541937AAFE80D01962960A2",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            4
                        ]
                    }
                },
                "indent": 0,
                "uid": "0C8C8DA35EEB72476649D971466BBE9D17D2"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "C5BBB4DA86ADF545DD7B5BA05C5D30141D98"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "02ADBE8653D16443DB989445F092CE7B75EF",
                        "defaultText": "감히! 네놈의 저주받은 나라에서\n내가 어떤 끔찍한 광경을 봤는지도 모르면서!"
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "28CBB4613E6C854A0D496D286F9E7AE30552",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "91DBCD3D2E18394E1A49DED41EA93CE67FAD"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "74704161939193444D98C815DA8AEB12C6B2"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "FDD27E831B58C249DA69F0C8EC89DBBE8F92",
                        "defaultText": "내 나라라면... 파일럼인가? 아마도?"
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "15D282DC71CA3440531AEDA373E8622EB2C1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "D471FC337197E846907831367D22CADC00D7"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "11FD9FC71A1EB1470B38F2E169EBA07850B0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CC07D01367BB924F0549B364083BE5F66F43",
                        "defaultText": "대모 소라야의 축복을 받은 순결한 나라라 불리지...\n전부 추악한 거짓말이다!"
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "EF8319D95713124AA24B7A54A9C2B009EA32",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "1C0807EA42B2784A30498935B576D2C572AF"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "CF33D6438D70E4445E4967443B4C3F3EABC8",
                        "defaultText": "사제와 여사제들에게 둘러싸여\n내 가장 어두운 나날을 보냈다.\n빛을 아는 자일수록 어둠도 사랑하기 쉬운 법이지."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "D7E2F9D10033C1417B5BDB15E008BE54B4ED",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "788E6CCD7CAF3642F42A48D971AB20505C4F"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "8AA3C11E9CC526429F6A4F554D53A13D261C"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "C8A9FCF82A7E234EA069C7F6241E9FA0F96B",
                        "defaultText": "그건... 안타까운 일이네.\n그런 일을 겪었다니 유감이야--"
                    },
                    "position": 0,
                    "characterId": 0,
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "2C11406F8922C64D5D18A3269927DB42AA56",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "9191F64C83CFB843AA296B30212DB73A16DC"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                            0,
                            0,
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "0947E4841D2521434B6A6B17FD3C214165E7"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "388248156EDF114F176A4CF1ECF166437109",
                        "defaultText": "날 내버려 둬. 너와 친해질 생각은 없다.\n리아 공주에게 빚을 졌기 때문에 여기 있을 뿐이다."
                    },
                    "position": 0,
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "5394CCE34C55A840D47B90F0DA9529153C6A",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "56EF9F71213B344D2818B57745FC584F7B78"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "EE3A196D07DBC640A57BF5045B97009CEC32"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 24
                },
                "indent": 0,
                "uid": "DACA5A1448DED446543A2A2310513373E99C"
            },
            {
                "id": "vn.L2DExitScene",
                "params": {
                    "characterId": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "duration": 30,
                    "waitForCompletion": 1,
                    "easing": {
                        "type": 1,
                        "inOut": 0
                    },
                    "animation": {
                        "type": 1,
                        "movement": 0,
                        "mask": {
                            "graphic": null,
                            "vague": 30
                        }
                    },
                    "fieldFlags": {
                        "duration": 0
                    }
                },
                "indent": 0,
                "uid": "56EE76CB80240544EA8BD318C3FF26E7CF86"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Visual Novel",
                        "name": "Horse_neigh.ogg",
                        "volume": "80",
                        "playbackRate": "120"
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 0,
                        "sound.playbackRate": 0
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "1CCD19B484FC9842FB29F31744C037F03620"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 90
                },
                "indent": 0,
                "uid": "53140ED7753F0847EA49E9B462D2A0090AE8"
            },
            {
                "id": "gs.ShakeScreen",
                "params": {
                    "duration": 12,
                    "waitForCompletion": 0,
                    "range": {
                        "y": 20,
                        "x": 5
                    },
                    "speed": 180,
                    "easing": {
                        "type": 0,
                        "inOut": 1
                    }
                },
                "indent": 0,
                "uid": "0F29CF83722AA74163195D034FEA3BA58B14"
            },
            {
                "id": "gs.PlaySound",
                "params": {
                    "sound": {
                        "folderPath": "Audio/Sounds/Map",
                        "name": "Wing_Slap.ogg",
                        "volume": 100,
                        "playbackRate": 100
                    },
                    "musicEffect": 0,
                    "loop": 0,
                    "waitForCompletion": 0,
                    "fieldFlags": {
                        "sound.volume": 1,
                        "sound.playbackRate": 1
                    },
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "AE7A861478517446398B05B7BAF57A1A98F1"
            },
            {
                "id": "gs.WaitCommand",
                "params": {
                    "time": 108
                },
                "indent": 0,
                "uid": "FF1AD2FE867BD74673482561FDAC615862EF"
            },
            {
                "id": "gs.Comment",
                "params": {
                    "text": "he goes away. pegasus sound"
                },
                "indent": 0,
                "uid": "866729300C0E974EB9485072DA48AB4E68A1",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "567EC37E492AE942BF8A0378AEF199F68AE2",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "AA10BF4B7F3DF247BD49220475BF797C403E"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "AD0416D52F4A0640C6583CB262CF720CBC4C",
                    "parameters": {
                        "values": [
                            "BA77A09EK7F14A4C2BSA11BE8CC099F00810",
                            0,
                            0,
                            1,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "E852082C0C248248F36B2629BAA6E79FCFA6"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "61D51D46680D624CC90BB3C706C3F88146F6",
                        "defaultText": "좋아, 잘 풀리지 않았네.\n하지만 저 말이 사실이라면..."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "BF4283678F55774FEA4BE8C90AA6C2347598",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "3D43B8B78E12A34BF5591BA7EF0A5E1424D0"
            },
            {
                "id": "gs.ShowMessage",
                "params": {
                    "waitForCompletion": 1,
                    "duration": 15,
                    "expressionId": null,
                    "custom": {
                        "object": {
                            "x": 0,
                            "y": 0,
                            "size": {
                                "width": 300,
                                "height": 100
                            }
                        }
                    },
                    "message": {
                        "lcId": "AC9A62A21D7CE3492D288040F8449A8EA2BC",
                        "defaultText": "파일럼에도 숨겨진 추문이 몇 가지 있을지 몰라."
                    },
                    "position": 0,
                    "characterId": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "partial": 0,
                    "fieldFlags": {
                        "duration": 1
                    },
                    "expressions": [],
                    "animations": []
                },
                "indent": 0,
                "uid": "06FAC72B4FCFA147515BB2464A63BE5EEF70",
                "expanded": true
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "449506621B3B23429E19FE40D92EFA6DA899",
                    "parameters": {
                        "values": [
                            1
                        ]
                    }
                },
                "indent": 0,
                "uid": "5E77E53A352AF14DCF59C975901BCC27B232"
            },
            {
                "id": "gs.CallCommonEvent",
                "params": {
                    "commonEventId": "3470CD9A332CB748BE68F8814BFC7A0D9580",
                    "parameters": {
                        "values": [
                            0,
                            0
                        ]
                    }
                },
                "indent": 0,
                "uid": "13AD95854AEE55480F1B687908112212C90F"
            },
            {
                "id": "gs.ChangeBooleanVariables",
                "params": {
                    "target": 0,
                    "targetReferenceDomain": "com.degica.vnm.default",
                    "targetReference": {
                        "index": 0,
                        "scope": 1,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetVariable": {
                        "name": "Schwarz talk about evil Pylum c8-08e",
                        "index": 190,
                        "scope": 1,
                        "changed": true,
                        "domain": "com.degica.vnm.default"
                    },
                    "targetRangeScope": 0,
                    "rangeStart": 0,
                    "rangeEnd": 0,
                    "value": 1,
                    "previewBackground": {
                        "name": "$live_preview_snapshot"
                    }
                },
                "indent": 0,
                "uid": "9DDDEC2A8E9C484CB35A1AA34AC94D86E15C"
            }
        ],
        "localizableStrings": {
            "115FAD855CD82641C318BFE2BB33ED4FB216": {
                "t": "Who's disturbing my rest?",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "16452DBC213B644A7C4819C16B62E524936F"
                }
            },
            "2970233C46F6714AF86881112CFF9A9F0635": {
                "t": "Nice to meet you, uh... Schwarz, right? I think Rya talked to me about you.",
                "d": {
                    "cid": 0,
                    "eid": "2736D9415985234FDB78A077DF4296272B21"
                }
            },
            "B96DA6198E44A54E2D5BAF30F7B8017F2B0F": {
                "t": "Tch. I have no business with you, Captain.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "6AFC91E31E6E434EA06B0859D669E365D99D"
                }
            },
            "137266D68C3A044D4449ABC1BD7959454D7E": {
                "t": "Wait! There's something I want to ask!",
                "d": {
                    "cid": 0,
                    "eid": "8B8A3BB4663F08460049A527F7DF7F536AA3"
                }
            },
            "B72F98EF58D94242F898B2C8010B521EBCEE": {
                "t": "Argh, what a bother. What do you want?",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "D3D62EF0380F9349C24A4B67A8C5F11D1538"
                }
            },
            "0B92B4F31AF917489E487C78036219AE06AD": {
                "t": "Did you just call me \"Captain\"?",
                "d": {
                    "eid": "1BBC4B8A0D1F174745496E17852A163096F2"
                }
            },
            "517CCE4B5858D34B49789B3587968F831E92": {
                "t": "Do you have unfinished business with me?",
                "d": {
                    "eid": "5AA9A538284D8646F96A555426D81C27B554"
                }
            },
            "2AD8924800C33447FA1B1F627C48DC775ABE": {
                "t": "Well, yes. Isn't it obvious?",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "B2EF211C52BAC5440A8B2C413AB8CDA68B0F"
                }
            },
            "E54B36566623624D2E0A9B7396654005B993": {
                "t": "Huh? What kind of stupid question is that? We've never met before.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "329F5E27238FC84F3E4889A912AC6F7FFC33"
                }
            },
            "DB17830E5137E644B90834A8EC79946ED3D9": {
                "t": "Alright. I suppose he doesn't know 'past me'. So how did he...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "12A2FD7B3A1A224A6B7949A55EC08244A48B"
                }
            },
            "1265365135EBD64D8D2AEB2573546FBF7D6E": {
                "t": "Your sword. It has a Manadrop attached to it. I would never forget the swords of those who sent me to prison.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "CDE5F57251BA494A302AE207D733802B8BBD"
                }
            },
            "ADCF9F1710453642A70BBD44FD6F56827379": {
                "t": "So you were captured by the Holy Knights in the past?",
                "d": {
                    "cid": 0,
                    "eid": "8F6813100A0A764CC79B9A94ED917233BE0F"
                }
            },
            "8C066372852C23450B28C1490EA5C8E2DAED": {
                "t": "It's a long, old story and I have zero interest in telling you about it.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "6AB2BA6F9320D346522A95532E8F57088555"
                }
            },
            "3B9C04FF6A9B55457218FDF8B804C6642F3F": {
                "t": "Talk about being elusive!\nMaybe I should taunt him...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "4764F6EC3ADAF54DC72AE893B2CFF95A4689"
                }
            },
            "CD526E579850A84FA57B7A42ED248B9FD4BA": {
                "t": "I've never heard of you despite being in the knights. You must be some small fry, huh?",
                "d": {
                    "cid": 0,
                    "eid": "E630724174CB974C91387A81B61196177FE9"
                }
            },
            "02ADBE8653D16443DB989445F092CE7B75EF": {
                "t": "How dare you! You don't even know what kinds of horrors I've witnessed in your accursed country!",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "28CBB4613E6C854A0D496D286F9E7AE30552"
                }
            },
            "FDD27E831B58C249DA69F0C8EC89DBBE8F92": {
                "t": "In my country... so, Pylum? I guess?",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "15D282DC71CA3440531AEDA373E8622EB2C1"
                }
            },
            "CC07D01367BB924F0549B364083BE5F66F43": {
                "t": "The so-called pure nation, blessed by Soraya the Matriarch... what filthy lies!",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "EF8319D95713124AA24B7A54A9C2B009EA32"
                }
            },
            "CF33D6438D70E4445E4967443B4C3F3EABC8": {
                "t": "I lived my darkest days surrounded by priests and priestesses. Those who know the light are also more likely to love the darkness.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "D7E2F9D10033C1417B5BDB15E008BE54B4ED"
                }
            },
            "C8A9FCF82A7E234EA069C7F6241E9FA0F96B": {
                "t": "That's... uh, unfortunate. I'm sorry that you went through such circumstances--",
                "d": {
                    "cid": 0,
                    "eid": "2C11406F8922C64D5D18A3269927DB42AA56"
                }
            },
            "388248156EDF114F176A4CF1ECF166437109": {
                "t": "Leave me alone. I have no intention of making friends with you. I'm only here because I owe a debt to Princess Rya.",
                "d": {
                    "cid": "8ECCF0DA7214924BDA0A8EF82FA2B64500E4",
                    "eid": "5394CCE34C55A840D47B90F0DA9529153C6A"
                }
            },
            "61D51D46680D624CC90BB3C706C3F88146F6": {
                "t": "Okay, that didn't go well. But if what he said is true, then...",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "BF4283678F55774FEA4BE8C90AA6C2347598"
                }
            },
            "AC9A62A21D7CE3492D288040F8449A8EA2BC": {
                "t": "Pylum may have a few skeletons in its closet as well.",
                "d": {
                    "cid": "D373AC0C074F444A7C09C3E68721C5FFEC7F",
                    "eid": "06FAC72B4FCFA147515BB2464A63BE5EEF70"
                }
            }
        },
        "stringVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "numberVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ],
        "booleanVariables": [
            {
                "name": "",
                "index": 0,
                "scope": 0
            }
        ]
    },
    "summary": [
        "name",
        "type",
        "parentId",
        "chapterUid",
        "order"
    ],
    "externalItems": []
}